<?php
// public_html/api/nai_memory.php
// NagalandAI Memory System v2.0
// - Stores personal context for paid subscribers
// - Admin can grant memory to any user (school parents)
// - Auto-extracts parent codes for school attendance queries
// Memories stored in WordPress user meta as JSON array.

if (!defined('ABSPATH') && !defined('NAI_LOADED')) {
  exit;
}

/* =========================================================
   PLAN MEMORY LIMITS
   Admin override: If user has 'nai_memory_slots' meta > 0,
   that value is used instead of the plan limit.
   This lets Aloto grant memory to school parents for free.
   
   HOW TO GRANT MEMORY TO A PARENT (from WordPress admin):
   Go to Users > click user > scroll to 'nai_memory_slots'
   Set it to 10 (or any number). Save. Done.
   Or use WPCode snippet: nai_grant_memory_slots(USER_ID, 10);
   ========================================================= */
function nai_memory_limit($plan, $user_id = 0) {
  // Check admin override first (for school parents etc.)
  if ($user_id > 0 && function_exists('get_user_meta')) {
    $override = (int) get_user_meta($user_id, 'nai_memory_slots', true);
    if ($override > 0) {
      return $override;
    }
  }

  $limits = [
    'guest'      => 0,
    'explore'    => 1,
    'pro'        => 5,
    'promax'     => 20,
    'promaxplus' => 50,
    'school'     => 10,
  ];
  return $limits[$plan] ?? 0;
}

/* =========================================================
   GET ALL MEMORIES FOR A USER
   ========================================================= */
function nai_get_memories($user_id) {
  if (!$user_id || !function_exists('get_user_meta')) return [];

  $raw = get_user_meta($user_id, 'nai_memories', true);
  if (!$raw || !is_array($raw)) return [];

  $clean = [];
  foreach ($raw as $mem) {
    if (!is_array($mem) || empty($mem['text'])) continue;
    $clean[] = [
      'id'      => $mem['id'] ?? uniqid('mem_'),
      'text'    => trim((string)$mem['text']),
      'created' => $mem['created'] ?? time(),
    ];
  }
  return $clean;
}

/* =========================================================
   ADD A MEMORY
   ========================================================= */
function nai_add_memory($user_id, $plan, $text) {
  if (!$user_id || !function_exists('update_user_meta')) {
    return ['success' => false, 'message' => 'You must be logged in to save memories.'];
  }

  $limit = nai_memory_limit($plan, $user_id);
  if ($limit <= 0) {
    return ['success' => false, 'message' => 'Memory is available for Pro, ProMax, ProMax+ subscribers, and registered school parents. Please upgrade your plan or contact your school.'];
  }

  $text = trim((string)$text);
  if ($text === '') {
    return ['success' => false, 'message' => 'Empty memory cannot be saved.'];
  }

  if (mb_strlen($text) > 500) {
    $text = mb_substr($text, 0, 500);
  }

  $memories = nai_get_memories($user_id);

  foreach ($memories as $mem) {
    if (strtolower($mem['text']) === strtolower($text)) {
      return ['success' => false, 'message' => 'I already remember that!'];
    }
  }

  if (count($memories) >= $limit) {
    return ['success' => false, 'message' => 'You have reached your memory limit (' . $limit . ' memories). Delete an old memory first or upgrade your plan.'];
  }

  $memories[] = [
    'id'      => uniqid('mem_'),
    'text'    => $text,
    'created' => time(),
  ];

  update_user_meta($user_id, 'nai_memories', $memories);
  return ['success' => true, 'message' => 'Memory saved! I will remember this in all our future conversations.'];
}

/* =========================================================
   DELETE A SPECIFIC MEMORY BY ID
   ========================================================= */
function nai_delete_memory($user_id, $memory_id) {
  if (!$user_id || !function_exists('update_user_meta')) {
    return ['success' => false, 'message' => 'You must be logged in.'];
  }

  $memories = nai_get_memories($user_id);
  $found = false;
  $updated = [];

  foreach ($memories as $mem) {
    if ($mem['id'] === $memory_id) { $found = true; continue; }
    $updated[] = $mem;
  }

  if (!$found) return ['success' => false, 'message' => 'Memory not found.'];

  update_user_meta($user_id, 'nai_memories', $updated);
  return ['success' => true, 'message' => 'Memory deleted.'];
}

/* =========================================================
   EDIT A SPECIFIC MEMORY BY ID
   ========================================================= */
function nai_edit_memory($user_id, $memory_id, $new_text) {
  if (!$user_id || !function_exists('update_user_meta')) {
    return ['success' => false, 'message' => 'You must be logged in.'];
  }

  $new_text = trim((string)$new_text);
  if ($new_text === '') {
    return ['success' => false, 'message' => 'Memory text cannot be empty.'];
  }

  if (mb_strlen($new_text) > 500) {
    $new_text = mb_substr($new_text, 0, 500);
  }

  $memories = nai_get_memories($user_id);
  $found = false;

  foreach ($memories as &$mem) {
    if ($mem['id'] === $memory_id) {
      $mem['text'] = $new_text;
      $found = true;
      break;
    }
  }
  unset($mem);

  if (!$found) return ['success' => false, 'message' => 'Memory not found.'];

  update_user_meta($user_id, 'nai_memories', $memories);
  return ['success' => true, 'message' => 'Memory updated.'];
}

/* =========================================================
   CLEAR ALL MEMORIES
   ========================================================= */
function nai_clear_memories($user_id) {
  if (!$user_id || !function_exists('update_user_meta')) {
    return ['success' => false, 'message' => 'You must be logged in.'];
  }

  update_user_meta($user_id, 'nai_memories', []);
  return ['success' => true, 'message' => 'All memories cleared.'];
}

/* =========================================================
   DETECT MEMORY COMMANDS IN USER MESSAGE
   ========================================================= */
function nai_detect_memory_command($message) {
  $msg = strtolower(trim($message));

  // SAVE patterns
  $savePatterns = [
    '/^(?:please\s+)?remember\s+(?:that\s+)?(.+)/i',
    '/^(?:please\s+)?save\s+(?:this|that)?\s*:?\s*(.+)/i',
    '/^(?:please\s+)?note\s+(?:that\s+)?(.+)/i',
    '/^(?:please\s+)?keep\s+in\s+mind\s+(?:that\s+)?(.+)/i',
    '/^(?:please\s+)?don\'?t\s+forget\s+(?:that\s+)?(.+)/i',
  ];
  foreach ($savePatterns as $pattern) {
    if (preg_match($pattern, $message, $matches)) {
      $content = trim($matches[1]);
      $content = rtrim($content, '.!');
      if (mb_strlen($content) >= 3) return ['type' => 'save', 'content' => $content];
    }
  }

  // LIST
  $listPatterns = ['what do you remember','what do you know about me','show my memories','show memories','list my memories','list memories','my memories','what have i told you'];
  foreach ($listPatterns as $p) { if (strpos($msg, $p) !== false) return ['type' => 'list', 'content' => '']; }

  // CLEAR
  $clearPatterns = ['forget everything','clear all memories','clear my memories','delete all memories','forget about me','erase my memories','reset my memories'];
  foreach ($clearPatterns as $p) { if (strpos($msg, $p) !== false) return ['type' => 'clear', 'content' => '']; }

  return null;
}

/* =========================================================
   EXTRACT PARENT CODES FROM MEMORIES
   Scans memories for 6-digit parent codes + child names.
   Returns array of [name, code] pairs.
   
   Examples it catches:
   "my child is Anya, code 483921"
   "my son Kevi parent code 291034"
   "daughter Azeno 582910"
   "Anya code 483921"
   "children: Anya 483921, Kevi 291034"
   ========================================================= */
function nai_extract_parent_codes($memories) {
  $children = [];

  foreach ($memories as $mem) {
    $text = $mem['text'];

    // Pattern 1: child/son/daughter + name + code
    if (preg_match('/(?:child|son|daughter|kid)\s+(?:is\s+)?([A-Za-z\s]+?)[\s,;:\-]+(?:code|number|parent\s*code|id)?\s*(\d{6})/i', $text, $m)) {
      $children[] = ['name' => trim($m[1]), 'code' => $m[2]];
      continue;
    }

    // Pattern 2: code then name
    if (preg_match('/(?:code|number|parent\s*code)\s*(\d{6})[\s,;:\-]+(?:for\s+)?([A-Za-z\s]+)/i', $text, $m)) {
      $children[] = ['name' => trim($m[2]), 'code' => $m[1]];
      continue;
    }

    // Pattern 3: name + 6 digits anywhere
    if (preg_match('/([A-Za-z]{2,})\s+(\d{6})/i', $text, $m)) {
      $children[] = ['name' => trim($m[1]), 'code' => $m[2]];
      continue;
    }
    if (preg_match('/(\d{6})\s+([A-Za-z]{2,})/i', $text, $m)) {
      $children[] = ['name' => trim($m[2]), 'code' => $m[1]];
      continue;
    }
  }

  return $children;
}

/* =========================================================
   BUILD MEMORY CONTEXT FOR SYSTEM PROMPT
   Special handling for school parents with children codes.
   ========================================================= */
function nai_build_memory_context($memories) {
  if (empty($memories)) return '';

  $lines = [];
  foreach ($memories as $mem) {
    $lines[] = '- ' . $mem['text'];
  }

  $context  = "\n\nUSER MEMORY (personal facts the user asked you to remember):\n";
  $context .= implode("\n", $lines);
  $context .= "\n\nUse these memories naturally when relevant. Do not list them unless asked.";

  // Check for parent codes
  $children = nai_extract_parent_codes($memories);
  if (!empty($children)) {
    $context .= "\n\nSCHOOL PARENT: This user is a parent. Their children:\n";
    foreach ($children as $child) {
      $context .= '- ' . $child['name'] . ' (parent code: ' . $child['code'] . ")\n";
    }
    $context .= "When they ask about attendance, automatically use these codes to look up data. ";
    $context .= "Do NOT ask for the code again - you already have it from their saved memories. ";
    $context .= "If they say 'my child' and have one child, use that child. ";
    $context .= "If they have multiple children, ask which one unless the name is mentioned.";
  }

  return $context;
}

/* =========================================================
   ADMIN HELPERS
   
   Grant memory to a specific user:
     nai_grant_memory_slots(42, 10);
   
   Revoke memory:
     nai_grant_memory_slots(42, 0);
   
   From WPCode snippet or functions.php.
   ========================================================= */
function nai_grant_memory_slots($user_id, $slots = 10) {
  if (!$user_id || !function_exists('update_user_meta')) return false;
  update_user_meta($user_id, 'nai_memory_slots', (int)$slots);
  return true;
}