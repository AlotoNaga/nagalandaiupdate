<?php
/**
 * ═══════════════════════════════════════════════════════════
 * NAGALAND AI — CHAT MODE (nai_chat.php) v1.2
 * Default AI assistant: News, Weather, Scholarships, Ecosystem
 *
 * v1.2 (Jul 2026): Added a voice/speaking detector so questions like
 * "do you have voice" load the features knowledge. Without it the AI
 * never saw that voice exists and wrongly denied having it.
 *
 * v1.1 (Jul 2026): Pricing intent detector now catches word forms
 * like "prices", "costs", "upgrading". Added Noklak and Meluri to
 * Nagaland topic detection (17 districts). Fixed rule 11 so it no
 * longer contradicts the pricing knowledge base.
 * ═══════════════════════════════════════════════════════════
 *
 * Included by chat.php when mode === 'chat' (default).
 * Builds the $messages array with the main system prompt,
 * news context, weather data, scholarship data, and ecosystem data.
 *
 * EXPECTED VARIABLES FROM chat.php:
 *   $message, $apiKey, $naiSources, $rssCacheFile, $planName
 *   From nai_ecosystem.php (if loaded):
 *     $isDictionaryQuery, $isProfileQuery
 *     $naiDictionaryContext, $naiProfilesContext, $naiEcosystemAwareness
 * ═══════════════════════════════════════════════════════════
 */

/* =========================================================
   LOAD KNOWLEDGE BASE (for self-awareness queries)
   ========================================================= */
if (file_exists(__DIR__ . '/nai_knowledge.php')) {
  require_once __DIR__ . '/nai_knowledge.php';
}

/* =========================================================
   INTENT DETECTORS
   ========================================================= */

// ─── SELF-KNOWLEDGE / PRICING / PLANS ───
$isSelfPricingQuery = (bool)preg_match('/\b(free|pricing|prices?|costs?|how\s+much|subscriptions?|subscribe|plans?|upgrades?|upgrading|paid|payments?|pay|charges?|fees?|monthly|yearly|annual|affordable|expensive|cheap|budget|worth|value|₹|rupees?|inr)\b/i', $message);
$isSelfIdentityQuery = (bool)preg_match('/\b(who\s+are\s+you|what\s+are\s+you|are\s+you\s+free|are\s+you\s+paid|what\s+can\s+you\s+do|what\s+do\s+you\s+do|your\s+features|your\s+capabilities|how\s+do\s+you\s+work|tell\s+me\s+about\s+yourself|about\s+nagaland\s+ai|introduce\s+yourself|what\s+is\s+nagaland\s+ai)\b/i', $message);
$isSchoolProductQuery = (bool)preg_match('/\b(school\s+attendance|school\s+system|school\s+plan|school\s+pricing|school\s+subscription|nagaland\s+ai\s+schools|attendance\s+system|school\s+app|school\s+software|parent\s+code|parent\s+query|digital\s+attendance|teacher\s+attendance)\b/i', $message);
$isComparisonQuery = (bool)preg_match('/\b(better\s+than|compared\s+to|vs|versus|chatgpt|openai|gemini|google\s+ai|other\s+ai|different\s+from|why\s+should\s+i|why\s+use|competitor|alternative)\b/i', $message);

// Voice / speaking questions. These do NOT match the identity patterns
// above ("do you have voice" contains none of those phrases), so without
// this the AI never sees that voice exists and denies having it.
$isVoiceQuery = (bool)preg_match(
  '/\b(voice|voices|spoken|speaking|microphone|mic|pronounce|pronunciation|audio|out\s+loud)\b/i',
  $message
) || (bool)preg_match(
  '/\b(can|could|do|does|are)\s+(you|u)\s+(speak|talk|listen|hear|say)\b/i',
  $message
) || (bool)preg_match(
  '/\btalk\s+(to|with)\s+(you|me)\b/i',
  $message
);

// Determine which knowledge topics to load (can be multiple)
$knowledgeTopics = [];
if ($isSelfPricingQuery || $isComparisonQuery) {
  $knowledgeTopics[] = 'pricing';
}
if ($isSchoolProductQuery) {
  $knowledgeTopics[] = 'schools';
}
if ($isSelfIdentityQuery || $isVoiceQuery) {
  $knowledgeTopics[] = 'features';
  if (empty($knowledgeTopics) || !in_array('pricing', $knowledgeTopics)) {
    $knowledgeTopics[] = 'pricing'; // Identity questions often lead to "are you free?"
  }
}

$naiKnowledgeContext = '';
if (!empty($knowledgeTopics) && function_exists('nai_get_knowledge')) {
  $naiKnowledgeContext = nai_get_knowledge(implode(',', array_unique($knowledgeTopics)));
}

// ─── NEWS ───
$isNewsQuery = (bool)preg_match('/\b(news|latest|update|updates|today|breaking|headline|headlines|recent|current|share|inform|what\'?s\s+happening|what\s+is\s+going\s+on|what\'?s\s+new|what\'?s\s+going\s+on|kya\s+hua|kya\s+ho\s+raha|any\s+news|tell\s+me\s+news|show\s+me\s+news|give\s+me\s+news|news\s+de|trending|viral|khabar|samachar|report|incident|event|events|happening|happened|announcement|announced|press\s+release|media)\b/i', $message);

// ─── NAGALAND SCOPE ───
$isNagalandTopic = (bool)preg_match('/\b(nagaland|naga|nagas|kohima|dimapur|mokokchung|tuensang|mon|wokha|zunheboto|phek|kiphire|longleng|peren|tseminyu|chumoukedima|niuland|shamator|noklak|meluri|dipr|nsdma|nagaland\s+government|state\s+government|district\s+administration|nbse|npsc|naga\s+tribe|ao\s+naga|angami|sema|lotha|chakhesang|rengma|sangtam|konyak|chang|phom|khiamniungan|pochury|zeliang|yimchunger|dimasa|nscn|ndpp|npf|acaut|ensf|rio|neiphiu|eastern\s+nagaland|western\s+nagaland|hornbill|sekrenyi|moatsu|tuluni)\b/i', $message);

$isNagalandNewsDefault = ($isNewsQuery && !$isNagalandTopic);

// ─── LIST vs DEEP DIVE ───
$isListRequest = (bool)preg_match('/\b(top\s*\d+|top\s*five|top\s*5|five\s+news|list|headlines|all\s+news|show\s+me\s+news|give\s+me\s+news|tell\s+me\s+news|summary|roundup|round\s*up|brief|briefs|overview)\b/i', $message);
$isExplainRequest = (bool)preg_match('/\b(tell\s+me\s+more|explain|full\s+details|in\s+detail|detailed|what\s+happened|why\s+did|how\s+did|more\s+about|breakdown|break\s+down|elaborate|deep\s+dive|full\s+story|complete\s+story|full\s+report|analysis|analyze|discuss)\b/i', $message);

$newsMode = 'LIST';
if ($isListRequest) $newsMode = 'LIST';
elseif ($isExplainRequest) $newsMode = 'DEEP_DIVE';

$forceFreshNews = (bool)preg_match('/\b(latest|breaking|now|right\s+now|today|just\s+now|current|abhi|aaj)\b/i', $message);

// ─── SCHOLARSHIP ───
$hasScholarshipWord = (bool)preg_match('/\bscholarship\b/i', $message);
$isScholarshipWritingRequest = $hasScholarshipWord && (bool)preg_match('/\b(scholarship\s+essay|essay\s+for\s+scholarship|scholarship\s+letter|recommendation\s+letter|sop|statement\s+of\s+purpose|personal\s+statement)\b/i', $message);

$scholarshipSignals = [
  '/\b(release|released|releasing|open|opening|start|starting|deadline|last\s+date|closing|close|extended|extension|update|notification|notice|announced|announce|timeline)\b/i',
  '/\b(apply|application|portal|register|registration|login|form|submit|renewal|verify|verification)\b/i',
  '/\b(eligibility|eligible|criteria|who\s+can|documents|document|required|income|certificate|st\s+students|post\s+matric|merit|research)\b/i',
  '/\b(payment|paid|credit|credited|disbursement|pending|rejected|status|beneficiary|amount)\b/i',
  '/\b(post\s+matric|state\s+merit|state\s+research|nec|ishan\s+uday|ugc|nsp|national\s+scholarship\s+portal)\b/i',
];

$isScholarshipIntent = false;
if ($hasScholarshipWord && !$isScholarshipWritingRequest) {
  foreach ($scholarshipSignals as $rx) {
    if (preg_match($rx, $message)) { $isScholarshipIntent = true; break; }
  }
}
$isScholarshipInfoMode = ($hasScholarshipWord && $isScholarshipIntent && !$isScholarshipWritingRequest);
$isScholarshipSoftMention = ($hasScholarshipWord && !$isScholarshipInfoMode);

// ─── ALOTO BIO ───
$isAiIdentityQuestion = (bool)preg_match('/\b(who\s+created\s+you|who\s+made\s+you|who\s+owns\s+you|who\s+are\s+you|are\s+you\s+chatgpt|are\s+you\s+openai|who\s+developed\s+you)\b/i', $message);
$isAlotoQuery = !$isAiIdentityQuestion && (bool)preg_match('/\b(aloto|aloto\s+naga|who\s+is\s+aloto|about\s+aloto|editor\s+of\s+nagaland\s+news\s+today|founder\s+of\s+nagaland\s+news\s+today|owner\s+of\s+nagaland\s+ai|owner\s+of\s+nagaland\s+news\s+today)\b/i', $message);

$alotoProfileUrl = 'https://nagalandnewstoday.com/about-the-author/';
$naiAlotoContext = '';

if ($isAlotoQuery) {
  $bioText = nai_get_page_text_cached('about_aloto', $alotoProfileUrl, 21600, 20000);
  if (mb_strlen($bioText) >= 400) {
    $naiAlotoContext  = "VERIFIED PROFILE SOURCE:\n";
    $naiAlotoContext .= "- Answer about Aloto Naga based ONLY on this text. Paraphrase; do NOT copy.\n";
    $naiAlotoContext .= "- 6–10 short paragraphs, professional, not promotional.\n";
    $naiAlotoContext .= "- End with: Source: {$alotoProfileUrl}\n\n";
    $naiAlotoContext .= "SOURCE_TEXT:\n" . $bioText . "\n";
  } else {
    $naiAlotoContext = "Profile page could not be fetched. Ask user to try again. Source: {$alotoProfileUrl}";
  }
}

// ─── WEATHER ───
$isWeatherQuery = (bool)preg_match('/\b(weather|temperature|temp|forecast|rain|rainfall|humidity|wind|climate)\b/i', $message);
$forceFreshWeather = (bool)preg_match('/\b(now|right\s+now|current)\b/i', $message);

$naiWeatherContext = '';

if ($isWeatherQuery) {
  [$placeMentioned, $lat, $lon] = nai_detect_nagaland_place($message);
  $weatherTtl = $forceFreshWeather ? 0 : 600;

  $overviewPlaces = [
    ['Kohima', 25.6751, 94.1086], ['Dimapur', 25.9117, 93.7277],
    ['Mokokchung', 26.3240, 94.5180], ['Tuensang', 26.2670, 94.8250],
    ['Mon', 26.7330, 95.0560],
  ];

  $weatherRows = [];

  if ($placeMentioned) {
    $w = nai_get_weather_cached($placeMentioned, $lat, $lon, $weatherTtl);
    if (is_array($w)) $weatherRows[] = $w;
  } else {
    foreach ($overviewPlaces as $p) {
      $w = nai_get_weather_cached($p[0], $p[1], $p[2], $weatherTtl);
      if (is_array($w)) $weatherRows[] = $w;
    }
  }

  if (!empty($weatherRows)) {
    $naiWeatherContext .= "LIVE WEATHER DATA:\nUse ONLY this data. Present conversationally.\n\n";
    foreach ($weatherRows as $idx => $w) {
      $n = $idx + 1;
      $naiWeatherContext .= "PLACE {$n}: {$w['place']} | {$w['temperature_c']}°C | {$w['weather_label']} | Humidity: {$w['humidity_pct']}% | Wind: {$w['wind_kmh']} km/h | High: {$w['today_max_c']}°C Low: {$w['today_min_c']}°C | Rain: {$w['today_rain_mm']}mm | Updated: {$w['current_time']}\n";
    }
    if (!$isNagalandTopic && !$placeMentioned) {
      $naiWeatherContext .= "\nNOTE: If you meant weather elsewhere, tell me the city.\n";
    }
  } else {
    $naiWeatherContext = "Weather data unavailable right now. Tell user to try again shortly.";
  }
}

/* =========================================================
   SCHOLARSHIP SOURCES
   ========================================================= */

$scholarshipOfficialSources = [
  ['name' => 'DHE Nagaland – Scholarship Timeline', 'url' => 'https://highereducation.nagaland.gov.in/scholarship-timeline/'],
  ['name' => 'Nagaland – Common Scholarship Portal', 'url' => 'https://scholarship.nagaland.gov.in/'],
  ['name' => 'DHE Nagaland – Scholarship Schemes', 'url' => 'https://highereducation.nagaland.gov.in/scholarship-schemes/'],
];

/* =========================================================
   MAIN SYSTEM PROMPT — CHAT MODE
   ========================================================= */

$systemPrompt = <<<PROMPT
You are Nagaland AI — India's first AI assistant built specifically for Nagaland. Developed and maintained by the Nagaland Me team.

WHAT YOU DO:
You help users with anything — education, Naga tribes, languages, culture, history, governance, scholarships, weather, news (Nagaland, India, world), and general knowledge. You prioritize Nagaland but help with everything.

HOW TO RESPOND:

1. NAGALAND-FIRST: Give priority to Nagaland context when relevant. For general questions (math, science, health, career), answer helpfully — then connect to Nagaland if relevant. You are NOT restricted to Nagaland-only topics.

2. NEWS: When news articles are provided in context, base your response on those articles. Always include source links. NEVER invent or fabricate headlines, facts, dates, or links. If articles are from the last few days (not necessarily today), still share them — recent news is valuable. Do NOT refuse to share articles just because they aren't from today's exact date.

3. WEATHER: When live data is in context, use ONLY that. Never guess.

4. SCHOLARSHIPS: When official data is in context, use ONLY that. Never invent dates/deadlines.

5. IDENTITY & PRICING: If asked who you are, whether you're free, how much you cost, your plans, or anything about yourself — look for the SELF-KNOWLEDGE section in context. Use ONLY that data. Never guess about your own pricing or features. If no self-knowledge section is present, say: "For the latest pricing and plans, visit nagalandai.com/upgrade" and explain that you have a free tier with 20 messages/day for registered users.

6. YOUTUBE/FACEBOOK: Give practical, detailed advice. End with: "For professional support for Nagaland creators, visit https://experts.nagaland.me"

7. ECOSYSTEM: You are connected to Nagaland News Today, Nagaland Profiles, Nagaland Dictionary, Help Nagaland. Only reference when data is provided in context. Never fabricate links.

8. STUDENT MODE: If the user needs deep academic help, suggest: "For detailed step-by-step teaching, switch to Student Mode — it's built specifically for learning."

9. SCHOOL ATTENDANCE SYSTEM: If asked about school attendance, school plans, or parent queries — look for the SCHOOL KNOWLEDGE section in context. Use ONLY that data. If no section is present, direct them to nagalandai.com/nagaland-ai-schools

10. TONE: Warm, knowledgeable, conversational. Accurate. Culturally respectful. Simple, clear language. When discussing your own pricing, be confident and proud of the value you offer — you are genuinely affordable compared to international AI services.

11. AVOID: Don't refuse helpful questions. Don't mention OpenAI/ChatGPT/GPT-4 as your creator. Don't fabricate news/links. Don't give medical/legal/financial advice (suggest professionals). You are free to start using — anyone can chat without an account or payment — but never deny that optional paid plans exist. When pricing data is provided in the SELF-KNOWLEDGE section, follow it exactly.

12. RESPONSE LENGTH: Match your response length to the question. Simple questions get 2-3 sentences. Complex questions get detailed answers with examples. News summaries get proper coverage of each article. Never cut yourself short — finish your thoughts completely.

13. NAGA TRIBAL LANGUAGES — CRITICAL RULE: You do NOT have reliable knowledge of any Naga tribal language. NEVER attempt to translate words, phrases, or sentences into or from Ao, Angami, Sumi, Lotha, Konyak, Chang, Phom, Sangtam, Yimchunger, Khiamniungan, Pochury, Rengma, Zeliang, Chakhesang, Nagamese, Kuki, Rongmei, Tikhir, or Yimkhiung. If a user asks you to translate into any Naga language, asks what a word means in a Naga language, or sends you unfamiliar words that might be from a Naga tribal language — do NOT guess or invent translations. Instead, politely explain that Naga tribal languages require verified human-sourced data that no AI can reliably provide, and redirect them to Nagaland Dictionary (https://nagalanddictionary.com) which has community-verified translations for 18+ Naga languages. You may still discuss Naga languages in general terms (history, origins, language family, number of speakers, etc.) — just never provide specific translations or word meanings.

CURRENT USER PLAN: {$planName}
PROMPT;

/* =========================================================
   BUILD $messages
   ========================================================= */
$messages = [
  ['role' => 'system', 'content' => $systemPrompt]
];

if (!empty($naiSources['extra_prompt'])) {
  $messages[] = ['role' => 'system', 'content' => $naiSources['extra_prompt']];
}

// ─── SELF-KNOWLEDGE (pricing, features, schools) ───
if (!empty($naiKnowledgeContext)) {
  $messages[] = ['role' => 'system', 'content' => "SELF-KNOWLEDGE — USE THIS DATA TO ANSWER ACCURATELY:\n\n" . $naiKnowledgeContext];
}

if (!empty($naiAlotoContext)) {
  $messages[] = ['role' => 'system', 'content' => $naiAlotoContext];
}

if (!empty($naiWeatherContext)) {
  $messages[] = ['role' => 'system', 'content' => $naiWeatherContext];
}

// Ecosystem awareness
if (!empty($naiEcosystemAwareness)) {
  $messages[] = ['role' => 'system', 'content' => $naiEcosystemAwareness];
}
if (!empty($naiDictionaryContext)) {
  $messages[] = ['role' => 'system', 'content' => $naiDictionaryContext];
}
if (!empty($naiProfilesContext)) {
  $messages[] = ['role' => 'system', 'content' => $naiProfilesContext];
}

/* =========================================================
   SCHOLARSHIP CONTEXT
   ========================================================= */

if ($isScholarshipInfoMode) {
  $forceFreshScholarship = (bool)preg_match('/\b(latest|now|right\s+now|today|current)\b/i', $message);
  $schTtl = $forceFreshScholarship ? 0 : 900;

  $schContext  = "NAGALAND SCHOLARSHIP DATA:\n\n";
  $schContext .= "1) Post Matric Scholarship to ST Students — NSP\n";
  $schContext .= "2) State Merit Scholarship — Nagaland Portal\n";
  $schContext .= "3) State Research Scholarship — Nagaland Portal\n";
  $schContext .= "4) NEC Merit Scholarship — NSP\n";
  $schContext .= "5) National Scholarship for PG Studies — NSP\n";
  $schContext .= "6) Ishan Uday Special Scholarship (NER) — NSP\n\n";
  $schContext .= nai_get_scholarship_sources_text($scholarshipOfficialSources, $schTtl, 14000);

  $messages[] = ['role' => 'system', 'content' => $schContext];
  $messages[] = ['role' => 'system', 'content' =>
    "Answer scholarship questions based ONLY on official data above. If dates/status not shown, say it hasn't been announced. End with Sources section."
  ];
} elseif ($isScholarshipSoftMention) {
  $messages[] = ['role' => 'system', 'content' =>
    "User mentioned 'scholarship' but their main question is different. Answer their question fully, then add: 'Would you also like an update on Nagaland scholarships?'"
  ];
}

/* =========================================================
   NEWS CONTEXT (SPEED OPTIMIZED)
   ========================================================= */

if ($isNewsQuery && ($isNagalandTopic || $isNagalandNewsDefault)) {
  $rssTtl = $forceFreshNews ? 0 : 300;
  $rssItems = nai_get_rss_items_cached($naiSources['rss_sources'] ?? [], $rssCacheFile, $rssTtl, 18);

  $preferredSources = ['Nagaland Post','Morung Express','Nagaland News Today','Help Nagaland','DIPR Nagaland','Nagaland Tribune','EastMojo','All India Radio','Department of School Education'];

  usort($rssItems, function($a, $b) use ($preferredSources) {
    $ai = array_search($a['source'] ?? '', $preferredSources, true);
    $bi = array_search($b['source'] ?? '', $preferredSources, true);
    return (($ai === false) ? 9999 : $ai) <=> (($bi === false) ? 9999 : $bi);
  });

  $articleTtl = 21600;
  $maxAttach = ($newsMode === 'LIST') ? 5 : 1;
  $maxChars = ($newsMode === 'LIST') ? 4000 : 12000;
  $attached = 0;

  $context = "NEWS ARTICLES FROM RSS FEEDS:\nShare these articles with the user. Always include source links. NEVER invent or make up any news — only use what is listed below.\n\n";

  foreach ($rssItems as $it) {
    if ($attached >= $maxAttach) break;
    $title = trim((string)($it['title'] ?? ''));
    $url = trim((string)($it['url'] ?? ''));
    if (!$title || !$url) continue;

    $n = $attached + 1;
    $context .= "ARTICLE {$n}: {$title}\nSOURCE: " . ($it['source'] ?? '') . "\n";
    if (!empty($it['published'])) $context .= "PUBLISHED: {$it['published']}\n";
    $context .= "LINK: {$url}\n";

    if ($newsMode === 'DEEP_DIVE') {
      $text = nai_get_article_text_cached($url, $articleTtl, $maxChars);
      if (mb_strlen($text) >= 400) {
        $context .= "TEXT: {$text}\n\n";
      } else {
        $context .= "SUMMARY: " . ($it['summary'] ?? 'Headline only.') . "\n\n";
      }
    } else {
      $context .= "SUMMARY: " . ($it['summary'] ?? 'Headline only.') . "\n\n";
    }
    $attached++;
  }

  if ($attached > 0) {
    $messages[] = ['role' => 'system', 'content' => $context];
    if ($newsMode === 'LIST') {
      $messages[] = ['role' => 'system', 'content' => "Present all {$attached} articles as numbered summaries (2-4 lines each) with source links. Nagaland sources first, then India, then World. These are recent articles from our news feeds — share them confidently even if they are a day or two old."];
    } else {
      $messages[] = ['role' => 'system', 'content' => "Deep dive ARTICLE 1 only. Sections: What Happened, Key Details, Background, Who's Involved, Why It Matters, What's Next. End with Source link."];
    }
  } else {
    $messages[] = ['role' => 'system', 'content' => "Our news feeds returned no articles right now. This is a temporary issue. Tell the user: 'Our news sources are being refreshed right now. In the meantime, you can check the latest Nagaland news directly at Nagaland News Today: https://nagalandnewstoday.com or visit our blog at https://nagalandai.com/blogs/ for recent updates.' Do NOT invent or fabricate any news headlines or stories."];
  }
}