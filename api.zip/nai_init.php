<?php
// public_html/api/nai_init.php
// Generates a server-side session token for chat requests.
// The frontend calls this on page load. chat.php verifies the token.
// Rate limited: 1 token per IP per 2 minutes.

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// CORS
$allowedOrigins = [
  'https://nagalandai.com',
  'https://www.nagalandai.com',
];
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($origin, $allowedOrigins, true)) {
  header("Access-Control-Allow-Origin: $origin");
  header('Access-Control-Allow-Methods: GET, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type');
}
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// Block non-browser requests
$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
if (strlen($ua) < 30 || preg_match('/^(curl|wget|python|httpie|postman|insomnia|go-http|java|perl|ruby|php|node|axios)/i', $ua)) {
  http_response_code(403);
  echo json_encode(['error' => 'Access denied.']);
  exit;
}

$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$now = time();

// Rate limit: 1 new token per IP per 2 minutes
// If a valid recent token exists, return that instead
$rateFile = sys_get_temp_dir() . '/nai_tinit_' . md5('tinit:' . $ip) . '.json';
$rateData = null;

if (file_exists($rateFile)) {
  $rateRaw = @file_get_contents($rateFile);
  if ($rateRaw) $rateData = @json_decode($rateRaw, true);
}

if (is_array($rateData) && ($now - ($rateData['t'] ?? 0)) < 120) {
  // Return existing token (still valid)
  $existingToken = $rateData['tok'] ?? '';
  $tokenFile = sys_get_temp_dir() . '/nai_tok_' . md5('tok:' . $existingToken) . '.json';
  if ($existingToken !== '' && file_exists($tokenFile)) {
    echo json_encode(['token' => $existingToken]);
    exit;
  }
}

// Generate new random token (32 hex chars — unpredictable)
$token = bin2hex(random_bytes(16));

// Store token server-side
$tokenFile = sys_get_temp_dir() . '/nai_tok_' . md5('tok:' . $token) . '.json';
@file_put_contents($tokenFile, json_encode([
  'ip'      => $ip,
  'created' => $now,
]));

// Save rate limit record
@file_put_contents($rateFile, json_encode([
  't'   => $now,
  'tok' => $token,
]));

echo json_encode(['token' => $token]);