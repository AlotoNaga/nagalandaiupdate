<?php
/**
 * Nagaland AI — Ecosystem Connector
 * File: public_html/api/nai_ecosystem.php (on nagalandai.com)
 *
 * Connects Nagaland AI to all Nagaland Me platforms:
 * - nagalanddictionary.com (word lookups)
 * - nagalandprofiles.com (profile search)
 * - nagalandnewstoday.com (already via RSS + Aloto bio)
 * - helpnagaland.com (already via RSS)
 *
 * Include this file in chat.php AFTER the intent detectors section.
 * It adds $naiEcosystemContext which gets injected into the AI messages.
 */

// ─── SHARED SECRET KEY (must match all API endpoints) ───
define('NAI_ECOSYSTEM_KEY', 'Alhou$*abalunahoi10%');

// ─── API ENDPOINTS ───
$naiEcosystemEndpoints = [
  'dictionary' => 'https://nagalanddictionary.com/api/nai-lookup.php',
  'profiles'   => 'https://nagalandprofiles.com/api/nai-search.php',
];

/* =========================================================
   INTENT DETECTORS — DICTIONARY
   ========================================================= */

// User wants to translate/look up a word
$isDictionaryQuery = (bool)preg_match(
  '/\b(translate|translation|meaning\s+of|what\s+does\s+.+\s+mean|how\s+to\s+say|how\s+do\s+you\s+say|dictionary|word\s+for|what\s+is\s+.+\s+in\s+(ao|angami|sema|lotha|chakhesang|rengma|sangtam|konyak|chang|phom|khiamniungan|pochury|zeliang|yimchunger|nagamese|sumi|tenyidie|chungli|mongsen)|in\s+naga|in\s+nagamese|naga\s+word|nagamese\s+word|tribal\s+word|local\s+word)\b/i',
  $message
);

// Also detect when user asks in format: "hello in Ao" or "water in Sumi"
if (!$isDictionaryQuery) {
  $isDictionaryQuery = (bool)preg_match(
    '/\b\w+\s+in\s+(ao|angami|sema|sumi|lotha|chakhesang|rengma|sangtam|konyak|chang|phom|khiamniungan|pochury|zeliang|yimchunger|nagamese|tenyidie|chungli|mongsen)\b/i',
    $message
  );
}

// Extract the target language if mentioned
$dictTargetLang = '';
if ($isDictionaryQuery) {
  $langMap = [
    'ao' => 'Ao', 'angami' => 'Angami', 'sema' => 'Sema', 'sumi' => 'Sumi',
    'lotha' => 'Lotha', 'chakhesang' => 'Chakhesang', 'rengma' => 'Rengma',
    'sangtam' => 'Sangtam', 'konyak' => 'Konyak', 'chang' => 'Chang',
    'phom' => 'Phom', 'khiamniungan' => 'Khiamniungan', 'pochury' => 'Pochury',
    'zeliang' => 'Zeliang', 'yimchunger' => 'Yimchunger', 'nagamese' => 'Nagamese',
    'tenyidie' => 'Tenyidie', 'chungli' => 'Chungli', 'mongsen' => 'Mongsen',
  ];
  foreach ($langMap as $pattern => $langName) {
    if (preg_match('/\b' . preg_quote($pattern, '/') . '\b/i', $message)) {
      $dictTargetLang = $langName;
      break;
    }
  }
}

// Extract the search word (best effort — remove the language and instruction parts)
$dictSearchWord = '';
if ($isDictionaryQuery) {
  $cleaned = $message;
  // Remove common instruction phrases
  $cleaned = preg_replace('/\b(translate|translation|meaning\s+of|what\s+does|mean|how\s+to\s+say|how\s+do\s+you\s+say|dictionary|word\s+for|what\s+is|in\s+naga|in\s+nagamese|naga\s+word|nagamese\s+word|tribal\s+word|local\s+word)\b/i', '', $cleaned);
  // Remove the target language name
  if ($dictTargetLang !== '') {
    $cleaned = preg_replace('/\b' . preg_quote($dictTargetLang, '/') . '\b/i', '', $cleaned);
  }
  $cleaned = preg_replace('/\bin\b/i', '', $cleaned);
  $cleaned = trim(preg_replace('/\s+/', ' ', $cleaned));
  // Remove quotes and question marks
  $cleaned = trim($cleaned, '"\' ?.');
  $dictSearchWord = $cleaned;
}

/* =========================================================
   INTENT DETECTORS — PROFILES
   ========================================================= */

$isProfileQuery = (bool)preg_match(
  '/\b(find\s+profile|search\s+profile|look\s+up\s+profile|nagaland\s+profile|who\s+is\s+on\s+nagaland\s+profiles|profiles?\s+of|find\s+people|find\s+business|business\s+directory|professional\s+directory|find\s+.+\s+on\s+nagaland\s+profiles|create\s+profile|list\s+profiles|nagalandprofiles|nagaland\s+profiles)\b/i',
  $message
);

// Extract search query for profiles
$profileSearchQuery = '';
if ($isProfileQuery) {
  $cleaned = $message;
  $cleaned = preg_replace('/\b(find|search|look\s+up|profile|profiles|on|nagaland|nagalandprofiles|people|business|directory|professional|who\s+is|list|create)\b/i', '', $cleaned);
  $cleaned = trim(preg_replace('/\s+/', ' ', $cleaned));
  $cleaned = trim($cleaned, '"\' ?.');
  $profileSearchQuery = $cleaned;
}

/* =========================================================
   API CALLER — SHARED FUNCTION
   ========================================================= */

function nai_ecosystem_call($endpoint, $params = [], $timeout = 10) {
  $params['key'] = NAI_ECOSYSTEM_KEY;
  $url = $endpoint . '?' . http_build_query($params);

  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => $timeout,
    CURLOPT_USERAGENT => 'NagalandAI-Ecosystem/1.0',
    CURLOPT_HTTPHEADER => [
      'Accept: application/json',
      'Origin: https://nagalandai.com',
    ],
  ]);
  $body = curl_exec($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($body === false || $code >= 400) return null;

  $data = json_decode($body, true);
  return is_array($data) ? $data : null;
}

/* =========================================================
   DICTIONARY LOOKUP — FETCH LIVE DATA
   ========================================================= */

$naiDictionaryContext = '';

if ($isDictionaryQuery && $dictSearchWord !== '') {

  $dictParams = ['word' => $dictSearchWord, 'action' => 'lookup'];
  if ($dictTargetLang !== '') {
    $dictParams['lang'] = $dictTargetLang;
  }

  $dictResult = nai_ecosystem_call($naiEcosystemEndpoints['dictionary'], $dictParams, 8);

  if ($dictResult && !empty($dictResult['results'])) {
    $naiDictionaryContext  = "LIVE DICTIONARY DATA (from Nagaland Dictionary — nagalanddictionary.com):\n";
    $naiDictionaryContext .= "The user is asking about a word/translation. Here are the REAL results from the dictionary database:\n\n";

    $count = 0;
    foreach ($dictResult['results'] as $r) {
      if ($count >= 10) break;
      $count++;
      $naiDictionaryContext .= "ENTRY {$count}:\n";
      $naiDictionaryContext .= "  Language: {$r['language']}\n";
      $naiDictionaryContext .= "  English: {$r['english']}\n";
      $naiDictionaryContext .= "  Local term: {$r['local']}\n";
      if (!empty($r['pos'])) {
        $naiDictionaryContext .= "  Part of speech: {$r['pos']}\n";
      }
      if (!empty($r['sentences'])) {
        $naiDictionaryContext .= "  Example sentences:\n";
        foreach (array_slice($r['sentences'], 0, 2) as $s) {
          $naiDictionaryContext .= "    EN: {$s['english']}\n";
          $naiDictionaryContext .= "    Local: {$s['local']}\n";
        }
      }
      if (!empty($r['grammar'])) {
        foreach (array_slice($r['grammar'], 0, 2) as $g) {
          $naiDictionaryContext .= "  Grammar ({$g['type']}): {$g['note']}\n";
        }
      }
      if (!empty($r['word_page'])) {
        $naiDictionaryContext .= "  Full page: {$r['word_page']}\n";
      }
      $naiDictionaryContext .= "\n";
    }

    $naiDictionaryContext .= "RESPONSE RULES:\n";
    $naiDictionaryContext .= "- Present these translations clearly and conversationally.\n";
    $naiDictionaryContext .= "- If multiple languages have the word, show all of them.\n";
    $naiDictionaryContext .= "- Include example sentences if available.\n";
    $naiDictionaryContext .= "- End with: 'Explore more words at https://nagalanddictionary.com'\n";
    $naiDictionaryContext .= "- Do NOT invent translations. Only use what is provided above.\n";

  } elseif ($dictResult && empty($dictResult['results'])) {
    $naiDictionaryContext  = "DICTIONARY LOOKUP RESULT: No results found for \"{$dictSearchWord}\"";
    if ($dictTargetLang !== '') {
      $naiDictionaryContext .= " in {$dictTargetLang}";
    }
    $naiDictionaryContext .= ".\n";
    $naiDictionaryContext .= "Tell the user this word is not in the dictionary yet. Suggest they:\n";
    $naiDictionaryContext .= "1) Try a different spelling\n";
    $naiDictionaryContext .= "2) Visit https://nagalanddictionary.com to suggest this word for addition\n";
    $naiDictionaryContext .= "3) Try searching for a simpler/root form of the word\n";

  } else {
    // API call failed — don't block the response, just skip
    $naiDictionaryContext = '';
  }
}

/* =========================================================
   PROFILE SEARCH — FETCH LIVE DATA
   ========================================================= */

$naiProfilesContext = '';

if ($isProfileQuery) {

  $profileParams = ['action' => 'search'];
  if ($profileSearchQuery !== '') {
    $profileParams['q'] = $profileSearchQuery;
  }

  $profileResult = nai_ecosystem_call($naiEcosystemEndpoints['profiles'], $profileParams, 8);

  if ($profileResult && !empty($profileResult['results'])) {
    $naiProfilesContext  = "LIVE PROFILE DATA (from Nagaland Profiles — nagalandprofiles.com):\n";
    $naiProfilesContext .= "Here are real profiles from the Nagaland Profiles directory:\n\n";

    $count = 0;
    foreach ($profileResult['results'] as $p) {
      if ($count >= 5) break;
      $count++;
      $naiProfilesContext .= "PROFILE {$count}:\n";
      $naiProfilesContext .= "  Name: {$p['name']}\n";
      $naiProfilesContext .= "  Type: {$p['type']}\n";
      if (!empty($p['title'])) $naiProfilesContext .= "  Title: {$p['title']}\n";
      if (!empty($p['location'])) $naiProfilesContext .= "  Location: {$p['location']}\n";
      if (!empty($p['business_name'])) $naiProfilesContext .= "  Business: {$p['business_name']}\n";
      if (!empty($p['categories'])) $naiProfilesContext .= "  Category: " . implode(', ', $p['categories']) . "\n";
      if ($p['verified']) $naiProfilesContext .= "  Status: Verified ✓\n";
      if (!empty($p['bio_excerpt'])) $naiProfilesContext .= "  About: {$p['bio_excerpt']}\n";
      $naiProfilesContext .= "  Profile: {$p['profile_url']}\n\n";
    }

    if ($profileResult['total_available'] > 5) {
      $naiProfilesContext .= "NOTE: Showing 5 of {$profileResult['total_available']} total results.\n";
    }

    $naiProfilesContext .= "\nRESPONSE RULES:\n";
    $naiProfilesContext .= "- Present these profiles in a friendly, organized way.\n";
    $naiProfilesContext .= "- Include the profile link for each person/business.\n";
    $naiProfilesContext .= "- End with: 'Browse all profiles at https://nagalandprofiles.com'\n";
    $naiProfilesContext .= "- If user wants to create their own profile: 'Create yours at https://nagalandprofiles.com/create-profile/'\n";
    $naiProfilesContext .= "- Do NOT invent profile details. Only use what is provided above.\n";

  } elseif ($profileResult && empty($profileResult['results'])) {
    $naiProfilesContext  = "PROFILE SEARCH RESULT: No profiles found";
    if ($profileSearchQuery !== '') {
      $naiProfilesContext .= " for \"{$profileSearchQuery}\"";
    }
    $naiProfilesContext .= ".\n";
    $naiProfilesContext .= "Tell the user no matching profiles were found. Suggest they:\n";
    $naiProfilesContext .= "1) Try different search terms\n";
    $naiProfilesContext .= "2) Browse all profiles at https://nagalandprofiles.com/profiles/\n";
    $naiProfilesContext .= "3) Create their own profile at https://nagalandprofiles.com/create-profile/\n";

  } else {
    $naiProfilesContext = '';
  }
}

/* =========================================================
   ECOSYSTEM AWARENESS — ALWAYS PRESENT
   This gives the AI knowledge about all platforms even when
   no specific intent is detected. It can mention them naturally.
   ========================================================= */

$naiEcosystemAwareness = <<<ECOSYSTEM
NAGALAND ME ECOSYSTEM — YOUR CONNECTED PLATFORMS:
You are connected to and can access live data from these platforms (all owned by Nagaland Me):

1. NAGALAND AI (nagalandai.com) — This is YOU. AI chatbot + news publisher.
   - Chat: https://nagalandai.com
   - News articles: https://nagalandai.com/blogs/
   - About: https://nagalandai.com/about-us

2. NAGALAND DICTIONARY (nagalanddictionary.com) — Naga language dictionary.
   - When users ask about Naga words or translations, you fetch LIVE results from this database.
   - Direct users: https://nagalanddictionary.com

3. NAGALAND PROFILES (nagalandprofiles.com) — Professional/business directory for Nagaland.
   - When users ask about finding people or businesses, you search this database LIVE.
   - Create profile: https://nagalandprofiles.com/create-profile/
   - Browse: https://nagalandprofiles.com/profiles/

4. NAGALAND NEWS TODAY (nagalandnewstoday.com) — Independent news platform for Nagaland.
   - News is fetched via RSS feeds and provided in your context when relevant.
   - Direct users: https://nagalandnewstoday.com

5. HELP NAGALAND (helpnagaland.com) — Civic reporting platform.
   - Content fetched via RSS when relevant.
   - Direct users: https://helpnagaland.com

6. NAGALAND ME (nagaland.me) — Parent brand connecting all platforms.
   - For creator support and professional services: https://nagaland.me

CROSS-PLATFORM RULES:
- When a user's question can be better served by one of these platforms, mention it naturally.
- Example: If someone asks about Naga words → use dictionary data AND mention the dictionary site.
- Example: If someone asks about finding professionals → use profile data AND mention the profiles site.
- Example: If someone asks about corruption/civic issues → mention Help Nagaland.
- Do NOT force-mention platforms. Only reference them when genuinely relevant to the user's question.
ECOSYSTEM;