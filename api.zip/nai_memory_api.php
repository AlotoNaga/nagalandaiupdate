<?php
/**
 * ===============================================================
 * NAGALAND AI — Memory Management API (nai_memory_api.php)
 * ===============================================================
 * REST endpoint for the Memory Settings UI.
 * Handles: list, add, edit, delete, clear
 *
 * DEPLOYMENT: nagalandai.com/public_html/api/nai_memory_api.php
 * ===============================================================
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// Load WordPress (needed for authentication + user meta)
$wpLoadPath = dirname(__DIR__) . '/wp-load.php';
if (!file_exists($wpLoadPath)) {
  http_response_code(500);
  echo json_encode(['error' => 'Server configuration error.']);
  exit;
}
define('NAI_LOADED', true);
require_once $wpLoadPath;

// CORS
$allowedOrigins = [
  'https://nagalandai.com',
  'https://www.nagalandai.com',
];
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($origin, $allowedOrigins, true)) {
  header("Access-Control-Allow-Origin: $origin");
  header('Access-Control-Allow-Methods: POST, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type');
}
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// POST only
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(['error' => 'Method not allowed']);
  exit;
}

// Auth check
if (!function_exists('is_user_logged_in') || !is_user_logged_in()) {
  http_response_code(401);
  echo json_encode(['error' => 'Please log in to manage memories.', 'login_required' => true]);
  exit;
}

$userId = get_current_user_id();
$plan = get_user_meta($userId, 'nai_plan', true) ?: 'explore';

// Load memory functions
require_once __DIR__ . '/nai_memory.php';

// Read request
$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);

if (!is_array($payload)) {
  http_response_code(400);
  echo json_encode(['error' => 'Invalid request']);
  exit;
}

$action = trim((string)($payload['action'] ?? ''));

/* =========================================================
   ROUTE ACTIONS
   ========================================================= */

switch ($action) {

  case 'list':
    $memories = nai_get_memories($userId);
    $limit = nai_memory_limit($plan, $userId);
    echo json_encode([
      'success'  => true,
      'memories' => $memories,
      'used'     => count($memories),
      'limit'    => $limit,
      'plan'     => $plan,
    ], JSON_UNESCAPED_UNICODE);
    break;

  case 'add':
    $text = trim((string)($payload['text'] ?? ''));
    if ($text === '') {
      echo json_encode(['success' => false, 'message' => 'Memory text cannot be empty.']);
      exit;
    }
    $result = nai_add_memory($userId, $plan, $text);
    $memories = nai_get_memories($userId);
    $limit = nai_memory_limit($plan, $userId);
    echo json_encode(array_merge($result, [
      'memories' => $memories,
      'used'     => count($memories),
      'limit'    => $limit,
    ]), JSON_UNESCAPED_UNICODE);
    break;

  case 'edit':
    $memoryId = trim((string)($payload['memory_id'] ?? ''));
    $newText  = trim((string)($payload['text'] ?? ''));
    if ($memoryId === '' || $newText === '') {
      echo json_encode(['success' => false, 'message' => 'Missing memory ID or text.']);
      exit;
    }
    $result = nai_edit_memory($userId, $memoryId, $newText);
    $memories = nai_get_memories($userId);
    $limit = nai_memory_limit($plan, $userId);
    echo json_encode(array_merge($result, [
      'memories' => $memories,
      'used'     => count($memories),
      'limit'    => $limit,
    ]), JSON_UNESCAPED_UNICODE);
    break;

  case 'delete':
    $memoryId = trim((string)($payload['memory_id'] ?? ''));
    if ($memoryId === '') {
      echo json_encode(['success' => false, 'message' => 'Missing memory ID.']);
      exit;
    }
    $result = nai_delete_memory($userId, $memoryId);
    $memories = nai_get_memories($userId);
    $limit = nai_memory_limit($plan, $userId);
    echo json_encode(array_merge($result, [
      'memories' => $memories,
      'used'     => count($memories),
      'limit'    => $limit,
    ]), JSON_UNESCAPED_UNICODE);
    break;

  case 'clear':
    $result = nai_clear_memories($userId);
    echo json_encode(array_merge($result, [
      'memories' => [],
      'used'     => 0,
      'limit'    => nai_memory_limit($plan, $userId),
    ]), JSON_UNESCAPED_UNICODE);
    break;

  default:
    http_response_code(400);
    echo json_encode(['error' => 'Unknown action. Use: list, add, edit, delete, clear']);
}