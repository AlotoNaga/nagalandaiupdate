<?php
// public_html/api/nai_sources.php (v1.1 — Jul 2026: source links must be bare URLs, matching the app-safe link rule in chat.php v3.1)
return [
  // ✅ RSS feed list (edit this file only in future)
  // IMPORTANT: Put priority sources FIRST (Nagaland → India → World)
  'rss_sources' => [
    // 🔹 Priority 1: Nagaland news sources
    ['name' => 'Nagaland Post', 'url' => 'https://nagalandpost.com/feed'],
    ['name' => 'Morung Express', 'url' => 'https://morungexpress.com/feed'],
    ['name' => 'Nagaland News Today', 'url' => 'https://nagalandnewstoday.com/feed'],
    ['name' => 'Help Nagaland', 'url' => 'https://helpnagaland.com/feed'],
    ['name' => 'Nagaland Tribune', 'url' => 'https://nagalandtribune.in/feed'],
    // 🔹 Priority 2: Nagaland Government (custom scraper — free forever, no rss.app)
    ['name' => 'DIPR Nagaland', 'url' => 'https://nagalandai.com/api/nai_gov_rss.php?source=dipr'],
    ['name' => 'Department of School Education', 'url' => 'https://nagalandai.com/api/nai_gov_rss.php?source=education'],
    // 🔹 Priority 3: Northeast India
    ['name' => 'EastMojo', 'url' => 'https://www.eastmojo.com/feed/'],
    ['name' => 'NorthEast Now', 'url' => 'https://nenow.in/feed'],
    ['name' => 'The News Mill', 'url' => 'https://thenewsmill.com/feed'],
    // 🔹 Priority 4: India / National
    ['name' => 'The Hindu (India)', 'url' => 'https://www.thehindu.com/news/feeder/default.rss'],
    ['name' => 'Hindustan Times (India News)', 'url' => 'https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml'],
    ['name' => 'NDTV (India News)', 'url' => 'https://feeds.feedburner.com/ndtvnews-india-news'],
    ['name' => 'India Today', 'url' => 'https://www.indiatoday.in/rss/home'],
    ['name' => 'LiveMint (News)', 'url' => 'https://www.livemint.com/rss/news'],
    // 🔹 Priority 5: World
    ['name' => 'BBC News', 'url' => 'https://feeds.bbci.co.uk/news/rss.xml'],
    ['name' => 'Washington Post (World)', 'url' => 'https://feeds.washingtonpost.com/rss/world'],
    ['name' => 'SCMP (Asia)', 'url' => 'https://www.scmp.com/rss/91/feed/'],
    ['name' => 'World Health Organization', 'url' => 'https://www.who.int/rss-feeds/news-english.xml'],
  ],
  // ✅ Extra instructions that apply to ALL responses (not just news)
  'extra_prompt' => <<<PROMPT
CRITICAL RULES FOR ALL RESPONSES:
1. NEWS INTEGRITY:
   When verified news articles are provided in the system context, use ONLY those articles as your source. NEVER invent headlines, facts, dates, quotes, or links. ALWAYS include the original source link for each news item.
2. NEWS PRIORITY:
   When presenting news: Nagaland sources first → India sources second → World sources third. If user specifically asks for India or world news, prioritize accordingly. If no relevant articles match the user's question, say so honestly.
3. GOVERNMENT INFORMATION:
   For government-related questions (orders, tenders, press releases, policy changes): Only state facts that appear in the provided verified articles or official source data. If you don't have verified information, say: "I don't have a verified official source for that right now. Please check the relevant government portal."
4. GENERAL KNOWLEDGE:
   For education, science, math, history, health, career, and technology questions: Answer helpfully using your training knowledge. You are a capable AI — don't refuse helpful questions just because they aren't Nagaland-specific. But when relevant, add a Nagaland connection or context.
5. FORMATTING:
   Use clean formatting. Bold key terms. Use short paragraphs. For news lists, number each item clearly. Write every source link as a full bare URL (https://...) on its own line after the item — never use markdown [title](url) syntax. Make responses easy to scan and read on mobile.
PROMPT
];