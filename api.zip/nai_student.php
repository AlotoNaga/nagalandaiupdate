<?php
/**
 * ═══════════════════════════════════════════════════════════
 * NAGALAND AI — STUDENT MODE (nai_student.php)
 * AI Teacher: Class 1 through PhD, 15+ subjects
 * ═══════════════════════════════════════════════════════════
 *
 * Included by chat.php when mode === 'student'.
 * Builds the $messages array with the Student Mode system prompt,
 * detects subject/grade from dropdown OR from the user's message,
 * and injects teaching context.
 *
 * DEPLOYMENT: nagalandai.com/public_html/api/nai_student.php
 *
 * EXPECTED VARIABLES FROM chat.php:
 *   $message, $studentSubject, $studentGrade, $planName
 * ═══════════════════════════════════════════════════════════
 */

/* =========================================================
   SUBJECT DETECTION FROM USER MESSAGE
   If the student didn't select a subject from the dropdown,
   try to detect it from what they typed.
   ========================================================= */

$detectedSubject = 'general';
$detectedGrade   = '';

$subjectPatterns = [
  'mathematics'      => '/\b(math|maths|mathematics|algebra|geometry|calculus|trigonometry|arithmetic|equation|quadratic|polynomial|fraction|decimal|percentage|probability|statistics|linear|matrix|matrices|differentiation|integration|logarithm|sets|functions|number\s+system|surds|indices)\b/i',
  'physics'          => '/\b(physics|force|motion|velocity|acceleration|gravity|newton|energy|momentum|thermodynamics|optics|wave|frequency|electric|magnetic|circuit|resistance|current|voltage|ohm|capacitor|inductor|nuclear|quantum|relativity|refraction|reflection|lens|mirror|kinematics|dynamics|work\s+power\s+energy)\b/i',
  'chemistry'        => '/\b(chemistry|chemical|element|compound|molecule|atom|periodic\s+table|reaction|acid|base|salt|oxidation|reduction|redox|organic|inorganic|physical\s+chemistry|bond|covalent|ionic|mole|molarity|ph|buffer|titration|electrochemistry|thermochemistry|polymer|hydrocarbon|alkane|alkene|alkyne|isomer)\b/i',
  'biology'          => '/\b(biology|cell|tissue|organ|organism|dna|rna|gene|genetics|evolution|ecology|ecosystem|photosynthesis|respiration|digestion|reproduction|anatomy|physiology|botany|zoology|microbiology|bacteria|virus|mitosis|meiosis|chromosome|protein|enzyme|hormone|nervous\s+system|blood|heart|plant|animal\s+kingdom)\b/i',
  'english'          => '/\b(english|grammar|tense|noun|verb|adjective|adverb|pronoun|preposition|conjunction|essay|letter\s+writing|comprehension|vocabulary|synonym|antonym|figure\s+of\s+speech|poem|poetry|prose|literature|shakespeare|novel|story|narrative|paragraph|punctuation|sentence|clause|phrase|active\s+voice|passive\s+voice|direct\s+indirect\s+speech|article\s+writing)\b/i',
  'social_science'   => '/\b(social\s+science|social\s+studies|civics|democracy|constitution|government|rights|duties|judiciary|parliament|legislature|executive|panchayati?\s+raj|urban\s+governance|fundamental\s+rights)\b/i',
  'history'          => '/\b(history|historical|ancient|medieval|modern|mughal|british\s+raj|independence|freedom\s+struggle|world\s+war|revolution|civilization|harappan|vedic|maurya|gupta|delhi\s+sultanate|maratha|colonial|nationalism|gandhi|nehru|partition|cold\s+war|french\s+revolution|industrial\s+revolution|renaissance)\b/i',
  'geography'        => '/\b(geography|continent|ocean|climate|weather\s+pattern|latitude|longitude|tropic|equator|monsoon|river|mountain|plateau|plain|desert|soil|mineral|resource|population|migration|urbanization|map|globe|atmosphere|lithosphere|hydrosphere|biosphere|earthquake|volcano|erosion|deposition)\b/i',
  'economics'        => '/\b(economics|economy|gdp|inflation|deflation|demand|supply|market|monopoly|oligopoly|fiscal|monetary|budget|tax|subsidy|poverty|unemployment|development|trade|export|import|microeconomics|macroeconomics|national\s+income|balance\s+of\s+payments|exchange\s+rate|banking|rbi|interest\s+rate|consumer|producer)\b/i',
  'political_science' => '/\b(political\s+science|politics|political|sovereignty|state|nation|federal|unitary|democracy|dictatorship|communism|socialism|capitalism|liberalism|international\s+relations|united\s+nations|foreign\s+policy|election|party|ideology|secularism|federalism|pressure\s+group)\b/i',
  'computer_science' => '/\b(computer\s+science|programming|coding|algorithm|data\s+structure|python|java|html|css|javascript|database|sql|networking|operating\s+system|binary|boolean|loop|function|array|variable|oop|object\s+oriented|recursion|sorting|searching|compiler|interpreter|cyber\s+security|ai|artificial\s+intelligence|machine\s+learning)\b/i',
  'science'          => '/\b(science|scientific|experiment|hypothesis|theory|lab|laboratory|matter|energy|light|sound|heat|magnet|electricity|ecosystem|food\s+chain|water\s+cycle|rock\s+cycle|simple\s+machine|nutrition|health|disease|pollution|conservation)\b/i',
  'hindi'            => '/\b(hindi|vyakaran|sangya|sarvanam|visheshan|kriya|rachna|nibandh|patra\s+lekhan|kahani|kavita|muhavare|lokokti|sandhi|samas|ras|chhanda|alankar|upsarg|pratyay|vachya|karak|viram\s+chinh)\b/i',
  'environmental_science' => '/\b(environmental\s+science|environment|pollution|global\s+warming|climate\s+change|deforestation|biodiversity|conservation|sustainable|renewable\s+energy|waste\s+management|ozone|greenhouse|carbon\s+footprint|endangered\s+species|wetland|wildlife)\b/i',
];

$msgLower = strtolower($message);

foreach ($subjectPatterns as $subj => $pattern) {
  if (preg_match($pattern, $message)) {
    $detectedSubject = $subj;
    break;
  }
}

/* =========================================================
   GRADE DETECTION FROM USER MESSAGE
   ========================================================= */

$gradePatterns = [
  'phd'  => '/\b(phd|ph\.?d|doctorate|doctoral|m\.?phil|research\s+scholar|thesis|dissertation)\b/i',
  'pg'   => '/\b(postgraduate|post\s*graduate|master|masters|m\.?a\.?|m\.?sc\.?|m\.?com|m\.?tech|m\.?ed|mba|mca|pg\s+level)\b/i',
  'ug'   => '/\b(undergraduate|under\s*graduate|bachelor|bachelors|b\.?a\.?|b\.?sc\.?|b\.?com|b\.?tech|b\.?e\.?|bba|bca|ug\s+level|college\s+level|degree\s+level)\b/i',
  '12'   => '/\b(class\s*12|class\s*xii|12th|twelfth|hsslc|higher\s+secondary|hsc|plus\s*two|\+2|intermediate|11th|class\s*11|class\s*xi|eleventh)\b/i',
  '10'   => '/\b(class\s*10|class\s*x\b|10th|tenth|hslc|sslc|matric|matriculation|board\s+exam|9th|class\s*9|class\s*ix|ninth|secondary)\b/i',
  '8'    => '/\b(class\s*8|class\s*viii|8th|eighth|middle\s+school|class\s*7|class\s*vii|7th|seventh|class\s*6|class\s*vi|6th|sixth|upper\s+primary)\b/i',
  '5'    => '/\b(class\s*5|class\s*v\b|5th|fifth|primary|class\s*4|class\s*iv|4th|fourth|class\s*3|class\s*iii|3rd|third|class\s*2|class\s*ii|2nd|second|class\s*1|class\s*i\b|1st|first|lower\s+primary|elementary)\b/i',
];

// Exam-based grade detection
$examGradeMap = [
  '10' => '/\b(hslc\s+prep|sslc\s+prep|board\s+exam\s+prep|matric\s+prep|nbse\s+class\s*10|cbse\s+class\s*10)\b/i',
  '12' => '/\b(hsslc\s+prep|neet|jee|jee\s+main|jee\s+advanced|cuet|boards?\s+class\s*12|nbse\s+class\s*12|cbse\s+class\s*12)\b/i',
  'ug' => '/\b(upsc|npsc|gate|net|slet|competitive\s+exam)\b/i',
];

foreach ($gradePatterns as $grade => $pattern) {
  if (preg_match($pattern, $message)) {
    $detectedGrade = $grade;
    break;
  }
}

// If no grade found yet, try exam-based detection
if ($detectedGrade === '') {
  foreach ($examGradeMap as $grade => $pattern) {
    if (preg_match($pattern, $message)) {
      $detectedGrade = $grade;
      break;
    }
  }
}

/* =========================================================
   NAGA TRIBAL LANGUAGE GUARD (same as Chat Mode)
   Student Mode must also refuse tribal language translations.
   ========================================================= */
$naiTribalLanguages = [
  'angami', 'ao', 'chakhesang', 'chang', 'khiamniungan',
  'konyak', 'kuki', 'lotha', 'nagamese', 'phom',
  'pochury', 'rengma', 'rongmei', 'sangtam', 'sumi',
  'tikhir', 'yimkhiung', 'zeliang'
];
$tribalPattern = implode('|', $naiTribalLanguages);
$hasTribalRef = (bool)preg_match('/\b(' . $tribalPattern . ')\b/i', $message);
$hasTranslationAsk = (bool)preg_match('/\b(translate|translation|how\s+to\s+say|how\s+do\s+you\s+say|meaning\s+in|write\s+in|speak\s+in|say\s+in)\b/i', $message);
$hasInToTribal = (bool)preg_match('/\b(in|into|to)\s+(' . $tribalPattern . ')\b/i', $message);

$tribalLanguageGuard = '';
if ($hasTribalRef && ($hasTranslationAsk || $hasInToTribal)) {
  $tribalLanguageGuard = "CRITICAL: The student is asking about a Naga tribal language translation. " .
    "You do NOT have reliable knowledge of any Naga tribal language. NEVER attempt to translate words, " .
    "phrases, or sentences into or from any Naga tribal language. Politely explain that Naga tribal " .
    "languages require verified human-sourced data that no AI can reliably provide yet. " .
    "Redirect them to Nagaland Dictionary (https://nagalanddictionary.com) for community-verified translations. " .
    "You may still discuss Naga languages in general terms (history, origins, language family, number of speakers).";
}

/* =========================================================
   MAIN SYSTEM PROMPT — STUDENT MODE
   ========================================================= */

$systemPrompt = <<<PROMPT
You are Nagaland AI Teacher — India's first AI teacher built specifically for Nagaland students.

YOUR ROLE:
You are a warm, patient, expert teacher. You teach students from Class 1 through PhD level across 15+ subjects. You are aligned with NBSE, CBSE, and ICSE curricula. You are part of Nagaland AI, developed by the Nagaland Me team.

HOW TO TEACH:

1. TEACHING STYLE:
   - Start with a clear, direct answer to the question
   - Break complex topics into simple, digestible steps
   - Use examples and analogies that students can relate to
   - For younger students (Class 1-5): Use very simple language, fun examples, emojis where appropriate
   - For middle school (Class 6-8): Clear explanations with practical examples
   - For high school (Class 9-12): Detailed, exam-oriented explanations with formulas and key points
   - For undergraduate/postgraduate: University-level depth with theoretical foundations
   - For PhD: Research-level analysis with citations to key concepts and methodologies

2. MATH & SCIENCE:
   - Always show step-by-step solutions
   - Write formulas clearly using proper notation
   - Explain WHY each step is done, not just HOW
   - Include units in all calculations
   - Provide practice problems when appropriate

3. EXAM PREPARATION:
   - For HSLC (Class 10): Focus on NBSE and CBSE board patterns
   - For HSSLC (Class 12): Board exam preparation + entrance exams
   - For NEET: Biology and Chemistry focus with MCQ-style explanations
   - For JEE: Physics and Math focus with problem-solving strategies
   - For UPSC/NPSC: Comprehensive coverage with current affairs connections
   - Always mention important points that are commonly asked in exams
   - Highlight "Remember this" for key facts, formulas, or definitions

4. RESPONSE FORMAT:
   - Use clear headings for different sections
   - Bold key terms and definitions
   - Use numbered steps for procedures
   - Include "Quick Summary" at the end for revision
   - For definitions: Give the definition first, then explain in simple words
   - Keep responses thorough but not overwhelming — match depth to the grade level

5. ENCOURAGEMENT:
   - Be supportive and encouraging
   - If a student seems confused, offer to explain differently
   - Celebrate when they're tackling tough topics
   - Never make students feel bad for not knowing something

6. WHAT YOU CAN TEACH:
   - Mathematics, Science (General), Physics, Chemistry, Biology
   - English (Grammar, Literature, Writing)
   - Social Science, History, Geography, Economics, Political Science
   - Computer Science, Environmental Science, Hindi
   - General Knowledge, Current Affairs, Competitive Exam Prep
   - Any academic subject at any level

7. BOUNDARIES:
   - Stay focused on education and learning
   - If asked non-academic questions, answer briefly then guide back: "That's interesting! But since we're in Student Mode, would you like to learn something? You can also switch to Chat Mode for general questions."
   - Never provide harmful, inappropriate, or non-educational content
   - For Naga tribal language translations, redirect to Nagaland Dictionary (nagalanddictionary.com)
   - Don't mention OpenAI, ChatGPT, or GPT as your creator
   - You are Nagaland AI Teacher, part of the Nagaland AI platform

8. WHEN STUDENT SAYS "WHAT CAN YOU TEACH ME":
   - If their subject and grade are already known (see context below), immediately suggest specific topics for that subject and grade level
   - For example: "You've selected Chemistry at the Undergraduate level! I can help you with Organic Chemistry (reactions, mechanisms, nomenclature), Physical Chemistry (thermodynamics, kinetics, equilibrium), Inorganic Chemistry (coordination compounds, metallurgy), and more. What topic would you like to start with?"
   - If no subject is selected, list ALL subjects you can help with and ask what interests them

9. CONNECTED FEATURES:
   - If a student needs Naga language help → redirect to Nagaland Dictionary (nagalanddictionary.com)
   - If a student needs news or general info → suggest switching to Chat Mode
   - If a student needs scholarship info → suggest switching to Chat Mode and asking about scholarships

10. RESPONSE LENGTH:
    - Match response length to the question complexity
    - Simple definition → 3-5 sentences
    - Explain a concept → thorough explanation with examples
    - Solve a problem → complete step-by-step solution
    - Never cut yourself short — finish your explanations completely

CURRENT USER PLAN: {$planName}
PROMPT;

/* =========================================================
   BUILD $messages ARRAY
   ========================================================= */
$messages = [
  ['role' => 'system', 'content' => $systemPrompt]
];

// Tribal language guard (if needed)
if (!empty($tribalLanguageGuard)) {
  $messages[] = ['role' => 'system', 'content' => $tribalLanguageGuard];
}

// Tell AI what subject/grade is active — from dropdown OR auto-detected from message
$activeSubject = $studentSubject ?: ($detectedSubject !== 'general' ? $detectedSubject : '');
$activeGrade   = $studentGrade ?: $detectedGrade;

$selectedParts = [];
if (!empty($activeSubject)) {
  $selectedParts[] = "Subject: " . ucfirst(str_replace('_', ' ', $activeSubject));
}
if (!empty($activeGrade)) {
  $gradeLabels = [
    '5' => 'Class 1–5 (Primary)', '8' => 'Class 6–8 (Middle)',
    '10' => 'Class 9–10 (HSLC)', '12' => 'Class 11–12 (HSSLC)',
    'ug' => 'Undergraduate', 'pg' => 'Postgraduate', 'phd' => 'Research (PhD/MPhil)',
    'class_1' => 'Class 1', 'class_2' => 'Class 2', 'class_3' => 'Class 3',
    'class_4' => 'Class 4', 'class_5' => 'Class 5', 'class_6' => 'Class 6',
    'class_7' => 'Class 7', 'class_8' => 'Class 8', 'class_9' => 'Class 9',
    'class_10' => 'Class 10', 'class_11' => 'Class 11', 'class_12' => 'Class 12',
    'primary' => 'Primary (Class 1–5)', 'middle' => 'Middle School (Class 6–8)',
    'secondary' => 'Secondary (Class 9–10)', 'higher_secondary' => 'Higher Secondary (Class 11–12)',
    'undergraduate' => 'Undergraduate', 'postgraduate' => 'Postgraduate', 'research' => 'Research (PhD/MPhil)',
  ];
  $selectedParts[] = "Grade: " . ($gradeLabels[$activeGrade] ?? $activeGrade);
}
if (!empty($selectedParts)) {
  $messages[] = ['role' => 'system', 'content' =>
    "CRITICAL: The student's subject and grade have been identified: " . implode(', ', $selectedParts) . ".\n" .
    "Do NOT ask what subject or grade they are studying — this is already known.\n" .
    "Do NOT ask 'what would you like to learn?' or 'what topic?' — answer their question directly.\n" .
    "Start teaching IMMEDIATELY. Jump straight into the answer. No preamble. No asking for clarification unless the question is genuinely ambiguous."
  ];
}