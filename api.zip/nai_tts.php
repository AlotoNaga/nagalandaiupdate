<?php
// public_html/api/nai_tts.php
// NAGALAND AI — PREMIUM VOICE PROXY v1.6  (app + website access)
//
// v1.6 — THE WEBSITE DOOR.
//   Until now only the mobile app could request premium audio, because the
//   only accepted proof was the app's secret header. The WEBSITE could not
//   use the clone voice at all — which is why the site spoke in each phone's
//   built-in browser voice instead.
//
//   The obvious "fix" — putting the app secret into the website's JavaScript
//   — must NEVER be done. Website JS is public: anyone can view-source, copy
//   the secret, drain the ElevenLabs balance, and bypass chat.php's bot wall
//   (the same secret skips its User-Agent check). So instead there are now
//   TWO doors:
//
//     Door 1 (unchanged): the app's secret header. Byte-for-byte the same
//             behaviour as before — the mobile app is unaffected.
//     Door 2 (new): a LOGGED-IN WordPress user. The browser's WordPress
//             login cookie is the proof. Guests on the website get
//             fallback:true and the site uses the browser voice for them.
//
//   Extra protections on Door 2:
//     - Foreign-origin block: if a request arrives from another website
//       (riding a logged-in visitor's cookies), it is refused. Your own
//       pages pass because same-origin requests carry no foreign Origin.
//       IMPORTANT for the future site JS: call this endpoint with a
//       RELATIVE url ('/api/nai_tts.php') so the call is always same-origin
//       and cookies flow automatically.
//     - Burst identity: website users are rate-limited per ACCOUNT
//       (user id), which is fairer and stronger than per-IP.
//     - Every existing cost wall (daily character budget, per-minute burst,
//       max reply length) applies to both doors identically.
//
//   NOTE ON COST: the website now draws from the SAME daily character budget
//   as the app (NAI_TTS_DAILY_CHARS below). If the site gets real use, that
//   budget will run out sooner and BOTH app and site fall back to device
//   voices for the rest of the day. Size the budget for the combined demand.
//
// v1.5 — THE EMOTION FIX.
//   The premium voice was already Multilingual v2, a good model, but it has a
//   ceiling: every sentence comes out with about the same energy, so it can
//   still sound flat and unfeeling — exactly the complaint.
//
//   Eleven v3 (generally available since 14 Mar 2026) is ElevenLabs' most
//   expressive model. It actually reads the MEANING of a sentence and shifts
//   its delivery — lifting on a question, warming on praise, slowing on
//   something serious — instead of reading every line the same way. This is
//   the single biggest change to how the voice feels.
//
//   THE CRITICAL DETAIL that was hurting the old setup: v3 and v2 take
//   DIFFERENT settings. v3's stability must be exactly 0.0, 0.5 or 1.0, and
//   v3 has no "speed" setting at all. The old file sent v2-tuned numbers
//   (stability 0.35, style 0.45, speed 0.97) to whatever model was chosen.
//   Sent to v3 those are rounded, ignored, or rejected — which is a very
//   common reason a "premium" voice still sounds flat. Settings are now
//   chosen PER MODEL, further down.
//
//   THE TRADE:
//     Quality : real emotional range and intonation, not just clean audio.
//     Cost    : NONE. v3 bills the same as Multilingual v2 — 1 credit per
//               character — so your daily ceiling and monthly plan are
//               unchanged. (Flash is cheaper but flat; that is the trade you
//               would be making the OTHER way.)
//     Latency : a little slower to generate than v2, still invisible next to
//               the 1-3s the AI already takes to think.
//
//   TWO things decide how good v3 sounds, and NEITHER is in this file:
//     1. THE VOICE. In v3 the chosen voice matters more than ever, because the
//        model can now push a voice's natural character much further. Pick a
//        warm, expressive voice from the ElevenLabs library (their voices
//        marked as good for v3 are best) and set ELEVENLABS_VOICE_ID to it.
//        A flat voice will still sound flat, even on v3.
//     2. THE WORDS. v3's emotion comes from the text and its punctuation.
//        nai_speaking.php already asks the teacher to write warm, naturally
//        punctuated sentences — keep it that way and do NOT let it emit
//        brackets or symbols (the v2 fallback would read them aloud).
//
//   Multilingual v2 is kept as an automatic fallback, so if v3 ever fails the
//   voice is still human, never the flat Flash one.
//
//   HOW TO CHANGE BACK: set NAI_TTS_MODEL to 'eleven_multilingual_v2'. The
//   per-model settings below handle the rest — nothing else to touch.
//
// v1.4 — THE BIG QUALITY FIX.
//   v1.0-1.3 used Flash v2.5. ElevenLabs built Flash for SPEED, not beauty.
//   Their own docs call Multilingual v2 "our most life-like, emotionally
//   rich model". Flash is the model they recommend for phone agents where
//   every millisecond counts — not for something a student listens to and
//   is meant to enjoy.
//
// v1.3 — voice quality tuning, from real listening:
//   LOUDNESS: audio was being generated at 22kHz / 32kbps, which is phone-call
//     quality and sounds thin and quiet. Now requests 44.1kHz / 128kbps, which
//     is fuller and noticeably louder. If your account cannot use that format
//     it automatically retries at the safe one, so it can never just fail.
//     Audio quality does NOT change the price — you are billed per character.
//
// v1.2: identical lines are cached on disk for 30 days. The greeting is the
// same words every single session, so without this you paid for it and
// waited for it every time. Cached lines come back instantly and cost
// nothing, which speeds up the moment that matters most: the very first
// thing a new user hears.
//
// v1.1: works even if a host is missing the mbstring extension, and reports
// cleanly if curl is unavailable, so a server quirk degrades to the phone
// voice instead of returning a blank error the app cannot read.
//
// WHY THIS FILE EXISTS
// The app and website must NEVER hold the ElevenLabs key. Anyone can unpack
// an installed app — or simply view-source a web page — and read it, then
// spend your balance until it is gone. So clients ask THIS endpoint for
// audio, and only this server ever sees the key.
//
// SETUP (one time)
//   1. Get your key at elevenlabs.io -> Developer settings -> API Keys
//   2. Pick a voice at elevenlabs.io -> Voices, copy its Voice ID
//   3. In wp-config.php, below your OPENAI_API_KEY line, add BOTH:
//        define('ELEVENLABS_API_KEY', 'your-key-here');
//        define('ELEVENLABS_VOICE_ID', 'your-voice-id-here');
//   4. Upload this file to public_html/api/
//
// If either constant is missing, this endpoint politely reports that premium
// voice is off and clients fall back to the device/browser voice. Nothing
// breaks, it just sounds ordinary.
//
// COST CONTROL — read this before going live
// Eleven v3 and Multilingual v2 both cost $0.10 per 1,000 characters (Flash is
// half that, but flat). A typical reply is about 500 characters, so roughly 5
// US cents each on v3.
//
// THREE walls protect your balance:
//   1. ElevenLabs Pay As You Go spend cap (set this in their dashboard, and
//      turn Auto Top Up OFF)
//   2. NAI_TTS_DAILY_CHARS below — a hard daily ceiling on this server
//   3. NAI_TTS_MAX_CHARS below — no single reply can be huge
//
// Wall 2 matters most. If your app secret ever leaks, someone could hammer
// this endpoint. The daily ceiling means the worst case is one wasted day,
// not an empty balance.

@ini_set('display_errors', '0');
@set_time_limit(45); // v3 is a heavier model than Flash/v2; give a slow line room

/* ---------- TUNE THESE THREE NUMBERS ---------- */

// Total characters this server will speak per day, across ALL users —
// app AND website combined (v1.6).
// Sized to spread a Starter plan across a full month. See the formula above.
// Raise it once you see real usage. This is your safety ceiling.
// PACING, NOT PENNY PINCHING.
// You pay a fixed monthly subscription, so unused credits are wasted money
// and there is no per-reply cost to avoid. This number exists only to make
// your monthly credit allowance LAST THE MONTH, instead of premium voice
// disappearing on day three and everyone hearing the device voice after that.
//
// HOW YOUR PLAN TRANSLATES
//   Plans are sold in MINUTES of audio. Roughly:
//       1 minute of speech  ~=  750 characters
//       one 3-5 sentence reply  ~=  40 seconds  ~=  500 characters
//
//   Starter   40 min/month  ~= 30,000 chars  ~= 60 replies  -> 950/day
//   Creator  100 min/month  ~= 75,000 chars  ~= 150 replies -> 2,400/day
//   Pro      500 min/month  ~= 375,000 chars ~= 750 replies -> 12,000/day
//
// v3 costs the SAME per character as Multilingual v2, so these numbers are
// unchanged by the v1.5 upgrade. Set for Starter (40 minutes). Formula:
// monthly characters / 31.
//
// IMPORTANT REALITY CHECK: at 1,100/day this server can speak only about two
// unique 500-char replies PER DAY across ALL users before the ceiling is hit
// and everyone falls back to the device voice. Repeated lines (the greeting,
// limit messages) are cached and free, so real capacity is a bit higher — but
// if users often hear the plain device voice, THIS number (and the size of
// your ElevenLabs plan) is why, not the voice model. Raise both together if
// you want most users to actually hear the clone.
//
// YOU ALSO HAVE PREPAID API CREDIT AS A RESERVE.
// When the monthly minutes run out, that credit covers the difference. So
// raising this number does not break anything — it just means you lean on
// the reserve sooner. Raise it if you would rather have generous premium
// voice now and top up occasionally, keep it low if you would rather the
// good voice be there every day of the month without thinking about it.
//
// IMPORTANT: repeated lines come from the cache and cost ZERO, so your real
// capacity is meaningfully higher than the numbers above. Watch actual usage
// in the ElevenLabs dashboard for a week before tuning this.
//
// THE BIGGEST SAVING IS NOT HERE. It is reply LENGTH. A 3-sentence reply
// costs 40 seconds; a rambling one costs 90. nai_speaking.php already tells
// the AI to converse rather than lecture, which roughly doubles how many
// replies your minutes cover. Keep it that way.
//
// If this ceiling is reached, or your credits run out entirely, voice does
// NOT break — the device/browser voice takes over until the next day.
define('NAI_TTS_DAILY_CHARS', 1800);

// Which voice model.
//   'eleven_v3'              — most expressive and emotional (GA since Mar 2026).
//                              Same price as Multilingual v2 (1 credit/char).
//   'eleven_multilingual_v2' — very good, a little flatter; used as the fallback.
//                              Clones can sound MORE like the original person
//                              on v2 — listen to both and keep whichever
//                              sounds most like you.
//   'eleven_flash_v2_5'      — half price and faster, but the flattest. For
//                              agents where latency is everything, not for a
//                              voice a student sits and listens to.
// Changing this ALSO changes which settings are sent — see the per-model
// voice settings further down.
define('NAI_TTS_MODEL', 'eleven_v3');

// Longest single reply we will send for speech. Voice replies are short by
// design, so anything longer is either a bug or abuse.
define('NAI_TTS_MAX_CHARS', 250);

// Per identity, per minute (app device, or website account). Stops one
// phone or one account hammering the endpoint.
define('NAI_TTS_BURST_PER_MIN', 12);

/* ---------- END OF TUNING ---------- */

header('X-Content-Type-Options: nosniff');

/* CORS + preflight, mirroring chat.php. Same-origin website calls (a
   RELATIVE url from your own pages) need none of this, but it makes the
   endpoint robust if a page on www. ever calls the apex domain. */
$naiAllowedOrigins = [
  'https://nagalandai.com',
  'https://www.nagalandai.com',
];
$naiOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($naiOrigin, $naiAllowedOrigins, true)) {
  header('Access-Control-Allow-Origin: ' . $naiOrigin);
  header('Access-Control-Allow-Methods: POST, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, X-Nai-App');
  header('Access-Control-Allow-Credentials: true');
  header('Vary: Origin');
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }

function nai_tts_len($s) {
  return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s);
}
function nai_tts_cut($s, $n) {
  return function_exists('mb_substr') ? mb_substr($s, 0, $n) : substr($s, 0, $n);
}

function nai_tts_fail($msg, $code = 200) {
  // 200 with fallback:true on purpose. A failure here is NOT an error for
  // the user — the client simply uses the device/browser voice instead.
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['fallback' => true, 'reason' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  nai_tts_fail('post_only', 405);
}

/* ---------- Load wp-config EARLY (v1.6) ----------
   It provides the ElevenLabs keys AND bootstraps WordPress, which is what
   makes is_user_logged_in() available for the website door below. chat.php
   relies on the exact same behaviour. */
$wpConfig = dirname(__DIR__) . '/wp-config.php';
if (file_exists($wpConfig)) {
  require_once $wpConfig;
}

/* ---------- AUTH: two doors (v1.6) ----------
   Door 1: the mobile app, proven by its secret header. Unchanged.
   Door 2: a logged-in WordPress user on the website, proven by their
           login cookie. Guests get fallback:true (browser voice).
   The app secret must NEVER be placed in website JavaScript — it is
   readable by anyone via view-source. */
$APP_SECRET = 'NAI_APP_9f3Kd72Lp0qWmZx4Rb8Tn6Vy1Hs5Jc';
$sentSecret = $_SERVER['HTTP_X_NAI_APP'] ?? '';
$isApp = hash_equals($APP_SECRET, (string)$sentSecret);

$webUserId = 0;
if (!$isApp) {
  if (function_exists('is_user_logged_in') && is_user_logged_in()) {
    $webUserId = (int) get_current_user_id();
  }
  if ($webUserId <= 0) {
    // Not the app, not a logged-in visitor: no premium. The site's JS treats
    // fallback:true as "use the browser voice", so guests still hear speech.
    nai_tts_fail('unauthorised', 403);
  }
  // Foreign-origin block: stop another website from spending your credits by
  // riding a logged-in visitor's cookies. Same-origin requests from your own
  // pages send no foreign Origin and pass untouched.
  if ($naiOrigin !== '' && !in_array($naiOrigin, $naiAllowedOrigins, true)) {
    nai_tts_fail('bad_origin', 403);
  }
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);
if (!is_array($payload)) {
  nai_tts_fail('bad_request', 400);
}

$text = trim((string)($payload['text'] ?? ''));
$fp   = trim((string)($payload['_nai_fp'] ?? ''));
$ip   = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

/* Burst identity: app devices as before (IP + fingerprint); website users
   per ACCOUNT, which is fairer than per-IP and immune to shared carrier
   IPs. */
$deviceKey = $isApp
  ? (($fp !== '' && strlen($fp) >= 4) ? ($ip . '|' . $fp) : $ip)
  : ('user:' . $webUserId);

if ($text === '') {
  nai_tts_fail('empty');
}

// Strip anything that would be read aloud as noise, just in case
$text = preg_replace('/\[([^\]]+)\]\((?:https?:\/\/|\/)[^\s)]*\)/', '$1', $text);
$text = preg_replace('/https?:\/\/\S+/', '', $text);
$text = preg_replace('/[*_`#>]/', '', $text);
$text = trim(preg_replace('/\s+/u', ' ', $text));

if ($text === '') {
  nai_tts_fail('empty_after_clean');
}
if (nai_tts_len($text) > NAI_TTS_MAX_CHARS) {
  $text = nai_tts_cut($text, NAI_TTS_MAX_CHARS);
}

/* ---------- WALL 3: per-identity burst ---------- */
$burstFile = sys_get_temp_dir() . '/nai_tts_burst_' . md5($deviceKey) . '.json';
$now = time();
$hits = [];
if (file_exists($burstFile)) {
  $decoded = json_decode((string)@file_get_contents($burstFile), true);
  if (is_array($decoded)) $hits = $decoded;
}
$hits = array_values(array_filter($hits, function ($t) use ($now) {
  return is_numeric($t) && ($now - $t) < 60;
}));
if (count($hits) >= NAI_TTS_BURST_PER_MIN) {
  nai_tts_fail('too_fast');
}
$hits[] = $now;
@file_put_contents($burstFile, json_encode($hits));

/* ---------- WALL 2: server-wide daily character budget ---------- */
$today = date('Y-m-d');
$budgetFile = sys_get_temp_dir() . '/nai_tts_budget_' . $today . '.txt';
$usedToday = file_exists($budgetFile) ? (int)@file_get_contents($budgetFile) : 0;
$need = nai_tts_len($text);

if (($usedToday + $need) > NAI_TTS_DAILY_CHARS) {
  // Budget spent for today. Clients quietly use the device/browser voice
  // instead, so users never see an error — voice just sounds ordinary
  // until midnight.
  nai_tts_fail('daily_budget_reached');
}

/* ---------- Config present? (wp-config already loaded at the top) ---------- */
if (!function_exists('curl_init')) {
  nai_tts_fail('no_curl');
}
if (!defined('ELEVENLABS_API_KEY') || !ELEVENLABS_API_KEY ||
    !defined('ELEVENLABS_VOICE_ID') || !ELEVENLABS_VOICE_ID) {
  nai_tts_fail('not_configured');
}

/* ---------- CACHE: have we already spoken this exact line? ----------
   Repeated lines (the greeting, the limit message, common replies) are
   identical every time. Serving them from disk is instant and free.
   Cache is keyed on the MODEL, the voice AND the text, so changing the
   model (v2 -> v3) or the voice in wp-config.php naturally produces fresh
   audio instead of replaying the old voice. (Without the model in the key,
   the greeting would keep playing in the OLD voice for up to 30 days after
   an upgrade.)
   ------------------------------------------------------------------ */
$cacheDir = __DIR__ . '/nai_tts_cache';
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);

$voiceForKey = defined('ELEVENLABS_VOICE_ID') ? ELEVENLABS_VOICE_ID : '';
$cacheFile = $cacheDir . '/' . md5(NAI_TTS_MODEL . '|' . $voiceForKey . '|' . $text) . '.mp3';

if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 2592000) {
  $cached = @file_get_contents($cacheFile);
  if ($cached !== false && strlen($cached) > 500) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
      'audio'  => base64_encode($cached),
      'format' => 'mp3',
      'cached' => true,
      'chars'  => 0,
    ], JSON_UNESCAPED_UNICODE);
    exit;
  }
}

/* ---------- Generate ---------- */
// Preferred audio quality first, then a format every account can fall back to.
// Audio quality (kbps) costs nothing extra — ElevenLabs bills per character,
// not per bitrate — so we always ask for the fuller 44.1kHz / 128kbps first.
$formats = ['mp3_44100_128', 'mp3_22050_32'];
$baseUrl = 'https://api.elevenlabs.io/v1/text-to-speech/' . rawurlencode(ELEVENLABS_VOICE_ID);

/* VOICE SETTINGS — chosen PER MODEL, because Eleven v3 and the v2 family take
   DIFFERENT parameters. Sending v2's knobs to v3 (or the reverse) gives worse
   audio, or is silently ignored, or is rejected outright. This is the single
   most common reason a "premium" voice still sounds flat.

   Eleven v3 (the expressive model):
     - Emotion comes from the MODEL interpreting the sentence, not from tuning.
       Warm text with real punctuation is what makes it rise and fall — which
       is exactly what nai_speaking.php already asks the teacher to write.
     - stability MUST be exactly 0.0, 0.5 or 1.0 (any other value is rounded to
       the nearest, and some setups reject it). 0.5 = "Natural": genuine
       emotional range while staying clear and consistent — the right balance
       for a voice a learner is trying to follow. 0.0 "Creative" is more
       dramatic but can rush words or add stray sounds; 1.0 "Robust" is flat
       like the old voice. If you want it even more expressive AND can accept
       the occasional oddity, try 0.0.
     - v3 has NO "speed" setting, so it is left out on purpose.
     - style stays 0: v3 does not need it and non-zero style can add artifacts.
     - use_speaker_boost stays on: fuller, clearer, and a little louder, which
       also helps the "too quiet / thin" complaint.

   Multilingual v2 (the automatic fallback): the classic knobs — a little
   emotion via lower stability, natural pace, speaker boost on. Style kept low
   (0.15) because high style on v2 introduces artifacts and latency. */
function nai_tts_voice_settings($modelId) {
  if ($modelId === 'eleven_v3') {
    return [
      'stability'         => 0.5,   // "Natural" — MUST be 0.0 / 0.5 / 1.0
      'similarity_boost'  => 0.75,
      'style'             => 0.0,
      'use_speaker_boost' => true,
    ];
  }
  // eleven_multilingual_v2 (and any other v2-family model)
  return [
    'stability'         => 0.40,
    'similarity_boost'  => 0.80,
    'style'             => 0.15,
    'use_speaker_boost' => true,
    'speed'             => 1.0,
  ];
}

// Try the chosen model first; if it ever fails, drop to Multilingual v2 —
// still warm and human — rather than the flat Flash voice.
$models = [NAI_TTS_MODEL];
if (NAI_TTS_MODEL !== 'eleven_multilingual_v2') {
  $models[] = 'eleven_multilingual_v2';
}

$audio = false; $httpCode = 0; $curlErr = '';
foreach ($models as $modelId) {
  $settings = nai_tts_voice_settings($modelId);
  foreach ($formats as $fmt) {
    $body = json_encode([
      'text'           => $text,
      'model_id'       => $modelId,
      'voice_settings' => $settings,
    ], JSON_UNESCAPED_UNICODE);

    $ch = curl_init($baseUrl . '?output_format=' . $fmt);
    curl_setopt_array($ch, [
      CURLOPT_POST           => true,
      CURLOPT_POSTFIELDS     => $body,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Accept: audio/mpeg',
        'xi-api-key: ' . ELEVENLABS_API_KEY,
      ],
      CURLOPT_CONNECTTIMEOUT => 5,
      CURLOPT_TIMEOUT        => 30,   // v3 is heavier than Flash/v2 — give it room
      CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $audio    = curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($audio !== false && $httpCode === 200 && strlen($audio) > 500) break 2;

    // 401 means the key itself is wrong — nothing else will help
    if ($httpCode === 401) break 2;
  }
}

if ($audio === false || $httpCode !== 200 || strlen($audio) < 500) {
  // Log quietly so you can see WHY if it ever stops working
  $logDir = __DIR__ . '/nai_logs';
  if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
  @file_put_contents(
    $logDir . '/tts_errors.log',
    date('c') . ' http=' . $httpCode . ' curl=' . $curlErr .
    ' body=' . substr((string)$audio, 0, 200) . "\n",
    FILE_APPEND
  );
  // Common causes: balance empty, wrong voice id, key revoked.
  nai_tts_fail($httpCode === 401 ? 'auth_failed' : 'generation_failed');
}

// Only charge the budget for audio we actually produced
@file_put_contents($budgetFile, $usedToday + $need);

// Keep it so this exact line is instant and free next time
@file_put_contents($cacheFile, $audio);

// Light housekeeping: if the cache grows past 400 files, drop the oldest.
// Runs rarely (1 in 50 requests) so it never slows a normal reply.
if (mt_rand(1, 50) === 1) {
  $files = @glob($cacheDir . '/*.mp3');
  if (is_array($files) && count($files) > 400) {
    usort($files, function ($a, $b) { return filemtime($a) - filemtime($b); });
    foreach (array_slice($files, 0, count($files) - 400) as $old) { @unlink($old); }
  }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
  'audio'      => base64_encode($audio),
  'format'     => 'mp3',
  'chars'      => $need,
  'used_today' => $usedToday + $need,
  'budget'     => NAI_TTS_DAILY_CHARS,
], JSON_UNESCAPED_UNICODE);