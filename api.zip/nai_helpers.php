<?php
/**
 * ═══════════════════════════════════════════════════════════
 * NAGALAND AI — SHARED HELPERS (nai_helpers.php)
 * Functions used by both Chat Mode and Student Mode
 * ═══════════════════════════════════════════════════════════
 */

/* =========================================================
   URL FETCH (raw HTML)
   ========================================================= */

function nai_fetch_url_raw($url, $timeout = 12) {
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => $timeout,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (NagalandAI/2.0; https://nagalandai.com)',
    CURLOPT_HTTPHEADER => [
      'Cache-Control: no-cache',
      'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    ],
  ]);
  $body = curl_exec($ch);
  $err  = curl_error($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($body === false || $code >= 400) return [null, $err ?: ("HTTP " . $code)];
  return [$body, null];
}

/* =========================================================
   HTML → CLEAN TEXT
   ========================================================= */

function nai_html_to_clean_text($html) {
  if (!is_string($html) || $html === '') return '';
  $html = preg_replace('#<(script|style|noscript)[^>]*>.*?</\1>#is', ' ', $html);
  $text = strip_tags($html);
  $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  $text = preg_replace('/[ \t]+/', ' ', $text);
  $text = preg_replace("/\r\n|\r|\n/", "\n", $text);
  $text = preg_replace("/\n{3,}/", "\n\n", $text);
  return trim($text);
}

/* =========================================================
   PAGE TEXT CACHE (for Aloto bio, scholarship pages, etc.)
   ========================================================= */

function nai_get_page_text_cached($cacheKey, $url, $ttlSeconds = 21600, $maxChars = 16000) {
  $cacheFile = __DIR__ . '/nai_page_cache.json';
  $now = time();

  $cache = [];
  if (file_exists($cacheFile)) {
    $decoded = json_decode(@file_get_contents($cacheFile), true);
    if (is_array($decoded)) $cache = $decoded;
  }

  if (isset($cache[$cacheKey]['fetched_at'], $cache[$cacheKey]['text']) && $ttlSeconds > 0) {
    if (($now - (int)$cache[$cacheKey]['fetched_at']) < $ttlSeconds) {
      return (string)$cache[$cacheKey]['text'];
    }
  }

  [$body, $err] = nai_fetch_url_raw($url, 15);
  if ($err || !$body) return '';

  $text = nai_html_to_clean_text($body);

  $pos = mb_stripos($text, 'Aloto');
  if ($pos !== false) {
    $start = max(0, $pos - 2500);
    $text = mb_substr($text, $start, $maxChars);
  } else {
    $text = mb_substr($text, 0, $maxChars);
  }

  $cache[$cacheKey] = ['fetched_at' => $now, 'text' => $text, 'url' => $url];
  @file_put_contents($cacheFile, json_encode($cache, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  return $text;
}

/* =========================================================
   WEATHER CODE LABELS
   ========================================================= */

function nai_weather_code_label($code) {
  $map = [
    0=>'Clear sky',1=>'Mainly clear',2=>'Partly cloudy',3=>'Overcast',
    45=>'Fog',48=>'Rime fog',51=>'Light drizzle',53=>'Moderate drizzle',
    55=>'Dense drizzle',56=>'Light freezing drizzle',57=>'Dense freezing drizzle',
    61=>'Slight rain',63=>'Moderate rain',65=>'Heavy rain',
    66=>'Light freezing rain',67=>'Heavy freezing rain',
    71=>'Slight snow',73=>'Moderate snow',75=>'Heavy snow',77=>'Snow grains',
    80=>'Slight rain showers',81=>'Moderate rain showers',82=>'Violent rain showers',
    85=>'Slight snow showers',86=>'Heavy snow showers',
    95=>'Thunderstorm',96=>'Thunderstorm with slight hail',99=>'Thunderstorm with heavy hail',
  ];
  return $map[$code] ?? ('Code ' . (string)$code);
}

/* =========================================================
   WEATHER FETCH + CACHE (Open-Meteo, no API key needed)
   ========================================================= */

function nai_get_weather_cached($placeKey, $lat, $lon, $ttlSeconds = 600) {
  $cacheFile = __DIR__ . '/nai_weather_cache.json';
  $now = time();

  $cache = [];
  if (file_exists($cacheFile)) {
    $decoded = json_decode(@file_get_contents($cacheFile), true);
    if (is_array($decoded)) $cache = $decoded;
  }

  if (isset($cache[$placeKey]['fetched_at'], $cache[$placeKey]['data']) && $ttlSeconds > 0) {
    if (($now - (int)$cache[$placeKey]['fetched_at']) < $ttlSeconds) {
      return $cache[$placeKey]['data'];
    }
  }

  $url = 'https://api.open-meteo.com/v1/forecast'
    . '?latitude=' . rawurlencode((string)$lat)
    . '&longitude=' . rawurlencode((string)$lon)
    . '&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code'
    . '&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code'
    . '&forecast_days=1&timezone=Asia%2FKolkata';

  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => 12,
    CURLOPT_USERAGENT => 'NagalandAI-Weather/2.0',
    CURLOPT_HTTPHEADER => ['Accept: application/json'],
  ]);
  $body = curl_exec($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($body === false || $code >= 400) return null;
  $json = json_decode($body, true);
  if (!is_array($json)) return null;

  $current = $json['current'] ?? [];
  $daily = $json['daily'] ?? [];

  $data = [
    'place' => $placeKey,
    'current_time' => $current['time'] ?? '',
    'temperature_c' => $current['temperature_2m'] ?? null,
    'humidity_pct' => $current['relative_humidity_2m'] ?? null,
    'wind_kmh' => $current['wind_speed_10m'] ?? null,
    'weather_label' => isset($current['weather_code']) ? nai_weather_code_label((int)$current['weather_code']) : '',
    'today_date' => $daily['time'][0] ?? '',
    'today_max_c' => $daily['temperature_2m_max'][0] ?? null,
    'today_min_c' => $daily['temperature_2m_min'][0] ?? null,
    'today_rain_mm' => $daily['precipitation_sum'][0] ?? null,
    'today_weather_label' => isset($daily['weather_code'][0]) ? nai_weather_code_label((int)$daily['weather_code'][0]) : '',
    'source' => 'Open-Meteo',
  ];

  $cache[$placeKey] = ['fetched_at' => $now, 'data' => $data];
  @file_put_contents($cacheFile, json_encode($cache, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  return $data;
}

/* =========================================================
   NAGALAND PLACE DETECTOR (for weather)
   ========================================================= */

function nai_detect_nagaland_place($message) {
  $places = [
    'Kohima'       => [25.6751, 94.1086],
    'Dimapur'      => [25.9117, 93.7277],
    'Chumoukedima' => [25.8560, 93.7260],
    'Mokokchung'   => [26.3240, 94.5180],
    'Tuensang'     => [26.2670, 94.8250],
    'Mon'          => [26.7330, 95.0560],
    'Wokha'        => [26.1000, 94.2590],
    'Zunheboto'    => [25.9660, 94.5180],
    'Phek'         => [25.6670, 94.5000],
    'Kiphire'      => [25.8750, 94.7810],
    'Longleng'     => [26.4800, 94.8160],
    'Peren'        => [25.5120, 93.7360],
    'Tseminyu'     => [26.2210, 94.3680],
    'Niuland'      => [25.7330, 93.7000],
    'Shamator'     => [26.2840, 94.9700],
    'Noklak'       => [26.1860, 95.0260],
    'Meluri'       => [25.6410, 94.6790],
  ];

  foreach ($places as $name => $coords) {
    if (preg_match('/\b' . preg_quote(strtolower($name), '/') . '\b/i', $message)) {
      return [$name, $coords[0], $coords[1]];
    }
  }
  return [null, null, null];
}

/* =========================================================
   SCHOLARSHIP FETCH + CACHE
   ========================================================= */

function nai_get_scholarship_sources_text($sources, $ttlSeconds = 900, $maxChars = 12000) {
  $cacheFile = __DIR__ . '/nai_scholarship_cache.json';
  $now = time();

  $cache = [];
  if (file_exists($cacheFile)) {
    $decoded = json_decode(@file_get_contents($cacheFile), true);
    if (is_array($decoded)) $cache = $decoded;
  }

  $out = "";
  foreach ($sources as $s) {
    $url = $s['url'];
    $key = md5($url);

    $text = '';
    if ($ttlSeconds > 0 && isset($cache[$key]['fetched_at'], $cache[$key]['text'])) {
      if (($now - (int)$cache[$key]['fetched_at']) < $ttlSeconds) {
        $text = (string)$cache[$key]['text'];
      }
    }

    if ($text === '') {
      [$body, $err] = nai_fetch_url_raw($url, 15);
      if (!$err && $body) {
        $text = nai_html_to_clean_text($body);
        if (mb_strlen($text) > $maxChars) $text = mb_substr($text, 0, $maxChars);
      }
      $cache[$key] = ['fetched_at' => $now, 'text' => $text, 'url' => $url, 'name' => $s['name'] ?? 'Official Source'];
      @file_put_contents($cacheFile, json_encode($cache, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    $out .= "SOURCE: " . ($s['name'] ?? '') . "\nLINK: {$url}\nTEXT: " . ($text ?: "[Unavailable]") . "\n\n";
  }
  return $out;
}