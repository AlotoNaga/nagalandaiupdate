<?php
// public_html/api/nai_rss.php
// Library ONLY: RSS fetch/parse/cache + article fetch/extract/cache
// ❌ No headers, ❌ no echo, ❌ no exit

date_default_timezone_set('Asia/Kolkata');

/* =========================================================
   FETCH URL (RSS or HTML)
   ========================================================= */
function nai_fetch_url($url, $timeout = 12) {
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => $timeout,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (NagalandAI-RSS/1.0; +https://nagalandai.com)',
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_ENCODING => '',
  ]);
  $body = curl_exec($ch);
  $err  = curl_error($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($body === false || $code >= 400) return [null, $err ?: ("HTTP " . $code)];
  return [$body, null];
}

/* =========================================================
   PARSE RSS / ATOM
   ========================================================= */
function nai_parse_rss($xmlString, $sourceName, $maxItems = 4) {
  $items = [];
  libxml_use_internal_errors(true);
  $xml = simplexml_load_string($xmlString, "SimpleXMLElement", LIBXML_NOCDATA);
  if (!$xml) return $items;

  if (isset($xml->channel->item)) {
    $n = 0;
    foreach ($xml->channel->item as $it) {
      $title = trim((string)$it->title);
      $link  = trim((string)$it->link);
      $date  = trim((string)$it->pubDate);
      $desc  = trim(strip_tags((string)$it->description));

      if ($title && $link) {
        $items[] = [
          'source' => $sourceName,
          'title' => $title,
          'url' => $link,
          'published' => $date ?: null,
          'summary' => mb_substr($desc, 0, 240),
        ];
        if (++$n >= $maxItems) break;
      }
    }
    return $items;
  }

  if (isset($xml->entry)) {
    $n = 0;
    foreach ($xml->entry as $en) {
      $title = trim((string)$en->title);
      $link = '';
      foreach ($en->link as $lnk) {
        if (!empty($lnk['href'])) { $link = (string)$lnk['href']; break; }
      }
      $date = trim((string)($en->updated ?: $en->published));
      $desc = trim(strip_tags((string)($en->summary ?: $en->content)));

      if ($title && $link) {
        $items[] = [
          'source' => $sourceName,
          'title' => $title,
          'url' => $link,
          'published' => $date ?: null,
          'summary' => mb_substr($desc, 0, 240),
        ];
        if (++$n >= $maxItems) break;
      }
    }
  }

  return $items;
}

/* =========================================================
   RSS LIST CACHE (FIX: never cache empty results)
   ========================================================= */
function nai_get_rss_items_cached($sources, $cacheFile, $ttlSeconds = 300, $maxTotal = 18) {
  // ── Check cache ──
  if (file_exists($cacheFile)) {
    $cached = json_decode(@file_get_contents($cacheFile), true);
    if (isset($cached['fetched_at'], $cached['items']) &&
        (time() - $cached['fetched_at']) < $ttlSeconds) {
      // ✅ FIX: Only return cache if it actually has items
      if (!empty($cached['items'])) {
        return array_slice($cached['items'], 0, $maxTotal);
      }
      // Cache is empty — fall through and retry fetching
    }
  }

  // ── Fetch fresh from all sources ──
  $all = [];
  $logDir = __DIR__ . '/nai_logs';
  if (!is_dir($logDir)) @mkdir($logDir, 0755, true);

  $logLines = [];
  $logLines[] = "[" . date('Y-m-d H:i:s') . "] RSS FETCH STARTED — " . count($sources) . " sources";

  foreach ($sources as $src) {
    $name = $src['name'] ?? 'Unknown';
    $url  = $src['url'] ?? '';
    if (!$url) {
      $logLines[] = "  ❌ SKIP: {$name} — no URL";
      continue;
    }

    [$xml, $err] = nai_fetch_url($url);

    if ($err || !$xml) {
      $logLines[] = "  ❌ FAIL: {$name} — {$err}";
      continue;
    }

    $parsed = nai_parse_rss($xml, $name, 4);
    $count  = count($parsed);

    if ($count > 0) {
      $logLines[] = "  ✅ OK: {$name} — {$count} items";
      $all = array_merge($all, $parsed);
    } else {
      $logLines[] = "  ⚠️ EMPTY: {$name} — fetched OK but 0 items parsed";
    }

    if (count($all) >= $maxTotal) break;
  }

  $logLines[] = "TOTAL ITEMS: " . count($all);
  $logLines[] = "---";

  // ✅ Write log (append, keep last 500 lines max)
  $logFile = $logDir . '/rss_fetch.log';
  $existingLog = file_exists($logFile) ? file($logFile, FILE_IGNORE_NEW_LINES) : [];
  $existingLog = array_merge($existingLog, $logLines);
  $existingLog = array_slice($existingLog, -500); // Keep last 500 lines
  @file_put_contents($logFile, implode("\n", $existingLog) . "\n");

  // ✅ FIX: Only cache if we actually got items — never cache empty results
  if (!empty($all)) {
    @file_put_contents($cacheFile, json_encode([
      'fetched_at' => time(),
      'items' => $all
    ], JSON_UNESCAPED_UNICODE));
  }

  return array_slice($all, 0, $maxTotal);
}

/* =========================================================
   ARTICLE EXTRACTION + CACHE
   ========================================================= */
function nai_extract_article_text($html) {
  $html = preg_replace('#<(script|style|noscript)[^>]*>.*?</\1>#is', '', $html);
  if (preg_match('#<article\b[^>]*>(.*?)</article>#is', $html, $m)) {
    $html = $m[1];
  }
  $text = trim(preg_replace('/\s+/', ' ',
    html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5)
  ));
  return mb_strlen($text) >= 250 ? $text : '';
}

function nai_get_article_text_cached($url, $ttlSeconds = 21600, $maxChars = 12000) {
  $dir = __DIR__ . '/nai_article_cache';
  if (!is_dir($dir)) @mkdir($dir, 0755, true);
  $path = $dir . '/' . md5($url) . '.json';

  if (file_exists($path)) {
    $cached = json_decode(@file_get_contents($path), true);
    if ((time() - $cached['fetched_at']) < $ttlSeconds) {
      return mb_substr($cached['text'], 0, $maxChars);
    }
  }

  [$html, $err] = nai_fetch_url($url, 15);
  $text = (!$err && $html) ? nai_extract_article_text($html) : '';

  // Only cache non-empty results — never cache failed fetches
  if ($text !== '') {
    @file_put_contents($path, json_encode([
      'fetched_at' => time(),
      'text' => mb_substr($text, 0, $maxChars)
    ], JSON_UNESCAPED_UNICODE));
  }

  return mb_substr($text, 0, $maxChars);
}