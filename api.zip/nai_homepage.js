/* nai_homepage.js v1.2 (Jul 2026): history is cleaned of links before sending (a link left in history could get the request blocked, breaking that one conversation permanently while a new chat worked). v1.1: resilient callApi with silent retry; error detector now logs to console only — users never see red debug bars */
window.onerror=function(m,u,l){try{console.error('NAI JS ERROR: '+m+' (line '+l+')')}catch(e){}};

(function(){
  /* KEY FIX: Changed <form> to <div> and button type="submit" to type="button"
     This eliminates ALL form submission/page reload issues entirely.
     Send is now triggered ONLY by JavaScript click/keydown handlers. */

  var msgBox=document.getElementById("nai-messages");
  var input=document.getElementById("nai-input");
  var sendBtn=document.getElementById("nai-send");
  var note=document.getElementById("nai-note");
  var tabChat=document.getElementById("nai-tab-chat");
  var tabStudent=document.getElementById("nai-tab-student");
  var studentBar=document.getElementById("nai-student-bar");
  var subjectSelect=document.getElementById("nai-subject");
  var gradeSelect=document.getElementById("nai-grade");
  var app=document.getElementById("nagaland-ai-app");
  var canvas=document.getElementById("nagaland-stars");
  var ctx=canvas?canvas.getContext("2d"):null;
  var historyBtn=document.getElementById("nai-history-btn");
  var historyDropdown=document.getElementById("nai-history-dropdown");
  var hdList=document.getElementById("nai-hd-list");
  var hdNewBtn=document.getElementById("nai-hd-new");
  var newHpBtn=document.getElementById("nai-new-hp");

  var stars=[];
  var history=[];
  var currentMode="chat";
  var welcomeBubble=null;
  var API_ENDPOINT="/api/chat.php";
  var _naiSessionToken='';
  var _naiFingerprint='';

  /* == Helpers == */
  function escapeHtml(s){return String(s).replace(/[&<>"']/g,function(m){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]})}
  function linkify(t){var s=escapeHtml(t);return s.replace(/(https?:\/\/[^\s<]+)/g,function(u){var c=u.replace(/[)\]}>,.]+$/g,"");var r=u.slice(c.length);return'<a href="'+c+'" target="_blank" rel="noopener noreferrer">'+c+'</a>'+r})}
  function parseMarkdown(t){var s=escapeHtml(t),lines=s.split('\n'),h='',inUl=false,inOl=false;for(var i=0;i<lines.length;i++){var line=lines[i],tr=line.trim();if(/^-{3,}$/.test(tr)||/^\*{3,}$/.test(tr)){if(inUl){h+='</ul>';inUl=false}if(inOl){h+='</ol>';inOl=false}h+='<hr>';continue}var hm=tr.match(/^(#{1,4})\s+(.+)$/);if(hm){if(inUl){h+='</ul>';inUl=false}if(inOl){h+='</ol>';inOl=false}h+='<div class="nai-md-heading">'+hm[2]+'</div>';continue}if(/^[-*]\s+(.+)$/.test(tr)){if(inOl){h+='</ol>';inOl=false}if(!inUl){h+='<ul>';inUl=true}h+='<li>'+tr.replace(/^[-*]\s+/,'')+'</li>';continue}if(/^\d+\.\s+(.+)$/.test(tr)){if(inUl){h+='</ul>';inUl=false}if(!inOl){h+='<ol>';inOl=true}h+='<li>'+tr.replace(/^\d+\.\s+/,'')+'</li>';continue}if(inUl){h+='</ul>';inUl=false}if(inOl){h+='</ol>';inOl=false}if(tr===''){h+='<br>'}else{h+='<p>'+line+'</p>'}}if(inUl)h+='</ul>';if(inOl)h+='</ol>';h=h.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');h=h.replace(/\*(.+?)\*/g,'<em>$1</em>');h=h.replace(/`([^`]+)`/g,'<code>$1</code>');h=h.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');h=h.replace(/(^|[^"=])(https?:\/\/[^\s<"]+)/g,function(match,prefix,url){var c=url.replace(/[)\]}>,.]+$/,'');var r=url.slice(c.length);return prefix+'<a href="'+c+'" target="_blank" rel="noopener noreferrer">'+c+'</a>'+r});return h}
  function generateId(){return'chat_'+Date.now()+'_'+Math.random().toString(36).substr(2,6)}
  function getTimeLabel(ts){if(!ts)return'';var d=Date.now()-ts;if(d<60000)return'Now';if(d<3600000)return Math.floor(d/60000)+'m';if(d<86400000)return Math.floor(d/3600000)+'h';return new Date(ts).toLocaleDateString('en-IN',{day:'numeric',month:'short'})}

  /* == Multi-chat storage == */
  var MULTI_KEY='nai_multi_chats_v3';
  function loadAllChats(){try{var r=localStorage.getItem(MULTI_KEY);if(r){var p=JSON.parse(r);if(p&&Array.isArray(p.chats))return p}}catch(e){}return{chats:[],activeId:null}}
  function saveAllChats(s){try{localStorage.setItem(MULTI_KEY,JSON.stringify(s))}catch(e){}}
  function getActiveChat(s){if(!s||!s.activeId||!Array.isArray(s.chats))return null;for(var i=0;i<s.chats.length;i++){if(s.chats[i].id===s.activeId)return s.chats[i]}return null}
  var store=loadAllChats();

  /* == Mode switching == */
  function switchMode(mode,silent){try{currentMode=mode;if(mode==="student"){if(tabStudent)tabStudent.classList.add("nai-mode-active");if(tabChat)tabChat.classList.remove("nai-mode-active");if(studentBar)studentBar.style.display="flex";if(input)input.placeholder="Ask your teacher anything..."}else{if(tabChat)tabChat.classList.add("nai-mode-active");if(tabStudent)tabStudent.classList.remove("nai-mode-active");if(studentBar)studentBar.style.display="none";if(input)input.placeholder="Ask Nagaland AI anything..."}if(!silent){var a=getActiveChat(store);if(a){a.mode=mode;saveAllChats(store)}if(history.length===0)showWelcome()}}catch(e){}}
  try{if(tabChat)tabChat.addEventListener("click",function(){switchMode("chat")})}catch(e){}
  try{if(tabStudent)tabStudent.addEventListener("click",function(){switchMode("student")})}catch(e){}

  /* == Welcome == */
  function showWelcome(){if(welcomeBubble){welcomeBubble.remove();welcomeBubble=null}welcomeBubble=document.createElement("div");welcomeBubble.className="nai-bubble nai-ai";welcomeBubble.textContent=currentMode==="student"?"Hi! I'm your Nagaland AI Teacher. Pick your subject and grade above, or just ask me anything.":"Hi! I'm Nagaland AI - ask me about news, weather, scholarships, Naga languages, or anything else.";if(msgBox)msgBox.appendChild(welcomeBubble)}
  function removeWelcome(){if(!welcomeBubble)return;welcomeBubble.remove();welcomeBubble=null}

  /* == Dropdown == */
  try{if(historyBtn)historyBtn.addEventListener('click',function(e){e.stopPropagation();if(historyDropdown){if(historyDropdown.classList.contains('nai-hd-open'))historyDropdown.classList.remove('nai-hd-open');else{renderHistoryDropdown();historyDropdown.classList.add('nai-hd-open')}}})}catch(e){}
  try{document.addEventListener('click',function(e){try{if(historyDropdown&&historyDropdown.classList.contains('nai-hd-open')){var wrap=document.getElementById('nai-history-wrap');if(wrap&&!wrap.contains(e.target))historyDropdown.classList.remove('nai-hd-open')}}catch(ex){}})}catch(e){}

  function renderHistoryDropdown(){try{if(!hdList)return;hdList.innerHTML='';if(!store.chats||!store.chats.length){hdList.innerHTML='<div class="nai-hd-empty">No chats yet</div>';return}var sorted=store.chats.slice().sort(function(a,b){return(b.updatedAt||0)-(a.updatedAt||0)});for(var s=0;s<Math.min(sorted.length,15);s++){(function(chat){var item=document.createElement('div');item.className='nai-hd-item'+(chat.id===store.activeId?' nai-hd-active':'');item.innerHTML='<div class="nai-hd-item-title">'+escapeHtml(chat.title||'New Chat')+'</div><div class="nai-hd-item-time">'+getTimeLabel(chat.updatedAt||chat.createdAt)+'</div><button class="nai-hd-item-del" type="button">&times;</button>';item.addEventListener('click',function(e){if(e.target.className&&e.target.className.indexOf('nai-hd-item-del')!==-1)return;switchToChat(chat.id);if(historyDropdown)historyDropdown.classList.remove('nai-hd-open')});var del=item.querySelector('.nai-hd-item-del');if(del)del.addEventListener('click',function(e){e.stopPropagation();deleteChat(chat.id);renderHistoryDropdown()});hdList.appendChild(item)})(sorted[s])}}catch(e){}}

  /* == Chat management == */
  function switchToChat(chatId){store.activeId=chatId;var chat=getActiveChat(store);if(!chat)return;history=Array.isArray(chat.history)?chat.history:[];switchMode(chat.mode||'chat',true);if(msgBox)msgBox.innerHTML='';welcomeBubble=null;if(!chat.messages||!chat.messages.length){showWelcome()}else{for(var i=0;i<chat.messages.length;i++){var m=chat.messages[i];if(!m)continue;var div=document.createElement("div");div.className="nai-bubble "+(m.who==="user"?"nai-user":"nai-ai");if(m.who==="ai")div.innerHTML=m.html||parseMarkdown(m.text||"");else div.textContent=m.text||"";if(msgBox)msgBox.appendChild(div)}if(msgBox)msgBox.scrollTop=msgBox.scrollHeight}saveAllChats(store);setNote('')}

  function createNewChat(){var nc={id:generateId(),title:'New Chat',mode:currentMode,history:[],messages:[],createdAt:Date.now(),updatedAt:Date.now()};store.chats.unshift(nc);store.activeId=nc.id;history=[];welcomeBubble=null;saveAllChats(store);if(msgBox)msgBox.innerHTML='';showWelcome();setNote('');if(input)input.focus();if(historyDropdown)historyDropdown.classList.remove('nai-hd-open')}
  try{if(hdNewBtn)hdNewBtn.addEventListener('click',createNewChat)}catch(e){}
  try{if(newHpBtn)newHpBtn.addEventListener('click',createNewChat)}catch(e){}

  function deleteChat(chatId){store.chats=store.chats.filter(function(c){return c.id!==chatId});if(store.activeId===chatId){welcomeBubble=null;if(store.chats.length){switchToChat(store.chats[0].id)}else{store.activeId=null;history=[];if(msgBox)msgBox.innerHTML='';saveAllChats(store);showWelcome()}}else{saveAllChats(store)}}

  function saveActiveChat(){try{var active=getActiveChat(store);if(!active)return;active.history=history;active.mode=currentMode;var bubbles=msgBox?msgBox.querySelectorAll('.nai-bubble'):[];var msgs=[];for(var i=0;i<bubbles.length;i++){var el=bubbles[i];if(el.classList.contains('nai-typing'))continue;if(el===welcomeBubble)continue;msgs.push({who:el.classList.contains("nai-user")?"user":"ai",html:el.innerHTML,text:el.textContent})}active.messages=msgs;active.updatedAt=Date.now();if(active.title==='New Chat'&&msgs.length>0){for(var j=0;j<msgs.length;j++){if(msgs[j].who==='user'){active.title=String(msgs[j].text).substring(0,50);break}}}saveAllChats(store)}catch(e){}}

  function ensureActiveChat(){if(!store.activeId||!getActiveChat(store)){var nc={id:generateId(),title:'New Chat',mode:currentMode,history:[],messages:[],createdAt:Date.now(),updatedAt:Date.now()};store.chats.unshift(nc);store.activeId=nc.id;history=[];saveAllChats(store)}}

  /* == Stars == */
  try{
    function resizeCanvas(){if(!app||!canvas)return;var r=app.getBoundingClientRect();canvas.width=Math.max(1,Math.floor(r.width));canvas.height=Math.max(1,Math.floor(r.height))}
    function initStars(){if(!canvas)return;stars=[];var c=window.innerWidth<768?120:220;for(var i=0;i<c;i++){stars.push({x:Math.random()*canvas.width,y:Math.random()*canvas.height,r:Math.random()*1.6+0.4,o:Math.random()*0.8+0.2,s:Math.random()*0.55+0.08,t:(Math.random()*0.02+0.01)*(Math.random()>0.5?1:-1)})}}
    function drawStars(){if(!ctx||!canvas)return;ctx.clearRect(0,0,canvas.width,canvas.height);for(var j=0;j<stars.length;j++){var st=stars[j];st.o+=st.t;if(st.o>1){st.o=1;st.t*=-1}if(st.o<0.2){st.o=0.2;st.t*=-1}ctx.beginPath();ctx.arc(st.x,st.y,st.r,0,Math.PI*2);ctx.fillStyle="rgba(255,255,255,"+st.o+")";ctx.fill();st.y+=st.s;if(st.y>canvas.height){st.y=0;st.x=Math.random()*canvas.width}}requestAnimationFrame(drawStars)}
    resizeCanvas();initStars();drawStars()
  }catch(e){}

  /* == Chat functions == */
  function addBubble(text,who){removeWelcome();ensureActiveChat();var div=document.createElement("div");div.className="nai-bubble "+(who==="user"?"nai-user":"nai-ai");div.innerHTML=(who==="user")?escapeHtml(text):parseMarkdown(text);if(msgBox){msgBox.appendChild(div);msgBox.scrollTop=msgBox.scrollHeight}saveActiveChat();return div}
  function setNote(text){if(!note)return;if(!text){note.style.display="none";note.innerHTML="";return}note.style.display="block";if(String(text).indexOf("<a ")!==-1)note.innerHTML=text;else note.innerHTML=linkify(String(text))}
  function autoGrow(){if(!input)return;input.style.height="auto";input.style.height=Math.min(input.scrollHeight,160)+"px"}
  try{if(input)input.addEventListener("input",autoGrow)}catch(e){}

  /* == Init == */
  try{if(store.activeId&&getActiveChat(store)){switchToChat(store.activeId)}else{showWelcome()}}catch(e){showWelcome()}

  /* == Card clicks == */
  try{var cards=document.querySelectorAll(".nai-card");for(var c=0;c<cards.length;c++){cards[c].addEventListener("click",function(){var p=this.getAttribute("data-prompt")||"";var m=this.getAttribute("data-mode")||"";if(m==="student")switchMode("student");if(input){input.value=p;autoGrow();input.focus()}})}}catch(e){}

  /* == Security token == */
  try{fetch('/api/nai_init.php').then(function(r){return r.json()}).then(function(d){_naiSessionToken=d.token||''}).catch(function(){})}catch(e){}
  function naiGetFingerprint(){if(_naiFingerprint)return _naiFingerprint;try{var d=[screen.width,screen.height,screen.colorDepth,navigator.language,navigator.platform,new Date().getTimezoneOffset(),navigator.hardwareConcurrency||0,navigator.deviceMemory||0].join('|');var h=0;for(var i=0;i<d.length;i++){h=((h<<5)-h+d.charCodeAt(i))&0x7FFFFFFF}_naiFingerprint=h.toString(36)}catch(e){_naiFingerprint='x'}return _naiFingerprint}

  /* == API call == */
  function naiCleanHistory(h){if(!Array.isArray(h))return[];var out=[];for(var i=0;i<h.length;i++){var e=h[i];if(!e||typeof e!=='object')continue;var t=String(e.content==null?'':e.content);t=t.replace(/\[([^\]]+)\]\((?:https?:\/\/|\/)[^\s)]*\)/g,'$1');t=t.replace(/https?:\/\/[^\s]+/g,'(link)');t=t.replace(/\s+/g,' ').trim();if(t.length>600)t=t.slice(0,600)+'...';if(t)out.push({role:e.role==='assistant'?'assistant':'user',content:t});}return out;}

  function callApi(userMessage){
    /* v1.1: resilient call.
       If the hosting layer blocks a request (plain "Forbidden" text, timeout
       page, any non-JSON body) or the network hiccups, we quietly wait 1.8s
       and retry ONCE before showing anything. If it still fails, users see a
       friendly sentence — never raw code errors like "Unexpected token".
       Real JSON replies and real JSON error messages (limits, login) behave
       exactly as before. */
    var payload={message:userMessage,history:naiCleanHistory(history),mode:currentMode,_nai_tok:_naiSessionToken,_nai_fp:naiGetFingerprint()};
    if(currentMode==="student"){if(subjectSelect&&subjectSelect.value)payload.subject=subjectSelect.value;if(gradeSelect&&gradeSelect.value)payload.grade=gradeSelect.value}
    function attempt(){
      return fetch(API_ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)})
        .catch(function(){var t=new Error("__nai_transient__");t.naiTransient=true;throw t})
        .then(function(res){
          return res.text().then(function(raw){
            var data=null;
            try{data=JSON.parse(raw)}catch(err){}
            if(data===null){var t=new Error("__nai_transient__");t.naiTransient=true;throw t}
            if(!res.ok)throw new Error((data&&(data.error||data.message))||"Something went wrong.");
            return data.reply||""
          })
        })
    }
    return attempt().catch(function(e){
      if(!(e&&e.naiTransient))throw e;
      return new Promise(function(r){setTimeout(r,1800)}).then(attempt).catch(function(e2){
        if(e2&&e2.naiTransient)throw new Error("The server is a little busy right now. Please wait a few seconds and send your message again.");
        throw e2
      })
    })
  }

  /* == Send message == */
  function sendMessage(){removeWelcome();var userText=(input?input.value||"":"").trim();if(!userText)return;setNote("");addBubble(userText,"user");history.push({role:"user",content:userText});saveActiveChat();if(input)input.value="";autoGrow();if(sendBtn)sendBtn.disabled=true;var thinking=document.createElement("div");thinking.className="nai-bubble nai-ai nai-typing";thinking.innerHTML='<div class="nai-shimmer"><div class="nai-shimmer-dot"></div><div class="nai-shimmer-line"></div><div class="nai-shimmer-line"></div><div class="nai-shimmer-line"></div></div>';if(msgBox){msgBox.appendChild(thinking);msgBox.scrollTop=msgBox.scrollHeight}callApi(userText).then(function(reply){thinking.classList.remove("nai-typing");var ft=reply||"(No response)";thinking.innerHTML=parseMarkdown(ft);history.push({role:"assistant",content:ft});saveActiveChat();renderHistoryDropdown()}).catch(function(e){thinking.classList.remove("nai-typing");var et=String((e&&e.message)?e.message:"I couldn't reply right now.");if(et.toLowerCase().indexOf("log in")!==-1||et.toLowerCase().indexOf("login")!==-1){et='Please <a href="/login/" target="_blank">login</a> or <a href="/register/" target="_blank">create an account</a> to continue chatting.'}if(et.indexOf("<a ")!==-1)thinking.innerHTML=et;else thinking.innerHTML=linkify(et);setNote(et);saveActiveChat()}).then(function(){if(sendBtn)sendBtn.disabled=false;if(input)input.focus()}).catch(function(){if(sendBtn)sendBtn.disabled=false})}

  /* == SEND BUTTON CLICK (not form submit - no reload possible) == */
  try{if(sendBtn)sendBtn.addEventListener("click",function(){sendMessage()})}catch(e){}
  try{if(input)input.addEventListener("keydown",function(e){if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage()}})}catch(e){}

})();


/* =====================================================================
   APP GATE — merged in so NO page editing is needed.

   This used to live in a separate file that had to be added to the page
   with a <script> tag. That step kept getting lost, which is why the
   gate was never actually running. It now travels with this file: you
   upload this one file and the gate is live.

   Desktop        -> full chat, untouched.
   Mobile browser -> "Chat is now in the app" + store buttons.
   Inside the app -> "Chat is in the app", pointing at the Chat tab,
                     with no download buttons (they already have it).

   Safe to keep /api/nai_app_gate.js on the server as well — the code
   below refuses to apply itself twice.
   ===================================================================== */
(function () {
  'use strict';

  function run() {
    var ua = navigator.userAgent || '';
    var isAndroid = /android/i.test(ua);
    var isIOS = /iPad|iPhone|iPod/.test(ua);

    // Desktop keeps the full chat experience — nothing to do.
    if (!isAndroid && !isIOS) return;

    /* Is this page being shown INSIDE our app?
       Two independent signals, either is enough:
         1. the flag the app injects on pages it opens as a tab
         2. the WebView signature — Android WebViews carry "; wv)", and
            iOS WKWebView has no "Safari" in its user agent  */
    var injectedFlag = (window.IS_NAGALAND_AI_APP === true ||
                        window.IS_NAGALAND_ME_APP === true);
    var looksLikeWebView = (isAndroid && /;\s?wv\)/i.test(ua)) ||
                           (isIOS && !/Safari/i.test(ua));
    var insideApp = injectedFlag || looksLikeWebView;

    /* Find whichever chat panel this page has.
       Homepage  -> a panel inside #nagaland-ai-app
       Chat page -> the whole #nagaland-ai-chat-app screen  */
    var host = document.querySelector('#nagaland-ai-app .nai-chat');
    var fullScreen = false;
    if (!host) {
      host = document.getElementById('nagaland-ai-chat-app');
      fullScreen = true;
    }
    if (!host) return;              // neither panel on this page
    if (host.querySelector('.naigate')) return;   // already applied

    injectStyles();

    var gate = document.createElement('div');
    gate.className = 'naigate' + (fullScreen ? ' naigate-full' : '');

    if (insideApp) {
      // Already in the app. Sending them to a store would be nonsense.
      gate.innerHTML =
        '<div class="naigate-icon">&#128172;</div>' +
        '<div class="naigate-title">Chat is in the app</div>' +
        '<div class="naigate-sub">You are viewing our website inside the app. ' +
        'Close this window and use the Chat tab, where your conversations ' +
        'and memory are saved.</div>' +
        '<div class="naigate-note">Tap the X at the top to go back to chat.</div>';
    } else {
      gate.innerHTML =
        '<div class="naigate-icon">&#10024;</div>' +
        '<div class="naigate-title">Chat is now in the app</div>' +
        '<div class="naigate-sub">Nagaland AI chat has moved to our free mobile app. ' +
        'Faster, smoother, and built for your phone.</div>' +
        (isIOS
          ? '<a class="naigate-btn" href="https://apps.apple.com/app/id6772763733">Download on the App Store</a>'
          : '<a class="naigate-btn" href="https://play.google.com/store/apps/details?id=com.nagalandme.nagalandai">Get it on Google Play</a>') +
        (isIOS
          ? '<a class="naigate-btn naigate-gold" href="https://play.google.com/store/apps/details?id=com.nagalandme.nagalandai">Android? Get it on Google Play</a>'
          : '<a class="naigate-btn naigate-gold" href="https://apps.apple.com/app/id6772763733">iPhone? Download on the App Store</a>') +
        '<div class="naigate-note">100% free &middot; No login required &middot; ' +
        'Chat also available on desktop at nagalandai.com</div>' +
        (fullScreen ? '<a class="naigate-home" href="/">Back to nagalandai.com</a>' : '');
    }

    host.appendChild(gate);

    // Disable the inputs behind the cover, whichever layout this is
    ['nai-input', 'nai-send', 'naic-input', 'naic-send'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.disabled = true;
    });
  }

  function injectStyles() {
    if (document.getElementById('naigate-styles')) return;
    var css =
      '.naigate{position:absolute;inset:0;z-index:60;display:flex;flex-direction:column;' +
      'align-items:center;justify-content:center;text-align:center;padding:26px 20px;' +
      'border-radius:22px;font-family:"Outfit",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;' +
      'background:linear-gradient(180deg,rgba(8,12,20,0.96),rgba(6,10,16,0.99))}' +
      '.naigate-full{position:fixed;z-index:99999;border-radius:0;padding:28px 22px;' +
      'background:radial-gradient(ellipse at bottom,#1b2735 0%,#090a0f 100%)}' +
      '.naigate-icon{width:64px;height:64px;border-radius:18px;display:flex;align-items:center;' +
      'justify-content:center;font-size:30px;margin-bottom:16px;' +
      'background:linear-gradient(135deg,#10B981 0%,#0d9488 100%);' +
      'box-shadow:0 10px 30px rgba(16,185,129,0.35)}' +
      '.naigate-title{font-size:22px;font-weight:800;color:#fff;margin-bottom:8px;letter-spacing:-0.3px}' +
      '.naigate-sub{font-size:13.5px;color:rgba(242,246,244,0.65);line-height:1.55;' +
      'max-width:310px;margin-bottom:20px}' +
      '.naigate-btn{display:block;width:100%;max-width:280px;padding:14px 18px;border-radius:13px;' +
      'font-size:15px;font-weight:700;text-decoration:none !important;color:#06130d !important;' +
      'background:#10B981;margin-bottom:10px;box-shadow:0 8px 22px rgba(16,185,129,0.35)}' +
      '.naigate-gold{background:#EAC85E;box-shadow:0 8px 22px rgba(234,200,94,0.25)}' +
      '.naigate-note{margin-top:10px;font-size:11.5px;color:rgba(242,246,244,0.4);' +
      'max-width:300px;line-height:1.5}' +
      '.naigate-home{margin-top:18px;font-size:13px;color:#67e8f9 !important;' +
      'text-decoration:underline !important}';
    var el = document.createElement('style');
    el.id = 'naigate-styles';
    el.textContent = css;
    (document.head || document.documentElement).appendChild(el);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();