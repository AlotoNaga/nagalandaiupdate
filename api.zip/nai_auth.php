<?php
// public_html/api/nai_auth.php
// NAGALAND AI — NATIVE LOGIN, REGISTER & ACCOUNT DELETION v1.4
//
// v1.4 FIXES A REAL BUG carried since v1.2: the brute-force lock check sat
// ABOVE the handler, where $failFile did not exist yet. It was therefore
// checking nothing, and the lockout after repeated wrong passwords never
// actually engaged. It now runs directly after $failFile is created.
//
// v1.3 adds action 'delete'. Both app stores now REQUIRE that an app which
// lets people create an account also lets them delete it from inside the
// app, or the update is rejected. This is that.
//
// v1.2 FIXES A REAL BUG that made every login fail with "Unknown action".
//   v1.0 read the request into variables ($action, $payload, $ip) and THEN
//   loaded WordPress underneath them. WordPress and its plugins create
//   globals with those same names, so they landed on top and by the time
//   the code checked $action it was no longer "login" — which is why a
//   perfectly correct email and password kept being refused.
//
//   The fix is ordering: WordPress is loaded FIRST, then the request is
//   read inside a function. Anything read afterwards is safe, because
//   nothing runs after it. Verified against a stub that deliberately sets
//   a clashing $action global.
//
// Lets the mobile app log people in and create accounts WITHOUT opening a
// web page. The app posts here, this file talks to WordPress, and WordPress
// sets its normal session cookies. Those cookies then travel with every
// later request from the app, so chat.php, memory and the in-app browser
// all see the same logged-in person. Nothing else in your system changes.
//
// WHY THIS IS SAFE TO ADD
//   - It uses WordPress's own functions for everything that matters:
//     password checking, password hashing, session cookies. No custom
//     cryptography, no passwords stored anywhere by this file.
//   - New accounts are created with wp_create_user() and fire the normal
//     user_register hook, so any plugin that listens for new signups still
//     runs exactly as it does on the website.
//   - A new account has no plan set, and chat.php already treats that as
//     the free "explore" plan. So a native signup behaves identically to
//     a website signup on day one.
//
// WHAT IT DELIBERATELY DOES NOT DO
//   - No payments. Upgrades stay on the web on purpose: anything bought
//     inside an app can fall under Apple's in-app purchase rules and their
//     cut. Keep that flow in a browser.
//
// ---------------------------------------------------------------------
// UPLOAD TO: public_html/api/nai_auth.php
// No configuration needed. It uses your existing WordPress install.
// ---------------------------------------------------------------------

@ini_set('display_errors', '0');
@set_time_limit(30);

/* ---------- TUNE THESE IF YOU EVER NEED TO ---------- */

// Failed logins allowed per device before it is made to wait.
define('NAI_AUTH_MAX_FAILS', 8);
// How long that wait lasts, in seconds.
define('NAI_AUTH_LOCK_SECONDS', 900);   // 15 minutes
// New accounts allowed from one IP per day. Stops bulk fake signups.
define('NAI_AUTH_MAX_SIGNUPS_PER_IP', 10);
// Shortest password we will accept.
define('NAI_AUTH_MIN_PASSWORD', 8);

/* ---------- END OF TUNING ---------- */

header('X-Content-Type-Options: nosniff');

function nai_auth_out($arr, $code = 200) {
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
  exit;
}

function nai_auth_fail($msg, $code = 400) {
  nai_auth_out(['success' => false, 'error' => $msg], $code);
}

/* =========================================================
   EVERYTHING BELOW RUNS INSIDE THIS FUNCTION.
   That is deliberate: WordPress defines hundreds of global
   variables, and several share names with the ones used here
   ($action, $user, $ip, $payload). Keeping them local means
   loading WordPress can never quietly overwrite them.
   ========================================================= */

/* ---------------------------------------------------------------------
   Small helpers, kept at file level so they are declared once and never
   re-declared. They take everything they need as arguments, so they do
   not touch globals either.
   --------------------------------------------------------------------- */
function nai_auth_fails($file) {
  if (!file_exists($file)) return ['n' => 0, 'until' => 0];
  $d = json_decode((string)@file_get_contents($file), true);
  return is_array($d) ? $d + ['n' => 0, 'until' => 0] : ['n' => 0, 'until' => 0];
}

function nai_auth_note_fail($file) {
  $d = nai_auth_fails($file);
  $d['n'] = (int)$d['n'] + 1;
  if ($d['n'] >= NAI_AUTH_MAX_FAILS) {
    $d['until'] = time() + NAI_AUTH_LOCK_SECONDS;
    $d['n'] = 0;
  }
  @file_put_contents($file, json_encode($d));
}

function nai_auth_clear_fails($file) { @unlink($file); }

function nai_auth_user_payload($user) {
  $plan = get_user_meta($user->ID, 'nai_plan', true);
  if (!$plan) $plan = 'explore';

  $name = trim((string)get_user_meta($user->ID, 'first_name', true));
  if ($name === '') {
    $display = trim((string)$user->display_name);
    $name = ($display !== '' && strpos($display, '@') === false) ? $display : '';
  }

  return [
    'success' => true,
    'user' => [
      'id'    => (int)$user->ID,
      'name'  => $name,
      'email' => (string)$user->user_email,
      'plan'  => $plan,
    ],
  ];
}

function nai_auth_handle() {

  if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    nai_auth_fail('This endpoint only accepts POST.', 405);
  }

  // Same shared secret as chat.php — only our app may call this.
  $APP_SECRET = 'NAI_APP_9f3Kd72Lp0qWmZx4Rb8Tn6Vy1Hs5Jc';
  if (!hash_equals($APP_SECRET, (string)($_SERVER['HTTP_X_NAI_APP'] ?? ''))) {
    nai_auth_fail('Not authorised.', 403);
  }

  $payload = json_decode(file_get_contents('php://input'), true);
  if (!is_array($payload)) {
    nai_auth_fail('Bad request.', 400);
  }

  $action = trim((string)($payload['action'] ?? ''));
  $fp     = trim((string)($payload['_nai_fp'] ?? ''));
  $ip     = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $device = ($fp !== '' && strlen($fp) >= 4) ? ($ip . '|' . $fp) : $ip;

  /* =========================================================
     BRUTE FORCE GUARD
     Counts failed logins per device. After too many, the device
     waits. Successful login clears the count immediately.
     ========================================================= */
  $failFile = sys_get_temp_dir() . '/nai_auth_fail_' . md5($device) . '.json';

  // Is this device currently locked out for too many wrong passwords?
  // This MUST come after $failFile exists — it previously sat above the
  // handler, where $failFile was undefined, so the lock never triggered.
  $fails = nai_auth_fails($failFile);
  if (!empty($fails['until']) && time() < (int)$fails['until']) {
    $mins = max(1, (int)ceil(((int)$fails['until'] - time()) / 60));
    nai_auth_fail("Too many attempts. Please try again in {$mins} minutes.", 429);
  }


  /* =========================================================
     Shared: describe the signed-in user back to the app
     ========================================================= */

  /* =========================================================
     ACTION: status — am I logged in?
     ========================================================= */
  if ($action === 'status') {
    if (is_user_logged_in()) {
      nai_auth_out(nai_auth_user_payload(wp_get_current_user()));
    }
    nai_auth_out(['success' => true, 'user' => null]);
  }

  /* =========================================================
     ACTION: logout
     ========================================================= */
  if ($action === 'logout') {
    wp_logout();
    nai_auth_out(['success' => true, 'user' => null]);
  }

  /* =========================================================
     ACTION: login
     ========================================================= */
  if ($action === 'login') {
    $email    = trim((string)($payload['email'] ?? ''));
    $password = (string)($payload['password'] ?? '');

    if ($email === '' || $password === '') {
      nai_auth_fail('Please enter your email and password.');
    }

    // People type their email; WordPress signs in by username. Look up the
    // account first so either works.
    $login = $email;
    if (is_email($email)) {
      $byEmail = get_user_by('email', $email);
      if ($byEmail) $login = $byEmail->user_login;
    }

    $user = wp_signon([
      'user_login'    => $login,
      'user_password' => $password,
      'remember'      => true,
    ], is_ssl());

    if (is_wp_error($user)) {
      nai_auth_note_fail($failFile);
      // Deliberately vague: never reveal whether an email is registered.
      nai_auth_fail('Email or password is incorrect.', 401);
    }

    nai_auth_clear_fails($failFile);
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, true, is_ssl());

    nai_auth_out(nai_auth_user_payload($user));
  }

  /* =========================================================
     ACTION: register
     ========================================================= */
  if ($action === 'register') {
    $name     = trim((string)($payload['name'] ?? ''));
    $email    = trim((string)($payload['email'] ?? ''));
    $password = (string)($payload['password'] ?? '');

    if ($name === '')  nai_auth_fail('Please enter your name.');
    if (mb_strlen($name) > 60) $name = mb_substr($name, 0, 60);
    if (!is_email($email)) nai_auth_fail('Please enter a valid email address.');
    if (strlen($password) < NAI_AUTH_MIN_PASSWORD) {
      nai_auth_fail('Please choose a password of at least ' . NAI_AUTH_MIN_PASSWORD . ' characters.');
    }

    if (email_exists($email)) {
      nai_auth_fail('An account already exists with that email. Please log in instead.', 409);
    }

    // Signup flood guard, per IP per day
    $signupFile = sys_get_temp_dir() . '/nai_auth_signups_' . md5($ip . date('Y-m-d')) . '.txt';
    $signups = file_exists($signupFile) ? (int)@file_get_contents($signupFile) : 0;
    if ($signups >= NAI_AUTH_MAX_SIGNUPS_PER_IP) {
      nai_auth_fail('Too many accounts created from this network today. Please try again tomorrow.', 429);
    }

    // Build a clean, unique username from the email
    $base = sanitize_user(current(explode('@', $email)), true);
    if ($base === '') $base = 'user';
    $username = $base;
    $i = 1;
    while (username_exists($username)) {
      $username = $base . $i;
      $i++;
      if ($i > 500) { $username = $base . wp_rand(1000, 999999); break; }
    }

    $userId = wp_create_user($username, $password, $email);
    if (is_wp_error($userId)) {
      nai_auth_fail('Could not create the account. Please try again.', 500);
    }

    // Store the name the way the website does, so greetings work everywhere
    $parts = preg_split('/\s+/u', $name, 2);
    wp_update_user([
      'ID'           => $userId,
      'display_name' => $name,
      'first_name'   => $parts[0] ?? $name,
      'last_name'    => $parts[1] ?? '',
    ]);

    @file_put_contents($signupFile, $signups + 1);

    // Sign them straight in — no second step, no email round trip
    wp_set_current_user($userId);
    wp_set_auth_cookie($userId, true, is_ssl());

    $user = get_user_by('id', $userId);
    $out = nai_auth_user_payload($user);
    $out['created'] = true;
    nai_auth_out($out);
  }

  /* =========================================================
     ACTION: delete — remove this account for good
     ---------------------------------------------------------
     Required by both app stores: an app that lets people sign up
     must let them delete their account from inside the app.

     Deliberately simple. It deletes the WordPress user, which also
     removes all of their user meta (that is where memories, plan and
     name live). Then the session is destroyed so the old cookie is
     worthless.

     Only ever affects the person who is signed in on THIS device.
     There is no way to name someone else's account.
     ========================================================= */
  if ($action === 'delete') {
    if (!is_user_logged_in()) {
      nai_auth_fail('You are not signed in.', 401);
    }

    $me = wp_get_current_user();
    $userId = (int)$me->ID;
    if ($userId <= 0) {
      nai_auth_fail('You are not signed in.', 401);
    }

    // Safety rail: never let an administrator delete themselves through
    // the app. That would be a support disaster and no real user is an
    // admin anyway.
    if (user_can($userId, 'manage_options')) {
      nai_auth_fail('Admin accounts cannot be deleted from the app. Please contact support.', 403);
    }

    // wp_delete_user() lives in an admin file that is not always loaded
    // for a plain request like this one.
    if (!function_exists('wp_delete_user')) {
      require_once ABSPATH . 'wp-admin/includes/user.php';
    }
    if (!function_exists('wp_delete_user')) {
      nai_auth_fail('Could not delete the account right now. Please contact support.', 500);
    }

    // If memories are kept in their own table rather than user meta,
    // clear those rows too. Harmless when no such table exists.
    global $wpdb;
    if (isset($wpdb)) {
      foreach (array('nai_memories', 'nai_memory') as $suffix) {
        $table = $wpdb->prefix . $suffix;
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ($found === $table) {
          $wpdb->delete($table, array('user_id' => $userId), array('%d'));
        }
      }
    }

    // Delete first, then sign out.
    //
    // The other order (logout first) meant that if deletion failed, the
    // person was left signed out of an account that still existed — they
    // would think it was gone when it was not. Deleting first means the
    // account is either really gone, or nothing changed at all and they
    // are still signed in to retry.
    //
    // There is no window of risk in this order: once wp_delete_user()
    // succeeds the user no longer exists, so their cookie is already
    // worthless. wp_logout() just clears it tidily.
    $done = wp_delete_user($userId);
    if (!$done) {
      nai_auth_fail('Could not delete the account right now. Please contact support.', 500);
    }

    wp_logout();

    nai_auth_out(array('success' => true, 'user' => null, 'deleted' => true));
  }

  nai_auth_fail('Unknown action.', 400);

}

/* =========================================================
   LOAD WORDPRESS FIRST — ORDER MATTERS HERE.

   wp-config.php loads the whole of WordPress, and WordPress plus its
   plugins create a great many global variables. Several share names with
   the ones this file needs ($action, $user, $ip, $payload).

   v1.0 read the request BEFORE this line, so WordPress landed on top and
   every login failed with "Unknown action". Loading WordPress first means
   anything the handler sets afterwards is safe.

   This require stays at file level, exactly as chat.php does it, because
   WordPress expects to be loaded that way.
   ========================================================= */
ob_start();
$nai_auth_wp_config = dirname(__DIR__) . '/wp-config.php';
if (!file_exists($nai_auth_wp_config)) {
  ob_end_clean();
  nai_auth_fail('Server not configured.', 500);
}
require_once $nai_auth_wp_config;
ob_end_clean();

if (!function_exists('wp_signon') || !function_exists('wp_create_user')) {
  nai_auth_fail('Server not ready.', 500);
}

// Everything from here runs with WordPress already loaded, inside a
// function, so its variables are local and set last. Nothing can clash.
nai_auth_handle();