/* nai_chatpage.js v1.2 (Jul 2026): history is cleaned of links before sending (a link left in history could get the request blocked, breaking that one conversation permanently while a new chat worked). v1.1: resilient callApi — silent retry on hosting blocks/non-JSON, friendly error wording */
window.onerror=function(m,u,l){var d=document.createElement('div');d.style.cssText='position:fixed;bottom:0;left:0;right:0;background:red;color:white;padding:12px;z-index:99999;font-size:14px;font-family:monospace;word-break:break-all;';d.textContent='JS ERROR: '+m+' (line '+l+')';document.body.appendChild(d);};

(function(){
  var msgBox=document.getElementById("naic-messages");
  var input=document.getElementById("naic-input");
  var sendBtn=document.getElementById("naic-send");
  var note=document.getElementById("naic-note");
  var tabChat=document.getElementById("naic-tab-chat");
  var tabStudent=document.getElementById("naic-tab-student");
  var studentBar=document.getElementById("naic-student-bar");
  var subjectSelect=document.getElementById("naic-subject");
  var gradeSelect=document.getElementById("naic-grade");
  var app=document.getElementById("nagaland-ai-chat-app");
  var canvas=document.getElementById("nai-chat-stars");
  var ctx=canvas?canvas.getContext("2d"):null;
  var sidebar=document.getElementById("naic-sidebar");
  var sidebarOverlay=document.getElementById("naic-sidebar-overlay");
  var menuBtn=document.getElementById("naic-menu-btn");
  var chatList=document.getElementById("naic-chat-list");
  var newChatBtn=document.getElementById("naic-new-chat");
  var newTopBtn=document.getElementById("naic-new-top");

  var stars=[];var history=[];var currentMode="chat";var API_ENDPOINT="/api/chat.php";
  var _naiSessionToken='';var _naiFingerprint='';

  function escapeHtml(s){return String(s).replace(/[&<>"']/g,function(m){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]})}
  function linkify(t){var s=escapeHtml(t);return s.replace(/(https?:\/\/[^\s<]+)/g,function(u){var c=u.replace(/[)\]}>,.]+$/g,"");var r=u.slice(c.length);return'<a href="'+c+'" target="_blank" rel="noopener noreferrer">'+c+'</a>'+r})}
  function parseMarkdown(t){var s=escapeHtml(t),lines=s.split('\n'),h='',inUl=false,inOl=false;for(var i=0;i<lines.length;i++){var line=lines[i],tr=line.trim();if(/^-{3,}$/.test(tr)||/^\*{3,}$/.test(tr)){if(inUl){h+='</ul>';inUl=false}if(inOl){h+='</ol>';inOl=false}h+='<hr>';continue}var hm=tr.match(/^(#{1,4})\s+(.+)$/);if(hm){if(inUl){h+='</ul>';inUl=false}if(inOl){h+='</ol>';inOl=false}h+='<div class="naic-md-heading">'+hm[2]+'</div>';continue}if(/^[-*]\s+(.+)$/.test(tr)){if(inOl){h+='</ol>';inOl=false}if(!inUl){h+='<ul>';inUl=true}h+='<li>'+tr.replace(/^[-*]\s+/,'')+'</li>';continue}if(/^\d+\.\s+(.+)$/.test(tr)){if(inUl){h+='</ul>';inUl=false}if(!inOl){h+='<ol>';inOl=true}h+='<li>'+tr.replace(/^\d+\.\s+/,'')+'</li>';continue}if(inUl){h+='</ul>';inUl=false}if(inOl){h+='</ol>';inOl=false}if(tr===''){h+='<br>'}else{h+='<p>'+line+'</p>'}}if(inUl)h+='</ul>';if(inOl)h+='</ol>';h=h.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');h=h.replace(/\*(.+?)\*/g,'<em>$1</em>');h=h.replace(/`([^`]+)`/g,'<code>$1</code>');h=h.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');h=h.replace(/(^|[^"=])(https?:\/\/[^\s<"]+)/g,function(match,prefix,url){var c=url.replace(/[)\]}>,.]+$/,'');var r=url.slice(c.length);return prefix+'<a href="'+c+'" target="_blank" rel="noopener noreferrer">'+c+'</a>'+r});return h}
  function generateId(){return'chat_'+Date.now()+'_'+Math.random().toString(36).substr(2,6)}
  function getTimeLabel(ts){if(!ts)return'';var d=Date.now()-ts;if(d<60000)return'Now';if(d<3600000)return Math.floor(d/60000)+'m';if(d<86400000)return Math.floor(d/3600000)+'h';return new Date(ts).toLocaleDateString('en-IN',{day:'numeric',month:'short'})}

  var MULTI_KEY='nai_multi_chats_v3';
  function loadAllChats(){try{var r=localStorage.getItem(MULTI_KEY);if(r){var p=JSON.parse(r);if(p&&Array.isArray(p.chats))return p}}catch(e){}return{chats:[],activeId:null}}
  function saveAllChats(s){try{localStorage.setItem(MULTI_KEY,JSON.stringify(s))}catch(e){}}
  function getActiveChat(s){if(!s||!s.activeId||!Array.isArray(s.chats))return null;for(var i=0;i<s.chats.length;i++){if(s.chats[i].id===s.activeId)return s.chats[i]}return null}
  var store=loadAllChats();

  function switchMode(mode,silent){try{currentMode=mode;if(mode==="student"){if(tabStudent)tabStudent.classList.add("naic-tab-active");if(tabChat)tabChat.classList.remove("naic-tab-active");if(studentBar)studentBar.style.display="flex";if(input)input.placeholder="Ask your teacher anything..."}else{if(tabChat)tabChat.classList.add("naic-tab-active");if(tabStudent)tabStudent.classList.remove("naic-tab-active");if(studentBar)studentBar.style.display="none";if(input)input.placeholder="Ask Nagaland AI anything..."}if(!silent){var a=getActiveChat(store);if(a){a.mode=mode;saveAllChats(store)}}}catch(e){}}
  try{if(tabChat)tabChat.addEventListener("click",function(){switchMode("chat")})}catch(e){}
  try{if(tabStudent)tabStudent.addEventListener("click",function(){switchMode("student")})}catch(e){}

  function openSidebar(){try{if(sidebar)sidebar.classList.add('naic-open');if(sidebarOverlay)sidebarOverlay.classList.add('naic-show')}catch(e){}}
  function closeSidebar(){try{if(sidebar)sidebar.classList.remove('naic-open');if(sidebarOverlay)sidebarOverlay.classList.remove('naic-show')}catch(e){}}
  try{if(menuBtn)menuBtn.addEventListener('click',function(){if(sidebar&&sidebar.classList.contains('naic-open'))closeSidebar();else openSidebar()})}catch(e){}
  try{if(sidebarOverlay)sidebarOverlay.addEventListener('click',closeSidebar)}catch(e){}

  function showWelcome(){if(!msgBox)return;msgBox.innerHTML='';var w=document.createElement("div");w.className="naic-welcome";w.id="naic-welcome";w.innerHTML='<div class="naic-welcome-logo">Nagaland AI</div><div class="naic-welcome-sub">Ask me anything - education, news, Naga languages, weather, scholarships, or switch to Student Mode.</div><div class="naic-suggestions"><button class="naic-suggestion" data-q="What is the latest news in Nagaland?" type="button">Latest News</button><button class="naic-suggestion" data-q="Translate hello into Ao and Sumi" type="button">Naga Languages</button><button class="naic-suggestion" data-q="Weather in Kohima today" type="button">Weather</button><button class="naic-suggestion" data-q="Explain photosynthesis for class 8" data-mode="student" type="button">Student Mode</button><button class="naic-suggestion" data-q="Tell me about the Naga tribes" type="button">About Nagaland</button></div>';msgBox.appendChild(w);var btns=w.querySelectorAll(".naic-suggestion");for(var i=0;i<btns.length;i++){btns[i].addEventListener("click",function(){var q=this.getAttribute("data-q")||"";var m=this.getAttribute("data-mode")||"";if(m==="student")switchMode("student");if(input){input.value=q;autoGrow();input.focus()}})}}
  function hideWelcome(){var w=document.getElementById("naic-welcome");if(w)w.remove()}

  function renderChatList(){try{if(!chatList)return;chatList.innerHTML='';if(!store.chats||!store.chats.length){chatList.innerHTML='<div class="naic-empty-state">No chats yet.<br>Start a new conversation!</div>';return}var sorted=store.chats.slice().sort(function(a,b){return(b.updatedAt||0)-(a.updatedAt||0)});for(var s=0;s<sorted.length;s++){(function(chat){var item=document.createElement('div');item.className='naic-chat-item'+(chat.id===store.activeId?' naic-active':'');var ml=chat.mode==='student'?'<span class="naic-chat-item-mode">Student</span>':'';item.innerHTML='<div class="naic-chat-item-icon">&#128172;</div><div class="naic-chat-item-info"><div class="naic-chat-item-title">'+escapeHtml(chat.title||'New Chat')+'</div><div class="naic-chat-item-time">'+ml+(ml?' . ':'')+getTimeLabel(chat.updatedAt||chat.createdAt)+'</div></div><button class="naic-chat-delete" type="button">&times;</button>';item.addEventListener('click',function(e){if(e.target.className&&e.target.className.indexOf('naic-chat-delete')!==-1)return;switchToChat(chat.id);closeSidebar()});var del=item.querySelector('.naic-chat-delete');if(del)del.addEventListener('click',function(e){e.stopPropagation();deleteChat(chat.id)});chatList.appendChild(item)})(sorted[s])}}catch(e){}}

  function switchToChat(chatId){store.activeId=chatId;var chat=getActiveChat(store);if(!chat)return;history=Array.isArray(chat.history)?chat.history:[];switchMode(chat.mode||'chat',true);if(msgBox)msgBox.innerHTML='';if(!chat.messages||!chat.messages.length){showWelcome()}else{for(var i=0;i<chat.messages.length;i++){var m=chat.messages[i];if(!m)continue;var div=document.createElement("div");div.className="naic-bubble "+(m.who==="user"?"naic-user":"naic-ai");if(m.who==="ai")div.innerHTML=m.html||parseMarkdown(m.text||"");else div.textContent=m.text||"";if(msgBox)msgBox.appendChild(div)}if(msgBox)msgBox.scrollTop=msgBox.scrollHeight}saveAllChats(store);renderChatList();setNote('')}

  function createNewChat(){var nc={id:generateId(),title:'New Chat',mode:currentMode,history:[],messages:[],createdAt:Date.now(),updatedAt:Date.now()};store.chats.unshift(nc);store.activeId=nc.id;history=[];saveAllChats(store);renderChatList();showWelcome();setNote('');if(input)input.focus();closeSidebar()}
  try{if(newChatBtn)newChatBtn.addEventListener('click',createNewChat)}catch(e){}
  try{if(newTopBtn)newTopBtn.addEventListener('click',createNewChat)}catch(e){}

  function deleteChat(chatId){store.chats=store.chats.filter(function(c){return c.id!==chatId});if(store.activeId===chatId){if(store.chats.length){switchToChat(store.chats[0].id)}else{store.activeId=null;history=[];if(msgBox)msgBox.innerHTML='';saveAllChats(store);showWelcome()}}else{saveAllChats(store)}renderChatList()}

  function saveActiveChat(){try{var active=getActiveChat(store);if(!active)return;active.history=history;active.mode=currentMode;var bubbles=msgBox?msgBox.querySelectorAll('.naic-bubble'):[];var msgs=[];for(var i=0;i<bubbles.length;i++){var el=bubbles[i];if(el.classList.contains('naic-typing'))continue;msgs.push({who:el.classList.contains("naic-user")?"user":"ai",html:el.innerHTML,text:el.textContent})}active.messages=msgs;active.updatedAt=Date.now();if(active.title==='New Chat'&&msgs.length>0){for(var j=0;j<msgs.length;j++){if(msgs[j].who==='user'){active.title=String(msgs[j].text).substring(0,50);break}}}saveAllChats(store)}catch(e){}}

  function ensureActiveChat(){if(!store.activeId||!getActiveChat(store)){var nc={id:generateId(),title:'New Chat',mode:currentMode,history:[],messages:[],createdAt:Date.now(),updatedAt:Date.now()};store.chats.unshift(nc);store.activeId=nc.id;history=[];saveAllChats(store);renderChatList()}}

  try{
    function resizeCanvas(){if(!canvas)return;canvas.width=window.innerWidth;canvas.height=window.innerHeight}
    function initStars(){if(!canvas)return;stars=[];var c=window.innerWidth<768?80:150;for(var i=0;i<c;i++){stars.push({x:Math.random()*canvas.width,y:Math.random()*canvas.height,r:Math.random()*1.4+0.3,o:Math.random()*0.6+0.2,s:Math.random()*0.35+0.05,t:(Math.random()*0.015+0.005)*(Math.random()>0.5?1:-1)})}}
    function drawStars(){if(!ctx||!canvas)return;ctx.clearRect(0,0,canvas.width,canvas.height);for(var j=0;j<stars.length;j++){var st=stars[j];st.o+=st.t;if(st.o>0.9){st.o=0.9;st.t*=-1}if(st.o<0.15){st.o=0.15;st.t*=-1}ctx.beginPath();ctx.arc(st.x,st.y,st.r,0,Math.PI*2);ctx.fillStyle="rgba(255,255,255,"+st.o+")";ctx.fill();st.y+=st.s;if(st.y>canvas.height){st.y=0;st.x=Math.random()*canvas.width}}requestAnimationFrame(drawStars)}
    resizeCanvas();initStars();drawStars()
  }catch(e){}

  function addBubble(text,who){hideWelcome();ensureActiveChat();var div=document.createElement("div");div.className="naic-bubble "+(who==="user"?"naic-user":"naic-ai");div.innerHTML=(who==="user")?escapeHtml(text):parseMarkdown(text);if(msgBox){msgBox.appendChild(div);msgBox.scrollTop=msgBox.scrollHeight}saveActiveChat();return div}
  function setNote(text){if(!note)return;if(!text){note.style.display="none";note.innerHTML="";return}note.style.display="block";if(String(text).indexOf("<a ")!==-1)note.innerHTML=text;else note.innerHTML=linkify(String(text))}
  function autoGrow(){if(!input)return;input.style.height="auto";input.style.height=Math.min(input.scrollHeight,140)+"px"}
  try{if(input)input.addEventListener("input",autoGrow)}catch(e){}

  try{if(store.activeId&&getActiveChat(store)){switchToChat(store.activeId)}else{showWelcome()}renderChatList()}catch(e){showWelcome()}

  try{fetch('/api/nai_init.php').then(function(r){return r.json()}).then(function(d){_naiSessionToken=d.token||''}).catch(function(){})}catch(e){}
  function naiGetFingerprint(){if(_naiFingerprint)return _naiFingerprint;try{var d=[screen.width,screen.height,screen.colorDepth,navigator.language,navigator.platform,new Date().getTimezoneOffset(),navigator.hardwareConcurrency||0,navigator.deviceMemory||0].join('|');var h=0;for(var i=0;i<d.length;i++){h=((h<<5)-h+d.charCodeAt(i))&0x7FFFFFFF}_naiFingerprint=h.toString(36)}catch(e){_naiFingerprint='x'}return _naiFingerprint}

  function naiCleanHistory(h){if(!Array.isArray(h))return[];var out=[];for(var i=0;i<h.length;i++){var e=h[i];if(!e||typeof e!=='object')continue;var t=String(e.content==null?'':e.content);t=t.replace(/\[([^\]]+)\]\((?:https?:\/\/|\/)[^\s)]*\)/g,'$1');t=t.replace(/https?:\/\/[^\s]+/g,'(link)');t=t.replace(/\s+/g,' ').trim();if(t.length>600)t=t.slice(0,600)+'...';if(t)out.push({role:e.role==='assistant'?'assistant':'user',content:t});}return out;}

  function callApi(userMessage){
    /* v1.1: resilient call.
       If the hosting layer blocks a request (plain "Forbidden" text, timeout
       page, any non-JSON body) or the network hiccups, we quietly wait 1.8s
       and retry ONCE before showing anything. If it still fails, users see a
       friendly sentence — never raw code errors like "Unexpected token".
       Real JSON replies and real JSON error messages (limits, login) behave
       exactly as before. */
    var payload={message:userMessage,history:naiCleanHistory(history),mode:currentMode,_nai_tok:_naiSessionToken,_nai_fp:naiGetFingerprint()};
    if(currentMode==="student"){if(subjectSelect&&subjectSelect.value)payload.subject=subjectSelect.value;if(gradeSelect&&gradeSelect.value)payload.grade=gradeSelect.value}
    function attempt(){
      return fetch(API_ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)})
        .catch(function(){var t=new Error("__nai_transient__");t.naiTransient=true;throw t})
        .then(function(res){
          return res.text().then(function(raw){
            var data=null;
            try{data=JSON.parse(raw)}catch(err){}
            if(data===null){var t=new Error("__nai_transient__");t.naiTransient=true;throw t}
            if(!res.ok)throw new Error((data&&(data.error||data.message))||"Something went wrong.");
            return data.reply||""
          })
        })
    }
    return attempt().catch(function(e){
      if(!(e&&e.naiTransient))throw e;
      return new Promise(function(r){setTimeout(r,1800)}).then(attempt).catch(function(e2){
        if(e2&&e2.naiTransient)throw new Error("The server is a little busy right now. Please wait a few seconds and send your message again.");
        throw e2
      })
    })
  }

  function sendMessage(){var userText=(input?input.value||"":"").trim();if(!userText)return;hideWelcome();setNote("");addBubble(userText,"user");history.push({role:"user",content:userText});saveActiveChat();renderChatList();if(input)input.value="";autoGrow();if(sendBtn)sendBtn.disabled=true;var thinking=document.createElement("div");thinking.className="naic-bubble naic-ai naic-typing";thinking.innerHTML='<div class="naic-shimmer"><div class="naic-shimmer-dot"></div><div class="naic-shimmer-line"></div><div class="naic-shimmer-line"></div><div class="naic-shimmer-line"></div></div>';if(msgBox){msgBox.appendChild(thinking);msgBox.scrollTop=msgBox.scrollHeight}callApi(userText).then(function(reply){thinking.classList.remove("naic-typing");var ft=reply||"(No response)";thinking.innerHTML=parseMarkdown(ft);history.push({role:"assistant",content:ft});saveActiveChat();renderChatList()}).catch(function(e){thinking.classList.remove("naic-typing");var et=String((e&&e.message)?e.message:"I couldn't reply right now.");if(et.toLowerCase().indexOf("log in")!==-1||et.toLowerCase().indexOf("login")!==-1){et='Please <a href="/login/">login</a> or <a href="/register/">create an account</a> to continue chatting.'}if(et.indexOf("<a ")!==-1)thinking.innerHTML=et;else thinking.innerHTML=linkify(et);setNote(et);saveActiveChat()}).then(function(){if(sendBtn)sendBtn.disabled=false;if(input)input.focus()}).catch(function(){if(sendBtn)sendBtn.disabled=false})}

  try{if(sendBtn)sendBtn.addEventListener("click",function(){sendMessage()})}catch(e){}
  try{if(input)input.addEventListener("keydown",function(e){if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage()}})}catch(e){}
})();


/* =====================================================================
   APP GATE — merged in so NO page editing is needed.

   This used to live in a separate file that had to be added to the page
   with a <script> tag. That step kept getting lost, which is why the
   gate was never actually running. It now travels with this file: you
   upload this one file and the gate is live.

   Desktop        -> full chat, untouched.
   Mobile browser -> "Chat is now in the app" + store buttons.
   Inside the app -> "Chat is in the app", pointing at the Chat tab,
                     with no download buttons (they already have it).

   Safe to keep /api/nai_app_gate.js on the server as well — the code
   below refuses to apply itself twice.
   ===================================================================== */
(function () {
  'use strict';

  function run() {
    var ua = navigator.userAgent || '';
    var isAndroid = /android/i.test(ua);
    var isIOS = /iPad|iPhone|iPod/.test(ua);

    // Desktop keeps the full chat experience — nothing to do.
    if (!isAndroid && !isIOS) return;

    /* Is this page being shown INSIDE our app?
       Two independent signals, either is enough:
         1. the flag the app injects on pages it opens as a tab
         2. the WebView signature — Android WebViews carry "; wv)", and
            iOS WKWebView has no "Safari" in its user agent  */
    var injectedFlag = (window.IS_NAGALAND_AI_APP === true ||
                        window.IS_NAGALAND_ME_APP === true);
    var looksLikeWebView = (isAndroid && /;\s?wv\)/i.test(ua)) ||
                           (isIOS && !/Safari/i.test(ua));
    var insideApp = injectedFlag || looksLikeWebView;

    /* Find whichever chat panel this page has.
       Homepage  -> a panel inside #nagaland-ai-app
       Chat page -> the whole #nagaland-ai-chat-app screen  */
    var host = document.querySelector('#nagaland-ai-app .nai-chat');
    var fullScreen = false;
    if (!host) {
      host = document.getElementById('nagaland-ai-chat-app');
      fullScreen = true;
    }
    if (!host) return;              // neither panel on this page
    if (host.querySelector('.naigate')) return;   // already applied

    injectStyles();

    var gate = document.createElement('div');
    gate.className = 'naigate' + (fullScreen ? ' naigate-full' : '');

    if (insideApp) {
      // Already in the app. Sending them to a store would be nonsense.
      gate.innerHTML =
        '<div class="naigate-icon">&#128172;</div>' +
        '<div class="naigate-title">Chat is in the app</div>' +
        '<div class="naigate-sub">You are viewing our website inside the app. ' +
        'Close this window and use the Chat tab, where your conversations ' +
        'and memory are saved.</div>' +
        '<div class="naigate-note">Tap the X at the top to go back to chat.</div>';
    } else {
      gate.innerHTML =
        '<div class="naigate-icon">&#10024;</div>' +
        '<div class="naigate-title">Chat is now in the app</div>' +
        '<div class="naigate-sub">Nagaland AI chat has moved to our free mobile app. ' +
        'Faster, smoother, and built for your phone.</div>' +
        (isIOS
          ? '<a class="naigate-btn" href="https://apps.apple.com/app/id6772763733">Download on the App Store</a>'
          : '<a class="naigate-btn" href="https://play.google.com/store/apps/details?id=com.nagalandme.nagalandai">Get it on Google Play</a>') +
        (isIOS
          ? '<a class="naigate-btn naigate-gold" href="https://play.google.com/store/apps/details?id=com.nagalandme.nagalandai">Android? Get it on Google Play</a>'
          : '<a class="naigate-btn naigate-gold" href="https://apps.apple.com/app/id6772763733">iPhone? Download on the App Store</a>') +
        '<div class="naigate-note">100% free &middot; No login required &middot; ' +
        'Chat also available on desktop at nagalandai.com</div>' +
        (fullScreen ? '<a class="naigate-home" href="/">Back to nagalandai.com</a>' : '');
    }

    host.appendChild(gate);

    // Disable the inputs behind the cover, whichever layout this is
    ['nai-input', 'nai-send', 'naic-input', 'naic-send'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.disabled = true;
    });
  }

  function injectStyles() {
    if (document.getElementById('naigate-styles')) return;
    var css =
      '.naigate{position:absolute;inset:0;z-index:60;display:flex;flex-direction:column;' +
      'align-items:center;justify-content:center;text-align:center;padding:26px 20px;' +
      'border-radius:22px;font-family:"Outfit",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;' +
      'background:linear-gradient(180deg,rgba(8,12,20,0.96),rgba(6,10,16,0.99))}' +
      '.naigate-full{position:fixed;z-index:99999;border-radius:0;padding:28px 22px;' +
      'background:radial-gradient(ellipse at bottom,#1b2735 0%,#090a0f 100%)}' +
      '.naigate-icon{width:64px;height:64px;border-radius:18px;display:flex;align-items:center;' +
      'justify-content:center;font-size:30px;margin-bottom:16px;' +
      'background:linear-gradient(135deg,#10B981 0%,#0d9488 100%);' +
      'box-shadow:0 10px 30px rgba(16,185,129,0.35)}' +
      '.naigate-title{font-size:22px;font-weight:800;color:#fff;margin-bottom:8px;letter-spacing:-0.3px}' +
      '.naigate-sub{font-size:13.5px;color:rgba(242,246,244,0.65);line-height:1.55;' +
      'max-width:310px;margin-bottom:20px}' +
      '.naigate-btn{display:block;width:100%;max-width:280px;padding:14px 18px;border-radius:13px;' +
      'font-size:15px;font-weight:700;text-decoration:none !important;color:#06130d !important;' +
      'background:#10B981;margin-bottom:10px;box-shadow:0 8px 22px rgba(16,185,129,0.35)}' +
      '.naigate-gold{background:#EAC85E;box-shadow:0 8px 22px rgba(234,200,94,0.25)}' +
      '.naigate-note{margin-top:10px;font-size:11.5px;color:rgba(242,246,244,0.4);' +
      'max-width:300px;line-height:1.5}' +
      '.naigate-home{margin-top:18px;font-size:13px;color:#67e8f9 !important;' +
      'text-decoration:underline !important}';
    var el = document.createElement('style');
    el.id = 'naigate-styles';
    el.textContent = css;
    (document.head || document.documentElement).appendChild(el);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();