<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAGALAND AI — SCHOOL ATTENDANCE CONNECTOR (nai_school.php)
 * ═══════════════════════════════════════════════════════════════
 *
 * This file is included by chat.php on nagalandai.com.
 * It detects when a parent asks about their child's attendance
 * and fetches real data from schools.nagalandai.com.
 *
 * DEPLOYMENT: nagalandai.com/public_html/api/nai_school.php
 *
 * HOW IT WORKS:
 * 1. Parent tells NagalandAI their code (e.g. "my code is 482716")
 * 2. This module detects the attendance query + extracts the code
 * 3. Calls schools.nagalandai.com REST API with the code
 * 4. Returns formatted attendance data to the AI prompt
 * 5. NagalandAI responds naturally: "Your child was present today!"
 *
 * SUPPORTED QUERIES:
 *   - "Did my child go to school today? My code is 452466"
 *   - "Did my child go to school yesterday? My code is 452466"
 *   - "Monthly report for code 452466"
 *   - "How was my child's attendance this year? Code 452466"
 *   - "Any holidays this month? Code 452466"
 *   - "Last week attendance, code 452466"
 *
 * API KEY: Must match NAIS_API_KEY in nagaland-ai-schools.php
 *          on schools.nagalandai.com
 */

if (!defined('NAI_LOADED')) {
    http_response_code(403);
    exit('Direct access not allowed.');
}

/* ─── CONFIGURATION ─── */
define('NAIS_SCHOOLS_API_URL', 'https://schools.nagalandai.com/wp-json/nais/v1');

/*
 * ⚠ THIS KEY MUST MATCH the NAIS_API_KEY constant in
 *   schools.nagalandai.com → wp-content/plugins/nagaland-ai-schools/nagaland-ai-schools.php
 *
 * If you change it there, change it here too. Both must be identical.
 */
define('NAIS_SCHOOLS_API_KEY', 'M0BfMujUvmLsog3eR8QGiVHvZhDKsmenNCmpHEKnEOdHOxkv');


/**
 * Detect if message is an attendance query and extract parent code.
 *
 * Returns array: ['is_attendance' => bool, 'parent_code' => string|null, 'query_type' => string, 'extras' => array]
 *
 * Query types: 'today', 'date', 'report', 'history', 'holidays'
 */
function nai_detect_attendance_query($message) {
    $msg = strtolower(trim($message));

    /* Attendance-related keywords */
    $attendance_keywords = [
        'attendance', 'present', 'absent',
        'did my child', 'did my son', 'did my daughter', 'did my kid',
        'go to school', 'went to school', 'came to school',
        'child attendance', 'student attendance',
        'parent code', 'my code is', 'code is',
        'check attendance', 'attendance report',
        'how many days absent', 'absent days', 'present days',
        'monthly report', 'attendance percentage',
        'school attendance', 'mark attendance',
        'did he go', 'did she go', 'was he present', 'was she present',
        'child go to school', 'son go to school', 'daughter go to school',
        'holiday', 'holidays', 'school holiday', 'school closed',
        'yesterday', 'last week', 'this week', 'this year', 'full year',
        'yearly report', 'annual report', 'year report',
    ];

    $is_attendance = false;
    foreach ($attendance_keywords as $kw) {
        if (strpos($msg, $kw) !== false) {
            $is_attendance = true;
            break;
        }
    }

    /* Also detect if message contains a 6-digit code near school-related words */
    if (!$is_attendance && preg_match('/\b\d{6}\b/', $message)) {
        $school_words = ['school', 'child', 'son', 'daughter', 'kid', 'attendance', 'code', 'parent'];
        foreach ($school_words as $sw) {
            if (strpos($msg, $sw) !== false) {
                $is_attendance = true;
                break;
            }
        }
    }

    if (!$is_attendance) {
        return ['is_attendance' => false, 'parent_code' => null, 'query_type' => '', 'extras' => []];
    }

    /* Extract 6-digit code from message */
    $parent_code = null;
    if (preg_match('/\b(\d{6})\b/', $message, $matches)) {
        $parent_code = $matches[1];
    }
    /* Also try alphanumeric codes if near "code" keyword */
    if (!$parent_code && preg_match('/\b([A-Za-z0-9]{6})\b/', $message, $matches)) {
        if (strpos($msg, 'code') !== false) {
            $parent_code = strtoupper($matches[1]);
        }
    }

    /* ─── Determine query type + extras ─── */
    $query_type = 'today';
    $extras = [];

    /* Holiday queries */
    if (preg_match('/holiday|holidays|school closed|school holiday|upcoming holiday/', $msg)) {
        $query_type = 'holidays';
        $extras['month'] = (int)date('m');
        $extras['year']  = (int)date('Y');
        /* "next month holidays" */
        if (preg_match('/next month/', $msg)) {
            $next = strtotime('first day of next month');
            $extras['month'] = (int)date('m', $next);
            $extras['year']  = (int)date('Y', $next);
        }
    }
    /* Yearly / full history queries */
    elseif (preg_match('/this year|full year|yearly|annual|year report|whole year|entire year/', $msg)) {
        $query_type = 'history';
        $cur_month = (int)date('m');
        $cur_year  = (int)date('Y');
        /* Academic year: April to March */
        if ($cur_month >= 4) {
            $extras['from'] = $cur_year . '-04-01';
        } else {
            $extras['from'] = ($cur_year - 1) . '-04-01';
        }
        $extras['to'] = date('Y-m-d');
    }
    /* Last week */
    elseif (preg_match('/last week/', $msg)) {
        $query_type = 'history';
        $extras['from'] = date('Y-m-d', strtotime('monday last week'));
        $extras['to']   = date('Y-m-d', strtotime('saturday last week'));
    }
    /* This week */
    elseif (preg_match('/this week/', $msg)) {
        $query_type = 'history';
        $extras['from'] = date('Y-m-d', strtotime('monday this week'));
        $extras['to']   = date('Y-m-d');
    }
    /* Monthly report */
    elseif (preg_match('/month|report|percentage|how many days/', $msg)) {
        $query_type = 'report';
        $extras['month'] = (int)date('m');
        $extras['year']  = (int)date('Y');

        /* "last month" */
        if (preg_match('/last month/', $msg)) {
            $last = strtotime('first day of last month');
            $extras['month'] = (int)date('m', $last);
            $extras['year']  = (int)date('Y', $last);
        }

        /* Detect specific month names */
        $months_map = [
            'january' => 1, 'february' => 2, 'march' => 3, 'april' => 4,
            'may' => 5, 'june' => 6, 'july' => 7, 'august' => 8,
            'september' => 9, 'october' => 10, 'november' => 11, 'december' => 12,
            'jan' => 1, 'feb' => 2, 'mar' => 3, 'apr' => 4,
            'jun' => 6, 'jul' => 7, 'aug' => 8, 'sep' => 9,
            'oct' => 10, 'nov' => 11, 'dec' => 12,
        ];
        foreach ($months_map as $mname => $mnum) {
            if (strpos($msg, $mname) !== false) {
                $extras['month'] = $mnum;
                break;
            }
        }
    }
    /* Day before yesterday */
    elseif (preg_match('/day before yesterday/', $msg)) {
        $query_type = 'date';
        $extras['date'] = date('Y-m-d', strtotime('-2 days'));
    }
    /* Yesterday */
    elseif (preg_match('/yesterday/', $msg)) {
        $query_type = 'date';
        $extras['date'] = date('Y-m-d', strtotime('-1 day'));
    }
    /* Last [weekday] */
    elseif (preg_match('/last (monday|tuesday|wednesday|thursday|friday|saturday|sunday)/', $msg, $m)) {
        $query_type = 'date';
        $extras['date'] = date('Y-m-d', strtotime('last ' . $m[1]));
    }

    return [
        'is_attendance' => true,
        'parent_code'   => $parent_code,
        'query_type'    => $query_type,
        'extras'        => $extras,
    ];
}


/**
 * Fetch attendance from schools.nagalandai.com API.
 *
 * @param string $parent_code  6-digit code
 * @param string $type         'today', 'date', 'report', 'history', or 'holidays'
 * @param array  $extras       Extra parameters (date, month, year, from, to)
 * @return array|null
 */
function nai_fetch_school_attendance($parent_code, $type = 'today', $extras = []) {
    if (!$parent_code) return null;

    /* Build URL based on query type */
    $base = NAIS_SCHOOLS_API_URL;
    $key  = urlencode(NAIS_SCHOOLS_API_KEY);
    $code = urlencode($parent_code);

    switch ($type) {
        case 'date':
            $date = urlencode($extras['date'] ?? date('Y-m-d'));
            $url  = "{$base}/attendance?code={$code}&date={$date}&api_key={$key}";
            break;

        case 'report':
            $month = (int)($extras['month'] ?? date('m'));
            $year  = (int)($extras['year']  ?? date('Y'));
            $url   = "{$base}/attendance/report?code={$code}&month={$month}&year={$year}&api_key={$key}";
            break;

        case 'history':
            $from = urlencode($extras['from'] ?? date('Y-m-01'));
            $to   = urlencode($extras['to']   ?? date('Y-m-d'));
            $url  = "{$base}/attendance/history?code={$code}&from={$from}&to={$to}&api_key={$key}";
            break;

        case 'holidays':
            $month = (int)($extras['month'] ?? date('m'));
            $year  = (int)($extras['year']  ?? date('Y'));
            $url   = "{$base}/school/holidays?code={$code}&month={$month}&year={$year}&api_key={$key}";
            break;

        default: /* today */
            $url = "{$base}/attendance?code={$code}&api_key={$key}";
            break;
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_HTTPHEADER     => [
            'Accept: application/json',
            'X-NAIS-API-Key: ' . NAIS_SCHOOLS_API_KEY,
        ],
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $result   = curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error    = curl_error($ch);
    curl_close($ch);

    if ($httpCode === 401) {
        return ['error' => 'API key mismatch. Contact administrator.'];
    }

    if ($httpCode === 404) {
        return ['error' => 'Parent code not found.'];
    }

    if ($httpCode !== 200 || !$result) {
        return ['error' => 'Could not connect to school system. ' . ($error ?: 'HTTP ' . $httpCode)];
    }

    $data = json_decode($result, true);

    if (!$data || isset($data['error'])) {
        return ['error' => $data['error'] ?? 'Invalid response from school system.'];
    }

    return $data;
}


/**
 * Build context string for the AI from attendance data.
 * This gets injected into the system prompt so the AI can
 * respond naturally about the student's attendance.
 *
 * @param array  $data  API response data
 * @param string $type  'today', 'date', 'report', 'history', or 'holidays'
 */
function nai_build_attendance_context($data, $type = 'today') {
    if (!$data || isset($data['error'])) {
        $err = $data['error'] ?? 'Unknown error';
        return "ATTENDANCE SYSTEM: Could not retrieve attendance. Error: {$err}. " .
               "Ask the parent to check their 6-digit code and try again. " .
               "If the problem persists, suggest they contact their school.";
    }

    $context = "SCHOOL ATTENDANCE DATA (REAL DATA — present this naturally to the parent):\n\n";
    $context .= "Student: " . ($data['student_name'] ?? 'Unknown') . "\n";
    $context .= "Class: " . ($data['class'] ?? '') . "\n";
    $context .= "School: " . ($data['school'] ?? '') . "\n\n";


    /* ─── HOLIDAYS LIST ─── */
    if ($type === 'holidays') {
        $month_name = date('F', mktime(0, 0, 0, (int)($data['month'] ?? date('m'))));
        $year = $data['year'] ?? date('Y');
        $context .= "HOLIDAYS FOR {$month_name} {$year}:\n";

        if (!empty($data['holidays'])) {
            foreach ($data['holidays'] as $h) {
                $hdate = date('D, M j', strtotime($h['date']));
                $htype = ($h['type'] === 'half_day') ? 'Half Day' : 'Holiday';
                $context .= "  - {$hdate}: {$htype}";
                if (!empty($h['title'])) $context .= " — " . $h['title'];
                $context .= "\n";
            }
        } else {
            $context .= "  No holidays scheduled for this month.\n";
        }
    }

    /* ─── HISTORY (date range — weekly / yearly) ─── */
    elseif ($type === 'history') {
        $from = $data['from'] ?? '';
        $to   = $data['to'] ?? '';
        $from_fmt = $from ? date('M j, Y', strtotime($from)) : '?';
        $to_fmt   = $to ? date('M j, Y', strtotime($to)) : '?';

        $context .= "ATTENDANCE HISTORY ({$from_fmt} to {$to_fmt}):\n\n";

        $summary = $data['summary'] ?? [];
        $context .= "SUMMARY:\n";
        $context .= "  Total school days recorded: " . ($summary['total_days'] ?? 0) . "\n";
        $context .= "  Present: " . ($summary['present'] ?? 0) . " days\n";
        $context .= "  Absent: " . ($summary['absent'] ?? 0) . " days\n";
        $context .= "  Late: " . ($summary['late'] ?? 0) . " days\n";
        $context .= "  Excused: " . ($summary['excused'] ?? 0) . " days\n";
        $context .= "  Attendance percentage: " . ($summary['percentage'] ?? 0) . "%\n";

        if (!empty($data['holidays'])) {
            $context .= "\nHOLIDAYS IN THIS PERIOD:\n";
            foreach ($data['holidays'] as $h) {
                $hdate = date('D, M j', strtotime($h['date']));
                $context .= "  - {$hdate}: " . ($h['title'] ?: $h['type']) . "\n";
            }
        }

        if (!empty($data['days'])) {
            $context .= "\nDAY-BY-DAY RECORDS:\n";
            foreach ($data['days'] as $d) {
                $ddate = date('D, M j', strtotime($d['date']));
                $context .= "  {$ddate}: " . strtoupper($d['status']);
                if (!empty($d['remarks'])) $context .= " (" . $d['remarks'] . ")";
                $context .= "\n";
            }
        }
    }

    /* ─── MONTHLY REPORT ─── */
    elseif ($type === 'report') {
        $month_name = date('F', mktime(0, 0, 0, (int)($data['month'] ?? date('m'))));
        $year = $data['year'] ?? date('Y');

        $context .= "MONTHLY REPORT ({$month_name} {$year}):\n\n";

        /* Handle new summary structure */
        $summary = $data['summary'] ?? $data;
        $context .= "SUMMARY:\n";
        $context .= "  Total school days: " . ($summary['total_days'] ?? 0) . "\n";
        $context .= "  Present: " . ($summary['present'] ?? 0) . " days\n";
        $context .= "  Absent: " . ($summary['absent'] ?? 0) . " days\n";
        $context .= "  Late: " . ($summary['late'] ?? 0) . " days\n";
        $context .= "  Excused: " . ($summary['excused'] ?? 0) . " days\n";
        $context .= "  Attendance percentage: " . ($summary['percentage'] ?? 0) . "%\n";

        if (!empty($data['holidays'])) {
            $context .= "\nHOLIDAYS THIS MONTH:\n";
            foreach ($data['holidays'] as $h) {
                $hdate = date('D, M j', strtotime($h['date']));
                $htype = ($h['type'] === 'half_day') ? 'Half Day' : 'Holiday';
                $context .= "  - {$hdate}: {$htype}";
                if (!empty($h['title'])) $context .= " — " . $h['title'];
                $context .= "\n";
            }
        }

        if (!empty($data['days'])) {
            $context .= "\nDAY-BY-DAY BREAKDOWN:\n";
            foreach ($data['days'] as $d) {
                $ddate = date('D, M j', strtotime($d['date']));
                $context .= "  {$ddate}: " . strtoupper($d['status']);
                if (!empty($d['remarks'])) $context .= " (" . $d['remarks'] . ")";
                $context .= "\n";
            }
        }
    }

    /* ─── TODAY / SPECIFIC DATE ─── */
    else {
        $query_date = $data['date'] ?? date('Y-m-d');
        $is_today   = !empty($data['is_today']);
        $date_label = $is_today ? "TODAY" : strtoupper(date('l, M j, Y', strtotime($query_date)));

        $context .= "ATTENDANCE FOR {$date_label} ({$query_date}):\n\n";

        /* Check if it's a holiday */
        if (!empty($data['holiday'])) {
            $h = $data['holiday'];
            $htype = ($h['type'] === 'half_day') ? 'HALF DAY' : 'SCHOOL HOLIDAY';
            $context .= "*** THIS DATE IS A {$htype}";
            if (!empty($h['title'])) $context .= ": " . $h['title'];
            $context .= " ***\n";
            $context .= "No attendance is expected on this day. The school is closed.\n";
        }
        elseif (!empty($data['attendance']) && is_array($data['attendance'])) {
            $att = $data['attendance'];
            $context .= "Status: " . strtoupper($att['status'] ?? 'unknown') . "\n";
            if (!empty($att['marked_at'])) {
                $context .= "Marked at: " . $att['marked_at'] . "\n";
            }
            if (!empty($att['remarks'])) {
                $context .= "Remarks: " . $att['remarks'] . "\n";
            }
        } else {
            if ($is_today) {
                $context .= "Status: NOT MARKED YET (attendance has not been recorded for today)\n";
                $context .= "Note: Teacher may not have marked attendance yet. It's usually done in the morning.\n";
            } else {
                $context .= "Status: NO RECORD FOUND for this date.\n";
                $context .= "Note: This could mean it was a weekend, a holiday not in the system, or attendance was not marked by the teacher that day.\n";
            }
        }

        if (!empty($data['periods']) && is_array($data['periods'])) {
            $context .= "\nPERIOD-WISE ATTENDANCE:\n";
            foreach ($data['periods'] as $p) {
                $context .= "  Period " . ($p['period'] ?? '?') . ": " . strtoupper($p['status'] ?? '?');
                if (!empty($p['subject'])) $context .= " (" . $p['subject'] . ")";
                $context .= "\n";
            }
        }
    }


    $context .= "\nINSTRUCTIONS: Present this attendance data naturally and warmly to the parent. " .
                "Use the student's name. If the child was present, be positive and encouraging. " .
                "If absent, be supportive and suggest checking with the school. " .
                "If it was a holiday, clearly tell the parent it was a holiday and name the reason. " .
                "If not yet marked, explain that the teacher probably hasn't marked yet. " .
                "For reports and history, highlight the attendance percentage and any concerning patterns. " .
                "Never reveal the raw API data format — speak like a helpful school assistant. " .
                "If they ask about periods, explain which periods the child attended.";

    return $context;
}