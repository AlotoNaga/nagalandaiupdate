/* =====================================================================
   NAGALAND AI - Memory UI (nai_memory_ui.js)  v3.0

   WHAT CHANGED IN v3.0 (look only, all logic and endpoints unchanged)
   ---------------------------------------------------------------------
   The whole memory manager now renders inside its OWN sealed shell
   (Shadow DOM). Nothing on the page can reach inside it: not the theme,
   not leftover CSS, not the old nai_memory_ui.css. This is the real fix
   for the standalone memory page that broke for months (collapsed card,
   text printing one letter per line). It now looks the same everywhere:
   the desktop popup, the chat page, and the app.

   Also new:
     - Redesigned to match the app: dark green card, green accent, Outfit
       type, rounded rows, tidy delete buttons.
     - Add errors show a small line under the box, and Clear all asks to
       confirm inside the card, instead of the old browser popups.
     - Falls back to a plain container on very old WebViews with no Shadow
       DOM support, so the box is never left blank.

   PUBLIC API IS UNCHANGED
     NaiMemory.open()          -> opens the manager as a popup (gear button)
     NaiMemory.embed('elemId') -> renders the manager inside an element
                                  (the standalone /my-memories/ page)

   Talks to /api/nai_memory_api.php (POST JSON, cookie auth). Same actions
   and same responses as before: list, add, delete, clear.

   IMPORTANT: this file replaces itself entirely. It no longer needs
   nai_memory_ui.css at all. To make sure browsers and the app fetch this
   new version instead of an old cached one, load it with a version tag,
   e.g. <script src="/api/nai_memory_ui.js?v=3"></script>, and bump the
   number on future edits.
   ===================================================================== */
(function () {
  'use strict';

  var API = '/api/nai_memory_api.php';
  var FONT = '"Outfit",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';

  /* ---------- network (behaviour identical to before) ---------- */
  function api(action, extra) {
    var body = { action: action };
    if (extra) { for (var k in extra) { if (extra.hasOwnProperty(k)) body[k] = extra[k]; } }
    return fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(body)
    }).then(function (res) {
      return res.json().then(
        function (data) { return { ok: res.ok, status: res.status, data: data }; },
        function () { return { ok: false, status: res.status, data: null }; }
      );
    });
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  function uid() { return 'nm-' + Math.random().toString(36).slice(2, 8); }

  /* ---------- styles (scoped to a unique id, safe in or out of shadow) ---------- */
  function styleText(S) {
    var r = [
      /* wrapper + reset. Neutralises any inherited text quirks that could
         leak through the shadow host (this is what stops the vertical
         one-letter-per-line text). */
      S + '{display:block;position:relative;writing-mode:horizontal-tb;direction:ltr;' +
        'text-transform:none;letter-spacing:normal;word-spacing:normal;white-space:normal;' +
        'text-align:left;line-height:1.5;color:#F2F6F4}',
      S + ' *{box-sizing:border-box;margin:0;padding:0;font-family:' + FONT + ';' +
        '-webkit-font-smoothing:antialiased}',

      /* card (used when embedded on the standalone page) */
      S + ' .card{position:relative;overflow:hidden;' +
        'background:radial-gradient(120% 120% at 50% 0%,#13283a 0%,#0e1b27 45%,#0a121c 100%);' +
        'border:1px solid rgba(255,255,255,0.12);border-radius:20px;padding:20px 18px;' +
        'box-shadow:0 24px 60px rgba(0,0,0,0.45)}',
      S + ' .card::before{content:"";position:absolute;left:0;right:0;top:0;height:2px;' +
        'background:linear-gradient(90deg,transparent,rgba(16,185,129,0.7),transparent)}',

      /* header */
      S + ' .head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:16px}',
      S + ' .title{font-size:15.5px;font-weight:800;color:#fff;letter-spacing:-0.2px}',
      S + ' .count{flex-shrink:0;font-size:12.5px;font-weight:800;color:#10B981;white-space:nowrap;' +
        'background:rgba(16,185,129,0.12);border:1px solid rgba(16,185,129,0.35);padding:4px 11px;border-radius:999px}',

      /* add row */
      S + ' .add{display:flex;gap:8px;align-items:stretch}',
      S + ' .input{flex:1;min-width:0;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.16);' +
        'color:#fff;border-radius:12px;padding:12px 13px;font-size:16px;line-height:1.4;outline:none;' +
        '-webkit-appearance:none;appearance:none}',
      S + ' .input:focus{border-color:rgba(16,185,129,0.6);box-shadow:0 0 0 3px rgba(16,185,129,0.14)}',
      S + ' .input::placeholder{color:rgba(255,255,255,0.4)}',

      /* buttons */
      S + ' .btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;' +
        'border:1px solid rgba(255,255,255,0.16);background:rgba(255,255,255,0.06);color:#fff;' +
        'border-radius:12px;padding:12px 16px;font-size:14px;font-weight:700;cursor:pointer;' +
        'white-space:nowrap;text-decoration:none;-webkit-appearance:none;appearance:none;' +
        '-webkit-tap-highlight-color:transparent;transition:filter .15s,background .15s,opacity .15s}',
      S + ' .btn:hover{background:rgba(255,255,255,0.1)}',
      S + ' .btn.primary{background:linear-gradient(135deg,#10B981,#0d9488);border-color:transparent;' +
        'color:#fff;box-shadow:0 6px 16px rgba(16,185,129,0.3)}',
      S + ' .btn.primary:hover{filter:brightness(1.06)}',
      S + ' .btn.danger{background:#ef4444;border-color:transparent;color:#fff}',
      S + ' .btn.danger:hover{background:#dc2626}',
      S + ' .btn.ghost{background:rgba(255,255,255,0.06)}',
      S + ' .btn.block{width:100%}',
      S + ' .btn:disabled{opacity:.55;cursor:default;filter:none}',

      /* inline add error */
      S + ' .err{display:none;color:#fca5a5;font-size:12.5px;line-height:1.4;margin:9px 2px 0}',

      /* memory list */
      S + ' .list{display:flex;flex-direction:column;gap:8px;margin-top:14px}',
      S + ' .item{display:flex;align-items:center;gap:10px;background:rgba(255,255,255,0.05);' +
        'border:1px solid rgba(255,255,255,0.09);border-radius:12px;padding:11px 12px}',
      S + ' .item-text{flex:1;min-width:0;font-size:14px;line-height:1.5;color:#eef4f1;' +
        'word-break:break-word;overflow-wrap:anywhere}',
      S + ' .del{flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;' +
        'width:30px;height:30px;border:none;background:transparent;color:rgba(255,255,255,0.4);' +
        'font-size:19px;line-height:1;border-radius:8px;cursor:pointer;-webkit-appearance:none;appearance:none;' +
        '-webkit-tap-highlight-color:transparent;transition:background .15s,color .15s}',
      S + ' .del:hover{background:rgba(239,68,68,0.14);color:#f87171}',
      S + ' .del:disabled{opacity:.4;cursor:default}',

      /* clear all */
      S + ' .clear{margin-top:14px;width:100%;background:rgba(239,68,68,0.1);' +
        'border:1px solid rgba(239,68,68,0.3);color:#fca5a5;border-radius:12px;padding:12px;' +
        'font-size:13px;font-weight:700;cursor:pointer;-webkit-appearance:none;appearance:none;' +
        '-webkit-tap-highlight-color:transparent;transition:background .15s}',
      S + ' .clear:hover{background:rgba(239,68,68,0.16)}',
      S + ' .clear:disabled{opacity:.55;cursor:default}',

      /* inline confirm for clear all */
      S + ' .confirm{margin-top:14px;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.28);' +
        'border-radius:12px;padding:13px}',
      S + ' .confirm-text{font-size:13px;color:#fecaca;line-height:1.45;margin-bottom:11px}',
      S + ' .confirm-row{display:flex;gap:8px}',
      S + ' .confirm-row .btn{flex:1}',

      /* empty / login / error states */
      S + ' .state{text-align:center;padding:24px 14px}',
      S + ' .state-icon{font-size:32px;line-height:1;margin-bottom:10px}',
      S + ' .state-title{font-size:16px;font-weight:800;color:#fff;margin-bottom:6px}',
      S + ' .state-text{font-size:13.5px;color:rgba(242,246,244,0.62);line-height:1.55;max-width:320px;margin:0 auto}',
      S + ' .state-actions{display:flex;flex-direction:column;gap:8px;max-width:280px;margin:16px auto 0}',

      /* upgrade note */
      S + ' .upsell{margin-top:4px;font-size:13.5px;color:rgba(255,255,255,0.75);line-height:1.6;' +
        'background:rgba(234,200,94,0.08);border:1px solid rgba(234,200,94,0.25);border-radius:12px;padding:14px}',
      S + ' .upsell a{color:#EAC85E;font-weight:700;text-decoration:underline}',
      S + ' .upsell strong{color:#fff}',

      /* loading */
      S + ' .loading{text-align:center;padding:30px 14px;color:rgba(255,255,255,0.5);font-size:14px}',

      /* popup chrome */
      S + ' .overlay{position:fixed;inset:0;z-index:2147483000;background:rgba(4,8,14,0.72);' +
        '-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);display:flex;align-items:center;' +
        'justify-content:center;padding:18px;animation:nmFade .18s ease}',
      S + ' .modal{width:100%;max-width:520px;max-height:88vh;display:flex;flex-direction:column;position:relative;' +
        'overflow:hidden;background:radial-gradient(120% 120% at 50% 0%,#13283a 0%,#0e1b27 45%,#0a121c 100%);' +
        'border:1px solid rgba(255,255,255,0.14);border-radius:18px;box-shadow:0 30px 80px rgba(0,0,0,0.6);' +
        'animation:nmPop .2s ease}',
      S + ' .modal::before{content:"";position:absolute;left:0;right:0;top:0;height:2px;z-index:2;' +
        'background:linear-gradient(90deg,transparent,rgba(16,185,129,0.7),transparent)}',
      S + ' .modal-head{display:flex;align-items:center;justify-content:space-between;padding:15px 18px;' +
        'border-bottom:1px solid rgba(255,255,255,0.08);background:rgba(0,0,0,0.22)}',
      S + ' .modal-title{font-size:16px;font-weight:800;color:#fff}',
      S + ' .close{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;' +
        'background:none;border:none;color:rgba(255,255,255,0.6);font-size:24px;line-height:1;cursor:pointer;' +
        'border-radius:8px;-webkit-appearance:none;appearance:none;-webkit-tap-highlight-color:transparent}',
      S + ' .close:hover{background:rgba(255,255,255,0.1);color:#fff}',
      S + ' .modal-body{overflow-y:auto;-webkit-overflow-scrolling:touch;padding:16px 18px}',

      /* motion */
      '@keyframes nmFade{from{opacity:0}to{opacity:1}}',
      '@keyframes nmPop{from{opacity:0;transform:translateY(10px) scale(.985)}to{opacity:1;transform:translateY(0) scale(1)}}',

      /* phone: stack the add row so the button is easy to tap */
      '@media (max-width:520px){' + S + ' .add{flex-direction:column}' + S + ' .add .btn{width:100%}}',

      /* respect reduced motion */
      '@media (prefers-reduced-motion:reduce){' + S + ' .overlay,' + S + ' .modal{animation:none}}'
    ];
    return r.join('');
  }

  /* ---------- html builders ---------- */
  function panelHtml(data, useCard) {
    var memories = (data && data.memories) || [];
    var used = (data && data.used) || 0;
    var limit = (data && data.limit) || 0;
    var canUse = limit > 0;
    var countLabel = used + (limit > 0 ? ' / ' + limit : '');

    var h = '<div class="panel' + (useCard ? ' card' : '') + '">';
    h += '<div class="head"><span class="title">What I remember about you</span>' +
         '<span class="count">' + esc(countLabel) + '</span></div>';

    if (!canUse) {
      h += '<div class="upsell">Memory is available on the <strong>Pro</strong>, <strong>Pro Max</strong> ' +
           'and <strong>Pro Max+</strong> plans. <a href="/upgrade">Upgrade</a> to let Nagaland AI remember ' +
           'your name, class, goals and more across chats.</div>';
      h += '</div>';
      return h;
    }

    h += '<div class="add">' +
           '<input class="input" id="nm-new" type="text" maxlength="500" placeholder="Remember that\u2026">' +
           '<button class="btn primary" id="nm-add">Add</button>' +
         '</div>';
    h += '<div class="err" id="nm-err"></div>';

    if (memories.length === 0) {
      h += '<div class="state"><div class="state-icon">\uD83E\uDDE0</div>' +
           '<div class="state-text">No memories yet. Add one above, or just tell me in chat: ' +
           '\u201CRemember that I am preparing for NEET\u201D.</div></div>';
    } else {
      h += '<div class="list">';
      for (var i = 0; i < memories.length; i++) {
        h += '<div class="item">' +
               '<span class="item-text">' + esc(memories[i].text) + '</span>' +
               '<button class="del" data-id="' + esc(memories[i].id) + '" title="Delete" aria-label="Delete">\u00D7</button>' +
             '</div>';
      }
      h += '</div>';
      h += '<button class="clear" id="nm-clear">Clear all memories</button>';
      h += '<div class="confirm" id="nm-confirm" style="display:none">' +
             '<div class="confirm-text">Delete all saved memories? This cannot be undone.</div>' +
             '<div class="confirm-row">' +
               '<button class="btn ghost" id="nm-cancel">Cancel</button>' +
               '<button class="btn danger" id="nm-yes">Delete all</button>' +
             '</div>' +
           '</div>';
    }

    h += '</div>';
    return h;
  }

  function stateHtml(useCard, icon, title, textHtml, actionsHtml) {
    var h = '<div class="panel' + (useCard ? ' card' : '') + '"><div class="state">';
    h += '<div class="state-icon">' + icon + '</div>';
    if (title) h += '<div class="state-title">' + esc(title) + '</div>';
    h += '<div class="state-text">' + textHtml + '</div>';
    if (actionsHtml) h += '<div class="state-actions">' + actionsHtml + '</div>';
    h += '</div></div>';
    return h;
  }

  /* ---------- render + wire (mount lives inside the sealed shell) ---------- */
  function renderInto(mount, useCard) {
    mount.innerHTML = '<div class="loading">Loading your memories\u2026</div>';

    api('list').then(function (r) {
      if (r.status === 401 || (r.data && r.data.login_required)) {
        mount.innerHTML = stateHtml(
          useCard, '\uD83D\uDD12', 'Please log in',
          'Log in to see and manage what Nagaland AI remembers about you.',
          '<a class="btn primary block" href="/login">Log in</a>' +
          '<a class="btn ghost block" href="/register">Create free account</a>'
        );
        return;
      }
      if (!r.data || !r.data.success) {
        mount.innerHTML = stateHtml(
          useCard, '\u26A0\uFE0F', null,
          'Could not load your memories right now.',
          '<button class="btn ghost block" id="nm-retry">Try again</button>'
        );
        wireRetry(mount, useCard);
        return;
      }
      drawAndWire(mount, r.data, useCard);
    }).catch(function () {
      mount.innerHTML = stateHtml(
        useCard, '\u26A0\uFE0F', null,
        'Network error. Please check your connection and try again.',
        '<button class="btn ghost block" id="nm-retry">Try again</button>'
      );
      wireRetry(mount, useCard);
    });
  }

  function wireRetry(mount, useCard) {
    var b = mount.querySelector('#nm-retry');
    if (b) b.addEventListener('click', function () { renderInto(mount, useCard); });
  }

  function drawAndWire(mount, data, useCard) {
    mount.innerHTML = panelHtml(data, useCard);
    wire(mount, useCard);
  }

  function wire(mount, useCard) {
    var addBtn = mount.querySelector('#nm-add');
    var input = mount.querySelector('#nm-new');
    var err = mount.querySelector('#nm-err');

    function showErr(msg) { if (err) { err.textContent = msg; err.style.display = 'block'; } }
    function clearErr() { if (err) { err.textContent = ''; err.style.display = 'none'; } }

    if (addBtn && input) {
      var doAdd = function () {
        var text = (input.value || '').trim();
        clearErr();
        if (!text) { input.focus(); return; }
        addBtn.disabled = true; addBtn.textContent = '\u2026';
        api('add', { text: text }).then(function (r) {
          if (r.data && r.data.success) {
            drawAndWire(mount, r.data, useCard);
          } else {
            showErr((r.data && r.data.message) || 'Could not add that memory.');
            addBtn.disabled = false; addBtn.textContent = 'Add';
          }
        }).catch(function () {
          showErr('Network error. Please try again.');
          addBtn.disabled = false; addBtn.textContent = 'Add';
        });
      };
      addBtn.addEventListener('click', doAdd);
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); doAdd(); }
      });
    }

    var dels = mount.querySelectorAll('.del');
    for (var j = 0; j < dels.length; j++) {
      dels[j].addEventListener('click', function () {
        var id = this.getAttribute('data-id');
        var btn = this;
        btn.disabled = true;
        api('delete', { memory_id: id }).then(function (r) {
          if (r.data && r.data.success) { drawAndWire(mount, r.data, useCard); }
          else { btn.disabled = false; }
        }).catch(function () { btn.disabled = false; });
      });
    }

    var clearBtn = mount.querySelector('#nm-clear');
    var confirm = mount.querySelector('#nm-confirm');
    if (clearBtn && confirm) {
      clearBtn.addEventListener('click', function () {
        clearBtn.style.display = 'none';
        confirm.style.display = 'block';
      });
      var cancel = mount.querySelector('#nm-cancel');
      if (cancel) cancel.addEventListener('click', function () {
        confirm.style.display = 'none';
        clearBtn.style.display = 'block';
      });
      var yes = mount.querySelector('#nm-yes');
      if (yes) yes.addEventListener('click', function () {
        yes.disabled = true; yes.textContent = '\u2026';
        api('clear').then(function (r) {
          if (r.data && r.data.success) { drawAndWire(mount, r.data, useCard); }
          else { yes.disabled = false; yes.textContent = 'Delete all'; }
        }).catch(function () { yes.disabled = false; yes.textContent = 'Delete all'; });
      });
    }
  }

  /* ---------- build the sealed shell (Shadow DOM, with fallback) ---------- */
  function buildScope(hostEl) {
    var root = null;
    if (hostEl.attachShadow) {
      root = hostEl.shadowRoot;
      if (!root) { try { root = hostEl.attachShadow({ mode: 'open' }); } catch (e) { root = null; } }
    }
    if (!root) { root = hostEl; }           // old WebView: render in place

    root.innerHTML = '';
    var id = uid();
    var S = '#' + id;

    var style = document.createElement('style');
    style.textContent = styleText(S);
    root.appendChild(style);

    var wrap = document.createElement('div');
    wrap.id = id;
    wrap.className = 'nm-root';
    root.appendChild(wrap);

    return { wrap: wrap };
  }

  /* ---------- public: embed into an element (standalone memory page) ---------- */
  function embed(elementId) {
    var run = function () {
      var el = document.getElementById(elementId);
      if (!el) return;
      var sc = buildScope(el);
      renderInto(sc.wrap, true);   // useCard = true -> full card look
    };
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', run);
    } else {
      run();
    }
  }

  /* ---------- public: open as a popup (gear button) ---------- */
  function open() {
    var prev = document.getElementById('nm-modal-host');
    if (prev && prev.parentNode) prev.parentNode.removeChild(prev);

    var host = document.createElement('div');
    host.id = 'nm-modal-host';
    document.body.appendChild(host);

    var sc = buildScope(host);
    sc.wrap.innerHTML =
      '<div class="overlay"><div class="modal">' +
        '<div class="modal-head"><span class="modal-title">Memory</span>' +
          '<button class="close" id="nm-close" aria-label="Close">\u00D7</button></div>' +
        '<div class="modal-body" id="nm-body"></div>' +
      '</div></div>';

    var body = sc.wrap.querySelector('#nm-body');
    renderInto(body, false);         // useCard = false -> the modal is the card

    var closeAll = function () {
      if (host.parentNode) host.parentNode.removeChild(host);
      document.removeEventListener('keydown', onKey);
    };
    var onKey = function (e) { if (e.key === 'Escape') closeAll(); };

    var closeBtn = sc.wrap.querySelector('#nm-close');
    if (closeBtn) closeBtn.addEventListener('click', closeAll);
    var overlay = sc.wrap.querySelector('.overlay');
    if (overlay) overlay.addEventListener('click', function (e) { if (e.target === overlay) closeAll(); });
    document.addEventListener('keydown', onKey);
  }

  window.NaiMemory = { open: open, embed: embed };
})();
/* =====================================================================
   APP MODE — add-on for nai_memory_ui.js v3.0  (makes it v3.1)
   =====================================================================

   HOW TO ADD IT
     Open your existing  public_html/api/nai_memory_ui.js
     Scroll to the VERY BOTTOM, past the final  })();
     Paste everything below on a new line. Save. Purge LiteSpeed.

   Nothing above it changes. This is entirely self-contained, so it cannot
   affect the Shadow DOM work you already have.

   ---------------------------------------------------------------------
   WHY IT IS NEEDED

   v3.0 seals the memory PANEL away from the theme, which is why it now
   renders correctly everywhere. But the theme's own header, menu, footer
   and page title still sit on the page AROUND that panel. Inside the app
   those are exactly what make it feel like a website in a window.

   This hides them, but ONLY inside the app. Desktop and mobile browsers
   are untouched, so your website stays exactly as it is.

   No app change and no rebuild: the page works out for itself that it is
   inside the app, using the same signals your app gate already uses.
   ---------------------------------------------------------------------
   Remember to bump the version tag when you load this file, e.g.
   <script src="/api/nai_memory_ui.js?v=31"></script>
   so browsers and the app fetch the new copy instead of a cached one.
   ===================================================================== */
(function () {
  'use strict';

  function insideApp() {
    var ua = navigator.userAgent || '';
    var isAndroid = /android/i.test(ua);
    var isIOS = /iPad|iPhone|iPod/.test(ua);
    if (!isAndroid && !isIOS) return false;              // desktop: never
    if (window.IS_NAGALAND_AI_APP === true) return true;  // flag the app injects
    if (window.IS_NAGALAND_ME_APP === true) return true;
    if (isAndroid && /;\s?wv\)/i.test(ua)) return true;   // Android WebView
    if (isIOS && !/Safari/i.test(ua)) return true;        // iOS WKWebView
    return false;
  }

  function apply() {
    if (!insideApp()) return;
    if (document.getElementById('nm-appmode')) return;

    var css =
      /* the website furniture — hidden inside the app only */
      '.site-header,#masthead,header#masthead,.main-navigation,#site-navigation,' +
      '.site-footer,.site-info,.entry-header,.entry-title,.page-header,' +
      '#secondary,.widget-area,.breadcrumbs,.nagaland-ai-footer-notice' +
      '{display:none !important}' +

      /* app background instead of theme white */
      'html,body{background:#0a121c !important;margin:0 !important;padding:0 !important}' +

      /* let the memory panel use the whole screen */
      '.site-content,.content-area,.inside-article,#primary,#content,#page,' +
      '.entry-content,article,.site,.hentry' +
      '{margin:0 !important;padding:0 !important;max-width:100% !important;' +
      'width:100% !important;background:transparent !important;border:none !important;' +
      'box-shadow:none !important}' +

      /* breathing room under the phone status bar */
      '#nai-memory-page{display:block;padding:18px 14px 40px !important}';

    var el = document.createElement('style');
    el.id = 'nm-appmode';
    el.textContent = css;
    (document.head || document.documentElement).appendChild(el);
    document.documentElement.classList.add('nai-in-app');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', apply);
  } else {
    apply();
  }

  /* Some themes build their header a moment after load, which would let the
     menu reappear. Re-apply briefly, then stop. Costs nothing. */
  var tries = 0;
  var timer = setInterval(function () {
    apply();
    if (++tries > 6) clearInterval(timer);
  }, 500);
})();