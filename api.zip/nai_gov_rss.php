<?php
/**
 * ═══════════════════════════════════════════════════════════
 * NAGALAND AI — Government RSS Scraper (nai_gov_rss.php)
 * ═══════════════════════════════════════════════════════════
 * Scrapes government websites that have NO native RSS feed
 * and outputs valid RSS XML so the existing system can read it.
 *
 * Usage in nai_sources.php:
 *   ['name' => 'DIPR Nagaland', 'url' => 'https://nagalandai.com/api/nai_gov_rss.php?source=dipr']
 *   ['name' => 'Department of School Education', 'url' => 'https://nagalandai.com/api/nai_gov_rss.php?source=education']
 *
 * Supported sources: ?source=dipr | ?source=education
 * Cache: 1 hour per source
 * ═══════════════════════════════════════════════════════════
 */

date_default_timezone_set('Asia/Kolkata');
header('Content-Type: application/rss+xml; charset=utf-8');

$source = strtolower(trim($_GET['source'] ?? ''));

if (!in_array($source, ['dipr', 'education'], true)) {
  echo '<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>Error</title><description>Invalid source. Use ?source=dipr or ?source=education</description></channel></rss>';
  exit;
}

/* =========================================================
   CACHE
   ========================================================= */
$cacheDir = __DIR__ . '/nai_gov_cache';
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);

$cacheFile = $cacheDir . '/' . $source . '.xml';
$cacheTtl  = 3600; // 1 hour

if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $cacheTtl) {
  readfile($cacheFile);
  exit;
}

/* =========================================================
   FETCH HELPER
   ========================================================= */
function gov_fetch($url, $timeout = 15) {
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT        => $timeout,
    CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_ENCODING       => '',
  ]);
  $body = curl_exec($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  return ($body !== false && $code < 400) ? $body : null;
}

/* =========================================================
   SCRAPER: DIPR NAGALAND (ipr.nagaland.gov.in)
   ========================================================= */
function scrape_dipr() {
  $items = [];

  $urls = [
    'https://ipr.nagaland.gov.in/',
    'https://ipr.nagaland.gov.in/naga-news',
  ];

  foreach ($urls as $pageUrl) {
    $html = gov_fetch($pageUrl);
    if (!$html) continue;

    if (preg_match_all('/<a[^>]+href=["\']([^"\']*nagaland\.gov\.in[^"\']*)["\'][^>]*>(.*?)<\/a>/is', $html, $matches, PREG_SET_ORDER)) {
      foreach ($matches as $m) {
        $url   = trim($m[1]);
        $title = trim(strip_tags($m[2]));

        if (mb_strlen($title) < 15) continue;
        if (preg_match('/^(home|about|contact|gallery|activities|terms|privacy|sitemap|login|register|read more)/i', $title)) continue;
        if (preg_match('/(\.pdf|\.jpg|\.png|\.doc)$/i', $url)) continue;

        $isDuplicate = false;
        foreach ($items as $existing) {
          if ($existing['url'] === $url || $existing['title'] === $title) {
            $isDuplicate = true;
            break;
          }
        }
        if ($isDuplicate) continue;

        $pubDate = '';
        $datePattern = '/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s+\d{4}/i';
        $pos = strpos($html, $m[0]);
        if ($pos !== false) {
          $nearby = substr($html, $pos, 500);
          if (preg_match($datePattern, $nearby, $dateMatch)) {
            $pubDate = date('r', strtotime($dateMatch[0]));
          }
        }

        $items[] = [
          'title'   => html_entity_decode($title, ENT_QUOTES | ENT_HTML5),
          'url'     => $url,
          'pubDate' => $pubDate,
        ];

        if (count($items) >= 10) break;
      }
    }

    if (count($items) >= 10) break;
  }

  return $items;
}

/* =========================================================
   SCRAPER: DEPT OF SCHOOL EDUCATION (education.nagaland.gov.in)
   ========================================================= */
function scrape_education() {
  $items = [];

  // Main page has "Latest News & Updates" section
  // Notifications page has the full list
  $urls = [
    'https://education.nagaland.gov.in/',
    'https://education.nagaland.gov.in/category/news-updates/',
  ];

  foreach ($urls as $pageUrl) {
    $html = gov_fetch($pageUrl);
    if (!$html) continue;

    // Pattern: links to education.nagaland.gov.in posts with dates
    // Homepage format: <a href="https://education.nagaland.gov.in/some-post/">Title</a>March 5, 2026
    // Category format: standard WordPress archive with <article> or <h2><a> patterns

    if (preg_match_all('/<a[^>]+href=["\']((https?:\/\/education\.nagaland\.gov\.in\/[^"\']+))["\'][^>]*>(.*?)<\/a>/is', $html, $matches, PREG_SET_ORDER)) {
      foreach ($matches as $m) {
        $url   = trim($m[1]);
        $title = trim(strip_tags($m[3]));

        if (mb_strlen($title) < 10) continue;
        // Skip navigation/menu/footer links
        if (preg_match('/^(home|about|contact|department|terms|privacy|sitemap|read more|view all|programmes|schemes|mid day|who|rti|academic|samagra|saakshar)/i', $title)) continue;
        // Skip non-post pages
        if (preg_match('/\/(about|contact|category|tag|wp-content|mid-day|school-details|rtipionapio|rtidisclusures|terms-of-use)\//i', $url)) continue;

        $isDuplicate = false;
        foreach ($items as $existing) {
          if ($existing['url'] === $url || $existing['title'] === $title) {
            $isDuplicate = true;
            break;
          }
        }
        if ($isDuplicate) continue;

        // Extract date near the link
        $pubDate = '';
        // WordPress date patterns: "March 5, 2026" or "February 26, 2026"
        $datePatterns = [
          '/(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}/i',
          '/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},?\s+\d{4}/i',
        ];
        $pos = strpos($html, $m[0]);
        if ($pos !== false) {
          $nearby = substr($html, $pos, 500);
          foreach ($datePatterns as $dp) {
            if (preg_match($dp, $nearby, $dateMatch)) {
              $pubDate = date('r', strtotime($dateMatch[0]));
              break;
            }
          }
        }

        $items[] = [
          'title'   => html_entity_decode($title, ENT_QUOTES | ENT_HTML5),
          'url'     => $url,
          'pubDate' => $pubDate,
        ];

        if (count($items) >= 10) break;
      }
    }

    if (count($items) >= 10) break;
  }

  return $items;
}

/* =========================================================
   BUILD RSS XML
   ========================================================= */
$items = [];
$feedTitle = '';
$feedLink  = '';
$feedDesc  = '';

switch ($source) {
  case 'dipr':
    $items     = scrape_dipr();
    $feedTitle = 'DIPR Nagaland - Press Releases';
    $feedLink  = 'https://ipr.nagaland.gov.in/';
    $feedDesc  = 'Latest press releases from Department of Information & Public Relations, Nagaland';
    break;
  case 'education':
    $items     = scrape_education();
    $feedTitle = 'Department of School Education, Nagaland';
    $feedLink  = 'https://education.nagaland.gov.in/';
    $feedDesc  = 'Latest notifications from Department of School Education, Nagaland';
    break;
}

// Build XML
$xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
$xml .= '<rss version="2.0">' . "\n";
$xml .= '<channel>' . "\n";
$xml .= '  <title>' . htmlspecialchars($feedTitle) . '</title>' . "\n";
$xml .= '  <link>' . htmlspecialchars($feedLink) . '</link>' . "\n";
$xml .= '  <description>' . htmlspecialchars($feedDesc) . '</description>' . "\n";
$xml .= '  <lastBuildDate>' . date('r') . '</lastBuildDate>' . "\n";

foreach ($items as $it) {
  $xml .= '  <item>' . "\n";
  $xml .= '    <title>' . htmlspecialchars($it['title']) . '</title>' . "\n";
  $xml .= '    <link>' . htmlspecialchars($it['url']) . '</link>' . "\n";
  $xml .= '    <guid>' . htmlspecialchars($it['url']) . '</guid>' . "\n";
  if ($it['pubDate']) {
    $xml .= '    <pubDate>' . $it['pubDate'] . '</pubDate>' . "\n";
  }
  $xml .= '  </item>' . "\n";
}

$xml .= '</channel>' . "\n";
$xml .= '</rss>';

// Cache the output (only if we got items)
if (!empty($items)) {
  @file_put_contents($cacheFile, $xml);
}

echo $xml;