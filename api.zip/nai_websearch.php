<?php
// public_html/api/nai_websearch.php
// NAGALAND AI — Live Web Search Module v1.0 (Brave Search API)
//
// Gives the AI real internet search when a user explicitly asks for it
// ("search online...", "google this...", "look it up on the internet").
//
// SETUP (one time):
//   1. Create a free API key at https://api-dashboard.search.brave.com
//   2. In wp-config.php, below the OPENAI_API_KEY line, add:
//        define('BRAVE_SEARCH_KEY', 'YOUR-KEY-HERE');
//   That is all. If the key is missing, this module stays silent and
//   the AI behaves exactly as before.
//
// COST CONTROL:
//   - Searches run ONLY when the user clearly asks to search.
//   - Identical queries are cached for 30 minutes (a repeated question
//     costs zero quota).
//   - A daily cap (NAI_SEARCH_DAILY_CAP below) protects the free
//     monthly quota. 60/day stays safely under Brave's free 2,000/month.

if (!defined('ABSPATH') && !defined('NAI_LOADED')) {
  exit;
}

if (!defined('NAI_SEARCH_DAILY_CAP')) {
  define('NAI_SEARCH_DAILY_CAP', 60); // change this number to allow more/fewer searches per day
}

/* =========================================================
   1. INTENT — did the user ask us to search the internet?
   Explicit requests only, so normal chat never spends quota.
   ========================================================= */
function nai_detect_search_intent($message) {
  $m = (string)$message;
  if (preg_match('/\b(search|look\s+up|look\s+it\s+up|check|find|browse)\b[^.?!]{0,50}\b(online|internet|web|google)\b/i', $m)) return true;
  if (preg_match('/\bgoogle\s+(it|this|that|for|about|search)\b/i', $m)) return true;
  if (preg_match('/\bon\s+google\b/i', $m)) return true;
  if (preg_match('/^\s*search\s+(for|about)\b/i', $m)) return true;
  return false;
}

/* =========================================================
   2. QUERY — turn the request into a clean search query
   "search online and tell me about hornbill festival dates"
   -> "hornbill festival dates"
   ========================================================= */
function nai_extract_search_query($message) {
  $q = trim((string)$message);

  // Strip the command words, keep the actual topic
  $q = preg_replace('/^\s*(please\s+|can\s+you\s+|could\s+you\s+|hey\s+)*/i', '', $q);
  $q = preg_replace('/\b(search|look\s+up|look\s+it\s+up|check|find|browse|google)\b/i', ' ', $q);
  $q = preg_replace('/\b(online|on\s+the\s+internet|the\s+internet|internet|on\s+the\s+web|the\s+web|web|on\s+google|google)\b/i', ' ', $q);
  $q = preg_replace('/\b(and\s+tell\s+me\s+about|and\s+tell\s+me|tell\s+me\s+about|tell\s+me|for\s+me|about|for|it|this|that)\b/i', ' ', $q, 3);
  $q = trim(preg_replace('/\s+/', ' ', $q), " \t\n\r.,?!");

  // If stripping removed everything, fall back to the original message
  if (mb_strlen($q) < 3) {
    $q = trim((string)$message);
  }
  return mb_substr($q, 0, 200);
}

/* =========================================================
   3. QUOTA GUARD — protects the free monthly allowance
   ========================================================= */
function nai_search_quota_ok() {
  $file = sys_get_temp_dir() . '/nai_search_count_' . date('Y-m-d') . '.txt';
  $count = file_exists($file) ? (int)@file_get_contents($file) : 0;
  if ($count >= NAI_SEARCH_DAILY_CAP) return false;
  @file_put_contents($file, $count + 1);
  return true;
}

/* =========================================================
   4. BRAVE CALL — with a 30-minute cache per query
   ========================================================= */
function nai_web_search_raw($query, $apiKey) {
  // Cache first: identical queries within 30 min cost no quota
  $cacheDir = __DIR__ . '/nai_cache';
  if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);
  $cacheFile = $cacheDir . '/nai_search_' . md5(mb_strtolower($query)) . '.json';

  if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 1800) {
    $cached = @json_decode(@file_get_contents($cacheFile), true);
    if (is_array($cached)) return $cached;
  }

  if (!nai_search_quota_ok()) return null;

  $url = 'https://api.search.brave.com/res/v1/web/search?' . http_build_query([
    'q' => $query,
    'count' => 5,
    'country' => 'IN',
    'search_lang' => 'en',
    'safesearch' => 'moderate',
  ]);

  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
      'Accept: application/json',
      'X-Subscription-Token: ' . $apiKey,
    ],
    CURLOPT_CONNECTTIMEOUT => 4,
    CURLOPT_TIMEOUT => 8,
    CURLOPT_SSL_VERIFYPEER => true,
  ]);
  $result = curl_exec($ch);
  $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $curlErr = curl_error($ch);
  curl_close($ch);

  if ($result === false || $httpCode !== 200) {
    if (function_exists('nai_log_error')) {
      nai_log_error('websearch', "http={$httpCode} curl={$curlErr} q=" . mb_substr($query, 0, 80));
    }
    return null;
  }

  $data = json_decode($result, true);
  if (!is_array($data)) return null;

  // Keep only what we need: title, url, description
  $results = [];
  $items = $data['web']['results'] ?? [];
  foreach ($items as $item) {
    if (!is_array($item)) continue;
    $title = trim(html_entity_decode(strip_tags((string)($item['title'] ?? ''))));
    $link  = trim((string)($item['url'] ?? ''));
    $desc  = trim(html_entity_decode(strip_tags((string)($item['description'] ?? ''))));
    if ($title === '' || $link === '') continue;
    $results[] = [
      'title' => mb_substr($title, 0, 150),
      'url'   => mb_substr($link, 0, 300),
      'desc'  => mb_substr($desc, 0, 300),
    ];
    if (count($results) >= 5) break;
  }

  if (count($results) > 0) {
    @file_put_contents($cacheFile, json_encode($results, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE));
  }
  return $results;
}

/* =========================================================
   5. CONTEXT — build the system message for the AI
   Returns '' when search is unavailable (no key / no results /
   quota reached) so chat.php can continue normally.
   ========================================================= */
function nai_web_search_context($message) {
  if (!defined('BRAVE_SEARCH_KEY') || !BRAVE_SEARCH_KEY) return '';

  $query = nai_extract_search_query($message);
  $results = nai_web_search_raw($query, BRAVE_SEARCH_KEY);

  if (!is_array($results) || count($results) === 0) {
    return "WEB SEARCH NOTE: The user asked you to search the internet. A live search was attempted for \"{$query}\" but no results could be fetched right now. Tell the user the live search could not be completed at this moment and answer from your own knowledge, clearly saying which part is from memory.";
  }

  $ctx = "LIVE WEB SEARCH RESULTS (fetched just now from the internet) for: \"{$query}\"\n\n";
  $n = 1;
  foreach ($results as $r) {
    $host = parse_url($r['url'], PHP_URL_HOST);
    $host = $host ? preg_replace('/^www\./', '', $host) : 'source';
    $ctx .= $n . '. ' . $r['title'] . "\n";
    if ($r['desc'] !== '') $ctx .= '   ' . $r['desc'] . "\n";
    $ctx .= '   Source: [' . $host . '](' . $r['url'] . ")\n\n";
    $n++;
  }
  $ctx .= "INSTRUCTIONS: Answer the user's question using these live results. " .
          "Mention that you searched the web. Cite 1-3 sources as markdown links " .
          "like [source name](url), never bare URLs, never bold-wrapped links. " .
          "If the results do not actually answer the question, say the search did " .
          "not find it — do NOT invent information.";
  return $ctx;
}