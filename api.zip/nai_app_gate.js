/* =====================================================================
   NAGALAND AI — APP GATE v2  (nai_app_gate.js)
   ---------------------------------------------------------------------
   Upload to:  public_html/api/nai_app_gate.js

   Then on BOTH pages (Home and the chat page), delete the old inline
   gate block and replace it with this single line:

       <script src="/api/nai_app_gate.js"></script>

   ---------------------------------------------------------------------
   WHAT IT DOES

   Desktop            -> full chat, untouched.
   Mobile browser     -> "Chat is now in the app" + store buttons.
   Inside the app     -> "Chat is in the app" pointing at the Chat tab,
                         with NO download buttons.

   WHY THE LAST CASE IS NEW

   The old gate deliberately allowed full website chat inside the app.
   That made sense before the app had its own chat. It does not now:
   when the AI sends a link, that link opens the website inside the app,
   and the user meets a SECOND chat that shares no history with the real
   one. Two chats, one app, neither aware of the other. This closes that.

   Handles both page layouts by itself, so the exact same file works on
   the homepage (.nai- classes) and the dedicated chat page (.naic-).
   ===================================================================== */
(function () {
  'use strict';

  function run() {
    var ua = navigator.userAgent || '';
    var isAndroid = /android/i.test(ua);
    var isIOS = /iPad|iPhone|iPod/.test(ua);

    // Desktop keeps the full chat experience — nothing to do.
    if (!isAndroid && !isIOS) return;

    /* Is this page being shown INSIDE our app?
       Two independent signals, either is enough:
         1. the flag the app injects on pages it opens as a tab
         2. the WebView signature — Android WebViews carry "; wv)", and
            iOS WKWebView has no "Safari" in its user agent  */
    var injectedFlag = (window.IS_NAGALAND_AI_APP === true ||
                        window.IS_NAGALAND_ME_APP === true);
    var looksLikeWebView = (isAndroid && /;\s?wv\)/i.test(ua)) ||
                           (isIOS && !/Safari/i.test(ua));
    var insideApp = injectedFlag || looksLikeWebView;

    /* Find whichever chat panel this page has.
       Homepage  -> a panel inside #nagaland-ai-app
       Chat page -> the whole #nagaland-ai-chat-app screen  */
    var host = document.querySelector('#nagaland-ai-app .nai-chat');
    var fullScreen = false;
    if (!host) {
      host = document.getElementById('nagaland-ai-chat-app');
      fullScreen = true;
    }
    if (!host) return;              // neither panel on this page
    if (host.querySelector('.naigate')) return;   // already applied

    injectStyles();

    var gate = document.createElement('div');
    gate.className = 'naigate' + (fullScreen ? ' naigate-full' : '');

    if (insideApp) {
      // Already in the app. Sending them to a store would be nonsense.
      gate.innerHTML =
        '<div class="naigate-icon">&#128172;</div>' +
        '<div class="naigate-title">Chat is in the app</div>' +
        '<div class="naigate-sub">You are viewing our website inside the app. ' +
        'Close this window and use the Chat tab, where your conversations ' +
        'and memory are saved.</div>' +
        '<div class="naigate-note">Tap the X at the top to go back to chat.</div>';
    } else {
      gate.innerHTML =
        '<div class="naigate-icon">&#10024;</div>' +
        '<div class="naigate-title">Chat is now in the app</div>' +
        '<div class="naigate-sub">Nagaland AI chat has moved to our free mobile app. ' +
        'Faster, smoother, and built for your phone.</div>' +
        (isIOS
          ? '<a class="naigate-btn" href="https://apps.apple.com/app/id6772763733">Download on the App Store</a>'
          : '<a class="naigate-btn" href="https://play.google.com/store/apps/details?id=com.nagalandme.nagalandai">Get it on Google Play</a>') +
        (isIOS
          ? '<a class="naigate-btn naigate-gold" href="https://play.google.com/store/apps/details?id=com.nagalandme.nagalandai">Android? Get it on Google Play</a>'
          : '<a class="naigate-btn naigate-gold" href="https://apps.apple.com/app/id6772763733">iPhone? Download on the App Store</a>') +
        '<div class="naigate-note">100% free &middot; No login required &middot; ' +
        'Chat also available on desktop at nagalandai.com</div>' +
        (fullScreen ? '<a class="naigate-home" href="/">Back to nagalandai.com</a>' : '');
    }

    host.appendChild(gate);

    // Disable the inputs behind the cover, whichever layout this is
    ['nai-input', 'nai-send', 'naic-input', 'naic-send'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.disabled = true;
    });
  }

  function injectStyles() {
    if (document.getElementById('naigate-styles')) return;
    var css =
      '.naigate{position:absolute;inset:0;z-index:60;display:flex;flex-direction:column;' +
      'align-items:center;justify-content:center;text-align:center;padding:26px 20px;' +
      'border-radius:22px;font-family:"Outfit",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;' +
      'background:linear-gradient(180deg,rgba(8,12,20,0.96),rgba(6,10,16,0.99))}' +
      '.naigate-full{position:fixed;z-index:99999;border-radius:0;padding:28px 22px;' +
      'background:radial-gradient(ellipse at bottom,#1b2735 0%,#090a0f 100%)}' +
      '.naigate-icon{width:64px;height:64px;border-radius:18px;display:flex;align-items:center;' +
      'justify-content:center;font-size:30px;margin-bottom:16px;' +
      'background:linear-gradient(135deg,#10B981 0%,#0d9488 100%);' +
      'box-shadow:0 10px 30px rgba(16,185,129,0.35)}' +
      '.naigate-title{font-size:22px;font-weight:800;color:#fff;margin-bottom:8px;letter-spacing:-0.3px}' +
      '.naigate-sub{font-size:13.5px;color:rgba(242,246,244,0.65);line-height:1.55;' +
      'max-width:310px;margin-bottom:20px}' +
      '.naigate-btn{display:block;width:100%;max-width:280px;padding:14px 18px;border-radius:13px;' +
      'font-size:15px;font-weight:700;text-decoration:none !important;color:#06130d !important;' +
      'background:#10B981;margin-bottom:10px;box-shadow:0 8px 22px rgba(16,185,129,0.35)}' +
      '.naigate-gold{background:#EAC85E;box-shadow:0 8px 22px rgba(234,200,94,0.25)}' +
      '.naigate-note{margin-top:10px;font-size:11.5px;color:rgba(242,246,244,0.4);' +
      'max-width:300px;line-height:1.5}' +
      '.naigate-home{margin-top:18px;font-size:13px;color:#67e8f9 !important;' +
      'text-decoration:underline !important}';
    var el = document.createElement('style');
    el.id = 'naigate-styles';
    el.textContent = css;
    (document.head || document.documentElement).appendChild(el);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();