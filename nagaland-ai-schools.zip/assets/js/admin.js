
/**
 * NAGALAND AI SCHOOLS — Admin JavaScript
 */
(function($) {
  'use strict';

  /* ─── Deactivate School ─── */
  $(document).on('click', '.nais-btn-deactivate', function() {
    var btn = $(this);
    var schoolId = btn.data('school-id');
    var schoolName = btn.data('school-name');

    if (!confirm('Are you sure you want to deactivate "' + schoolName + '"?\n\nThe school dashboard will be locked but all data will be preserved. You can reactivate it later.')) {
      return;
    }

    btn.prop('disabled', true).text('Deactivating...');

    $.post(naisAdmin.ajaxUrl, {
      action: 'nais_deactivate_school',
      nonce: naisAdmin.nonce,
      school_id: schoolId
    }, function(res) {
      if (res.success) {
        alert(res.data.message);
        location.reload();
      } else {
        alert('Error: ' + (res.data || 'Unknown error'));
        btn.prop('disabled', false).text('Deactivate');
      }
    }).fail(function() {
      alert('Network error. Please try again.');
      btn.prop('disabled', false).text('Deactivate');
    });
  });

  /* ─── Reactivate School ─── */
  $(document).on('click', '.nais-btn-reactivate', function() {
    var btn = $(this);
    var schoolId = btn.data('school-id');
    var schoolName = btn.data('school-name');

    if (!confirm('Reactivate "' + schoolName + '"?\n\nThe school dashboard will be unlocked and the school admin can access it again.')) {
      return;
    }

    btn.prop('disabled', true).text('Reactivating...');

    $.post(naisAdmin.ajaxUrl, {
      action: 'nais_reactivate_school',
      nonce: naisAdmin.nonce,
      school_id: schoolId
    }, function(res) {
      if (res.success) {
        alert(res.data.message);
        location.reload();
      } else {
        alert('Error: ' + (res.data || 'Unknown error'));
        btn.prop('disabled', false).text('Reactivate');
      }
    }).fail(function() {
      alert('Network error. Please try again.');
      btn.prop('disabled', false).text('Reactivate');
    });
  });

  /* ─── Hard Delete — Open Modal ─── */
  $(document).on('click', '.nais-btn-hard-delete', function() {
    var btn = $(this);
    var schoolName = btn.data('school-name');
    var schoolId = btn.data('school-id');
    var studentCount = btn.data('student-count') || 0;
    var teacherCount = btn.data('teacher-count') || 0;

    $('#nais-delete-school-name').text(schoolName);
    $('#nais-delete-school-id').val(schoolId);
    $('#nais-delete-school-expected').val(schoolName);
    $('#nais-confirm-school-name').val('');
    $('#nais-confirm-delete-btn').prop('disabled', true);
    $('#nais-delete-data-summary').text(
      'This school has ' + studentCount + ' student(s) and ' + teacherCount + ' teacher(s). All records will be permanently erased.'
    );
    $('#nais-delete-modal').fadeIn(200);
  });

  /* ─── Hard Delete — Enable button when name matches ─── */
  $(document).on('input', '#nais-confirm-school-name', function() {
    var typed = $(this).val().trim().toLowerCase();
    var expected = $('#nais-delete-school-expected').val().trim().toLowerCase();
    $('#nais-confirm-delete-btn').prop('disabled', typed !== expected);
  });

  /* ─── Hard Delete — Confirm ─── */
  $(document).on('click', '#nais-confirm-delete-btn', function() {
    var btn = $(this);
    var schoolId = $('#nais-delete-school-id').val();
    var confirmName = $('#nais-confirm-school-name').val();

    btn.prop('disabled', true).text('Deleting...');

    $.post(naisAdmin.ajaxUrl, {
      action: 'nais_hard_delete_school',
      nonce: naisAdmin.nonce,
      school_id: schoolId,
      confirm_name: confirmName
    }, function(res) {
      if (res.success) {
        $('#nais-delete-modal').fadeOut(200);
        alert(res.data.message);
        location.reload();
      } else {
        alert('Error: ' + (res.data || 'Unknown error'));
        btn.prop('disabled', false).text('Delete Permanently');
      }
    }).fail(function() {
      alert('Network error. Please try again.');
      btn.prop('disabled', false).text('Delete Permanently');
    });
  });

  /* ─── Modal — Close ─── */
  $(document).on('click', '.nais-modal-close, .nais-modal-cancel', function() {
    $('#nais-delete-modal').fadeOut(200);
  });
  $(document).on('click', '.nais-modal-overlay', function(e) {
    if (e.target === this) $(this).fadeOut(200);
  });

})(jQuery);