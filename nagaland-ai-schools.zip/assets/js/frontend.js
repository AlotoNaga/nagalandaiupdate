/**
 * ═══════════════════════════════════════════════
 * NAGALAND AI SCHOOLS — Frontend JavaScript v2.0
 * ═══════════════════════════════════════════════
 *
 * V2 Changes:
 *   - Homework: Teacher checklist (Done/Not Done/Half Done/No HW)
 *   - Exam Results: Document upload per student (not marks grid)
 *   - Teacher form: Subject + class teacher per class
 *   - Teacher page: Homework Check type
 */

(function($) {
  'use strict';

  /* ─── TAB SWITCHING ─── */
  $(document).on('click', '.nais-tab', function() {
    var tab = $(this).data('tab');
    $('.nais-tab').removeClass('active');
    $(this).addClass('active');
    $('.nais-tab-content').removeClass('active');
    $('#nais-tab-' + tab).addClass('active');
  });


  /* ═══════════════════════════════════════════
     TEACHER: LOAD STUDENTS FOR ATTENDANCE
     V2: Also handles Homework Check type
  ═══════════════════════════════════════════ */
  $(document).on('click', '#nais-load-students', function() {
    var classId = $('#nais-class-select').val();
    var date    = $('#nais-att-date').val();
    var attType = $('#nais-att-type').val();

    if (!classId) {
      alert('Please select a class.');
      return;
    }

    /* V2: If homework type, load homework checklist instead */
    if (attType === 'homework') {
      loadHomeworkChecklist(classId, date);
      return;
    }

    var $container = $('#nais-checklist-container');
    $container.html('<p>Loading students...</p>');

    $.post(naisData.ajaxUrl, {
      action:   'nais_get_attendance',
      nonce:    naisData.nonce,
      class_id: classId,
      date:     date
    }, function(res) {
      if (!res.success) {
        $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error loading students.') + '</p>');
        return;
      }

      var $holidayInfo = $('#nais-date-holiday-info');
      if (res.data.holiday) {
        var hType = res.data.holiday.type === 'half_day' ? '📋 Half Day' : '🎉 Holiday';
        var hTitle = res.data.holiday.title ? ' — ' + escHtml(res.data.holiday.title) : '';
        $holidayInfo.html('<div class="nais-alert nais-alert-holiday">' + hType + hTitle + '. Attendance is optional for this date.</div>').show();
      } else {
        $holidayInfo.hide();
      }

      var students = res.data.daily;
      if (!students || students.length === 0) {
        $container.html('<p>No students found in this class.</p>');
        return;
      }

      var subject = $('#nais-class-select option:selected').data('subject') || '';
      var typeLabel = '';
      if (attType !== 'daily' && subject) {
        typeLabel = '<div class="nais-subject-label">Subject: <strong>' + escHtml(subject) + '</strong> — Mark which students attended this class</div>';
      }

      var html = typeLabel + '<div class="nais-checklist">';
      students.forEach(function(s) {
        var currentStatus = s.status || '';

        html += '<div class="nais-checklist-row" data-student-id="' + s.student_id + '">';
        html += '  <div class="nais-student-info">';
        html += '    <div class="nais-student-name">' + escHtml(s.name) + '</div>';
        html += '    <div class="nais-student-roll">Roll: ' + escHtml(s.roll_no || '—') + '</div>';
        html += '  </div>';
        html += '  <div class="nais-status-buttons">';

        ['present', 'absent', 'late', 'excused'].forEach(function(st) {
          var activeClass = currentStatus === st ? ' active-' + st : '';
          html += '<button class="nais-status-btn' + activeClass + '" data-status="' + st + '">' + st.charAt(0).toUpperCase() + st.slice(1) + '</button>';
        });

        html += '  </div>';
        html += '  <input type="text" class="nais-remarks-input" placeholder="Remarks" value="' + escHtml(s.remarks || '') + '">';
        html += '</div>';
      });
      html += '</div>';

      $container.html(html);
      $('.nais-quick-actions').show();
      $('.nais-hw-quick-actions').hide();
      $('.nais-save-bar').show();
      $('#nais-save-attendance').show();
      $('#nais-save-homework').hide();
      updateSummary();
    });
  });


  /* ═══════════════════════════════════════════
     V2 TEACHER: HOMEWORK CHECKLIST
     Loads students, teacher marks Done/Not Done/
     Half Done/No Homework per student.
  ═══════════════════════════════════════════ */
  function loadHomeworkChecklist(classId, date) {
    var $container = $('#nais-checklist-container');
    $container.html('<p>Loading homework checklist...</p>');

    var subject = $('#nais-class-select option:selected').data('subject') || '';

    $.post(naisData.ajaxUrl, {
      action:   'nais_get_homework_checklist',
      nonce:    naisData.nonce,
      class_id: classId,
      hw_date:  date,
      subject:  subject
    }, function(res) {
      if (!res.success) {
        $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error loading checklist.') + '</p>');
        return;
      }

      var students = res.data.students;
      if (!students || students.length === 0) {
        $container.html('<p>No students found in this class.</p>');
        return;
      }

      var subjectLabel = subject ? '<div class="nais-subject-label">📋 Homework Check — Subject: <strong>' + escHtml(subject) + '</strong> — Date: ' + escHtml(date) + '</div>' : '<div class="nais-subject-label">📋 Homework Check — Date: ' + escHtml(date) + '</div>';

      var html = subjectLabel + '<div class="nais-checklist nais-hw-checklist">';
      students.forEach(function(s) {
        var currentStatus = s.status || '';

        html += '<div class="nais-checklist-row nais-hw-row" data-student-id="' + s.student_id + '">';
        html += '  <div class="nais-student-info">';
        html += '    <div class="nais-student-name">' + escHtml(s.name) + '</div>';
        html += '    <div class="nais-student-roll">Roll: ' + escHtml(s.roll_no || '—') + '</div>';
        html += '  </div>';
        html += '  <div class="nais-hw-status-buttons">';

        var statuses = [
          {key: 'done', label: '✓ Done', color: '#10b981'},
          {key: 'not_done', label: '✗ Not Done', color: '#ef4444'},
          {key: 'half_done', label: '½ Half', color: '#f59e0b'},
          {key: 'no_homework', label: '— No HW', color: '#6b7280'}
        ];

        statuses.forEach(function(st) {
          var activeClass = currentStatus === st.key ? ' nais-hw-btn-active' : '';
          html += '<button class="nais-hw-status-btn' + activeClass + '" data-status="' + st.key + '" data-color="' + st.color + '"';
          if (currentStatus === st.key) html += ' style="background:' + st.color + ';color:#fff;border-color:' + st.color + ';"';
          html += '>' + st.label + '</button>';
        });

        html += '  </div>';
        html += '</div>';
      });
      html += '</div>';

      $container.html(html);
      $('.nais-quick-actions').hide();
      $('.nais-hw-quick-actions').show();
      $('.nais-save-bar').show();
      $('#nais-save-attendance').hide();
      $('#nais-save-homework').show();
      updateHwSummary();
    });
  }

  /* Homework status button click */
  $(document).on('click', '.nais-hw-status-btn', function() {
    var $row = $(this).closest('.nais-hw-row');
    $row.find('.nais-hw-status-btn').removeClass('nais-hw-btn-active').removeAttr('style');
    var color = $(this).data('color');
    $(this).addClass('nais-hw-btn-active').css({background: color, color: '#fff', borderColor: color});
    updateHwSummary();
  });

  /* Homework mark all */
  $(document).on('click', '.nais-hw-mark-all', function() {
    var status = $(this).data('status');
    $('.nais-hw-row').each(function() {
      var $btn = $(this).find('.nais-hw-status-btn[data-status="' + status + '"]');
      $(this).find('.nais-hw-status-btn').removeClass('nais-hw-btn-active').removeAttr('style');
      var color = $btn.data('color');
      $btn.addClass('nais-hw-btn-active').css({background: color, color: '#fff', borderColor: color});
    });
    updateHwSummary();
  });

  /* Save homework checklist */
  $(document).on('click', '#nais-save-homework', function() {
    var $btn    = $(this);
    var classId = $('#nais-class-select').val();
    var date    = $('#nais-att-date').val();
    var subject = $('#nais-class-select option:selected').data('subject') || '';

    var homework = {};
    var hasEmpty = false;

    $('.nais-hw-row').each(function() {
      var studentId = $(this).data('student-id');
      var $active   = $(this).find('.nais-hw-status-btn.nais-hw-btn-active');

      if ($active.length === 0) {
        hasEmpty = true;
        return;
      }

      homework[studentId] = $active.data('status');
    });

    if (hasEmpty) {
      if (!confirm('Some students have no status marked. They will be skipped. Continue?')) return;
    }

    if (Object.keys(homework).length === 0) {
      alert('No homework status to save.');
      return;
    }

    $btn.prop('disabled', true).text('Saving...');

    $.post(naisData.ajaxUrl, {
      action:   'nais_save_homework',
      nonce:    naisData.nonce,
      class_id: classId,
      hw_date:  date,
      subject:  subject,
      homework: JSON.stringify(homework)
    }, function(res) {
      $btn.prop('disabled', false).text('Save Homework Check');
      if (res.success) {
        $('#nais-save-status').html('<span style="color:#10b981;">' + escHtml(res.data.message) + '</span>');
      } else {
        $('#nais-save-status').html('<span style="color:#ef4444;">' + escHtml(res.data || 'Error saving.') + '</span>');
      }
      setTimeout(function() { $('#nais-save-status').html(''); }, 5000);
    }).fail(function() {
      $btn.prop('disabled', false).text('Save Homework Check');
      $('#nais-save-status').html('<span style="color:#ef4444;">Network error. Please try again.</span>');
    });
  });

  function updateHwSummary() {
    var total    = $('.nais-hw-row').length;
    var done     = $('.nais-hw-row .nais-hw-status-btn[data-status="done"].nais-hw-btn-active').length;
    var notDone  = $('.nais-hw-row .nais-hw-status-btn[data-status="not_done"].nais-hw-btn-active').length;
    var halfDone = $('.nais-hw-row .nais-hw-status-btn[data-status="half_done"].nais-hw-btn-active').length;
    var noHw     = $('.nais-hw-row .nais-hw-status-btn[data-status="no_homework"].nais-hw-btn-active').length;
    var unmarked = total - done - notDone - halfDone - noHw;

    $('#nais-hw-summary').text(
      done + ' Done · ' + notDone + ' Not Done · ' + halfDone + ' Half · ' + noHw + ' No HW' +
      (unmarked > 0 ? ' · ' + unmarked + ' Unmarked' : '')
    );
  }


  /* ─── STATUS BUTTON CLICK ─── */
  $(document).on('click', '.nais-status-btn', function() {
    var $row = $(this).closest('.nais-checklist-row');
    $row.find('.nais-status-btn').removeClass('active-present active-absent active-late active-excused');
    $(this).addClass('active-' + $(this).data('status'));
    updateSummary();
  });


  /* ─── MARK ALL BUTTONS ─── */
  $(document).on('click', '.nais-mark-all', function() {
    var status = $(this).data('status');
    $('.nais-checklist-row').each(function() {
      $(this).find('.nais-status-btn').removeClass('active-present active-absent active-late active-excused');
      $(this).find('.nais-status-btn[data-status="' + status + '"]').addClass('active-' + status);
    });
    updateSummary();
  });


  /* ─── SAVE ATTENDANCE ─── */
  $(document).on('click', '#nais-save-attendance', function() {
    var $btn    = $(this);
    var classId = $('#nais-class-select').val();
    var date    = $('#nais-att-date').val();
    var attType = $('#nais-att-type').val();

    var attendance = {};
    var hasEmpty = false;

    $('.nais-checklist-row').each(function() {
      var studentId = $(this).data('student-id');
      var $active   = $(this).find('.nais-status-btn[class*="active-"]');
      var remarks   = $(this).find('.nais-remarks-input').val();

      if ($active.length === 0) {
        hasEmpty = true;
        return;
      }

      var status = $active.data('status');
      attendance[studentId] = { status: status, remarks: remarks };
    });

    if (hasEmpty) {
      if (!confirm('Some students have no status marked. They will be skipped. Continue?')) return;
    }

    if (Object.keys(attendance).length === 0) {
      alert('No attendance to save.');
      return;
    }

    $btn.prop('disabled', true).text('Saving...');

    var ajaxAction, postData;

    if (attType === 'daily') {
      ajaxAction = 'nais_save_daily_attendance';
      postData = {
        action:     ajaxAction,
        nonce:      naisData.nonce,
        class_id:   classId,
        date:       date,
        attendance: attendance
      };
    } else {
      var periodNum = parseInt(attType.replace('period-', ''));
      var subject   = $('#nais-class-select option:selected').data('subject') || '';

      var periodAtt = {};
      for (var sid in attendance) {
        periodAtt[sid] = attendance[sid].status;
      }

      ajaxAction = 'nais_save_period_attendance';
      postData = {
        action:        ajaxAction,
        nonce:         naisData.nonce,
        class_id:      classId,
        date:          date,
        period_number: periodNum,
        subject:       subject,
        attendance:    periodAtt
      };
    }

    $.post(naisData.ajaxUrl, postData, function(res) {
      $btn.prop('disabled', false).text('Save Attendance');
      if (res.success) {
        $('#nais-save-status').html('<span style="color:#10b981;">' + escHtml(res.data.message) + '</span>');
      } else {
        $('#nais-save-status').html('<span style="color:#ef4444;">' + escHtml(res.data || 'Error saving.') + '</span>');
      }
      setTimeout(function() { $('#nais-save-status').html(''); }, 5000);
    }).fail(function() {
      $btn.prop('disabled', false).text('Save Attendance');
      $('#nais-save-status').html('<span style="color:#ef4444;">Network error. Please try again.</span>');
    });
  });


  /* ─── Helper: get school_id from the page container ─── */
  function getSchoolId() {
    return $('.nais-school-admin').data('school-id') || $('.nais-teacher').data('school-id') || '';
  }

  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: ADD CLASS
  ═══════════════════════════════════════════ */
  $(document).on('submit', '#nais-add-class-form', function(e) {
    e.preventDefault();
    var $form = $(this);

    $.post(naisData.ajaxUrl, {
      action:     'nais_add_class',
      nonce:      naisData.nonce,
      school_id:  getSchoolId(),
      class_name: $form.find('[name="class_name"]').val(),
      section:    $form.find('[name="section"]').val()
    }, function(res) {
      if (res.success) {
        alert(res.data.message);
        var d = res.data;
        // Add new row to classes table
        var newRow = '<tr data-class-id="' + d.class_id + '">' +
          '<td>' + $('<span>').text(d.class_name).html() + '</td>' +
          '<td>' + $('<span>').text(d.section).html() + '</td>' +
          '<td>0</td>' +
          '<td>' + $('<span>').text(d.academic_year).html() + '</td>' +
          '<td><button type="button" class="nais-btn nais-btn-xs nais-btn-danger nais-delete-class-btn" data-class-id="' + d.class_id + '" data-class-name="' + $('<span>').text(d.class_name + ' ' + d.section).html() + '" data-student-count="0">Delete</button></td></tr>';
        $('#nais-classes-list').append(newRow);
        // Update class count badge
        var $badge = $('.nais-stat-badge').first();
        var count = $('#nais-classes-list tr').length;
        $badge.text(count + ' Classes');
        // Add to class dropdowns
        var optHtml = '<option value="' + d.class_id + '">' + $('<span>').text(d.class_name + ' ' + d.section).html() + '</option>';
        $('select[name="class_id"], #nais-students-filter-class, #nais-bulk-class, #nais-report-class').append(optHtml);
        // Reset form
        $form[0].reset();
      } else {
        alert(res.data || 'Error adding class.');
      }
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: ADD STUDENT
  ═══════════════════════════════════════════ */
  $(document).on('submit', '#nais-add-student-form', function(e) {
    e.preventDefault();
    var $form   = $(this);
    var $result = $('#nais-student-result');

    var formData = {
      action:       'nais_add_student',
      nonce:        naisData.nonce,
      school_id:    getSchoolId(),
      class_id:     $form.find('[name="class_id"]').val(),
      name:         $form.find('[name="name"]').val(),
      roll_no:      $form.find('[name="roll_no"]').val(),
      admission_no: $form.find('[name="admission_no"]').val(),
      gender:       $form.find('[name="gender"]').val(),
      dob:          $form.find('[name="dob"]').val(),
      parent_name:  $form.find('[name="parent_name"]').val(),
      parent_phone: $form.find('[name="parent_phone"]').val()
    };

    $.post(naisData.ajaxUrl, formData, function(res) {
      if (res.success) {
        $result.html('<div class="nais-alert nais-alert-success">' + escHtml(res.data.message) +
          '<br><strong>Parent Code: <span style="font-size:24px;letter-spacing:4px;">' +
          escHtml(res.data.parent_code) + '</span></strong></div>');
        $form[0].reset();
        // Update Students badge count
        var $badge = $('.nais-stat-badge').eq(1);
        var current = parseInt($badge.text()) || 0;
        $badge.text((current + 1) + ' Students');
      } else {
        $result.html('<div class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error.') + '</div>');
      }
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: ADD TEACHER (V2: subject + class teacher)
  ═══════════════════════════════════════════ */
  $(document).on('submit', '#nais-add-teacher-form', function(e) {
    e.preventDefault();
    var $form = $(this);

    var classIds = [];
    var subjects = {};
    var classTeacher = {};

    $form.find('[name="class_ids[]"]:checked').each(function() {
      var cid = $(this).val();
      classIds.push(cid);
      subjects[cid] = $form.find('[name="subjects[' + cid + ']"]').val() || '';
      classTeacher[cid] = $form.find('[name="class_teacher[' + cid + ']"]').is(':checked') ? '1' : '0';
    });

    $.post(naisData.ajaxUrl, {
      action:        'nais_add_teacher',
      nonce:         naisData.nonce,
      school_id:     getSchoolId(),
      name:          $form.find('[name="name"]').val(),
      email:         $form.find('[name="email"]').val(),
      phone:         $form.find('[name="phone"]').val(),
      employee_id:   $form.find('[name="employee_id"]').val(),
      designation:   $form.find('[name="designation"]').val(),
      class_ids:     classIds,
      subjects:      subjects,
      class_teacher: classTeacher
    }, function(res) {
      if (res.success) {
        alert(res.data.message);
        location.reload();
      } else {
        alert(res.data || 'Error adding teacher.');
      }
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: REASSIGN TEACHER CLASSES
  ═══════════════════════════════════════════ */
  $(document).on('click', '.nais-reassign-teacher-btn', function() {
    var $btn      = $(this);
    var teacherId = $btn.data('teacher-id');
    var name      = $btn.data('teacher-name');
    var assigns   = $btn.data('assigns') || [];

    /* Show panel */
    var $panel = $('#nais-reassign-panel');
    $panel.show();
    $('#nais-reassign-teacher-name').text(name);
    $('#nais-reassign-teacher-id').val(teacherId);

    /* Reset all checkboxes and selects */
    $panel.find('[name="reassign_class_ids[]"]').prop('checked', false);
    $panel.find('.nais-teacher-subject-select').val('');
    $panel.find('[name^="reassign_class_teacher"]').prop('checked', false);

    /* Pre-populate from current assignments */
    if (typeof assigns === 'string') {
      try { assigns = JSON.parse(assigns); } catch(e) { assigns = []; }
    }
    for (var i = 0; i < assigns.length; i++) {
      var a = assigns[i];
      $panel.find('[name="reassign_class_ids[]"][value="' + a.class_id + '"]').prop('checked', true);
      $panel.find('[name="reassign_subjects[' + a.class_id + ']"]').val(a.subject);
      if (a.is_class_teacher) {
        $panel.find('[name="reassign_class_teacher[' + a.class_id + ']"]').prop('checked', true);
      }
    }

    /* Scroll to panel */
    $('html, body').animate({ scrollTop: $panel.offset().top - 80 }, 300);
  });

  $(document).on('click', '#nais-reassign-cancel', function() {
    $('#nais-reassign-panel').hide();
  });

  $(document).on('click', '#nais-reassign-save', function() {
    var $panel    = $('#nais-reassign-panel');
    var teacherId = $('#nais-reassign-teacher-id').val();
    var classIds  = [];
    var subjects  = {};
    var classTeacher = {};

    $panel.find('[name="reassign_class_ids[]"]:checked').each(function() {
      var cid = $(this).val();
      classIds.push(cid);
      subjects[cid] = $panel.find('[name="reassign_subjects[' + cid + ']"]').val() || '';
      classTeacher[cid] = $panel.find('[name="reassign_class_teacher[' + cid + ']"]').is(':checked') ? '1' : '0';
    });

    if (!confirm('Reassign this teacher to ' + classIds.length + ' class(es)? This will replace their current assignments.')) return;

    $.post(naisData.ajaxUrl, {
      action:        'nais_assign_teacher_class',
      nonce:         naisData.nonce,
      school_id:     getSchoolId(),
      teacher_id:    teacherId,
      class_ids:     classIds,
      subjects:      subjects,
      class_teacher: classTeacher
    }, function(res) {
      if (res.success) {
        alert(res.data.message);
        location.reload();
      } else {
        alert(res.data || 'Error reassigning teacher.');
      }
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: STUDENT CODE LOOKUP
  ═══════════════════════════════════════════ */
  function naisCodeLookup() {
    var name    = $.trim($('#nais-code-lookup-name').val());
    var classId = $('#nais-code-lookup-class').val();
    var $btn    = $('#nais-code-lookup-btn');
    var $results = $('#nais-code-lookup-results');

    if (name.length < 2) {
      $results.html('<p class="nais-hint">Please enter at least 2 characters.</p>');
      return;
    }

    $btn.prop('disabled', true).text('Searching...');
    $results.html('<p class="nais-hint">Searching...</p>');

    $.post(naisData.ajaxUrl, {
      action:   'nais_lookup_student_code',
      nonce:    naisData.nonce,
      search:   name,
      class_id: classId
    }, function(res) {
      $btn.prop('disabled', false).text('Search');
      if (res.success) {
        $results.html(res.data.html);
      } else {
        $results.html('<p class="nais-hint" style="color:#ef4444;">' + escHtml(res.data || 'No results found.') + '</p>');
      }
    }).fail(function() {
      $btn.prop('disabled', false).text('Search');
      $results.html('<p class="nais-hint" style="color:#ef4444;">Network error. Please try again.</p>');
    });
  }

  $(document).on('click', '#nais-code-lookup-btn', naisCodeLookup);

  $(document).on('keypress', '#nais-code-lookup-name', function(e) {
    if (e.which === 13) { e.preventDefault(); naisCodeLookup(); }
  });

  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: PRINT PARENT CODE SLIPS
  ═══════════════════════════════════════════ */
  $(document).on('submit', '#nais-print-codes-form', function(e) {
    e.preventDefault();
    var classId = $(this).find('[name="class_id"]').val();

    $.post(naisData.ajaxUrl, {
      action:   'nais_get_parent_slips',
      nonce:    naisData.nonce,
      class_id: classId
    }, function(res) {
      if (res.success) {
        $('#nais-slips-container').html(res.data.html);
      } else {
        alert(res.data || 'Error generating slips.');
      }
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: BULK UPLOAD STUDENTS
  ═══════════════════════════════════════════ */
  var bulkStudents = [];

  $(document).on('click', '#nais-download-template', function() {
    var csv = 'Name,Roll No,Gender,Parent Name,Parent Phone\n';
    csv += 'Anya Longkumer,1,female,Mrs. Longkumer,9876543210\n';
    csv += 'Kevi Assumi,2,male,Mr. Assumi,9123456789\n';
    csv += 'Temsu Ao,3,male,Mr. Ao,8765432100\n';
    var blob = new Blob([csv], {type: 'text/csv'});
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'student-upload-template.csv';
    a.click();
  });

  $(document).on('click', '#nais-bulk-preview', function() {
    var classId = $('#nais-bulk-class').val();
    if (!classId) { alert('Please select a class first.'); return; }
    var file  = document.getElementById('nais-bulk-file');
    var paste = $('#nais-bulk-paste').val().trim();
    if (file.files.length > 0) {
      var reader = new FileReader();
      reader.onload = function(e) { bulkStudents = parseCSV(e.target.result); showBulkPreview(); };
      reader.readAsText(file.files[0]);
    } else if (paste) {
      bulkStudents = parseCSV(paste);
      showBulkPreview();
    } else {
      alert('Please upload a CSV file or paste student data.');
    }
  });

  function parseCSV(text) {
    var lines = text.split(/\r?\n/).filter(function(l) { return l.trim() !== ''; });
    var results = [];
    var first = lines[0].toLowerCase();
    if (first.indexOf('name') > -1 || first.indexOf('student') > -1 || first.indexOf('roll') > -1) { lines.shift(); }
    lines.forEach(function(line) {
      var parts = line.split(',').map(function(p) { return p.trim().replace(/^["']|["']$/g, ''); });
      var name = parts[0] || '';
      if (!name) return;
      results.push({ name: name, roll_no: parts[1] || '', gender: parts[2] || '', parent_name: parts[3] || '', parent_phone: parts[4] || '' });
    });
    return results;
  }

  function showBulkPreview() {
    if (bulkStudents.length === 0) { alert('No valid students found.'); return; }
    var $tbody = $('#nais-bulk-preview-table tbody');
    $tbody.empty();
    bulkStudents.forEach(function(s, i) {
      $tbody.append('<tr><td>' + (i + 1) + '</td><td><strong>' + escHtml(s.name) + '</strong></td><td>' + escHtml(s.roll_no) + '</td><td>' + escHtml(s.gender) + '</td><td>' + escHtml(s.parent_name) + '</td><td>' + escHtml(s.parent_phone) + '</td></tr>');
    });
    $('#nais-bulk-count').text(bulkStudents.length);
    $('#nais-bulk-step1').hide();
    $('#nais-bulk-step2').show();
    $('#nais-bulk-step3').hide();
  }

  $(document).on('click', '#nais-bulk-back', function() { $('#nais-bulk-step1').show(); $('#nais-bulk-step2').hide(); });

  $(document).on('click', '#nais-bulk-confirm', function() {
    var $btn = $(this); var classId = $('#nais-bulk-class').val();
    $btn.prop('disabled', true).text('Uploading...');
    $.post(naisData.ajaxUrl, { action: 'nais_bulk_add_students', nonce: naisData.nonce, school_id: getSchoolId(), class_id: classId, students: JSON.stringify(bulkStudents) }, function(res) {
      $btn.prop('disabled', false).text('Upload All Students');
      if (res.success) {
        var html = '<div class="nais-alert nais-alert-success"><strong>' + escHtml(res.data.message) + '</strong></div>';
        if (res.data.codes && res.data.codes.length > 0) {
          html += '<h4 style="margin-top:16px;">Parent Codes for ' + escHtml(res.data.class) + ':</h4>';
          html += '<table class="nais-table"><thead><tr><th>Student</th><th>Parent Code</th></tr></thead><tbody>';
          res.data.codes.forEach(function(c) { html += '<tr><td>' + escHtml(c.name) + '</td><td><strong style="font-size:18px;letter-spacing:3px;">' + escHtml(c.parent_code) + '</strong></td></tr>'; });
          html += '</tbody></table><p style="margin-top:12px;"><button onclick="location.reload()" class="nais-btn">Refresh Page</button></p>';
        }
        $('#nais-bulk-result').html(html);
        $('#nais-bulk-step2').hide();
        $('#nais-bulk-step3').show();
      } else { alert(res.data || 'Error uploading students.'); }
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: HOLIDAY CALENDAR
  ═══════════════════════════════════════════ */

  $(document).on('click', '#nais-admin-add-holiday', function() {
    var date = $('#nais-admin-holiday-date').val(); var type = $('#nais-admin-holiday-type').val(); var title = $('#nais-admin-holiday-title').val().trim();
    if (!date) { alert('Please select a date.'); return; }
    var $btn = $(this); $btn.prop('disabled', true).text('Adding...');
    $.post(naisData.ajaxUrl, { action: 'nais_mark_holiday', nonce: naisData.nonce, school_id: getSchoolId(), date: date, type: type, title: title }, function(res) {
      $btn.prop('disabled', false).text('Add');
      if (res.success) { alert(res.data.message); $('#nais-admin-holiday-date').val(''); $('#nais-admin-holiday-title').val(''); $('#nais-load-holidays').click(); }
      else { alert(res.data || 'Error adding holiday.'); }
    });
  });

  $(document).on('click', '#nais-load-holidays', function() {
    var month = $('#nais-holiday-month').val(); var year = $('#nais-holiday-year').val();
    var $container = $('#nais-holidays-list'); $container.html('<p>Loading holidays...</p>');
    $.post(naisData.ajaxUrl, { action: 'nais_get_holidays', nonce: naisData.nonce, school_id: getSchoolId(), month: month, year: year }, function(res) {
      if (!res.success) { $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error.') + '</p>'); return; }
      var holidays = res.data.holidays;
      if (!holidays || holidays.length === 0) { $container.html('<p class="nais-hint">No holidays set for this month.</p>'); return; }
      var html = '<table class="nais-table"><thead><tr><th>Date</th><th>Type</th><th>Reason</th><th>Action</th></tr></thead><tbody>';
      holidays.forEach(function(h) {
        var typeLabel = h.type === 'half_day' ? '📋 Half Day' : '🎉 Holiday';
        var dateFormatted = new Date(h.holiday_date + 'T00:00:00').toLocaleDateString('en-IN', {weekday:'short', day:'numeric', month:'short', year:'numeric'});
        html += '<tr><td>' + dateFormatted + '</td><td>' + typeLabel + '</td><td>' + escHtml(h.title || '—') + '</td><td><button class="nais-btn nais-btn-xs nais-btn-danger nais-remove-holiday" data-date="' + h.holiday_date + '">Remove</button></td></tr>';
      });
      html += '</tbody></table>';
      $container.html(html);
    });
  });

  $(document).on('click', '.nais-remove-holiday', function() {
    if (!confirm('Remove this holiday?')) return;
    var date = $(this).data('date'); var $btn = $(this); $btn.prop('disabled', true);
    $.post(naisData.ajaxUrl, { action: 'nais_remove_holiday', nonce: naisData.nonce, school_id: getSchoolId(), date: date }, function(res) {
      if (res.success) { $btn.closest('tr').fadeOut(300, function() { $(this).remove(); }); }
      else { alert(res.data || 'Error removing holiday.'); $btn.prop('disabled', false); }
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: EMERGENCY ALERTS
  ═══════════════════════════════════════════ */

  var alertTypeIcons = { emergency: '🚨', announcement: '📢', reminder: '📋', holiday: '🎉' };

  $(document).on('click', '#nais-preview-alert', function() {
    var type = $('#nais-alert-type').val(); var msg = $('#nais-alert-message').val().trim();
    if (!msg) { alert('Please type a message.'); return; }
    var icon = alertTypeIcons[type] || '📢'; var typeLabel = $('#nais-alert-type option:selected').text();
    var html = '<div class="nais-alert-card nais-alert-card-' + type + '"><span class="nais-alert-icon">' + icon + '</span> <strong>' + escHtml(typeLabel.split('(')[0].trim()) + '</strong><br><p style="margin:8px 0 0;">' + escHtml(msg) + '</p></div>';
    $('#nais-alert-preview-box').html(html); $('#nais-alert-preview').show();
  });

  $(document).on('click', '#nais-send-alert', function() {
    var type = $('#nais-alert-type').val(); var msg = $('#nais-alert-message').val().trim();
    if (!msg) { alert('Please type a message.'); return; }
    var confirmText = type === 'emergency' ? 'SEND EMERGENCY ALERT? This will notify ALL parents with an alarm sound.' : 'Send this alert to all parents?';
    if (!confirm(confirmText)) return;
    var $btn = $(this); $btn.prop('disabled', true).text('Sending...');
    $.post(naisData.ajaxUrl, { action: 'nais_send_alert', nonce: naisData.nonce, school_id: getSchoolId(), type: type, message: msg }, function(res) {
      $btn.prop('disabled', false).text('Send Alert to All Parents');
      if (res.success) { alert(res.data.message); $('#nais-alert-message').val(''); $('#nais-alert-preview').hide(); loadAlerts(); }
      else { alert(res.data || 'Error sending alert.'); }
    });
  });

  function loadAlerts() {
    $.post(naisData.ajaxUrl, { action: 'nais_get_alerts', nonce: naisData.nonce, school_id: getSchoolId() }, function(res) {
      if (!res.success || !res.data.alerts || res.data.alerts.length === 0) { $('#nais-alerts-history').html('<p class="nais-hint">No alerts sent yet.</p>'); return; }
      var html = '<table class="nais-table"><thead><tr><th>Date</th><th>Type</th><th>Message</th></tr></thead><tbody>';
      res.data.alerts.forEach(function(a) { var icon = alertTypeIcons[a.type] || '📢'; html += '<tr><td style="white-space:nowrap;">' + escHtml(a.sent_at) + '</td><td>' + icon + ' ' + escHtml(a.type) + '</td><td>' + escHtml(a.message) + '</td></tr>'; });
      html += '</tbody></table>';
      $('#nais-alerts-history').html(html);
    });
  }

  $(document).on('click', '[data-tab="alerts"]', function() { loadAlerts(); });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: ATTENDANCE REPORTS + PDF
  ═══════════════════════════════════════════ */

  /* View Report */
  $(document).on('submit', '#nais-report-form', function(e) {
    e.preventDefault();
    var classId = $('#nais-report-class').val();
    var month   = $('#nais-report-month').val();
    var year    = $('#nais-report-year').val();

    if (!classId) { alert('Please select a class.'); return; }

    var $container = $('#nais-report-container');
    $container.html('<p>Loading report...</p>');

    $.post(naisData.ajaxUrl, {
      action:   'nais_get_class_report',
      nonce:    naisData.nonce,
      class_id: classId,
      month:    month,
      year:     year
    }, function(res) {
      if (!res.success) {
        $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error loading report.') + '</p>');
        $('#nais-download-pdf').hide();
        return;
      }

      var d = res.data;
      var statusMap = { present: 'P', absent: 'A', late: 'L', excused: 'E', sunday: 'S', holiday: 'H', half_day: 'H' };
      var cssMap = { present: 'nais-rpt-P', absent: 'nais-rpt-A', late: 'nais-rpt-L', excused: 'nais-rpt-E', sunday: 'nais-rpt-S', holiday: 'nais-rpt-H', half_day: 'nais-rpt-H' };

      var html = '<div class="nais-report-header">';
      html += '<h4>' + escHtml(d.school) + '</h4>';
      html += '<p>' + escHtml(d.class) + ' — ' + escHtml(d.month) + ' ' + d.year + ' — ' + d.total + ' students</p>';
      html += '</div>';

      html += '<div class="nais-table-wrap"><table class="nais-table nais-report-table"><thead><tr>';
      html += '<th>#</th><th class="nais-rpt-name">Student</th>';
      for (var day = 1; day <= d.days_in_month; day++) { html += '<th class="nais-rpt-day">' + day + '</th>'; }
      html += '<th class="nais-rpt-stat">P</th><th class="nais-rpt-stat">A</th><th class="nais-rpt-stat">%</th>';
      html += '</tr></thead><tbody>';

      d.students.forEach(function(s, idx) {
        html += '<tr><td>' + escHtml(s.roll_no || (idx + 1)) + '</td>';
        html += '<td class="nais-rpt-name"><strong>' + escHtml(s.name) + '</strong></td>';
        for (var day = 1; day <= d.days_in_month; day++) {
          var val = s.days[day] || '';
          var letter = statusMap[val] || (val === '' ? '-' : val.charAt(0).toUpperCase());
          var cls = cssMap[val] || '';
          html += '<td class="nais-rpt-day ' + cls + '">' + letter + '</td>';
        }
        html += '<td class="nais-rpt-stat" style="color:#059669;font-weight:700;">' + s.present + '</td>';
        html += '<td class="nais-rpt-stat" style="color:#DC2626;font-weight:700;">' + s.absent + '</td>';
        html += '<td class="nais-rpt-stat" style="font-weight:700;">' + s.percentage + '%</td>';
        html += '</tr>';
      });

      html += '</tbody></table></div>';

      html += '<div class="nais-report-summary">';
      html += '<div class="nais-rpt-card"><div class="nais-rpt-num">' + d.total + '</div><div class="nais-rpt-label">Students</div></div>';
      html += '<div class="nais-rpt-card"><div class="nais-rpt-num" style="color:#059669;">' + d.class_present + '</div><div class="nais-rpt-label">Total Present</div></div>';
      html += '<div class="nais-rpt-card"><div class="nais-rpt-num" style="color:#DC2626;">' + d.class_absent + '</div><div class="nais-rpt-label">Total Absent</div></div>';
      html += '</div>';

      $container.html(html);
      $('#nais-download-pdf').show();
    });
  });

  /* Download PDF */
  $(document).on('click', '#nais-download-pdf', function() {
    var classId = $('#nais-report-class').val();
    var month   = $('#nais-report-month').val();
    var year    = $('#nais-report-year').val();
    if (!classId) { alert('Please select a class first.'); return; }
    var form = $('<form>', { method: 'POST', action: naisData.ajaxUrl, target: '_blank' }).append(
      $('<input>', { type: 'hidden', name: 'action', value: 'nais_download_report_pdf' }),
      $('<input>', { type: 'hidden', name: 'nonce', value: naisData.nonce }),
      $('<input>', { type: 'hidden', name: 'class_id', value: classId }),
      $('<input>', { type: 'hidden', name: 'month', value: month }),
      $('<input>', { type: 'hidden', name: 'year', value: year })
    );
    $('body').append(form); form.submit(); form.remove();
  });


  /* ═══════════════════════════════════════════
     DISTRICT GOVERNMENT DASHBOARD
  ═══════════════════════════════════════════ */

  /* Auto-load on page */
  if ($('.nais-district-dashboard').length) {
    setTimeout(function() { $('#nais-dd-load').click(); }, 500);
  }

  $(document).on('click', '#nais-dd-load', function() {
    var $btn = $(this);
    $btn.prop('disabled', true).text('Loading...');

    $.post(naisData.ajaxUrl, {
      action:   'nais_district_data',
      nonce:    naisData.nonce,
      district: $('#nais-dd-district').val(),
      period:   $('#nais-dd-period').val()
    }, function(res) {
      $btn.prop('disabled', false).text('Load Dashboard');
      if (!res.success) { alert(res.data || 'Error loading dashboard.'); return; }

      var d = res.data;

      $('#dd-total-schools').text(d.overview.schools);
      $('#dd-total-students').text(d.overview.students.toLocaleString());
      $('#dd-total-teachers').text(d.overview.teachers);
      $('#dd-att-rate').text(d.overview.att_rate);
      $('#dd-present-today').text(d.overview.present_today.toLocaleString());
      $('#dd-absent-today').text(d.overview.absent_today.toLocaleString());

      if (d.districts.length > 0) {
        var dhtml = '<h3 style="margin-top:24px;">District Breakdown</h3>';
        dhtml += '<div class="nais-table-wrap"><table class="nais-table"><thead><tr><th>District</th><th>Schools</th><th>Students</th><th>Attendance Rate</th></tr></thead><tbody>';
        d.districts.forEach(function(dist) {
          var color = dist.attendance >= 80 ? '#059669' : (dist.attendance >= 60 ? '#D97706' : '#DC2626');
          dhtml += '<tr><td><strong>' + escHtml(dist.district) + '</strong></td><td>' + dist.schools + '</td><td>' + dist.students.toLocaleString() + '</td><td><span style="color:' + color + ';font-weight:700;font-size:16px;">' + dist.attendance + '%</span></td></tr>';
        });
        dhtml += '</tbody></table></div>';
        $('#nais-dd-district-table').html(dhtml);
      } else { $('#nais-dd-district-table').html(''); }

      if (d.schools.length > 0) {
        var shtml = '<h3 style="margin-top:24px;">School-by-School (' + d.schools.length + ' schools)</h3>';
        shtml += '<p style="color:#666;font-size:13px;">Period: ' + escHtml(d.date_range) + '</p>';
        shtml += '<div class="nais-table-wrap"><table class="nais-table"><thead><tr><th>School</th><th>District</th><th>Board</th><th>Students</th><th>Teachers</th><th>Attendance</th><th>Details</th></tr></thead><tbody>';
        d.schools.forEach(function(sc) {
          var color = sc.attendance >= 80 ? '#059669' : (sc.attendance >= 60 ? '#D97706' : '#DC2626');
          shtml += '<tr><td><strong>' + escHtml(sc.name) + '</strong></td><td>' + escHtml(sc.district) + '</td><td>' + escHtml(sc.board) + '</td><td>' + sc.students + '</td><td>' + sc.teachers + '</td><td><span style="color:' + color + ';font-weight:700;font-size:16px;">' + sc.attendance + '%</span></td><td><button class="nais-btn nais-btn-xs nais-dd-detail" data-school-id="' + sc.id + '">View</button></td></tr>';
        });
        shtml += '</tbody></table></div><div id="nais-dd-school-detail"></div>';
        $('#nais-dd-school-table').html(shtml);
      } else { $('#nais-dd-school-table').html('<p class="nais-hint">No schools registered yet.</p>'); }
    });
  });

  /* School detail */
  $(document).on('click', '.nais-dd-detail', function() {
    var schoolId = $(this).data('school-id');
    var $detail = $('#nais-dd-school-detail');
    $detail.html('<p>Loading school details...</p>');

    $.post(naisData.ajaxUrl, { action: 'nais_district_school_detail', nonce: naisData.nonce, school_id: schoolId }, function(res) {
      if (!res.success) { $detail.html('<p>Error loading details.</p>'); return; }
      var s = res.data;
      var html = '<div class="nais-dd-detail-card">';
      html += '<h4>' + escHtml(s.school.name) + '</h4>';
      html += '<p>' + escHtml(s.school.district) + ' | ' + escHtml(s.school.board) + ' | UDISE: ' + escHtml(s.school.udise) + '</p>';
      if (s.school.phone) html += '<p>Phone: ' + escHtml(s.school.phone) + '</p>';
      if (s.school.email) html += '<p>Email: ' + escHtml(s.school.email) + '</p>';
      html += '<p>Subscription: <strong>' + escHtml(s.subscription.plan) + '</strong> (' + escHtml(s.subscription.status) + ') — Expires: ' + escHtml(s.subscription.expires) + '</p>';

      if (s.classes.length > 0) {
        html += '<h5 style="margin-top:12px;">Classes</h5><table class="nais-table"><thead><tr><th>Class</th><th>Section</th><th>Students</th></tr></thead><tbody>';
        s.classes.forEach(function(c) { html += '<tr><td>' + escHtml(c.class_name) + '</td><td>' + escHtml(c.section) + '</td><td>' + c.students + '</td></tr>'; });
        html += '</tbody></table>';
      }

      if (s.monthly.length > 0) {
        html += '<h5 style="margin-top:12px;">6-Month Attendance Trend</h5><table class="nais-table"><thead><tr><th>Month</th><th>Attendance</th><th>Records</th></tr></thead><tbody>';
        s.monthly.forEach(function(m) {
          var color = m.attendance >= 80 ? '#059669' : (m.attendance >= 60 ? '#D97706' : '#DC2626');
          html += '<tr><td>' + escHtml(m.month) + '</td><td><span style="color:' + color + ';font-weight:700;">' + m.attendance + '%</span></td><td>' + m.records + '</td></tr>';
        });
        html += '</tbody></table>';
      }

      html += '<button class="nais-btn nais-btn-sm" onclick="$(\'#nais-dd-school-detail\').html(\'\')" style="margin-top:12px;">Close</button>';
      html += '</div>';
      $detail.html(html);
      $('html,body').animate({scrollTop: $detail.offset().top - 100}, 300);
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: BUS MANAGEMENT
  ═══════════════════════════════════════════ */

  /* Add Bus */
  $(document).on('submit', '#nais-add-bus-form', function(e) {
    e.preventDefault();
    var $form = $(this);
    $.post(naisData.ajaxUrl, {
      action: 'nais_add_bus', nonce: naisData.nonce,
      bus_number: $form.find('[name="bus_number"]').val(),
      plate_number: $form.find('[name="plate_number"]').val(),
      driver_name: $form.find('[name="driver_name"]').val(),
      driver_phone: $form.find('[name="driver_phone"]').val(),
      capacity: $form.find('[name="capacity"]').val(),
      route_name: $form.find('[name="route_name"]').val(),
      route_details: $form.find('[name="route_details"]').val()
    }, function(res) {
      if (res.success) { alert(res.data.message); location.reload(); }
      else { alert(res.data || 'Error adding bus.'); }
    });
  });

  /* Delete Bus */
  $(document).on('click', '.nais-delete-bus', function() {
    if (!confirm('Delete this bus? All student assignments will be removed.')) return;
    var busId = $(this).data('bus-id');
    $.post(naisData.ajaxUrl, { action: 'nais_delete_bus', nonce: naisData.nonce, bus_id: busId }, function(res) {
      if (res.success) { alert(res.data.message); location.reload(); }
      else { alert(res.data || 'Error.'); }
    });
  });

  /* Kill Switch */
  $(document).on('click', '#nais-bus-kill-switch', function() {
    var $btn = $(this);
    var currentlyEnabled = $btn.data('enabled');
    var msg = currentlyEnabled
      ? 'DISABLE all bus tracking? All active trips will end and GPS data will be deleted immediately.'
      : 'Enable bus tracking for this school?';
    if (!confirm(msg)) return;

    $btn.prop('disabled', true).text('Processing...');
    $.post(naisData.ajaxUrl, {
      action: 'nais_bus_kill_switch', nonce: naisData.nonce,
      enabled: currentlyEnabled ? 0 : 1
    }, function(res) {
      if (res.success) { alert(res.data.message); location.reload(); }
      else { alert(res.data || 'Error.'); $btn.prop('disabled', false); }
    });
  });

  /* Assign Students — Open Modal */
  $(document).on('click', '.nais-assign-students-btn', function() {
    var busId = $(this).data('bus-id');
    var busName = $(this).data('bus-name');
    $('#nais-assign-bus-id').val(busId);
    $('#nais-assign-bus-name').text(busName);

    /* Uncheck all first */
    $('#nais-bus-student-list input[type="checkbox"]').prop('checked', false);

    /* Load existing assignments */
    $.post(naisData.ajaxUrl, { action: 'nais_get_bus_students', nonce: naisData.nonce, bus_id: busId }, function(res) {
      if (res.success && res.data.student_ids) {
        res.data.student_ids.forEach(function(sid) {
          $('#nais-bus-student-list input[value="' + sid + '"]').prop('checked', true);
        });
      }
    });

    $('#nais-bus-assign-modal').slideDown(300);
    $('#nais-bus-log-container').hide();
    $('html,body').animate({scrollTop: $('#nais-bus-assign-modal').offset().top - 100}, 300);
  });

  /* Save Student Assignments */
  $(document).on('click', '#nais-save-bus-students', function() {
    var busId = $('#nais-assign-bus-id').val();
    var studentIds = [];
    $('#nais-bus-student-list input[type="checkbox"]:checked').each(function() {
      studentIds.push($(this).val());
    });

    var $btn = $(this);
    $btn.prop('disabled', true).text('Saving...');

    $.post(naisData.ajaxUrl, {
      action: 'nais_assign_bus_students', nonce: naisData.nonce,
      bus_id: busId, student_ids: studentIds
    }, function(res) {
      $btn.prop('disabled', false).text('Save Assignments');
      if (res.success) { alert(res.data.message); location.reload(); }
      else { alert(res.data || 'Error.'); }
    });
  });

  /* Close Assign Modal */
  $(document).on('click', '#nais-close-assign-modal', function() {
    $('#nais-bus-assign-modal').slideUp(300);
  });

  /* View Bus Log */
  $(document).on('click', '.nais-view-bus-log', function() {
    var busId = $(this).data('bus-id');
    var $container = $('#nais-bus-log-data');
    $container.html('<p>Loading log...</p>');
    $('#nais-bus-log-container').slideDown(300);
    $('#nais-bus-assign-modal').hide();

    $.post(naisData.ajaxUrl, { action: 'nais_get_bus_view_log', nonce: naisData.nonce, bus_id: busId }, function(res) {
      if (!res.success) { $container.html('<p>Error loading log.</p>'); return; }

      if (!res.data.logs || res.data.logs.length === 0) {
        $container.html('<p class="nais-hint">No views recorded yet.</p>');
        return;
      }

      var html = '';
      if (res.data.flagged > 0) {
        html += '<div class="nais-alert nais-alert-error" style="margin-bottom:12px;">⚠️ <strong>' + res.data.flagged + ' suspicious view(s) detected.</strong> Check flagged entries below.</div>';
      }

      html += '<div class="nais-table-wrap"><table class="nais-table"><thead><tr><th>Parent</th><th>Student</th><th>Time</th><th>IP Address</th><th>Status</th></tr></thead><tbody>';
      res.data.logs.forEach(function(log) {
        var flagClass = log.flagged == 1 ? 'style="background:#fef2f2;"' : '';
        var flagBadge = log.flagged == 1 ? '<span style="color:#DC2626;font-weight:700;">⚠️ FLAGGED</span><br><small>' + escHtml(log.flag_reason) + '</small>' : '<span style="color:#059669;">OK</span>';
        html += '<tr ' + flagClass + '>';
        html += '<td>' + escHtml(log.parent_name || 'Unknown') + '</td>';
        html += '<td>' + escHtml(log.student_name || '—') + '</td>';
        html += '<td style="white-space:nowrap;">' + escHtml(log.viewed_at) + '</td>';
        html += '<td><code>' + escHtml(log.ip_address) + '</code></td>';
        html += '<td>' + flagBadge + '</td>';
        html += '</tr>';
      });
      html += '</tbody></table></div>';

      $container.html(html);
    });

    $('html,body').animate({scrollTop: $('#nais-bus-log-container').offset().top - 100}, 300);
  });

  /* Close Log */
  $(document).on('click', '#nais-close-log', function() {
    $('#nais-bus-log-container').slideUp(300);
  });


  /* ═══════════════════════════════════════════
     PARENT: LIVE BUS TRACKING MAP
  ═══════════════════════════════════════════ */

  var busMapInterval = null;

  /* Load bus location (called from parent My Child page) */
  $(document).on('click', '#nais-track-bus-btn', function() {
    var $btn = $(this);
    var $container = $('#nais-bus-map-container');
    $btn.prop('disabled', true).text('Loading...');
    $container.show();

    fetchBusLocation($container);

    /* Auto-refresh every 30 seconds */
    if (busMapInterval) clearInterval(busMapInterval);
    busMapInterval = setInterval(function() { fetchBusLocation($container); }, 30000);

    $btn.prop('disabled', false).text('Refresh Location');
  });

  /* Stop tracking */
  $(document).on('click', '#nais-stop-tracking', function() {
    if (busMapInterval) clearInterval(busMapInterval);
    busMapInterval = null;
    $('#nais-bus-map-container').slideUp(300);
  });

  function fetchBusLocation($container) {
    $.post(naisData.ajaxUrl, { action: 'nais_parent_get_bus_location', nonce: naisData.nonce }, function(res) {
      if (!res.success) {
        $container.html('<div class="nais-alert nais-alert-error">' + escHtml(res.data || 'Unable to load bus location.') + '</div>');
        if (busMapInterval) { clearInterval(busMapInterval); busMapInterval = null; }
        return;
      }

      var d = res.data;
      var html = '<div class="nais-bus-status">';
      html += '<strong>' + escHtml(d.bus) + '</strong> — ' + escHtml(d.student) + '';

      if (d.status === 'no_trip') {
        html += '<div class="nais-alert" style="background:#f3f4f6;border:1px solid #e5e7eb;color:#666;margin-top:8px;">🚌 ' + escHtml(d.message) + '</div>';
        if (busMapInterval) { clearInterval(busMapInterval); busMapInterval = null; }
      } else if (d.status === 'waiting') {
        html += '<div class="nais-alert" style="background:#fefce8;border:1px solid #fef08a;color:#92400e;margin-top:8px;">📡 ' + escHtml(d.message) + '</div>';
      } else if (d.status === 'live') {
        html += '<div class="nais-alert nais-alert-success" style="margin-top:8px;">📍 Live — Speed: ' + d.speed.toFixed(0) + ' km/h — Updated: ' + escHtml(d.updated) + '</div>';
        html += '<div id="nais-bus-map" style="height:350px;border-radius:12px;overflow:hidden;margin-top:10px;border:2px solid #0A7558;"></div>';
        html += '<p style="font-size:11px;color:#999;margin-top:6px;">Auto-refreshes every 30 seconds. <button id="nais-stop-tracking" class="nais-btn nais-btn-xs">Stop Tracking</button></p>';
      }

      html += '</div>';
      $container.html(html);

      /* Render map if live */
      if (d.status === 'live' && typeof L !== 'undefined') {
        var map = L.map('nais-bus-map').setView([d.latitude, d.longitude], 15);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '© OpenStreetMap'
        }).addTo(map);
        L.marker([d.latitude, d.longitude]).addTo(map)
          .bindPopup('<strong>' + escHtml(d.bus) + '</strong><br>Speed: ' + d.speed.toFixed(0) + ' km/h<br>' + escHtml(d.updated))
          .openPopup();
      } else if (d.status === 'live') {
        /* Fallback: show Google Maps embed if Leaflet not loaded */
        $('#nais-bus-map').html('<iframe width="100%" height="350" frameborder="0" style="border:0;border-radius:12px;" src="https://maps.google.com/maps?q=' + d.latitude + ',' + d.longitude + '&z=15&output=embed" allowfullscreen></iframe>');
      }
    });
  }


  /* ═══════════════════════════════════════════
     V2 SCHOOL ADMIN: EXAM RESULTS
     Document upload per student (NOT marks grid)
  ═══════════════════════════════════════════ */

  /* Create exam */
  $(document).on('submit', '#nais-create-exam-form', function(e) {
    e.preventDefault();
    var $form = $(this);
    var $result = $('#nais-exam-create-result');
    $form.find('button[type="submit"]').prop('disabled', true).text('Creating...');

    $.post(naisData.ajaxUrl, {
      action: 'nais_create_exam', nonce: naisData.nonce,
      class_id: $('#nais-exam-class').val(),
      exam_name: $('#nais-exam-name').val().trim(),
      exam_type: $('#nais-exam-type').val()
    }, function(res) {
      $form.find('button[type="submit"]').prop('disabled', false).text('Create Exam');
      if (res.success) {
        $result.html('<div class="nais-alert nais-alert-success">' + escHtml(res.data.message) + '</div>');
        /* Auto-open upload panel for this exam */
        openResultUploadPanel(res.data.class_id, res.data.exam_name, res.data.exam_type, res.data.class);
        $form[0].reset();
        setTimeout(function() { $result.html(''); }, 5000);
      } else {
        $result.html('<div class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error.') + '</div>');
      }
    });
  });

  /* Load exam list */
  $(document).on('click', '#nais-load-exams', function() {
    var $container = $('#nais-exams-container');
    $container.html('<p>Loading exams...</p>');

    $.post(naisData.ajaxUrl, {
      action: 'nais_get_exams', nonce: naisData.nonce,
      class_id: $('#nais-exam-list-class').val()
    }, function(res) {
      if (!res.success) { $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error.') + '</p>'); return; }
      var list = res.data.exams;
      if (!list || list.length === 0) { $container.html('<p class="nais-hint">No exams found. Create one above.</p>'); return; }

      var types = {unit_test:'Unit Test', half_yearly:'Half Yearly', annual:'Annual', other:'Exam'};
      var html = '';
      list.forEach(function(ex) {
        var uploadColor = ex.docs_uploaded >= ex.total_students ? '#059669' : (ex.docs_uploaded > 0 ? '#D97706' : '#DC2626');
        html += '<div class="nais-exam-item">';
        html += '<div class="nais-exam-item-top"><div>';
        html += '<strong>' + escHtml(ex.exam_name) + '</strong>';
        html += '<div class="nais-exam-item-meta">' + escHtml(ex.class_name + ' ' + ex.section) + ' — ' + escHtml(types[ex.exam_type] || ex.exam_type) + '</div>';
        html += '</div>';
        html += '<div style="text-align:right;">';
        html += '<span style="color:' + uploadColor + ';font-weight:700;font-size:18px;">' + ex.docs_uploaded + '/' + ex.total_students + '</span>';
        html += '<div style="font-size:11px;color:#999;">uploaded</div>';
        html += '</div></div>';
        html += '<div style="margin-top:8px;">';
        html += '<button class="nais-btn nais-btn-xs nais-result-upload-btn" data-class-id="' + ex.class_id + '" data-exam-name="' + escHtml(ex.exam_name) + '" data-exam-type="' + escHtml(ex.exam_type) + '" data-class="' + escHtml(ex.class_name + ' ' + ex.section) + '">📄 Upload Results</button>';
        html += '<button class="nais-btn nais-btn-xs nais-btn-danger nais-exam-archive" data-exam-name="' + escHtml(ex.exam_name) + '" data-class-id="' + ex.class_id + '" style="margin-left:4px;">Archive</button>';
        html += '</div></div>';
      });
      $container.html(html);
    });
  });

  $(document).on('click', '[data-tab="results"]', function() { $('#nais-load-exams').click(); });

  /* Archive exam */
  $(document).on('click', '.nais-exam-archive', function() {
    if (!confirm('Archive this exam? Parents will no longer see the results.')) return;
    var $btn = $(this); $btn.prop('disabled', true);
    $.post(naisData.ajaxUrl, {
      action: 'nais_delete_exam', nonce: naisData.nonce,
      exam_name: $btn.data('exam-name'),
      class_id: $btn.data('class-id')
    }, function(res) {
      if (res.success) { $btn.closest('.nais-exam-item').fadeOut(300, function() { $(this).remove(); }); }
      else { alert(res.data || 'Error.'); $btn.prop('disabled', false); }
    });
  });

  /* Open upload panel */
  $(document).on('click', '.nais-result-upload-btn', function() {
    openResultUploadPanel(
      $(this).data('class-id'),
      $(this).data('exam-name'),
      $(this).data('exam-type'),
      $(this).data('class')
    );
  });

  function openResultUploadPanel(classId, examName, examType, className) {
    var $panel = $('#nais-result-upload-panel');
    var $list  = $('#nais-upload-students-list');
    $('#nais-upload-exam-title').text(examName);
    $('#nais-upload-exam-meta').text(className + ' — Upload a scanned result card (PDF/image) for each student');
    $panel.data('class-id', classId).data('exam-name', examName).data('exam-type', examType);
    $list.html('<p>Loading students...</p>');
    $panel.slideDown(300);

    $.post(naisData.ajaxUrl, {
      action: 'nais_get_exam_students', nonce: naisData.nonce,
      class_id: classId, exam_name: examName
    }, function(res) {
      if (!res.success) { $list.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error.') + '</p>'); return; }

      var students = res.data.students;
      if (!students || students.length === 0) { $list.html('<p class="nais-hint">No students found.</p>'); return; }

      var html = '<div class="nais-result-upload-grid">';
      students.forEach(function(s) {
        html += '<div class="nais-result-upload-row" data-student-id="' + s.id + '">';
        html += '<div class="nais-result-upload-info">';
        html += '<strong>' + escHtml(s.roll_no || '—') + '. ' + escHtml(s.name) + '</strong>';
        if (s.uploaded) {
          html += '<div class="nais-result-upload-status nais-result-uploaded">';
          html += '✅ Uploaded: <a href="' + escHtml(s.file_url) + '" target="_blank">' + escHtml(s.file_name) + '</a>';
          html += ' <button class="nais-btn nais-btn-xs nais-btn-danger nais-result-remove" data-result-id="' + s.result_id + '" style="margin-left:6px;">Remove</button>';
          html += '</div>';
        } else {
          html += '<div class="nais-result-upload-status" style="color:#9ca3af;">No file uploaded</div>';
        }
        html += '</div>';
        html += '<div class="nais-result-upload-action">';
        html += '<input type="file" class="nais-result-file-input" accept=".pdf,.jpg,.jpeg,.png,.gif,.webp" data-sid="' + s.id + '">';
        html += '<button class="nais-btn nais-btn-xs nais-result-do-upload" data-sid="' + s.id + '">Upload</button>';
        html += '</div>';
        html += '</div>';
      });
      html += '</div>';
      $list.html(html);

      $('html,body').animate({scrollTop: $panel.offset().top - 100}, 300);
    });
  }

  /* Upload result for one student */
  $(document).on('click', '.nais-result-do-upload', function() {
    var $btn    = $(this);
    var sid     = $btn.data('sid');
    var $row    = $btn.closest('.nais-result-upload-row');
    var $input  = $row.find('.nais-result-file-input');
    var $panel  = $('#nais-result-upload-panel');

    if (!$input[0].files.length) { alert('Select a file first.'); return; }

    var fd = new FormData();
    fd.append('action', 'nais_upload_result_doc');
    fd.append('nonce', naisData.nonce);
    fd.append('result_file', $input[0].files[0]);
    fd.append('student_id', sid);
    fd.append('class_id', $panel.data('class-id'));
    fd.append('exam_name', $panel.data('exam-name'));
    fd.append('exam_type', $panel.data('exam-type'));

    $btn.prop('disabled', true).text('Uploading...');

    $.ajax({
      url: naisData.ajaxUrl, type: 'POST', data: fd,
      processData: false, contentType: false,
      success: function(res) {
        $btn.prop('disabled', false).text('Upload');
        if (res.success) {
          var $status = $row.find('.nais-result-upload-status');
          $status.removeClass().addClass('nais-result-upload-status nais-result-uploaded');
          $status.html('✅ Uploaded: <a href="' + escHtml(res.data.file_url) + '" target="_blank">' + escHtml(res.data.file_name) + '</a> <button class="nais-btn nais-btn-xs nais-btn-danger nais-result-remove" data-result-id="' + res.data.result_id + '" style="margin-left:6px;">Remove</button>');
          $input.val('');
        } else {
          alert(res.data || 'Upload failed.');
        }
      },
      error: function() { alert('Upload error.'); $btn.prop('disabled', false).text('Upload'); }
    });
  });

  /* Remove uploaded result */
  $(document).on('click', '.nais-result-remove', function() {
    if (!confirm('Remove this result document?')) return;
    var $btn = $(this);
    var resultId = $btn.data('result-id');
    $btn.prop('disabled', true);

    $.post(naisData.ajaxUrl, { action: 'nais_delete_result_doc', nonce: naisData.nonce, result_id: resultId }, function(res) {
      if (res.success) {
        var $status = $btn.closest('.nais-result-upload-status');
        $status.removeClass('nais-result-uploaded').html('<span style="color:#9ca3af;">No file uploaded</span>');
      } else { alert(res.data || 'Error.'); $btn.prop('disabled', false); }
    });
  });

  /* Close upload panel */
  $(document).on('click', '#nais-close-upload-panel', function() {
    $('#nais-result-upload-panel').slideUp(300);
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: DUES MANAGEMENT
  ═══════════════════════════════════════════ */
  $(document).on('click', '#nais-load-dues', function() {
    var classId = $('#nais-dues-class').val();
    if (!classId) { alert('Select a class.'); return; }
    var $container = $('#nais-dues-container');
    $container.html('<p>Loading students...</p>');

    $.post(naisData.ajaxUrl, { action: 'nais_get_dues_list', nonce: naisData.nonce, class_id: classId }, function(res) {
      if (!res.success) { $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error.') + '</p>'); return; }
      var students = res.data.students;
      if (!students || students.length === 0) { $container.html('<p class="nais-hint">No students found.</p>'); return; }

      var html = '<div style="margin-top:12px;">';
      students.forEach(function(s) {
        var ck = s.has_dues == 1 ? ' checked' : '';
        var amtVal = (parseFloat(s.due_amount) > 0) ? s.due_amount : '';
        html += '<div class="nais-dues-row" data-sid="' + s.id + '">';
        html += '<span class="nais-dues-name">' + escHtml(s.roll_no || '—') + '. ' + escHtml(s.name) + '</span>';
        html += '<label class="nais-dues-toggle"><input type="checkbox" class="nais-dues-check"' + ck + '> Unpaid Dues</label>';
        html += '<input type="number" class="nais-dues-amount" placeholder="₹ Enter amount" value="' + amtVal + '">';
        html += '<input type="text" class="nais-dues-desc" placeholder="e.g. Tuition fee, Books" value="' + escHtml(s.due_reason || '') + '">';
        html += '</div>';
      });
      html += '<button class="nais-btn" id="nais-save-dues-btn" style="margin-top:16px;">Save All Dues</button>';
      html += '<div id="nais-dues-status" style="margin-top:8px;"></div></div>';
      $container.html(html);
    });
  });

  $(document).on('click', '#nais-save-dues-btn', function() {
    var dues = [];
    $('.nais-dues-row').each(function() {
      dues.push({
        student_id: $(this).data('sid'),
        has_dues: $(this).find('.nais-dues-check').is(':checked') ? 1 : 0,
        amount: $(this).find('.nais-dues-amount').val() || 0,
        reason: $(this).find('.nais-dues-desc').val()
      });
    });

    var $btn = $(this); $btn.prop('disabled', true).text('Saving...');
    $.post(naisData.ajaxUrl, { action: 'nais_save_dues', nonce: naisData.nonce, dues: JSON.stringify(dues) }, function(res) {
      $btn.prop('disabled', false).text('Save All Dues');
      if (res.success) { $('#nais-dues-status').html('<span style="color:#10b981;font-weight:600;">' + escHtml(res.data.message) + '</span>'); }
      else { $('#nais-dues-status').html('<span style="color:#ef4444;">' + escHtml(res.data || 'Error.') + '</span>'); }
      setTimeout(function() { $('#nais-dues-status').html(''); }, 5000);
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: TIMETABLE MANAGEMENT
  ═══════════════════════════════════════════ */

  /* Load weekly timetable grid */
  $(document).on('click', '#nais-tt-load', function() {
    var classId = $('#nais-tt-class').val();
    if (!classId) { alert('Select a class.'); return; }
    var $container = $('#nais-tt-grid-container');
    $container.html('<p>Loading timetable...</p>');

    $.post(naisData.ajaxUrl, { action: 'nais_get_timetable', nonce: naisData.nonce, class_id: classId }, function(res) {
      if (!res.success) { $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error.') + '</p>'); return; }

      var d = res.data;
      var grid = d.grid || {};

      var html = '<div class="nais-table-wrap" style="margin-top:12px;"><table class="nais-table nais-tt-table"><thead><tr><th>Period</th>';
      $.each(d.days, function(dayNum, dayName) {
        html += '<th>' + dayName.substring(0, 3) + '</th>';
      });
      html += '</tr></thead><tbody>';

      for (var p = 1; p <= d.periods; p++) {
        html += '<tr><td style="font-weight:700;color:#0a7558;">P' + p + '</td>';
        $.each(d.days, function(dayNum, dayName) {
          var key = dayNum + '_' + p;
          var val = grid[key] || '';
          html += '<td><input class="nais-tt-input" data-key="' + key + '" value="' + escHtml(val) + '" placeholder="Subject"></td>';
        });
        html += '</tr>';
      }

      html += '</tbody></table></div>';
      html += '<button class="nais-btn" id="nais-tt-save" style="margin-top:12px;">Save Timetable</button>';
      html += '<div id="nais-tt-status" style="margin-top:8px;"></div>';
      $container.html(html);
    });
  });

  /* Save timetable */
  $(document).on('click', '#nais-tt-save', function() {
    var classId = $('#nais-tt-class').val();
    var timetable = {};

    $('#nais-tt-grid-container .nais-tt-input').each(function() {
      var key = $(this).data('key');
      var val = $(this).val().trim();
      if (val) timetable[key] = val;
    });

    var $btn = $(this); $btn.prop('disabled', true).text('Saving...');
    $.post(naisData.ajaxUrl, {
      action: 'nais_save_timetable', nonce: naisData.nonce,
      class_id: classId, timetable: JSON.stringify(timetable)
    }, function(res) {
      $btn.prop('disabled', false).text('Save Timetable');
      if (res.success) { $('#nais-tt-status').html('<span style="color:#10b981;font-weight:600;">' + escHtml(res.data.message) + '</span>'); }
      else { $('#nais-tt-status').html('<span style="color:#ef4444;">' + escHtml(res.data || 'Error.') + '</span>'); }
      setTimeout(function() { $('#nais-tt-status').html(''); }, 5000);
    });
  });

  /* EXAM SCHEDULE — Add via form submit */
  $(document).on('submit', '#nais-add-exam-schedule-form', function(e) {
    e.preventDefault();
    var classId = $('#nais-es-class').val();
    if (!classId) { alert('Select a class.'); return; }

    var $btn = $(this).find('button[type="submit"]');
    $btn.prop('disabled', true).text('Adding...');

    $.post(naisData.ajaxUrl, {
      action: 'nais_save_exam_schedule', nonce: naisData.nonce,
      class_id: classId,
      exam_name: $('#nais-es-name').val().trim(),
      subject: $('#nais-es-subject').val().trim(),
      exam_date: $('#nais-es-date').val(),
      start_time: $('#nais-es-start').val(),
      end_time: $('#nais-es-end').val(),
      venue: $('#nais-es-venue').val().trim()
    }, function(res) {
      $btn.prop('disabled', false).text('Add to Schedule');
      if (res.success) {
        $('#nais-es-result').html('<div class="nais-alert nais-alert-success" style="margin:0;">' + escHtml(res.data.message) + '</div>');
        $('#nais-es-subject').val(''); $('#nais-es-date').val(''); $('#nais-es-start').val(''); $('#nais-es-end').val(''); $('#nais-es-venue').val('');
        setTimeout(function() { $('#nais-es-result').html(''); }, 4000);
        /* Reload if same class */
        if ($('#nais-es-list-class').val() === classId) { $('#nais-es-load').click(); }
      } else { alert(res.data || 'Error.'); }
    });
  });

  /* Load exam schedule */
  $(document).on('click', '#nais-es-load', function() {
    var classId = $('#nais-es-list-class').val();
    if (!classId) { alert('Select a class.'); return; }
    var $container = $('#nais-es-container');
    $container.html('<p>Loading schedule...</p>');

    $.post(naisData.ajaxUrl, { action: 'nais_get_exam_schedule', nonce: naisData.nonce, class_id: classId }, function(res) {
      if (!res.success) { $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error.') + '</p>'); return; }
      var list = res.data.schedule;
      if (!list || list.length === 0) { $container.html('<p class="nais-hint">No exam dates scheduled yet.</p>'); return; }

      var html = '<table class="nais-table" style="margin-top:12px;"><thead><tr><th>Exam</th><th>Subject</th><th>Date</th><th>Time</th><th>Venue</th><th></th></tr></thead><tbody>';
      list.forEach(function(e) {
        var date = new Date(e.exam_date + 'T00:00:00').toLocaleDateString('en-IN', {day:'numeric', month:'short', year:'numeric', weekday:'short'});
        var time = (e.start_time && e.end_time) ? (e.start_time + ' – ' + e.end_time) : (e.start_time || '—');
        html += '<tr><td>' + escHtml(e.exam_name) + '</td><td><strong>' + escHtml(e.subject) + '</strong></td><td style="white-space:nowrap;">' + date + '</td><td>' + escHtml(time) + '</td><td>' + escHtml(e.venue || '—') + '</td>';
        html += '<td><button class="nais-btn nais-btn-xs nais-btn-danger nais-es-delete" data-id="' + e.id + '">Remove</button></td></tr>';
      });
      html += '</tbody></table>';
      $container.html(html);
    });
  });

  /* Delete exam schedule entry */
  $(document).on('click', '.nais-es-delete', function() {
    if (!confirm('Remove this exam date?')) return;
    var $btn = $(this); $btn.prop('disabled', true);
    $.post(naisData.ajaxUrl, { action: 'nais_delete_exam_schedule', nonce: naisData.nonce, schedule_id: $btn.data('id') }, function(res) {
      if (res.success) { $btn.closest('tr').fadeOut(300, function() { $(this).remove(); }); }
      else { alert(res.data || 'Error.'); $btn.prop('disabled', false); }
    });
  });


  /* ═══════════════════════════════════════════
     PARENT: DATA DELETION REQUEST
  ═══════════════════════════════════════════ */
  $(document).on('click', '.nais-delete-request', function(e) {
    e.preventDefault();
    if (!confirm('Are you sure you want to request data deletion? Your parent account link will be removed. This action cannot be undone.')) return;

    $.post(naisData.ajaxUrl, {
      action: 'nais_request_data_deletion',
      nonce:  naisData.nonce
    }, function(res) {
      if (res.success) {
        alert(res.data);
        location.reload();
      } else {
        alert(res.data || 'Error processing request.');
      }
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: HOMEWORK OVERVIEW SUMMARY
  ═══════════════════════════════════════════ */
  $(document).on('click', '#nais-hw-load-summary', function() {
    var classId = $('#nais-hw-summary-class').val();
    var date    = $('#nais-hw-summary-date').val();
    if (!classId) { alert('Please select a class.'); return; }
    var $container = $('#nais-hw-summary-container');
    $container.html('<p>Loading summary...</p>');

    $.post(naisData.ajaxUrl, {
      action:   'nais_get_homework_summary',
      nonce:    naisData.nonce,
      class_id: classId,
      date:     date
    }, function(res) {
      if (!res.success) {
        $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error loading summary.') + '</p>');
        return;
      }

      var d = res.data;
      if (!d.subjects || d.subjects.length === 0) {
        $container.html('<p class="nais-hint">No homework recorded for this class on ' + escHtml(d.date) + '.</p>');
        return;
      }

      var html = '<p style="color:#666;font-size:13px;margin-bottom:12px;">Total students in class: <strong>' + d.total_students + '</strong> — Date: <strong>' + escHtml(d.date) + '</strong></p>';
      html += '<div class="nais-table-wrap"><table class="nais-table"><thead><tr><th>Subject</th><th style="color:#10b981;">Done</th><th style="color:#ef4444;">Not Done</th><th style="color:#f59e0b;">Half Done</th><th style="color:#6b7280;">No HW</th><th>Total</th></tr></thead><tbody>';
      d.subjects.forEach(function(s) {
        html += '<tr>';
        html += '<td><strong>' + escHtml(s.subject) + '</strong></td>';
        html += '<td style="color:#10b981;font-weight:700;">' + s.done_count + '</td>';
        html += '<td style="color:#ef4444;font-weight:700;">' + s.not_done_count + '</td>';
        html += '<td style="color:#f59e0b;font-weight:700;">' + s.half_done_count + '</td>';
        html += '<td style="color:#6b7280;">' + s.no_hw_count + '</td>';
        html += '<td>' + s.total + '</td>';
        html += '</tr>';
      });
      html += '</tbody></table></div>';
      $container.html(html);
    });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: DELETE CLASS
  ═══════════════════════════════════════════ */
  $(document).on('click', '.nais-delete-class-btn', function() {
    var $btn       = $(this);
    var classId    = $btn.data('class-id');
    var className  = $btn.data('class-name');
    var studentCount = $btn.data('student-count') || 0;

    if (studentCount > 0) {
      alert('Cannot delete "' + className + '" — it has ' + studentCount + ' active student(s). Remove or move the students first.');
      return;
    }

    if (!confirm('Delete "' + className + '"? This will also remove any teacher assignments for this class.')) return;

    $btn.prop('disabled', true).text('Deleting...');
    $.post(naisData.ajaxUrl, {
      action: 'nais_delete_class', nonce: naisData.nonce, school_id: getSchoolId(), class_id: classId
    }, function(res) {
      if (res.success) {
        alert(res.data.message);
        // Remove row from classes table
        $btn.closest('tr').fadeOut(300, function() {
          $(this).remove();
          // Update class count badge
          var count = $('#nais-classes-list tr').length;
          $('.nais-stat-badge').first().text(count + ' Classes');
        });
        // Remove from class dropdowns
        $('select[name="class_id"], #nais-students-filter-class, #nais-bulk-class, #nais-report-class').find('option[value="' + classId + '"]').remove();
      }
      else { alert(res.data || 'Error deleting class.'); $btn.prop('disabled', false).text('Delete'); }
    }).fail(function() { alert('Network error.'); $btn.prop('disabled', false).text('Delete'); });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: STUDENTS LIST + DELETE + EDIT
  ═══════════════════════════════════════════ */
  $(document).on('click', '#nais-load-students-list', function() {
    var classId = $('#nais-students-filter-class').val();
    var $container = $('#nais-students-list-container');
    $container.html('<p>Loading students...</p>');

    $.post(naisData.ajaxUrl, {
      action: 'nais_get_students_list', nonce: naisData.nonce, school_id: getSchoolId(), class_id: classId
    }, function(res) {
      if (!res.success) { $container.html('<p class="nais-alert nais-alert-error">' + escHtml(res.data || 'Error.') + '</p>'); return; }
      var students = res.data.students;
      if (!students || students.length === 0) { $container.html('<p class="nais-hint">No students found.</p>'); return; }

      var html = '<p style="margin-bottom:8px;color:#666;font-size:13px;">' + students.length + ' student(s) found.</p>';
      html += '<div class="nais-table-wrap"><table class="nais-table"><thead><tr><th>Name</th><th>Class</th><th>Roll</th><th>Gender</th><th>Parent</th><th>Phone</th><th>Code</th><th>Actions</th></tr></thead><tbody>';
      students.forEach(function(s) {
        html += '<tr data-student-id="' + s.id + '">';
        html += '<td><strong>' + escHtml(s.name) + '</strong></td>';
        html += '<td>' + escHtml((s.class_name || '') + ' ' + (s.section || '')) + '</td>';
        html += '<td>' + escHtml(s.roll_no || '—') + '</td>';
        html += '<td>' + escHtml(s.gender || '—') + '</td>';
        html += '<td>' + escHtml(s.parent_name || '—') + '</td>';
        html += '<td>' + escHtml(s.parent_phone || '—') + '</td>';
        html += '<td>';
        html += '<button class="nais-btn nais-btn-xs nais-edit-student-btn" data-student="' + escHtml(JSON.stringify({id:s.id,name:s.name,roll_no:s.roll_no||'',admission_no:s.admission_no||'',gender:s.gender||'',dob:s.dob||'',parent_name:s.parent_name||'',parent_phone:s.parent_phone||'',class_id:s.class_id})) + '">Edit</button> ';
        html += '<button class="nais-btn nais-btn-xs nais-btn-danger nais-delete-student-btn" data-student-id="' + s.id + '" data-student-name="' + escHtml(s.name) + '">Delete</button>';
        html += '</td></tr>';
      });
      html += '</tbody></table></div>';
      $container.html(html);
    });
  });

  /* Delete Student */
  $(document).on('click', '.nais-delete-student-btn', function() {
    var $btn      = $(this);
    var studentId = $btn.data('student-id');
    var name      = $btn.data('student-name');

    if (!confirm('Remove student "' + name + '"?\n\nThe student will be deactivated. Their attendance records are preserved.')) return;

    $btn.prop('disabled', true).text('Removing...');
    $.post(naisData.ajaxUrl, {
      action: 'nais_delete_student', nonce: naisData.nonce, school_id: getSchoolId(), student_id: studentId
    }, function(res) {
      if (res.success) { $btn.closest('tr').fadeOut(300, function() { $(this).remove(); }); }
      else { alert(res.data || 'Error.'); $btn.prop('disabled', false).text('Delete'); }
    }).fail(function() { alert('Network error.'); $btn.prop('disabled', false).text('Delete'); });
  });

  /* Edit Student — show inline form */
  $(document).on('click', '.nais-edit-student-btn', function() {
    var data = $(this).data('student');
    if (typeof data === 'string') { try { data = JSON.parse(data); } catch(e) { return; } }

    var classOptions = '';
    $('#nais-students-filter-class option').each(function() {
      if (!$(this).val()) return;
      var sel = ($(this).val() == data.class_id) ? ' selected' : '';
      classOptions += '<option value="' + $(this).val() + '"' + sel + '>' + escHtml($(this).text()) + '</option>';
    });

    var html = '<div class="nais-edit-panel" style="background:#f0fdf4;border:2px solid #10B981;border-radius:12px;padding:20px;margin:16px 0;">';
    html += '<h4 style="margin:0 0 14px;color:#0F2419;">Edit Student</h4>';
    html += '<input type="hidden" id="nais-edit-student-id" value="' + data.id + '">';
    html += '<div class="nais-form" style="max-width:100%;display:grid;grid-template-columns:1fr 1fr;gap:10px;">';
    html += '<div class="nais-form-row"><label>Name *</label><input type="text" id="nais-edit-s-name" value="' + escHtml(data.name) + '" required></div>';
    html += '<div class="nais-form-row"><label>Class</label><select id="nais-edit-s-class">' + classOptions + '</select></div>';
    html += '<div class="nais-form-row"><label>Roll No</label><input type="text" id="nais-edit-s-roll" value="' + escHtml(data.roll_no) + '"></div>';
    html += '<div class="nais-form-row"><label>Gender</label><select id="nais-edit-s-gender"><option value="">Select</option><option value="male"' + (data.gender==='male'?' selected':'') + '>Male</option><option value="female"' + (data.gender==='female'?' selected':'') + '>Female</option><option value="other"' + (data.gender==='other'?' selected':'') + '>Other</option></select></div>';
    html += '<div class="nais-form-row"><label>Admission No</label><input type="text" id="nais-edit-s-admission" value="' + escHtml(data.admission_no) + '"></div>';
    html += '<div class="nais-form-row"><label>Date of Birth</label><input type="date" id="nais-edit-s-dob" value="' + escHtml(data.dob) + '"></div>';
    html += '<div class="nais-form-row"><label>Parent Name</label><input type="text" id="nais-edit-s-parent" value="' + escHtml(data.parent_name) + '"></div>';
    html += '<div class="nais-form-row"><label>Parent Phone</label><input type="tel" id="nais-edit-s-phone" value="' + escHtml(data.parent_phone) + '"></div>';
    html += '</div>';
    html += '<div style="margin-top:14px;"><button class="nais-btn nais-btn-primary" id="nais-save-edit-student">Save Changes</button> <button class="nais-btn nais-btn-sm" id="nais-cancel-edit-student" style="background:#6B7280;">Cancel</button></div>';
    html += '</div>';

    /* Remove any existing edit panel and insert this one */
    $('.nais-edit-panel').remove();
    $('#nais-students-list-container').prepend(html);
    $('html,body').animate({scrollTop: $('.nais-edit-panel').offset().top - 80}, 300);
  });

  $(document).on('click', '#nais-cancel-edit-student', function() { $('.nais-edit-panel').remove(); });

  $(document).on('click', '#nais-save-edit-student', function() {
    var $btn = $(this);
    var studentId = $('#nais-edit-student-id').val();
    var name      = $('#nais-edit-s-name').val().trim();
    if (!name) { alert('Student name is required.'); return; }

    $btn.prop('disabled', true).text('Saving...');
    $.post(naisData.ajaxUrl, {
      action:       'nais_edit_student',
      nonce:        naisData.nonce,
      school_id:    getSchoolId(),
      student_id:   studentId,
      name:         name,
      class_id:     $('#nais-edit-s-class').val(),
      roll_no:      $('#nais-edit-s-roll').val(),
      admission_no: $('#nais-edit-s-admission').val(),
      gender:       $('#nais-edit-s-gender').val(),
      dob:          $('#nais-edit-s-dob').val(),
      parent_name:  $('#nais-edit-s-parent').val(),
      parent_phone: $('#nais-edit-s-phone').val()
    }, function(res) {
      $btn.prop('disabled', false).text('Save Changes');
      if (res.success) {
        alert(res.data.message);
        $('.nais-edit-panel').remove();
        $('#nais-load-students-list').click(); /* Refresh list */
      } else {
        alert(res.data || 'Error saving changes.');
      }
    }).fail(function() { alert('Network error.'); $btn.prop('disabled', false).text('Save Changes'); });
  });


  /* ═══════════════════════════════════════════
     SCHOOL ADMIN: DELETE + EDIT TEACHER
  ═══════════════════════════════════════════ */
  $(document).on('click', '.nais-delete-teacher-btn', function() {
    var $btn      = $(this);
    var teacherId = $btn.data('teacher-id');
    var name      = $btn.data('teacher-name');

    if (!confirm('Remove teacher "' + name + '"?\n\nTheir class assignments will be removed and their teacher role will be revoked.')) return;

    $btn.prop('disabled', true).text('Removing...');
    $.post(naisData.ajaxUrl, {
      action: 'nais_delete_teacher', nonce: naisData.nonce, school_id: getSchoolId(), teacher_id: teacherId
    }, function(res) {
      if (res.success) { alert(res.data.message); location.reload(); }
      else { alert(res.data || 'Error.'); $btn.prop('disabled', false).text('Delete'); }
    }).fail(function() { alert('Network error.'); $btn.prop('disabled', false).text('Delete'); });
  });

  /* Edit Teacher — show inline form */
  $(document).on('click', '.nais-edit-teacher-btn', function() {
    var $btn = $(this);
    var data = {
      id:          $btn.data('teacher-id'),
      name:        $btn.data('name'),
      phone:       $btn.data('phone') || '',
      employee_id: $btn.data('employee-id') || '',
      designation: $btn.data('designation') || 'Teacher'
    };

    var html = '<div class="nais-edit-panel" style="background:#f0fdf4;border:2px solid #10B981;border-radius:12px;padding:20px;margin:16px 0;">';
    html += '<h4 style="margin:0 0 14px;color:#0F2419;">Edit Teacher: ' + escHtml(data.name) + '</h4>';
    html += '<input type="hidden" id="nais-edit-teacher-id" value="' + data.id + '">';
    html += '<div class="nais-form" style="max-width:600px;">';
    html += '<div class="nais-form-row"><label>Name *</label><input type="text" id="nais-edit-t-name" value="' + escHtml(data.name) + '" required></div>';
    html += '<div class="nais-form-row"><label>Phone</label><input type="tel" id="nais-edit-t-phone" value="' + escHtml(data.phone) + '"></div>';
    html += '<div class="nais-form-row"><label>Employee ID</label><input type="text" id="nais-edit-t-empid" value="' + escHtml(data.employee_id) + '"></div>';
    html += '<div class="nais-form-row"><label>Designation</label><input type="text" id="nais-edit-t-desig" value="' + escHtml(data.designation) + '"></div>';
    html += '</div>';
    html += '<div style="margin-top:14px;"><button class="nais-btn nais-btn-primary" id="nais-save-edit-teacher">Save Changes</button> <button class="nais-btn nais-btn-sm" id="nais-cancel-edit-teacher" style="background:#6B7280;">Cancel</button></div>';
    html += '</div>';

    $('.nais-edit-panel').remove();
    $('#nais-tab-teachers').prepend(html);
    $('html,body').animate({scrollTop: $('.nais-edit-panel').offset().top - 80}, 300);
  });

  $(document).on('click', '#nais-cancel-edit-teacher', function() { $('.nais-edit-panel').remove(); });

  $(document).on('click', '#nais-save-edit-teacher', function() {
    var $btn = $(this);
    var name = $('#nais-edit-t-name').val().trim();
    if (!name) { alert('Teacher name is required.'); return; }

    $btn.prop('disabled', true).text('Saving...');
    $.post(naisData.ajaxUrl, {
      action:      'nais_edit_teacher',
      nonce:       naisData.nonce,
      school_id:   getSchoolId(),
      teacher_id:  $('#nais-edit-teacher-id').val(),
      name:        name,
      phone:       $('#nais-edit-t-phone').val(),
      employee_id: $('#nais-edit-t-empid').val(),
      designation: $('#nais-edit-t-desig').val()
    }, function(res) {
      $btn.prop('disabled', false).text('Save Changes');
      if (res.success) { alert(res.data.message); location.reload(); }
      else { alert(res.data || 'Error saving changes.'); }
    }).fail(function() { alert('Network error.'); $btn.prop('disabled', false).text('Save Changes'); });
  });


  /* ─── HELPERS ─── */
  function updateSummary() {
    var total   = $('.nais-checklist-row').length;
    var present = $('.nais-checklist-row .active-present').length;
    var absent  = $('.nais-checklist-row .active-absent').length;
    var late    = $('.nais-checklist-row .active-late').length;
    var excused = $('.nais-checklist-row .active-excused').length;
    var unmarked = total - present - absent - late - excused;

    $('#nais-summary').text(
      present + ' Present · ' + absent + ' Absent · ' + late + ' Late · ' + excused + ' Excused' +
      (unmarked > 0 ? ' · ' + unmarked + ' Unmarked' : '')
    );
  }

  function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

})(jQuery);