<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAGALAND AI SCHOOLS — Attendance Management System
 * India's First AI-Powered School Attendance Platform
 * ═══════════════════════════════════════════════════════════════
 *
 * Plugin Name:  Nagaland AI Schools
 * Description:  AI-powered school attendance tracking with parent verification,
 *               teacher checklist, admin dashboards, and NagalandAI integration.
 * Version:      1.0.0
 * Author:       Nagaland Me (Aloto Naga)
 * Author URI:   https://nagaland.me
 * Text Domain:  nais
 * Domain Path:  /languages
 * License:      Proprietary
 * Requires PHP: 7.4
 *
 * Deployment:   schools.nagalandai.com
 * Parent Brand: Nagaland Me (GST: 13DIHPA5679B1ZK)
 *
 * ARCHITECTURE:
 * ─────────────────────────────────────────────────
 * This plugin manages the complete attendance lifecycle:
 *
 *   School Admin → adds teachers, students, classes
 *   Teacher      → marks daily + period attendance
 *   Parent       → registers with 6-digit code, views attendance
 *   NagalandAI   → parent asks "did my child go to school?"
 *                   → REST API returns real attendance data
 *   Government   → district dashboard (read-only aggregate)
 *
 * PRIVACY (DPDP Act 2023):
 *   - All pages: noindex, nofollow
 *   - REST API: authenticated only (API key + parent code)
 *   - No student data exposed to search engines
 *   - Parent sees only their own child's data
 *   - Data deletion requests built in
 *   - Audit trail on all attendance actions
 *
 * DATABASE TABLES (11):
 *   nais_schools, nais_classes, nais_students,
 *   nais_teachers, nais_teacher_classes,
 *   nais_attendance_daily, nais_attendance_period,
 *   nais_parent_links, nais_holidays, nais_audit_log,
 *   nais_rate_limits
 *
 * PAYMENT TABLES (2):
 *   nais_school_payments, nais_school_coupons
 *
 * GOVERNMENT-READY:
 *   - UDISE codes on schools (standard Indian school ID)
 *   - District + Block fields for district-level rollout
 *   - Academic year isolation
 *   - Audit logging for accountability
 *   - Government Auditor role (read-only)
 *   - District Dashboard (aggregate view across all schools)
 * ═══════════════════════════════════════════════════════════════
 */

if (!defined('ABSPATH')) exit;

/* ─── CONSTANTS ─── */
define('NAIS_VERSION',     '1.0.4');
define('NAIS_PLUGIN_DIR',  plugin_dir_path(__FILE__));
define('NAIS_PLUGIN_URL',  plugin_dir_url(__FILE__));
define('NAIS_PLUGIN_FILE', __FILE__);

/*
 * API key for NagalandAI ↔ Schools communication.
 * CHANGE THIS to your own secret key after uploading.
 * Must match the key in nai_school.php on nagalandai.com.
 */
define('NAIS_API_KEY', 'M0BfMujUvmLsog3eR8QGiVHvZhDKsmenNCmpHEKnEOdHOxkv');

/*
 * Current academic year. Update annually.
 * Format: YYYY-YYYY (e.g., 2026-2027)
 */
define('NAIS_ACADEMIC_YEAR', '2026-2027');

/* ─── LOAD INCLUDES ─── */
require_once NAIS_PLUGIN_DIR . 'includes/class-database.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-roles.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-privacy.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-admin.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-school-admin.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-teacher.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-parent.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-attendance.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-api.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-payment.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-school-register.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-district-dashboard.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-bus-tracking.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-homework.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-exam-results.php';
require_once NAIS_PLUGIN_DIR . 'includes/class-timetable.php';

/* ─── MAIN PLUGIN CLASS ─── */
final class Nagaland_AI_Schools {

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        /* Activation / Deactivation */
        register_activation_hook(NAIS_PLUGIN_FILE, [$this, 'activate']);
        register_deactivation_hook(NAIS_PLUGIN_FILE, [$this, 'deactivate']);

        /* Initialize all modules */
        add_action('init', [$this, 'init_modules']);

        /* Admin menus */
        add_action('admin_menu', [$this, 'admin_menus']);

        /* Enqueue assets */
        add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);

        /* Register shortcodes */
        add_action('init', [$this, 'register_shortcodes']);

        /* REST API */
        add_action('rest_api_init', [$this, 'register_api_routes']);

        /* DB version check (auto-upgrade) */
        add_action('plugins_loaded', [$this, 'check_db_version']);
    }

    /* ─── ACTIVATION ─── */
    public function activate() {
        NAIS_Database::create_tables();
        NAIS_Payment::create_tables();
        NAIS_Bus_Tracking::create_tables();
        NAIS_Homework::create_tables();
        NAIS_Exam_Results::create_tables();
        NAIS_Timetable::create_tables();
        NAIS_Roles::create_roles();
        NAIS_Privacy::setup_privacy();
        update_option('nais_db_version', NAIS_VERSION);
        flush_rewrite_rules();
    }

    /* ─── DEACTIVATION ─── */
    public function deactivate() {
        /* Roles are NOT removed on deactivation — data safety */
        flush_rewrite_rules();
    }

    /* ─── DB VERSION CHECK ─── */
    public function check_db_version() {
        $installed = get_option('nais_db_version', '0');
        if (version_compare($installed, NAIS_VERSION, '<')) {
            NAIS_Database::create_tables();
            NAIS_Payment::create_tables();
            NAIS_Bus_Tracking::create_tables();
            NAIS_Homework::create_tables();
            NAIS_Exam_Results::create_tables();
            NAIS_Timetable::create_tables();
            NAIS_Roles::create_roles();
            update_option('nais_db_version', NAIS_VERSION);
        }
    }

    /* ─── INIT MODULES ─── */
    public function init_modules() {
        NAIS_Privacy::init();
        NAIS_Attendance::init();
        NAIS_District_Dashboard::init();
        NAIS_Admin::init();
        /* NAIS_School_Admin, NAIS_Payment, NAIS_Homework, NAIS_Exam_Results,
           NAIS_Timetable, NAIS_Bus_Tracking, NAIS_School_Register
           all self-register via add_action('init', ...) at the bottom of their files. */
    }

    /* ─── ADMIN MENUS ─── */
    public function admin_menus() {
        NAIS_Admin::register_menus();
    }

    /* ─── SHORTCODES ─── */
    public function register_shortcodes() {
        /* Dashboard — routes by role */
        add_shortcode('nais_dashboard', [NAIS_Admin::class, 'dashboard_shortcode']);

        /* Teacher attendance marking */
        add_shortcode('nais_mark_attendance', [NAIS_Teacher::class, 'mark_attendance_shortcode']);

        /* Parent registration with 6-digit code */
        add_shortcode('nais_parent_register', [NAIS_Parent::class, 'register_shortcode']);

        /* Parent — view child attendance */
        add_shortcode('nais_my_child', [NAIS_Parent::class, 'my_child_shortcode']);

        /* School Admin — manage school */
        add_shortcode('nais_manage_school', [NAIS_School_Admin::class, 'manage_school_shortcode']);

        /* School payment/subscription */
        add_shortcode('nais_school_payment', [NAIS_Payment::class, 'payment_shortcode']);

        /* School self-registration (approval-based) */
        add_shortcode('nais_school_register', [NAIS_School_Register::class, 'register_shortcode']);

        /* District government dashboard (read-only aggregate) */
        add_shortcode('nais_district_dashboard', [NAIS_District_Dashboard::class, 'dashboard_shortcode']);
    }

    /* ─── REST API ROUTES ─── */
    public function register_api_routes() {
        NAIS_API::register_routes();
    }

    /* ─── FRONTEND ASSETS ─── */
    public function frontend_assets() {
        wp_enqueue_style('leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4');
        wp_enqueue_script('leaflet-js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], '1.9.4', true);
        wp_enqueue_style(
            'nais-frontend',
            NAIS_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            NAIS_VERSION
        );

        wp_enqueue_script(
            'nais-frontend',
            NAIS_PLUGIN_URL . 'assets/js/frontend.js',
            ['jquery'],
            NAIS_VERSION,
            true
        );

        wp_localize_script('nais-frontend', 'naisData', [
            'ajaxUrl'  => admin_url('admin-ajax.php'),
            'restUrl'  => rest_url('nais/v1/'),
            'nonce'    => wp_create_nonce('nais_nonce'),
            'restNonce'=> wp_create_nonce('wp_rest'),
        ]);
    }

    /* ─── ADMIN ASSETS ─── */
    public function admin_assets($hook) {
        if (strpos($hook, 'nais') === false && strpos($hook, 'nagaland-schools') === false) return;

        wp_enqueue_style(
            'nais-admin',
            NAIS_PLUGIN_URL . 'assets/css/admin.css',
            [],
            NAIS_VERSION
        );

        wp_enqueue_script(
            'nais-admin',
            NAIS_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            NAIS_VERSION,
            true
        );

        wp_localize_script('nais-admin', 'naisAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('nais_admin_nonce'),
        ]);
    }
}

/* ─── BOOT ─── */
Nagaland_AI_Schools::instance();