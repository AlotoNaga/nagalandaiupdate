<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS EXAM RESULTS — V2 Document Upload Design
 * ═══════════════════════════════════════════════════════════════
 *
 * V2 Design: Admin uploads scanned result card (PDF/image) per
 * student per exam. NO marks grid, NO manual marks entry.
 * Parent views ONLY their child's result document.
 * If student has unpaid dues → result viewing is LOCKED.
 *
 * DB Tables:
 *   nais_student_results — student_id, exam_name, file_url
 *   nais_student_dues    — student_id, has_dues, amount, reason
 */

if (!defined('ABSPATH')) exit;

class NAIS_Exam_Results {

    public static function init() {
        add_action('wp_ajax_nais_create_exam',        [__CLASS__, 'ajax_create_exam']);
        add_action('wp_ajax_nais_get_exams',          [__CLASS__, 'ajax_get_exams']);
        add_action('wp_ajax_nais_delete_exam',        [__CLASS__, 'ajax_delete_exam']);
        add_action('wp_ajax_nais_get_exam_students',  [__CLASS__, 'ajax_get_exam_students']);
        add_action('wp_ajax_nais_upload_result_doc',   [__CLASS__, 'ajax_upload_result_doc']);
        add_action('wp_ajax_nais_delete_result_doc',   [__CLASS__, 'ajax_delete_result_doc']);
        add_action('wp_ajax_nais_get_dues_list',       [__CLASS__, 'ajax_get_dues_list']);
        add_action('wp_ajax_nais_save_dues',           [__CLASS__, 'ajax_save_dues']);
        add_action('wp_ajax_nais_parent_view_result',  [__CLASS__, 'ajax_parent_view_result']);
    }


    /**
     * ═══ ADMIN TAB: Results Management ═══
     */
    public static function render_results_tab($school_id, $classes) {
        ob_start();
        ?>
        <h3>Exam Results</h3>
        <p class="nais-hint">Upload scanned result cards (PDF or image) for each student. Parents can view their child's result if they have no unpaid dues.</p>

        <!-- Create Exam -->
        <div style="margin-bottom:28px;">
            <h4>Create Exam</h4>
            <form class="nais-inline-form" id="nais-create-exam-form">
                <select id="nais-exam-class" required>
                    <option value="">Select Class</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="text" id="nais-exam-name" placeholder="Exam name (e.g. Unit Test 1)" required style="min-width:200px;">
                <select id="nais-exam-type">
                    <option value="unit_test">Unit Test</option>
                    <option value="half_yearly">Half Yearly</option>
                    <option value="annual">Annual</option>
                    <option value="other">Other</option>
                </select>
                <button type="submit" class="nais-btn">Create Exam</button>
            </form>
            <div id="nais-exam-create-result"></div>
        </div>

        <!-- Exam List + Upload -->
        <div style="margin-bottom:28px;">
            <h4>Upload Results</h4>
            <div class="nais-inline-form">
                <select id="nais-exam-list-class">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="nais-btn nais-btn-sm" id="nais-load-exams">Load Exams</button>
            </div>
            <div id="nais-exams-container"><p class="nais-hint">Click "Load Exams" to see existing exams.</p></div>
        </div>

        <!-- Upload Panel (shown when clicking Upload on an exam) -->
        <div id="nais-result-upload-panel" style="display:none;">
            <div style="padding:20px;background:#f9fafb;border-radius:14px;border:1.5px solid #e5e7eb;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                    <div>
                        <h4 style="margin:0;" id="nais-upload-exam-title"></h4>
                        <p style="margin:4px 0 0;color:#6b7280;font-size:13px;" id="nais-upload-exam-meta"></p>
                    </div>
                    <button class="nais-btn nais-btn-sm" id="nais-close-upload-panel">Close</button>
                </div>
                <div id="nais-upload-students-list"><p>Loading students...</p></div>
            </div>
        </div>

        <!-- Dues Management -->
        <div style="margin-top:32px;padding-top:24px;border-top:2px solid #e5e7eb;">
            <h4>Manage Student Dues</h4>
            <p class="nais-hint">Students with unpaid dues cannot view their exam results.</p>
            <div class="nais-inline-form">
                <select id="nais-dues-class">
                    <option value="">Select Class</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="nais-btn nais-btn-sm" id="nais-load-dues">Load Students</button>
            </div>
            <div id="nais-dues-container"></div>
        </div>
        <?php
        return ob_get_clean();
    }


    /**
     * ═══ PARENT VIEW: Exam Results (dues-gated) ═══
     */
    public static function render_parent_results($student) {
        global $wpdb;

        /* Check dues */
        $dues = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('student_dues') .
            " WHERE student_id = %d AND has_dues = 1",
            $student->id
        ));

        /* Get results */
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('student_results') .
            " WHERE student_id = %d AND status = 'active' ORDER BY created_at DESC",
            $student->id
        ));

        ob_start();
        ?>
        <div class="nais-results-section" style="margin-top:24px;">
            <h4 style="font-size:13px;color:#9ca3af;text-transform:uppercase;margin-bottom:12px;">Exam Results</h4>

            <?php if ($dues): ?>
                <div class="nais-result-locked">
                    <div class="nais-result-locked-icon">🔒</div>
                    <h5>Results Locked</h5>
                    <p>Your child has unpaid dues of <strong>₹<?php echo number_format((float)$dues->amount); ?></strong><?php echo $dues->reason ? ' (' . esc_html($dues->reason) . ')' : ''; ?>.</p>
                    <p>Please clear the dues with the school to view exam results.</p>
                </div>
            <?php elseif (empty($results)): ?>
                <p style="color:#6b7280;font-size:14px;">No exam results uploaded yet.</p>
            <?php else: ?>
                <div class="nais-result-list">
                    <?php foreach ($results as $r):
                        $types = ['unit_test'=>'Unit Test','half_yearly'=>'Half Yearly','annual'=>'Annual','other'=>'Exam'];
                        $type_label = $types[$r->exam_type] ?? 'Exam';
                        $date = date_i18n('d M Y', strtotime($r->created_at));
                        $ext = strtolower(pathinfo($r->file_name, PATHINFO_EXTENSION));
                        $is_image = in_array($ext, ['jpg','jpeg','png','gif','webp'], true);
                    ?>
                        <div class="nais-result-card">
                            <div class="nais-result-card-header">
                                <div>
                                    <strong style="font-size:15px;"><?php echo esc_html($r->exam_name); ?></strong>
                                    <div style="font-size:12px;color:#9ca3af;margin-top:2px;"><?php echo esc_html($type_label); ?> — Uploaded <?php echo $date; ?></div>
                                </div>
                                <div>
                                    <a href="<?php echo esc_url($r->file_url); ?>" target="_blank" class="nais-btn nais-btn-sm">
                                        <?php echo $is_image ? '🖼️ View' : '📄 Download'; ?>
                                    </a>
                                </div>
                            </div>
                            <?php if ($is_image): ?>
                                <div style="margin-top:10px;">
                                    <img src="<?php echo esc_url($r->file_url); ?>" alt="Result" style="max-width:100%;border-radius:8px;border:1px solid #e5e7eb;">
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }


    /* ═══════════════════════════════════════════
       AJAX HANDLERS
    ═══════════════════════════════════════════ */

    /** Create exam */
    public static function ajax_create_exam() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        $school_id = NAIS_Roles::get_user_school_id();
        $class_id  = absint($_POST['class_id'] ?? 0);
        $exam_name = sanitize_text_field($_POST['exam_name'] ?? '');
        $exam_type = sanitize_text_field($_POST['exam_type'] ?? 'other');

        if (!$school_id || !$class_id || !$exam_name) wp_send_json_error('Class and exam name are required.');
        if (!in_array($exam_type, ['unit_test','half_yearly','annual','other'], true)) $exam_type = 'other';

        global $wpdb;

        /* Verify class belongs to school */
        $class = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d",
            $class_id, $school_id
        ));
        if (!$class) wp_send_json_error('Class not found.');

        /* Check duplicate */
        $exists = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . NAIS_Database::table('student_results') .
            " WHERE school_id = %d AND class_id = %d AND exam_name = %s AND status = 'active'",
            $school_id, $class_id, $exam_name
        ));
        if ($exists > 0) wp_send_json_error('An exam with this name already exists for this class.');

        /* Insert a placeholder row so the exam is visible in get_exams even before docs are uploaded */
        $wpdb->insert(NAIS_Database::table('student_results'), [
            'school_id'   => $school_id,
            'class_id'    => $class_id,
            'student_id'  => 0,
            'exam_name'   => $exam_name,
            'exam_type'   => $exam_type,
            'file_url'    => '',
            'file_name'   => '',
            'uploaded_by'  => get_current_user_id(),
            'created_at'  => current_time('mysql'),
            'status'      => 'active',
        ]);

        NAIS_Database::audit_log('exam_created', 'class', $class_id, $school_id, $exam_name . ' (' . $exam_type . ')');

        wp_send_json_success([
            'message'   => 'Exam "' . $exam_name . '" created for ' . $class->class_name . ' ' . $class->section . '. Now upload result documents for each student.',
            'exam_name' => $exam_name,
            'exam_type' => $exam_type,
            'class_id'  => $class_id,
            'class'     => $class->class_name . ' ' . $class->section,
        ]);
    }

    /** Get exams list */
    public static function ajax_get_exams() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $class_id  = absint($_POST['class_id'] ?? 0);

        if (!$school_id) wp_send_json_error('No school.');

        $where = "r.school_id = %d AND r.status = 'active'";
        $params = [$school_id];

        if ($class_id) {
            $where .= " AND r.class_id = %d";
            $params[] = $class_id;
        }

        $exams = $wpdb->get_results($wpdb->prepare(
            "SELECT r.exam_name, r.exam_type, r.class_id,
                    c.class_name, c.section,
                    SUM(CASE WHEN r.student_id > 0 THEN 1 ELSE 0 END) AS docs_uploaded,
                    MAX(r.created_at) AS last_upload
             FROM " . NAIS_Database::table('student_results') . " r
             JOIN " . NAIS_Database::table('classes') . " c ON r.class_id = c.id
             WHERE $where
             GROUP BY r.exam_name, r.exam_type, r.class_id, c.class_name, c.section
             ORDER BY last_upload DESC",
            ...$params
        ));

        /* Get total students per class for context */
        $class_counts = [];
        foreach ($exams as $e) {
            if (!isset($class_counts[$e->class_id])) {
                $class_counts[$e->class_id] = (int)$wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM " . NAIS_Database::table('students') .
                    " WHERE class_id = %d AND status = 'active'",
                    $e->class_id
                ));
            }
        }

        $list = [];
        foreach ($exams as $e) {
            $list[] = [
                'exam_name'     => $e->exam_name,
                'exam_type'     => $e->exam_type,
                'class_id'      => (int)$e->class_id,
                'class_name'    => $e->class_name,
                'section'       => $e->section,
                'docs_uploaded' => (int)$e->docs_uploaded,
                'total_students'=> $class_counts[$e->class_id] ?? 0,
                'last_upload'   => $e->last_upload,
            ];
        }

        wp_send_json_success(['exams' => $list]);
    }

    /** Delete/Archive exam */
    public static function ajax_delete_exam() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $exam_name = sanitize_text_field($_POST['exam_name'] ?? '');
        $class_id  = absint($_POST['class_id'] ?? 0);

        if (!$exam_name || !$class_id) wp_send_json_error('Missing data.');

        $wpdb->update(
            NAIS_Database::table('student_results'),
            ['status' => 'archived'],
            ['school_id' => $school_id, 'class_id' => $class_id, 'exam_name' => $exam_name],
            ['%s'],
            ['%d', '%d', '%s']
        );

        NAIS_Database::audit_log('exam_archived', 'class', $class_id, $school_id, $exam_name);
        wp_send_json_success(['message' => 'Exam archived.']);
    }

    /** Get students for result upload */
    public static function ajax_get_exam_students() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $class_id  = absint($_POST['class_id'] ?? 0);
        $exam_name = sanitize_text_field($_POST['exam_name'] ?? '');

        if (!$class_id || !$exam_name) wp_send_json_error('Missing data.');

        $students = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name, roll_no FROM " . NAIS_Database::table('students') .
            " WHERE class_id = %d AND school_id = %d AND status = 'active'
              ORDER BY roll_no ASC, name ASC",
            $class_id, $school_id
        ));

        /* Get existing uploads */
        $uploads = [];
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, student_id, file_url, file_name FROM " . NAIS_Database::table('student_results') .
            " WHERE school_id = %d AND class_id = %d AND exam_name = %s AND student_id > 0 AND status = 'active'",
            $school_id, $class_id, $exam_name
        ));
        foreach ($rows as $row) {
            $uploads[$row->student_id] = [
                'result_id' => (int)$row->id,
                'file_url'  => $row->file_url,
                'file_name' => $row->file_name,
            ];
        }

        $list = [];
        foreach ($students as $s) {
            $list[] = [
                'id'       => (int)$s->id,
                'name'     => $s->name,
                'roll_no'  => $s->roll_no,
                'uploaded' => isset($uploads[$s->id]),
                'file_url' => $uploads[$s->id]['file_url'] ?? '',
                'file_name'=> $uploads[$s->id]['file_name'] ?? '',
                'result_id'=> $uploads[$s->id]['result_id'] ?? 0,
            ];
        }

        wp_send_json_success(['students' => $list, 'total' => count($list)]);
    }

    /** Upload result document for one student */
    public static function ajax_upload_result_doc() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        $school_id  = NAIS_Roles::get_user_school_id();
        $student_id = absint($_POST['student_id'] ?? 0);
        $class_id   = absint($_POST['class_id'] ?? 0);
        $exam_name  = sanitize_text_field($_POST['exam_name'] ?? '');
        $exam_type  = sanitize_text_field($_POST['exam_type'] ?? 'other');

        if (!$school_id || !$student_id || !$class_id || !$exam_name) wp_send_json_error('Missing data.');

        /* Verify student and class belong to this school */
        global $wpdb;
        $student_ok = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('students') . " WHERE id = %d AND school_id = %d AND class_id = %d",
            $student_id, $school_id, $class_id
        ));
        if (!$student_ok) wp_send_json_error('Student not found in your school.');

        if (empty($_FILES['result_file'])) wp_send_json_error('No file selected.');

        /* Validate file type */
        $allowed = ['pdf','jpg','jpeg','png','gif','webp'];
        $ext = strtolower(pathinfo($_FILES['result_file']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed, true)) wp_send_json_error('Only PDF and image files are allowed.');

        /* Max 10MB */
        if ($_FILES['result_file']['size'] > 10 * 1024 * 1024) wp_send_json_error('File size must be under 10MB.');

        require_once(ABSPATH . 'wp-admin/includes/file.php');
        $upload = wp_handle_upload($_FILES['result_file'], ['test_form' => false]);

        if (isset($upload['error'])) wp_send_json_error('Upload failed: ' . $upload['error']);

        global $wpdb;
        $results_table = NAIS_Database::table('student_results');

        /* Find old result for same student+exam (if exists) — delete AFTER insert succeeds */
        $old_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$results_table} WHERE school_id = %d AND student_id = %d AND class_id = %d AND exam_name = %s",
            $school_id, $student_id, $class_id, $exam_name
        ));

        /* Insert new */
        $inserted = $wpdb->insert($results_table, [
            'school_id'   => $school_id,
            'class_id'    => $class_id,
            'student_id'  => $student_id,
            'exam_name'   => $exam_name,
            'exam_type'   => $exam_type,
            'file_url'    => $upload['url'],
            'file_name'   => sanitize_file_name($_FILES['result_file']['name']),
            'uploaded_by'  => get_current_user_id(),
            'created_at'  => current_time('mysql'),
            'status'      => 'active',
        ]);

        if (!$inserted) {
            wp_send_json_error('Failed to save result record.');
        }

        /* Now safe to remove old results */
        if (!empty($old_ids)) {
            $placeholders = implode(',', array_fill(0, count($old_ids), '%d'));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$results_table} WHERE id IN ({$placeholders})",
                ...$old_ids
            ));
        }

        NAIS_Database::audit_log('result_uploaded', 'student', $student_id, $school_id, $exam_name);

        wp_send_json_success([
            'message'   => 'Result uploaded.',
            'file_url'  => $upload['url'],
            'file_name' => sanitize_file_name($_FILES['result_file']['name']),
            'result_id' => $wpdb->insert_id,
        ]);
    }

    /** Delete result document */
    public static function ajax_delete_result_doc() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $result_id = absint($_POST['result_id'] ?? 0);

        if (!$result_id) wp_send_json_error('Missing data.');

        $wpdb->delete(
            NAIS_Database::table('student_results'),
            ['id' => $result_id, 'school_id' => $school_id],
            ['%d', '%d']
        );

        wp_send_json_success(['message' => 'Result removed.']);
    }

    /** Get dues list for a class */
    public static function ajax_get_dues_list() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $class_id  = absint($_POST['class_id'] ?? 0);

        if (!$class_id) wp_send_json_error('Select a class.');

        $students = $wpdb->get_results($wpdb->prepare(
            "SELECT s.id, s.name, s.roll_no,
                    d.has_dues, d.amount AS due_amount, d.reason AS due_reason
             FROM " . NAIS_Database::table('students') . " s
             LEFT JOIN " . NAIS_Database::table('student_dues') . " d ON s.id = d.student_id
             WHERE s.class_id = %d AND s.school_id = %d AND s.status = 'active'
             ORDER BY s.roll_no ASC, s.name ASC",
            $class_id, $school_id
        ));

        $list = [];
        foreach ($students as $s) {
            $list[] = [
                'id'         => (int)$s->id,
                'name'       => $s->name,
                'roll_no'    => $s->roll_no,
                'has_dues'   => (int)($s->has_dues ?? 0),
                'due_amount' => $s->due_amount ?? 0,
                'due_reason' => $s->due_reason ?? '',
            ];
        }

        wp_send_json_success(['students' => $list]);
    }

    /** Save dues */
    public static function ajax_save_dues() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $dues = json_decode(stripslashes($_POST['dues'] ?? ''), true);

        if (!is_array($dues) || empty($dues)) wp_send_json_error('No data.');

        if (!$school_id) wp_send_json_error('No school.');

        $updated = 0;
        foreach ($dues as $d) {
            $student_id = absint($d['student_id'] ?? 0);
            if (!$student_id) continue;

            /* Verify student belongs to this school */
            $student_school = (int)$wpdb->get_var($wpdb->prepare(
                "SELECT school_id FROM " . NAIS_Database::table('students') . " WHERE id = %d",
                $student_id
            ));
            if ($student_school !== $school_id) continue;

            $has_dues = (int)($d['has_dues'] ?? 0);
            $amount   = floatval($d['amount'] ?? 0);
            $reason   = sanitize_text_field($d['reason'] ?? '');

            /* Check if row exists */
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM " . NAIS_Database::table('student_dues') . " WHERE student_id = %d",
                $student_id
            ));

            if ($exists) {
                $wpdb->update(
                    NAIS_Database::table('student_dues'),
                    ['has_dues' => $has_dues, 'amount' => $amount, 'reason' => $reason, 'updated_by' => get_current_user_id(), 'updated_at' => current_time('mysql')],
                    ['student_id' => $student_id],
                    ['%d', '%f', '%s', '%d', '%s'],
                    ['%d']
                );
            } else {
                $wpdb->insert(NAIS_Database::table('student_dues'), [
                    'student_id' => $student_id,
                    'school_id'  => $school_id,
                    'has_dues'   => $has_dues,
                    'amount'     => $amount,
                    'reason'     => $reason,
                    'updated_by' => get_current_user_id(),
                    'updated_at' => current_time('mysql'),
                ]);
            }
            $updated++;
        }

        NAIS_Database::audit_log('dues_updated', 'school', $school_id, $school_id, $updated . ' students updated');
        wp_send_json_success(['message' => $updated . ' student dues updated.']);
    }

    /** Parent: View result (dues check) */
    public static function ajax_parent_view_result() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!is_user_logged_in()) wp_send_json_error('Please log in.');

        global $wpdb;
        $user_id    = get_current_user_id();
        $student_id = absint($_POST['student_id'] ?? 0);
        $result_id  = absint($_POST['result_id'] ?? 0);

        if (!$student_id || !$result_id) wp_send_json_error('Missing data.');

        /* Verify parent link */
        $linked = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . NAIS_Database::table('parent_links') .
            " WHERE parent_user_id = %d AND student_id = %d AND verified = 1",
            $user_id, $student_id
        ));
        if (!$linked) wp_send_json_error('Access denied.');

        /* Check dues */
        $has_dues = $wpdb->get_var($wpdb->prepare(
            "SELECT has_dues FROM " . NAIS_Database::table('student_dues') .
            " WHERE student_id = %d AND has_dues = 1",
            $student_id
        ));
        if ($has_dues) wp_send_json_error('Results are locked due to unpaid dues. Please contact the school.');

        /* Get result */
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('student_results') .
            " WHERE id = %d AND student_id = %d AND status = 'active'",
            $result_id, $student_id
        ));
        if (!$result) wp_send_json_error('Result not found.');

        wp_send_json_success(['file_url' => $result->file_url, 'file_name' => $result->file_name]);
    }
    /**
     * Create exam results and student dues tables.
     */
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        /* Student results — one row per student per exam (document upload) */
        dbDelta("CREATE TABLE " . NAIS_Database::table('student_results') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            school_id BIGINT UNSIGNED NOT NULL,
            class_id BIGINT UNSIGNED NOT NULL,
            student_id BIGINT UNSIGNED NOT NULL,
            exam_name VARCHAR(255) NOT NULL,
            exam_type VARCHAR(30) NOT NULL DEFAULT 'other',
            file_url VARCHAR(500) NOT NULL,
            file_name VARCHAR(255) NOT NULL DEFAULT '',
            uploaded_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY school_id (school_id),
            KEY class_id (class_id),
            KEY student_id (student_id),
            KEY school_class_exam (school_id, class_id, exam_name),
            KEY status (status)
        ) {$charset};");

        /* Student dues — controls result viewing lock */
        dbDelta("CREATE TABLE " . NAIS_Database::table('student_dues') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id BIGINT UNSIGNED NOT NULL,
            school_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            has_dues TINYINT(1) NOT NULL DEFAULT 0,
            amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            reason VARCHAR(255) NOT NULL DEFAULT '',
            updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY student_id (student_id),
            KEY school_id (school_id),
            KEY has_dues (has_dues)
        ) {$charset};");
    }
}

add_action('init', [NAIS_Exam_Results::class, 'init']);
add_action('plugins_loaded', function() {
    if (get_option('nais_exam_results_tables_version', '0') !== '1.0') {
        NAIS_Exam_Results::create_tables();
        update_option('nais_exam_results_tables_version', '1.0');
    }
});