<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS ADMIN — Platform Admin Dashboard (wp-admin)
 * ═══════════════════════════════════════════════════════════════
 *
 * This is Aloto's view — sees all schools, all data.
 * - Register new schools
 * - Assign school admins
 * - View all-school attendance stats
 * - Audit log viewer
 *
 * SECURITY FIX: Uses add_role() instead of set_role() when
 * assigning school admin — prevents removing administrator role.
 */

if (!defined('ABSPATH')) exit;

class NAIS_Admin {

    /**
     * Register AJAX handlers for school management.
     */
    public static function init() {
        add_action('wp_ajax_nais_deactivate_school', [__CLASS__, 'ajax_deactivate_school']);
        add_action('wp_ajax_nais_reactivate_school', [__CLASS__, 'ajax_reactivate_school']);
        add_action('wp_ajax_nais_hard_delete_school', [__CLASS__, 'ajax_hard_delete_school']);
    }

    /**
     * AJAX: Deactivate a school (soft delete — set status to inactive).
     */
    public static function ajax_deactivate_school() {
        check_ajax_referer('nais_admin_nonce', 'nonce');
        if (!current_user_can('nais_platform_admin')) wp_send_json_error('Unauthorized.');

        $school_id = absint($_POST['school_id'] ?? 0);
        if (!$school_id) wp_send_json_error('Invalid school ID.');

        global $wpdb;
        $school = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('schools') . " WHERE id = %d", $school_id
        ));
        if (!$school) wp_send_json_error('School not found.');
        if ($school->status === 'inactive') wp_send_json_error('School is already inactive.');

        $wpdb->update(NAIS_Database::table('schools'), ['status' => 'inactive'], ['id' => $school_id]);
        NAIS_Database::audit_log('school_deactivated', 'school', $school_id, $school_id, [
            'school_name' => $school->name,
            'previous_status' => $school->status,
        ]);

        wp_send_json_success(['message' => 'School "' . esc_html($school->name) . '" has been deactivated.']);
    }

    /**
     * AJAX: Reactivate a school (set status back to active).
     */
    public static function ajax_reactivate_school() {
        check_ajax_referer('nais_admin_nonce', 'nonce');
        if (!current_user_can('nais_platform_admin')) wp_send_json_error('Unauthorized.');

        $school_id = absint($_POST['school_id'] ?? 0);
        if (!$school_id) wp_send_json_error('Invalid school ID.');

        global $wpdb;
        $school = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('schools') . " WHERE id = %d", $school_id
        ));
        if (!$school) wp_send_json_error('School not found.');
        if ($school->status === 'active') wp_send_json_error('School is already active.');

        $wpdb->update(NAIS_Database::table('schools'), ['status' => 'active'], ['id' => $school_id]);
        NAIS_Database::audit_log('school_reactivated', 'school', $school_id, $school_id, [
            'school_name' => $school->name,
            'previous_status' => $school->status,
        ]);

        wp_send_json_success(['message' => 'School "' . esc_html($school->name) . '" has been reactivated.']);
    }

    /**
     * AJAX: Permanently delete a school and all data (hard delete).
     * Requires school to be inactive first. Requires typing school name for confirmation.
     */
    public static function ajax_hard_delete_school() {
        check_ajax_referer('nais_admin_nonce', 'nonce');
        if (!current_user_can('nais_platform_admin')) wp_send_json_error('Unauthorized.');

        $school_id    = absint($_POST['school_id'] ?? 0);
        $confirm_name = sanitize_text_field($_POST['confirm_name'] ?? '');
        if (!$school_id) wp_send_json_error('Invalid school ID.');

        global $wpdb;
        $school = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('schools') . " WHERE id = %d", $school_id
        ));
        if (!$school) wp_send_json_error('School not found.');

        /* Safety: must be inactive first */
        if ($school->status !== 'inactive') {
            wp_send_json_error('School must be deactivated before permanent deletion. Deactivate it first.');
        }

        /* Safety: must type school name exactly */
        if (strtolower(trim($confirm_name)) !== strtolower(trim($school->name))) {
            wp_send_json_error('School name does not match. Please type the exact school name to confirm deletion.');
        }

        /* Perform cascading delete */
        $counts = NAIS_Database::delete_school_cascade($school_id);
        if ($counts === false) {
            wp_send_json_error('Deletion failed. Please try again.');
        }

        wp_send_json_success([
            'message' => 'School "' . esc_html($school->name) . '" and all its data have been permanently deleted.',
            'deleted' => $counts,
        ]);
    }

    /**
     * Register wp-admin menus.
     */
    public static function register_menus() {
        add_menu_page(
            'Nagaland AI Schools',
            'AI Schools',
            'nais_platform_admin',
            'nagaland-schools',
            [__CLASS__, 'page_dashboard'],
            'dashicons-welcome-learn-more',
            3
        );

        add_submenu_page(
            'nagaland-schools',
            'All Schools',
            'All Schools',
            'nais_platform_admin',
            'nagaland-schools',
            [__CLASS__, 'page_dashboard']
        );

        add_submenu_page(
            'nagaland-schools',
            'Add School',
            'Add School',
            'nais_platform_admin',
            'nais-add-school',
            [__CLASS__, 'page_add_school']
        );

        add_submenu_page(
            'nagaland-schools',
            'Audit Log',
            'Audit Log',
            'nais_platform_admin',
            'nais-audit-log',
            [__CLASS__, 'page_audit_log']
        );

        add_submenu_page(
            'nagaland-schools',
            'Settings',
            'Settings',
            'nais_platform_admin',
            'nais-settings',
            [__CLASS__, 'page_settings']
        );

        /* ─── AUDITOR MENU (read-only, separate from admin) ─── */
        add_menu_page(
            'School Audit',
            'School Audit',
            'nais_audit_access',
            'nais-auditor',
            [__CLASS__, 'page_auditor_dashboard'],
            'dashicons-visibility',
            4
        );

        add_submenu_page(
            'nais-auditor',
            'Audit Dashboard',
            'Dashboard',
            'nais_audit_access',
            'nais-auditor',
            [__CLASS__, 'page_auditor_dashboard']
        );

        add_submenu_page(
            'nais-auditor',
            'Audit Log',
            'Audit Log',
            'nais_audit_access',
            'nais-auditor-log',
            [__CLASS__, 'page_audit_log']
        );
    }

    /**
     * Dashboard — all schools list with stats.
     */
    public static function page_dashboard() {
        global $wpdb;

        $schools = $wpdb->get_results(
            "SELECT s.*,
                    (SELECT COUNT(*) FROM " . NAIS_Database::table('students') . " st WHERE st.school_id = s.id AND st.status = 'active') AS student_count,
                    (SELECT COUNT(*) FROM " . NAIS_Database::table('teachers') . " t WHERE t.school_id = s.id AND t.status = 'active') AS teacher_count,
                    (SELECT COUNT(*) FROM " . NAIS_Database::table('classes') . " c WHERE c.school_id = s.id AND c.status = 'active') AS class_count
             FROM " . NAIS_Database::table('schools') . " s
             ORDER BY s.name ASC"
        );

        $active_count   = 0;
        $inactive_count = 0;
        $pending_count  = 0;
        foreach ($schools as $s) {
            if ($s->status === 'active') $active_count++;
            elseif ($s->status === 'inactive') $inactive_count++;
            elseif ($s->status === 'pending') $pending_count++;
        }

        ?>
        <div class="wrap">
            <h1>Nagaland AI Schools — Platform Dashboard</h1>
            <div class="nais-dash-stats" style="display:flex;gap:16px;margin:16px 0;">
                <span style="background:#ecfdf5;padding:8px 16px;border-radius:8px;font-weight:600;">Total: <strong><?php echo count($schools); ?></strong></span>
                <span style="background:#ecfdf5;color:#059669;padding:8px 16px;border-radius:8px;">Active: <strong><?php echo $active_count; ?></strong></span>
                <?php if ($inactive_count): ?><span style="background:#fef2f2;color:#dc2626;padding:8px 16px;border-radius:8px;">Inactive: <strong><?php echo $inactive_count; ?></strong></span><?php endif; ?>
                <?php if ($pending_count): ?><span style="background:#fefce8;color:#ca8a04;padding:8px 16px;border-radius:8px;">Pending: <strong><?php echo $pending_count; ?></strong></span><?php endif; ?>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>School</th>
                        <th>District</th>
                        <th>UDISE Code</th>
                        <th>Board</th>
                        <th>Students</th>
                        <th>Teachers</th>
                        <th>Classes</th>
                        <th>Status</th>
                        <th>Admin</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($schools)): ?>
                        <tr><td colspan="10">No schools registered yet. <a href="<?php echo admin_url('admin.php?page=nais-add-school'); ?>">Add your first school</a></td></tr>
                    <?php else: ?>
                        <?php foreach ($schools as $school): ?>
                            <?php $admin_user = $school->admin_user_id ? get_userdata($school->admin_user_id) : null; ?>
                            <tr<?php echo $school->status === 'inactive' ? ' style="opacity:0.6;"' : ''; ?>>
                                <td><strong><?php echo esc_html($school->name); ?></strong></td>
                                <td><?php echo esc_html($school->district); ?></td>
                                <td><code><?php echo esc_html($school->udise_code ?: '—'); ?></code></td>
                                <td><?php echo esc_html($school->board); ?></td>
                                <td><?php echo (int)$school->student_count; ?></td>
                                <td><?php echo (int)$school->teacher_count; ?></td>
                                <td><?php echo (int)$school->class_count; ?></td>
                                <td>
                                    <?php if ($school->status === 'active'): ?>
                                        <span class="nais-badge nais-badge-active">Active</span>
                                    <?php elseif ($school->status === 'inactive'): ?>
                                        <span class="nais-badge nais-badge-inactive">Inactive</span>
                                    <?php elseif ($school->status === 'pending'): ?>
                                        <span class="nais-badge nais-badge-pending">Pending</span>
                                    <?php else: ?>
                                        <span class="nais-badge"><?php echo esc_html($school->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $admin_user ? esc_html($admin_user->display_name) : '—'; ?></td>
                                <td class="nais-actions-cell">
                                    <a href="<?php echo admin_url('admin.php?page=nais-add-school&edit=' . $school->id); ?>" class="button button-small">Edit</a>

                                    <?php if ($school->status === 'active'): ?>
                                        <button type="button" class="button button-small nais-btn-deactivate"
                                                data-school-id="<?php echo $school->id; ?>"
                                                data-school-name="<?php echo esc_attr($school->name); ?>">
                                            Deactivate
                                        </button>
                                    <?php elseif ($school->status === 'inactive'): ?>
                                        <button type="button" class="button button-small button-primary nais-btn-reactivate"
                                                data-school-id="<?php echo $school->id; ?>"
                                                data-school-name="<?php echo esc_attr($school->name); ?>">
                                            Reactivate
                                        </button>
                                        <button type="button" class="button button-small nais-btn-hard-delete"
                                                data-school-id="<?php echo $school->id; ?>"
                                                data-school-name="<?php echo esc_attr($school->name); ?>"
                                                data-student-count="<?php echo (int)$school->student_count; ?>"
                                                data-teacher-count="<?php echo (int)$school->teacher_count; ?>">
                                            Delete Permanently
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Hard Delete Confirmation Modal -->
        <div id="nais-delete-modal" class="nais-modal-overlay" style="display:none;">
            <div class="nais-modal">
                <div class="nais-modal-header">
                    <h2>Permanently Delete School</h2>
                    <button type="button" class="nais-modal-close">&times;</button>
                </div>
                <div class="nais-modal-body">
                    <div class="nais-modal-warning">
                        <strong>WARNING: This action is IRREVERSIBLE!</strong>
                        <p>You are about to permanently delete <strong id="nais-delete-school-name"></strong> and ALL associated data:</p>
                        <ul>
                            <li>All students and parent codes</li>
                            <li>All teachers and class assignments</li>
                            <li>All attendance records (daily + period)</li>
                            <li>All homework, exam results, and timetables</li>
                            <li>All bus tracking data</li>
                            <li>All payment records and holidays</li>
                            <li>All audit logs for this school</li>
                        </ul>
                        <p id="nais-delete-data-summary" style="margin-top:10px;font-weight:600;"></p>
                    </div>
                    <div style="margin-top:20px;">
                        <label for="nais-confirm-school-name" style="font-weight:600;display:block;margin-bottom:6px;">
                            Type the school name exactly to confirm:
                        </label>
                        <input type="text" id="nais-confirm-school-name" class="regular-text" style="width:100%;" autocomplete="off" placeholder="Type school name here...">
                        <input type="hidden" id="nais-delete-school-id" value="">
                        <input type="hidden" id="nais-delete-school-expected" value="">
                    </div>
                </div>
                <div class="nais-modal-footer">
                    <button type="button" class="button nais-modal-cancel">Cancel</button>
                    <button type="button" class="button nais-btn-confirm-delete" id="nais-confirm-delete-btn" disabled>
                        Delete Permanently
                    </button>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Add/Edit School page.
     */
    public static function page_add_school() {
        global $wpdb;

        $editing = false;
        $school  = null;

        if (isset($_GET['edit'])) {
            $school_id = absint($_GET['edit']);
            $school = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . NAIS_Database::table('schools') . " WHERE id = %d",
                $school_id
            ));
            if ($school) $editing = true;
        }

        /* Handle form submission */
        if (isset($_POST['nais_save_school']) && wp_verify_nonce($_POST['_nais_nonce'], 'nais_save_school')) {
            $data = [
                'name'          => sanitize_text_field($_POST['school_name']),
                'district'      => sanitize_text_field($_POST['district']),
                'block'         => sanitize_text_field($_POST['block']),
                'village_town'  => sanitize_text_field($_POST['village_town']),
                'pin_code'      => sanitize_text_field($_POST['pin_code']),
                'udise_code'    => sanitize_text_field($_POST['udise_code']),
                'board'         => sanitize_text_field($_POST['board']),
                'phone'         => sanitize_text_field($_POST['phone']),
                'email'         => sanitize_email($_POST['email']),
                'address'       => sanitize_textarea_field($_POST['address']),
                'admin_user_id' => absint($_POST['admin_user_id']),
                'status'        => sanitize_text_field($_POST['status']),
            ];

            if ($editing) {
                /* Handle admin role change on edit */
                $old_admin_id = (int)$school->admin_user_id;
                $new_admin_id = (int)$data['admin_user_id'];
                if ($old_admin_id !== $new_admin_id) {
                    if ($old_admin_id) {
                        /* Only remove role if this user isn't admin of another school */
                        $other_schools = $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM " . NAIS_Database::table('schools') . " WHERE admin_user_id = %d AND id != %d AND status IN ('active','trial','grace')",
                            $old_admin_id, $school->id
                        ));
                        if (!$other_schools) {
                            $old_user = get_user_by('id', $old_admin_id);
                            if ($old_user) { $old_user->remove_role(NAIS_Roles::SCHOOL_ADMIN); }
                        }
                    }
                    if ($new_admin_id) {
                        $new_user = get_user_by('id', $new_admin_id);
                        if ($new_user) { $new_user->add_role(NAIS_Roles::SCHOOL_ADMIN); }
                    }
                }

                $wpdb->update(NAIS_Database::table('schools'), $data, ['id' => $school->id]);
                NAIS_Database::audit_log('school_updated', 'school', $school->id, $school->id, $data);
                echo '<div class="notice notice-success"><p>School updated.</p></div>';
                $school = (object)array_merge((array)$school, $data);
            } else {
                $result = $wpdb->insert(NAIS_Database::table('schools'), $data);

                if ($result === false) {
                    echo '<div class="notice notice-error"><p>Failed to create school. Database error: ' . esc_html($wpdb->last_error) . '</p></div>';
                } else {
                    $new_id = $wpdb->insert_id;
                    NAIS_Database::audit_log('school_created', 'school', $new_id, $new_id, $data);

                    /*
                     * SECURITY FIX: Use add_role() not set_role().
                     * set_role() REPLACES all existing roles — this caused
                     * the admin lockout bug where administrators lost their role.
                     * add_role() ADDS the school admin role while keeping existing roles.
                     */
                    if ($data['admin_user_id']) {
                        $user = get_user_by('id', $data['admin_user_id']);
                        if ($user) {
                            $user->add_role(NAIS_Roles::SCHOOL_ADMIN);
                        }
                    }

                    /* Grant free trial to new school */
                    NAIS_Payment::grant_free_trial($new_id);

                    echo '<div class="notice notice-success"><p>School created! 6-month free trial activated. <a href="' . admin_url('admin.php?page=nagaland-schools') . '">View all schools</a></p></div>';
                }
            }
        }

        /* Get available users for admin dropdown */
        $users = get_users(['role__not_in' => ['subscriber'], 'number' => 100]);

        /* Nagaland districts */
        $districts = ['Chumoukedima', 'Dimapur', 'Kiphire', 'Kohima', 'Longleng', 'Mokokchung', 'Mon', 'Niuland', 'Noklak', 'Peren', 'Phek', 'Shamator', 'Tseminyü', 'Tuensang', 'Wokha', 'Zunheboto'];

        ?>
        <div class="wrap">
            <h1><?php echo $editing ? 'Edit School' : 'Add New School'; ?></h1>

            <form method="post">
                <?php wp_nonce_field('nais_save_school', '_nais_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th>School Name *</th>
                        <td><input type="text" name="school_name" value="<?php echo esc_attr($school->name ?? ''); ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th>District *</th>
                        <td>
                            <select name="district" required>
                                <option value="">Select District</option>
                                <?php foreach ($districts as $d): ?>
                                    <option value="<?php echo esc_attr($d); ?>" <?php selected(($school->district ?? ''), $d); ?>><?php echo esc_html($d); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Block</th>
                        <td><input type="text" name="block" value="<?php echo esc_attr($school->block ?? ''); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Village/Town</th>
                        <td><input type="text" name="village_town" value="<?php echo esc_attr($school->village_town ?? ''); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>PIN Code</th>
                        <td><input type="text" name="pin_code" value="<?php echo esc_attr($school->pin_code ?? ''); ?>" maxlength="6" class="small-text"></td>
                    </tr>
                    <tr>
                        <th>UDISE Code</th>
                        <td><input type="text" name="udise_code" value="<?php echo esc_attr($school->udise_code ?? ''); ?>" class="regular-text" placeholder="Optional — government school ID"><p class="description">Optional. Only government-recognized schools have this. Leave blank for private/unaffiliated schools.</p></td>
                    </tr>
                    <tr>
                        <th>Board</th>
                        <td>
                            <select name="board">
                                <option value="NBSE" <?php selected(($school->board ?? 'NBSE'), 'NBSE'); ?>>NBSE (Nagaland Board)</option>
                                <option value="CBSE" <?php selected(($school->board ?? ''), 'CBSE'); ?>>CBSE</option>
                                <option value="ICSE" <?php selected(($school->board ?? ''), 'ICSE'); ?>>ICSE</option>
                                <option value="Private" <?php selected(($school->board ?? ''), 'Private'); ?>>Private (Unaffiliated)</option>
                                <option value="Missionary" <?php selected(($school->board ?? ''), 'Missionary'); ?>>Missionary / Church School</option>
                                <option value="State" <?php selected(($school->board ?? ''), 'State'); ?>>State Government</option>
                                <option value="Other" <?php selected(($school->board ?? ''), 'Other'); ?>>Other</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Phone</th>
                        <td><input type="text" name="phone" value="<?php echo esc_attr($school->phone ?? ''); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><input type="email" name="email" value="<?php echo esc_attr($school->email ?? ''); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Address</th>
                        <td><textarea name="address" rows="3" class="large-text"><?php echo esc_textarea($school->address ?? ''); ?></textarea></td>
                    </tr>
                    <tr>
                        <th>School Admin</th>
                        <td>
                            <select name="admin_user_id">
                                <option value="0">— No admin assigned —</option>
                                <?php foreach ($users as $u): ?>
                                    <option value="<?php echo $u->ID; ?>" <?php selected(($school->admin_user_id ?? 0), $u->ID); ?>>
                                        <?php echo esc_html($u->display_name . ' (' . $u->user_email . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">This user will receive the School Admin role (existing roles are preserved).</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td>
                            <select name="status">
                                <option value="active" <?php selected(($school->status ?? 'active'), 'active'); ?>>Active</option>
                                <option value="inactive" <?php selected(($school->status ?? ''), 'inactive'); ?>>Inactive</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" name="nais_save_school" class="button-primary" value="<?php echo $editing ? 'Update School' : 'Create School'; ?>">
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * Audit log viewer.
     */
    public static function page_audit_log() {
        global $wpdb;

        $page    = max(1, absint($_GET['paged'] ?? 1));
        $per_page = 50;
        $offset  = ($page - 1) * $per_page;

        $total = $wpdb->get_var("SELECT COUNT(*) FROM " . NAIS_Database::table('audit_log'));

        $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT l.*, u.display_name AS user_name
             FROM " . NAIS_Database::table('audit_log') . " l
             LEFT JOIN {$wpdb->users} u ON l.user_id = u.ID
             ORDER BY l.created_at DESC
             LIMIT %d OFFSET %d",
            $per_page, $offset
        ));

        ?>
        <div class="wrap">
            <h1>Audit Log</h1>
            <p>Total entries: <strong><?php echo (int)$total; ?></strong></p>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Entity</th>
                        <th>School ID</th>
                        <th>IP</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html($log->created_at); ?></td>
                            <td><?php echo esc_html($log->user_name ?: 'System'); ?></td>
                            <td><code><?php echo esc_html($log->action); ?></code></td>
                            <td><?php echo esc_html($log->entity_type . ':' . $log->entity_id); ?></td>
                            <td><?php echo (int)$log->school_id; ?></td>
                            <td><?php echo esc_html($log->ip_address); ?></td>
                            <td><small><?php echo esc_html(mb_substr($log->details, 0, 100)); ?></small></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php
            $total_pages = ceil($total / $per_page);
            if ($total_pages > 1) {
                echo '<div class="tablenav"><div class="tablenav-pages">';
                echo paginate_links([
                    'base'    => add_query_arg('paged', '%#%'),
                    'total'   => $total_pages,
                    'current' => $page,
                ]);
                echo '</div></div>';
            }
            ?>
        </div>
        <?php
    }

    /**
     * Settings page.
     */
    public static function page_settings() {
        if (isset($_POST['nais_save_settings']) && wp_verify_nonce($_POST['_nais_nonce'], 'nais_settings')) {
            update_option('nais_academic_year', sanitize_text_field($_POST['academic_year']));
            update_option('nais_periods_per_day', absint($_POST['periods_per_day']));
            update_option('nais_school_start_time', sanitize_text_field($_POST['school_start_time']));
            echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
        }

        $academic_year    = get_option('nais_academic_year', NAIS_ACADEMIC_YEAR);
        $periods_per_day  = get_option('nais_periods_per_day', 6);
        $school_start     = get_option('nais_school_start_time', '08:00');

        ?>
        <div class="wrap">
            <h1>NAIS Settings</h1>
            <form method="post">
                <?php wp_nonce_field('nais_settings', '_nais_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th>Academic Year</th>
                        <td><input type="text" name="academic_year" value="<?php echo esc_attr($academic_year); ?>" placeholder="2026-2027" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Periods Per Day</th>
                        <td><input type="number" name="periods_per_day" value="<?php echo (int)$periods_per_day; ?>" min="1" max="12" class="small-text"></td>
                    </tr>
                    <tr>
                        <th>School Start Time</th>
                        <td><input type="time" name="school_start_time" value="<?php echo esc_attr($school_start); ?>"></td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" name="nais_save_settings" class="button-primary" value="Save Settings">
                </p>
            </form>

            <hr>
            <h2>API Key</h2>
            <p>Use this key in <code>nai_school.php</code> on nagalandai.com:</p>
            <code style="font-size:16px;padding:8px;background:#f0f0f0;display:block;margin:8px 0;"><?php echo esc_html(NAIS_API_KEY); ?></code>
            <p class="description">Change this in <code>nagaland-ai-schools.php</code> → <code>NAIS_API_KEY</code> constant.</p>
        </div>
        <?php
    }


    /**
     * ═══════════════════════════════════════════
     * AUDITOR DASHBOARD — READ-ONLY
     * For government inspectors / auditors.
     * Shows all data but NO edit/add/delete buttons.
     * ═══════════════════════════════════════════
     */
    public static function page_auditor_dashboard() {
        global $wpdb;

        $total_schools  = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . NAIS_Database::table('schools') . " WHERE status = 'active'");
        $total_students = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . NAIS_Database::table('students') . " WHERE status = 'active'");
        $total_teachers = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . NAIS_Database::table('teachers') . " WHERE status = 'active'");
        $total_classes  = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . NAIS_Database::table('classes') . " WHERE status = 'active'");
        $total_att_today = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . NAIS_Database::table('attendance_daily') . " WHERE att_date = %s",
            current_time('Y-m-d')
        ));
        $total_audit_entries = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . NAIS_Database::table('audit_log'));

        $schools = $wpdb->get_results(
            "SELECT s.*,
                    (SELECT COUNT(*) FROM " . NAIS_Database::table('students') . " st WHERE st.school_id = s.id AND st.status = 'active') AS student_count,
                    (SELECT COUNT(*) FROM " . NAIS_Database::table('teachers') . " t WHERE t.school_id = s.id AND t.status = 'active') AS teacher_count,
                    (SELECT COUNT(*) FROM " . NAIS_Database::table('classes') . " c WHERE c.school_id = s.id AND c.status = 'active') AS class_count
             FROM " . NAIS_Database::table('schools') . " s WHERE s.status = 'active'
             ORDER BY s.name ASC"
        );

        ?>
        <div class="wrap">
            <h1>Nagaland AI Schools — Audit Dashboard</h1>
            <p style="color:#666;font-size:14px;">Read-only access. This account cannot modify any data.</p>

            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:20px 0;">
                <div style="background:#ecfdf5;padding:20px;border-radius:10px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#059669;"><?php echo $total_schools; ?></div>
                    <div style="color:#666;">Active Schools</div>
                </div>
                <div style="background:#eff6ff;padding:20px;border-radius:10px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#2563eb;"><?php echo $total_students; ?></div>
                    <div style="color:#666;">Total Students</div>
                </div>
                <div style="background:#fefce8;padding:20px;border-radius:10px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#ca8a04;"><?php echo $total_teachers; ?></div>
                    <div style="color:#666;">Total Teachers</div>
                </div>
                <div style="background:#f0fdf4;padding:20px;border-radius:10px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#16a34a;"><?php echo $total_att_today; ?></div>
                    <div style="color:#666;">Attendance Records Today</div>
                </div>
                <div style="background:#fdf4ff;padding:20px;border-radius:10px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#a855f7;"><?php echo $total_classes; ?></div>
                    <div style="color:#666;">Total Classes</div>
                </div>
                <div style="background:#fff7ed;padding:20px;border-radius:10px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#ea580c;"><?php echo number_format($total_audit_entries); ?></div>
                    <div style="color:#666;">Audit Log Entries</div>
                </div>
            </div>

            <h2>Registered Schools</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>School Name</th>
                        <th>District</th>
                        <th>UDISE Code</th>
                        <th>Board</th>
                        <th>Students</th>
                        <th>Teachers</th>
                        <th>Classes</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($schools)): ?>
                        <tr><td colspan="8">No schools registered.</td></tr>
                    <?php else: ?>
                        <?php foreach ($schools as $school): ?>
                            <tr>
                                <td><strong><?php echo esc_html($school->name); ?></strong></td>
                                <td><?php echo esc_html($school->district); ?></td>
                                <td><code><?php echo esc_html($school->udise_code ?: '—'); ?></code></td>
                                <td><?php echo esc_html($school->board); ?></td>
                                <td><?php echo (int)$school->student_count; ?></td>
                                <td><?php echo (int)$school->teacher_count; ?></td>
                                <td><?php echo (int)$school->class_count; ?></td>
                                <td><?php echo esc_html($school->status); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <h2 style="margin-top:30px;">Security & Compliance Summary</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Security Measure</th><th>Status</th></tr></thead>
                <tbody>
                    <tr><td>HTTPS/TLS Encryption</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>Search Engine Blocking (noindex)</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>robots.txt (Disallow All)</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>Role-Based Access Control (4 roles)</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>School Data Isolation</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>SQL Injection Protection (Parameterized Queries)</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>XSS Protection (Output Escaping)</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>CSRF Protection (Nonce Verification)</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>Brute Force Protection (IP Lockout)</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>Audit Trail Logging</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span> (<?php echo number_format($total_audit_entries); ?> entries)</td></tr>
                    <tr><td>API Authentication (Shared Secret Key)</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>DPDP Act 2023 Compliance</td><td><span style="color:#059669;font-weight:700;">COMPLIANT</span></td></tr>
                    <tr><td>Parent Data Deletion Feature</td><td><span style="color:#059669;font-weight:700;">ACTIVE</span></td></tr>
                    <tr><td>Data Location</td><td>India (Hostinger India Servers)</td></tr>
                    <tr><td>Auto Audit Log Cleanup</td><td>Weekly (retains 12 months)</td></tr>
                </tbody>
            </table>

            <p style="margin-top:20px;color:#666;font-size:13px;">
                This dashboard provides read-only access for auditing purposes. To view detailed audit logs, click "Audit Log" in the menu.
                For questions, contact: <strong>info@nagaland.me</strong> | WhatsApp: <strong>+91 63833 59495</strong>
            </p>
        </div>
        <?php
    }


    /**
     * Frontend dashboard shortcode — routes by role.
     * Checks multiple roles since users can have administrator + school_admin.
     */
    public static function dashboard_shortcode() {
        if (!is_user_logged_in()) {
            return '<div class="nais-login-prompt"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">Welcome to Nagaland AI Schools</h2><p>Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to access your dashboard.</p></div>';
        }

        $user = wp_get_current_user();
        $roles = (array)$user->roles;

        /* School Admin gets school dashboard (even if also administrator) */
        if (in_array(NAIS_Roles::SCHOOL_ADMIN, $roles, true)) {
            return NAIS_School_Admin::manage_school_shortcode();
        }

        /* Teacher gets attendance marking */
        if (in_array(NAIS_Roles::TEACHER, $roles, true)) {
            return NAIS_Teacher::mark_attendance_shortcode();
        }

        /* Parent gets child view */
        if (in_array(NAIS_Roles::PARENT, $roles, true)) {
            return NAIS_Parent::my_child_shortcode();
        }

        /* Platform admin or administrator — link to wp-admin */
        if (in_array('administrator', $roles, true) || current_user_can('nais_platform_admin')) {
            return '<div class="nais-msg"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">Platform Admin</h2><p>Manage all schools from the <a href="' . admin_url('admin.php?page=nagaland-schools') . '">admin dashboard</a>.</p></div>';
        }

        return '<div class="nais-msg"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">No School Role</h2><p>Your account does not have a school role assigned yet. Please contact your school administrator or WhatsApp us at +91 63833 59495.</p></div>';
    }
}