<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS SCHOOL REGISTRATION — Self-Registration (Approval-Based)
 * ═══════════════════════════════════════════════════════════════
 *
 * Schools apply via [nais_school_register] shortcode.
 * School status starts as "pending".
 * Aloto reviews in wp-admin → AI Schools → Pending Schools.
 * Once approved, school admin gets email with login.
 * Free trial starts from approval date.
 *
 * Page: /register-school/ → [nais_school_register]
 */

if (!defined('ABSPATH')) exit;

class NAIS_School_Register {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('wp_ajax_nais_approve_school', [__CLASS__, 'ajax_approve_school']);
        add_action('wp_ajax_nais_reject_school', [__CLASS__, 'ajax_reject_school']);
    }

    /**
     * Admin submenu — Pending Schools.
     */
    public static function admin_menu() {
        add_submenu_page(
            'nagaland-schools',
            'Pending Schools',
            'Pending Schools',
            'nais_platform_admin',
            'nais-pending-schools',
            [__CLASS__, 'page_pending']
        );
    }

    /**
     * Frontend registration form.
     */
    public static function register_shortcode() {
        $success = false;
        $error   = '';

        if (isset($_POST['nais_school_apply']) && wp_verify_nonce($_POST['_nais_nonce'], 'nais_school_apply')) {

            $school_name = sanitize_text_field($_POST['school_name'] ?? '');
            $district    = sanitize_text_field($_POST['district'] ?? '');
            $board       = sanitize_text_field($_POST['board'] ?? 'NBSE');
            $village     = sanitize_text_field($_POST['village_town'] ?? '');
            $pin_code    = sanitize_text_field($_POST['pin_code'] ?? '');
            $udise       = sanitize_text_field($_POST['udise_code'] ?? '');
            $phone       = sanitize_text_field($_POST['phone'] ?? '');
            $email       = sanitize_email($_POST['email'] ?? '');
            $address     = sanitize_textarea_field($_POST['address'] ?? '');
            $admin_name  = sanitize_text_field($_POST['admin_name'] ?? '');
            $admin_email = sanitize_email($_POST['admin_email'] ?? '');
            $admin_phone = sanitize_text_field($_POST['admin_phone'] ?? '');
            $student_count = sanitize_text_field($_POST['student_count'] ?? '');
            $message     = sanitize_textarea_field($_POST['message'] ?? '');

            if (!$school_name || !$district || !$admin_name || !$admin_email) {
                $error = 'Please fill in all required fields: School Name, District, Admin Name, and Admin Email.';
            } else {
                global $wpdb;

                /* Check if school with same name+district already exists */
                $exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM " . NAIS_Database::table('schools') .
                    " WHERE name = %s AND district = %s",
                    $school_name, $district
                ));

                if ($exists) {
                    $error = 'A school with this name already exists in this district. If this is your school, please contact us on WhatsApp: +91 63833 59495.';
                } else {
                    /* Insert school with status = pending */
                    $inserted = $wpdb->insert(NAIS_Database::table('schools'), [
                        'name'         => $school_name,
                        'district'     => $district,
                        'block'        => '',
                        'board'        => $board,
                        'village_town' => $village,
                        'pin_code'     => $pin_code,
                        'udise_code'   => $udise,
                        'phone'        => $phone,
                        'email'        => $email,
                        'address'      => $address ?: '',
                        'admin_user_id'=> 0,
                        'status'       => 'pending',
                        'created_at'   => current_time('mysql'),
                        'updated_at'   => current_time('mysql'),
                    ]);

                    if ($inserted === false) {
                        $error = 'Registration failed due to a database error. Please try again or contact support. Error: ' . esc_html($wpdb->last_error);
                    } else {
                        $school_id = $wpdb->insert_id;

                        /* Store application details as school meta */
                        update_option("nais_school_{$school_id}_app_admin_name", $admin_name);
                        update_option("nais_school_{$school_id}_app_admin_email", $admin_email);
                        update_option("nais_school_{$school_id}_app_admin_phone", $admin_phone);
                        update_option("nais_school_{$school_id}_app_student_count", $student_count);
                        update_option("nais_school_{$school_id}_app_message", $message);
                        update_option("nais_school_{$school_id}_app_date", current_time('mysql'));

                        NAIS_Database::audit_log('school_application', 'school', $school_id, $school_id, [
                            'school_name' => $school_name,
                            'admin_name'  => $admin_name,
                            'admin_email' => $admin_email,
                        ]);

                        /* Notify platform admin */
                        $platform_email = get_option('admin_email');
                        wp_mail(
                            $platform_email,
                            '[NAIS] New School Application — ' . $school_name,
                            sprintf(
                                "New school registration application:\n\nSchool: %s\nDistrict: %s\nBoard: %s\nAdmin: %s (%s)\nPhone: %s\nStudents: %s\nMessage: %s\n\nReview in wp-admin → AI Schools → Pending Schools.",
                                $school_name, $district, $board,
                                $admin_name, $admin_email, $admin_phone,
                                $student_count, $message
                            )
                        );

                        $success = true;
                    }
                }
            }
        }

        /* Nagaland districts */
        $districts = ['Chumoukedima', 'Dimapur', 'Kiphire', 'Kohima', 'Longleng', 'Mokokchung', 'Mon', 'Niuland', 'Noklak', 'Peren', 'Phek', 'Shamator', 'Tseminyü', 'Tuensang', 'Wokha', 'Zunheboto'];

        ob_start();
        ?>
        <div class="nais-parent-register">
            <div class="nais-register-card" style="max-width:560px;">

                <?php if ($success): ?>
                    <h2>Application Submitted!</h2>
                    <div class="nais-alert nais-alert-success">
                        Your school registration has been submitted successfully. Our team will review your application and contact you within 24–48 hours.
                    </div>
                    <p style="text-align:center;color:#6B7280;font-size:14px;margin-top:16px;">
                        Questions? WhatsApp us: <strong>+91 63833 59495</strong>
                    </p>
                <?php else: ?>

                    <h2>Register Your School</h2>
                    <?php
                    $reg_settings = NAIS_Payment::get_payment_settings();
                    $reg_trial_days = max(7, (int)$reg_settings['free_trial_days']);
                    $reg_months = round($reg_trial_days / 30);
                    $reg_trial_label = $reg_trial_days >= 30
                        ? $reg_months . ' ' . ($reg_months > 1 ? 'months' : 'month')
                        : $reg_trial_days . ' ' . ($reg_trial_days > 1 ? 'days' : 'day');
                    ?>
                    <p style="text-align:center;color:#6B7280;font-size:14px;">Fill this form and our team will set up your school within 24–48 hours. <?php echo esc_html($reg_trial_label); ?> free trial included.</p>

                    <?php if ($error): ?>
                        <div class="nais-alert nais-alert-error"><?php echo esc_html($error); ?></div>
                    <?php endif; ?>

                    <form method="post" class="nais-form" style="max-width:100%;">
                        <?php wp_nonce_field('nais_school_apply', '_nais_nonce'); ?>

                        <h3 style="font-size:16px;margin:20px 0 10px;color:#0A7558;">School Details</h3>

                        <div class="nais-form-row">
                            <label>School Name *</label>
                            <input type="text" name="school_name" required value="<?php echo esc_attr($_POST['school_name'] ?? ''); ?>" placeholder="e.g. Holy Cross Higher Secondary School">
                        </div>

                        <div class="nais-form-row">
                            <label>District *</label>
                            <select name="district" required>
                                <option value="">Select District</option>
                                <?php foreach ($districts as $d): ?>
                                    <option value="<?php echo esc_attr($d); ?>" <?php selected(($_POST['district'] ?? ''), $d); ?>><?php echo esc_html($d); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="nais-form-row">
                            <label>Board / Affiliation</label>
                            <select name="board">
                                <option value="NBSE">NBSE (Nagaland Board)</option>
                                <option value="CBSE">CBSE</option>
                                <option value="ICSE">ICSE</option>
                                <option value="Private">Private (Unaffiliated)</option>
                                <option value="Missionary">Missionary / Church School</option>
                                <option value="State">State Government</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div class="nais-form-row">
                            <label>Village / Town</label>
                            <input type="text" name="village_town" value="<?php echo esc_attr($_POST['village_town'] ?? ''); ?>">
                        </div>

                        <div class="nais-form-row">
                            <label>PIN Code</label>
                            <input type="text" name="pin_code" maxlength="6" value="<?php echo esc_attr($_POST['pin_code'] ?? ''); ?>">
                        </div>

                        <div class="nais-form-row">
                            <label>UDISE Code (if any)</label>
                            <input type="text" name="udise_code" value="<?php echo esc_attr($_POST['udise_code'] ?? ''); ?>" placeholder="Optional — government schools only">
                        </div>

                        <div class="nais-form-row">
                            <label>School Phone</label>
                            <input type="tel" name="phone" value="<?php echo esc_attr($_POST['phone'] ?? ''); ?>">
                        </div>

                        <div class="nais-form-row">
                            <label>School Email</label>
                            <input type="email" name="email" value="<?php echo esc_attr($_POST['email'] ?? ''); ?>">
                        </div>

                        <div class="nais-form-row">
                            <label>School Address</label>
                            <textarea name="address" rows="2"><?php echo esc_textarea($_POST['address'] ?? ''); ?></textarea>
                        </div>

                        <div class="nais-form-row">
                            <label>Approximate Number of Students</label>
                            <select name="student_count">
                                <option value="1-50">1–50 students</option>
                                <option value="51-100">51–100 students</option>
                                <option value="101-200">101–200 students</option>
                                <option value="201-500">201–500 students</option>
                                <option value="500+">500+ students</option>
                            </select>
                        </div>

                        <h3 style="font-size:16px;margin:24px 0 10px;color:#0A7558;">Your Details (School Admin)</h3>

                        <div class="nais-form-row">
                            <label>Your Name *</label>
                            <input type="text" name="admin_name" required value="<?php echo esc_attr($_POST['admin_name'] ?? ''); ?>" placeholder="Principal / Administrator name">
                        </div>

                        <div class="nais-form-row">
                            <label>Your Email * (this will be your login)</label>
                            <input type="email" name="admin_email" required value="<?php echo esc_attr($_POST['admin_email'] ?? ''); ?>">
                        </div>

                        <div class="nais-form-row">
                            <label>Your Phone / WhatsApp</label>
                            <input type="tel" name="admin_phone" value="<?php echo esc_attr($_POST['admin_phone'] ?? ''); ?>">
                        </div>

                        <div class="nais-form-row">
                            <label>Message (optional)</label>
                            <textarea name="message" rows="2" placeholder="Any questions or special requirements?"><?php echo esc_textarea($_POST['message'] ?? ''); ?></textarea>
                        </div>

                        <button type="submit" name="nais_school_apply" class="nais-btn nais-btn-primary nais-btn-lg" style="margin-top:12px;">Submit Application</button>

                        <p style="text-align:center;color:#6B7280;font-size:12px;margin-top:16px;">
                            Your information is secure and will only be used to set up your school account.
                        </p>
                    </form>

                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }


    /**
     * Admin page — Pending Schools list with Approve/Reject.
     */
    public static function page_pending() {
        global $wpdb;

        $pending = $wpdb->get_results(
            "SELECT * FROM " . NAIS_Database::table('schools') . " WHERE status = 'pending' ORDER BY created_at DESC"
        );

        ?>
        <div class="wrap">
            <h1>Pending School Applications</h1>
            <p><?php echo count($pending); ?> applications waiting for review.</p>

            <?php if (empty($pending)): ?>
                <p>No pending applications. All caught up!</p>
            <?php else: ?>
                <?php foreach ($pending as $school): ?>
                    <?php
                    $admin_name  = get_option("nais_school_{$school->id}_app_admin_name", '—');
                    $admin_email = get_option("nais_school_{$school->id}_app_admin_email", '—');
                    $admin_phone = get_option("nais_school_{$school->id}_app_admin_phone", '—');
                    $student_count = get_option("nais_school_{$school->id}_app_student_count", '—');
                    $message     = get_option("nais_school_{$school->id}_app_message", '');
                    $app_date    = get_option("nais_school_{$school->id}_app_date", $school->created_at);
                    ?>
                    <div style="background:#fff;border:1px solid #ddd;border-radius:10px;padding:20px;margin:16px 0;">
                        <h3 style="margin:0 0 8px;"><?php echo esc_html($school->name); ?></h3>
                        <table class="form-table" style="margin:0;">
                            <tr><th style="width:150px;">District</th><td><?php echo esc_html($school->district); ?></td></tr>
                            <tr><th>Board</th><td><?php echo esc_html($school->board); ?></td></tr>
                            <tr><th>Village/Town</th><td><?php echo esc_html($school->village_town ?: '—'); ?></td></tr>
                            <tr><th>UDISE Code</th><td><?php echo esc_html($school->udise_code ?: '—'); ?></td></tr>
                            <tr><th>School Phone</th><td><?php echo esc_html($school->phone ?: '—'); ?></td></tr>
                            <tr><th>School Email</th><td><?php echo esc_html($school->email ?: '—'); ?></td></tr>
                            <tr><th>Students</th><td><?php echo esc_html($student_count); ?></td></tr>
                            <tr><th>Admin Name</th><td><strong><?php echo esc_html($admin_name); ?></strong></td></tr>
                            <tr><th>Admin Email</th><td><?php echo esc_html($admin_email); ?></td></tr>
                            <tr><th>Admin Phone</th><td><?php echo esc_html($admin_phone); ?></td></tr>
                            <tr><th>Message</th><td><?php echo esc_html($message ?: '—'); ?></td></tr>
                            <tr><th>Applied</th><td><?php echo esc_html($app_date); ?></td></tr>
                        </table>

                        <div style="margin-top:16px;display:flex;gap:12px;">
                            <form method="post" action="<?php echo admin_url('admin-ajax.php'); ?>" style="display:inline;">
                                <?php wp_nonce_field('nais_approve_school', '_nais_nonce'); ?>
                                <input type="hidden" name="action" value="nais_approve_school">
                                <input type="hidden" name="school_id" value="<?php echo (int)$school->id; ?>">
                                <button type="submit" class="button button-primary button-large">Approve & Activate</button>
                            </form>

                            <form method="post" action="<?php echo admin_url('admin-ajax.php'); ?>" style="display:inline;">
                                <?php wp_nonce_field('nais_reject_school', '_nais_nonce'); ?>
                                <input type="hidden" name="action" value="nais_reject_school">
                                <input type="hidden" name="school_id" value="<?php echo (int)$school->id; ?>">
                                <input type="text" name="reject_reason" placeholder="Reason (optional)" style="padding:6px 10px;">
                                <button type="submit" class="button" style="color:#c00;">Reject</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php
    }


    /**
     * AJAX: Approve school — create admin account, assign role, start trial.
     */
    public static function ajax_approve_school() {
        check_ajax_referer('nais_approve_school', '_nais_nonce');

        if (!current_user_can('nais_platform_admin')) wp_die('Not allowed.');

        global $wpdb;
        $school_id = absint($_POST['school_id'] ?? 0);
        if (!$school_id) wp_die('Invalid school.');

        $school = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('schools') . " WHERE id = %d",
            $school_id
        ));
        if (!$school) wp_die('School not found.');
        if ($school->status !== 'pending') wp_die('This school has already been processed (status: ' . esc_html($school->status) . ').');

        $admin_name  = get_option("nais_school_{$school_id}_app_admin_name", '');
        $admin_email = get_option("nais_school_{$school_id}_app_admin_email", '');

        if (!$admin_email) wp_die('No admin email found for this application.');

        /* Create WP user for school admin */
        $user = get_user_by('email', $admin_email);
        if (!$user) {
            $password = wp_generate_password(10);
            $user_id  = wp_create_user($admin_email, $password, $admin_email);
            if (is_wp_error($user_id)) wp_die('Could not create user: ' . $user_id->get_error_message());

            wp_update_user([
                'ID'           => $user_id,
                'display_name' => $admin_name,
                'first_name'   => $admin_name,
            ]);
            $user = get_user_by('id', $user_id);
        } else {
            $password = '(existing account — use your current password)';
        }

        /* Assign school admin role (add_role preserves existing roles) */
        $user->add_role(NAIS_Roles::SCHOOL_ADMIN);

        /* Update school: status → active, assign admin — use transaction */
        $wpdb->query('START TRANSACTION');

        $updated = $wpdb->update(NAIS_Database::table('schools'), [
            'status'        => 'active',
            'admin_user_id' => $user->ID,
        ], ['id' => $school_id]);

        if ($updated === false) {
            $wpdb->query('ROLLBACK');
            wp_die('Failed to activate school. Database error: ' . esc_html($wpdb->last_error));
        }

        /* Grant free trial */
        NAIS_Payment::grant_free_trial($school_id);

        $wpdb->query('COMMIT');

        NAIS_Database::audit_log('school_approved', 'school', $school_id, $school_id, [
            'admin_user_id' => $user->ID,
            'admin_email'   => $admin_email,
        ]);

        /* Send approval email to school admin */
        $login_url = wp_login_url(home_url('/dashboard/'));
        $trial_settings = NAIS_Payment::get_payment_settings();
        $trial_days = max(7, (int)$trial_settings['free_trial_days']);
        $trial_months = round($trial_days / 30);
        $trial_label = $trial_days >= 30
            ? $trial_months . ' ' . ($trial_months > 1 ? 'months' : 'month')
            : $trial_days . ' ' . ($trial_days > 1 ? 'days' : 'day');
        wp_mail(
            $admin_email,
            'Your School is Approved — Nagaland AI Schools',
            sprintf(
                "Dear %s,\n\nGreat news! Your school \"%s\" has been approved on Nagaland AI Schools.\n\nYour %s free trial has started.\n\nLogin Details:\nEmail: %s\nPassword: %s\nLogin URL: %s\n\nAfter logging in, you can:\n- Add your classes\n- Add students (each gets a unique parent code)\n- Add teachers\n- Print parent code slips\n\nNeed help? WhatsApp us: +91 63833 59495\n\nWelcome aboard!\nNagaland AI Schools Team\nnagalandai.com",
                $admin_name, $school->name, $trial_label,
                $admin_email, $password, $login_url
            )
        );

        /* Redirect back */
        wp_safe_redirect(admin_url('admin.php?page=nais-pending-schools&approved=1'));
        exit;
    }


    /**
     * AJAX: Reject school.
     */
    public static function ajax_reject_school() {
        check_ajax_referer('nais_reject_school', '_nais_nonce');

        if (!current_user_can('nais_platform_admin')) wp_die('Not allowed.');

        global $wpdb;
        $school_id = absint($_POST['school_id'] ?? 0);
        $reason    = sanitize_text_field($_POST['reject_reason'] ?? '');

        $school = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('schools') . " WHERE id = %d",
            $school_id
        ));
        if (!$school) wp_die('School not found.');
        if ($school->status !== 'pending') wp_die('This school has already been processed (status: ' . esc_html($school->status) . ').');

        $updated = $wpdb->update(NAIS_Database::table('schools'), [
            'status' => 'rejected',
        ], ['id' => $school_id]);

        if ($updated === false) {
            wp_die('Failed to reject school. Database error: ' . esc_html($wpdb->last_error));
        }

        $admin_email = get_option("nais_school_{$school_id}_app_admin_email", '');

        NAIS_Database::audit_log('school_rejected', 'school', $school_id, $school_id, ['reason' => $reason]);

        /* Notify applicant */
        if ($admin_email) {
            wp_mail(
                $admin_email,
                'School Application Update — Nagaland AI Schools',
                sprintf(
                    "Dear applicant,\n\nThank you for your interest in Nagaland AI Schools.\n\nUnfortunately, we are unable to approve your application for \"%s\" at this time.\n\n%s\n\nIf you have questions, please WhatsApp us: +91 63833 59495\n\nNagaland AI Schools Team\nnagalandai.com",
                    $school->name,
                    $reason ? "Reason: " . $reason : "Please contact us for more information."
                )
            );
        }

        wp_safe_redirect(admin_url('admin.php?page=nais-pending-schools&rejected=1'));
        exit;
    }
}

add_action('init', [NAIS_School_Register::class, 'init']);