<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS ROLES — 3 Custom WordPress Roles
 * ═══════════════════════════════════════════════════════════════
 *
 * nais_school_admin → Manages one school (teachers, students, classes)
 * nais_teacher      → Marks attendance for assigned classes
 * nais_parent       → Views own child's attendance
 *
 * Platform Admin = WordPress administrator (Aloto)
 */

if (!defined('ABSPATH')) exit;

class NAIS_Roles {

    const PLATFORM_ADMIN = 'nais_platform_admin';
    const SCHOOL_ADMIN   = 'nais_school_admin';
    const TEACHER        = 'nais_teacher';
    const PARENT         = 'nais_parent';
    const AUDITOR        = 'nais_auditor';

    /**
     * Create/update custom roles.
     * Removes old roles first to ensure cap changes apply.
     */
    public static function create_roles() {

        /* Remove first so cap updates are applied */
        remove_role(self::SCHOOL_ADMIN);
        remove_role(self::TEACHER);
        remove_role(self::PARENT);
        remove_role(self::AUDITOR);

        /* School Admin — manages their school */
        add_role(self::SCHOOL_ADMIN, 'School Admin', [
            'read'                  => true,
            'nais_manage_school'    => true,
            'nais_manage_teachers'  => true,
            'nais_manage_students'  => true,
            'nais_manage_classes'   => true,
            'nais_view_attendance'  => true,
            'nais_view_reports'     => true,
            'nais_generate_codes'   => true,
        ]);

        /* Teacher — marks attendance */
        add_role(self::TEACHER, 'Teacher', [
            'read'                  => true,
            'nais_mark_attendance'  => true,
            'nais_view_attendance'  => true,
        ]);

        /* Parent — view own child only */
        add_role(self::PARENT, 'Parent', [
            'read'                  => true,
            'nais_view_own_child'   => true,
        ]);

        /* Auditor — read-only access to everything */
        add_role(self::AUDITOR, 'Government Auditor', [
            'read'                   => true,
            'nais_audit_access'      => true,
            'nais_view_attendance'   => true,
            'nais_view_reports'      => true,
        ]);

        /* Grant all NAIS caps to administrators */
        $admin = get_role('administrator');
        if ($admin) {
            $admin->add_cap('nais_manage_school');
            $admin->add_cap('nais_manage_teachers');
            $admin->add_cap('nais_manage_students');
            $admin->add_cap('nais_manage_classes');
            $admin->add_cap('nais_view_attendance');
            $admin->add_cap('nais_view_reports');
            $admin->add_cap('nais_generate_codes');
            $admin->add_cap('nais_mark_attendance');
            $admin->add_cap('nais_view_own_child');
            $admin->add_cap('nais_platform_admin');
            $admin->add_cap('nais_audit_access');
        }
    }

    /**
     * Get the school_id for the current user.
     * Platform admin can access all schools.
     */
    public static function get_user_school_id($user_id = 0) {
        global $wpdb;

        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return 0;

        /* School Admin — look up their school first (even if also platform admin) */
        $school_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('schools') . " WHERE admin_user_id = %d AND status = 'active' LIMIT 1",
            $user_id
        ));
        if ($school_id) return (int)$school_id;

        /* Platform admin with no school — return requested school or 0 (all) */
        if (user_can($user_id, 'nais_platform_admin')) {
            return isset($_REQUEST['school_id']) ? absint($_REQUEST['school_id']) : 0;
        }

        /* Teacher — look up via teachers table */
        $school_id = $wpdb->get_var($wpdb->prepare(
            "SELECT school_id FROM " . NAIS_Database::table('teachers') . " WHERE user_id = %d AND status = 'active' LIMIT 1",
            $user_id
        ));
        if ($school_id) return (int)$school_id;

        /* Parent — look up via parent_links → students */
        $school_id = $wpdb->get_var($wpdb->prepare(
            "SELECT s.school_id FROM " . NAIS_Database::table('parent_links') . " pl
             JOIN " . NAIS_Database::table('students') . " s ON pl.student_id = s.id
             WHERE pl.parent_user_id = %d AND pl.verified = 1
             LIMIT 1",
            $user_id
        ));
        if ($school_id) return (int)$school_id;

        return 0;
    }

    /**
     * Check if current user can access a specific school.
     */
    public static function can_access_school($school_id) {
        $user_id = get_current_user_id();
        if (!$user_id) return false;

        /* Platform admin can access everything */
        if (current_user_can('nais_platform_admin')) return true;

        $user_school = self::get_user_school_id($user_id);
        return $user_school === (int)$school_id;
    }
}