<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS PAYMENT — School Subscription & Payment System
 * ═══════════════════════════════════════════════════════════════
 *
 * Payment is PER-SCHOOL (not per-student).
 * Village schools get affordable pricing with offline options.
 *
 * PAYMENT METHODS:
 *   1. Razorpay (online — card, UPI, netbanking)
 *   2. Offline — Cash at school office
 *   3. Offline — Bank transfer / NEFT / IMPS
 *   4. Offline — UPI manual (screenshot verification)
 *   5. Offline — WhatsApp payment confirmation
 *
 * PRICING TIERS (admin-adjustable from dashboard):
 *   Basic      → up to 100 students
 *   Growth     → up to 300 students
 *   Premium    → up to 700 students
 *   Enterprise → up to 1500 students
 *
 * All prices changeable from wp-admin → AI Schools → Pricing.
 * Coupon codes + admin gift upgrades included.
 *
 * TABLES: nais_school_payments, nais_school_coupons
 *
 * LIFECYCLE: trial → active → grace (15 days) → locked
 * Data is NEVER deleted. Dashboard locks until payment.
 *
 * @version 2.0.0
 */

if (!defined('ABSPATH')) exit;

class NAIS_Payment {

    /* ─── DEFAULT PRICING (admin can change anytime) ─── */
    private static $default_pricing = [
        'basic' => [
            'name'             => 'Basic',
            'max_students'     => 100,
            'yearly_price'     => 2999,
            'quarterly_price'  => 899,
            'description'      => 'Up to 100 students — perfect for small & village schools',
        ],
        'growth' => [
            'name'             => 'Growth',
            'max_students'     => 300,
            'yearly_price'     => 5999,
            'quarterly_price'  => 1799,
            'description'      => 'Up to 300 students — for growing schools',
        ],
        'premium' => [
            'name'             => 'Premium',
            'max_students'     => 700,
            'yearly_price'     => 9999,
            'quarterly_price'  => 2999,
            'description'      => 'Up to 700 students — for large schools',
        ],
        'enterprise' => [
            'name'             => 'Enterprise',
            'max_students'     => 1500,
            'yearly_price'     => 17999,
            'quarterly_price'  => 5399,
            'description'      => 'Up to 1500 students — for institutions & academies',
        ],
    ];

    /* ─── PAYMENT METHODS ─── */
    private static $payment_methods = [
        'razorpay'      => 'Razorpay (Card / UPI / Netbanking)',
        'bank_transfer' => 'Bank Transfer (NEFT / IMPS / RTGS)',
        'upi_manual'    => 'UPI Transfer (Send screenshot)',
        'cash'          => 'Cash Payment (At school office)',
        'whatsapp'      => 'WhatsApp Payment Confirmation',
    ];


    /**
     * Init hooks.
     */
    public static function init() {
        /* Admin menus */
        add_action('admin_menu', [__CLASS__, 'admin_menus']);

        /* ── AJAX handlers (method names match exactly) ── */
        add_action('wp_ajax_nais_initiate_school_payment', [__CLASS__, 'ajax_initiate_school_payment']);
        add_action('wp_ajax_nais_verify_school_payment',   [__CLASS__, 'ajax_verify_school_payment']);
        add_action('wp_ajax_nais_admin_mark_paid',         [__CLASS__, 'ajax_admin_mark_paid']);
        add_action('wp_ajax_nais_apply_school_coupon',     [__CLASS__, 'ajax_apply_coupon']);
        add_action('wp_ajax_nais_save_pricing',            [__CLASS__, 'ajax_save_pricing']);
        add_action('wp_ajax_nais_save_payment_settings',   [__CLASS__, 'ajax_save_payment_settings']);
        add_action('wp_ajax_nais_gift_school',             [__CLASS__, 'ajax_gift_school']);
        add_action('wp_ajax_nais_save_coupon',             [__CLASS__, 'ajax_save_coupon']);
        add_action('wp_ajax_nais_toggle_coupon',           [__CLASS__, 'ajax_toggle_coupon']);

        /* Shortcode registered in main plugin file (nagaland-ai-schools.php) */

        /* Expiry + grace period check */
        add_action('init', [__CLASS__, 'check_school_expiry']);

        /* Daily reminder cron */
        add_action('nais_daily_expiry_reminders', [__CLASS__, 'send_expiry_reminders']);
        if (!wp_next_scheduled('nais_daily_expiry_reminders')) {
            wp_schedule_event(time(), 'daily', 'nais_daily_expiry_reminders');
        }

        /* Weekly cleanup cron — removes old audit logs */
        add_action('nais_weekly_cleanup', ['NAIS_Database', 'cleanup_old_data']);
        if (!wp_next_scheduled('nais_weekly_cleanup')) {
            wp_schedule_event(time(), 'weekly', 'nais_weekly_cleanup');
        }

        /* DB tables on plugin activation (called from main plugin) */
        add_action('nais_create_payment_tables', [__CLASS__, 'create_tables']);
    }


    /* ═══════════════════════════════════════════
       DATABASE
    ═══════════════════════════════════════════ */

    /**
     * Create payment tables.
     */
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        /* School payments / invoices */
        $payments = NAIS_Database::table('school_payments');
        dbDelta("CREATE TABLE {$payments} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            school_id       BIGINT UNSIGNED NOT NULL,
            txnid           VARCHAR(50)     NOT NULL,
            plan_tier       VARCHAR(20)     NOT NULL,
            period          VARCHAR(10)     NOT NULL DEFAULT 'yearly',
            amount          DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
            original_amount DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
            discount_amount DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
            coupon_code     VARCHAR(32)     DEFAULT NULL,
            payment_method  VARCHAR(30)     NOT NULL DEFAULT 'razorpay',
            status          VARCHAR(20)     NOT NULL DEFAULT 'pending',
            razorpay_order_id    VARCHAR(50)  DEFAULT NULL,
            razorpay_payment_id  VARCHAR(50)  DEFAULT NULL,
            razorpay_signature   VARCHAR(255) DEFAULT NULL,
            offline_reference    VARCHAR(255) DEFAULT NULL,
            offline_screenshot   VARCHAR(500) DEFAULT NULL,
            admin_notes     TEXT            DEFAULT NULL,
            paid_by_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            verified_by     BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY txnid (txnid),
            KEY school_id (school_id),
            KEY status (status)
        ) {$charset};");

        /* School coupons (separate from nagalandai.com user coupons) */
        $coupons = NAIS_Database::table('school_coupons');
        dbDelta("CREATE TABLE {$coupons} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            code            VARCHAR(32)     NOT NULL,
            discount_type   VARCHAR(10)     NOT NULL DEFAULT 'percent',
            discount_value  DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
            max_uses        INT UNSIGNED    NOT NULL DEFAULT 0,
            used_count      INT UNSIGNED    NOT NULL DEFAULT 0,
            active          TINYINT(1)      NOT NULL DEFAULT 1,
            created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY code (code)
        ) {$charset};");
    }


    /* ═══════════════════════════════════════════
       PRICING (admin-adjustable)
    ═══════════════════════════════════════════ */

    /**
     * Get current pricing. Falls back to defaults if not set.
     */
    public static function get_pricing() {
        $saved = get_option('nais_school_pricing', []);
        if (!is_array($saved) || empty($saved)) return self::$default_pricing;

        /* Merge saved with defaults to handle new tiers */
        $merged = self::$default_pricing;
        foreach ($merged as $tier => &$data) {
            if (isset($saved[$tier])) {
                $data['quarterly_price'] = (float)($saved[$tier]['quarterly_price'] ?? $data['quarterly_price']);
                $data['yearly_price']    = (float)($saved[$tier]['yearly_price'] ?? $data['yearly_price']);
                $data['max_students']    = (int)($saved[$tier]['max_students'] ?? $data['max_students']);
                $data['description']     = $saved[$tier]['description'] ?? $data['description'];
                if (isset($saved[$tier]['name'])) {
                    $data['name'] = $saved[$tier]['name'];
                }
            }
        }

        return $merged;
    }

    /**
     * Get valid tier keys.
     */
    public static function get_valid_tiers() {
        return array_keys(self::$default_pricing);
    }

    /**
     * Get payment settings (Razorpay keys, bank details, UPI ID, WhatsApp number).
     */
    public static function get_payment_settings() {
        $defaults = [
            'razorpay_key_id'      => '',
            'razorpay_key_secret'  => '',
            'bank_name'            => '',
            'bank_account_name'    => 'Nagaland Me',
            'bank_account_number'  => '',
            'bank_ifsc'            => '',
            'upi_id'               => '',
            'whatsapp_number'      => '+916383359495',
            'payment_instructions' => 'After making payment, share the screenshot or reference number with us for verification.',
            'free_trial_days'      => 180,
        ];
        $saved = get_option('nais_payment_settings', []);
        if (!is_array($saved)) $saved = [];
        return wp_parse_args($saved, $defaults);
    }


    /* ═══════════════════════════════════════════
       SCHOOL SUBSCRIPTION STATUS
    ═══════════════════════════════════════════ */

    /**
     * Get a school's current subscription.
     */
    public static function get_school_subscription($school_id) {
        global $wpdb;
        $schools = NAIS_Database::table('schools');

        $school = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$schools} WHERE id = %d",
            $school_id
        ));

        if (!$school) return null;

        return [
            'plan_tier'      => get_option("nais_school_{$school_id}_plan", 'free_trial'),
            'plan_period'    => get_option("nais_school_{$school_id}_period", 'yearly'),
            'payment_status' => get_option("nais_school_{$school_id}_payment_status", 'trial'),
            'expires_at'     => (int)get_option("nais_school_{$school_id}_expires", 0),
            'school'         => $school,
        ];
    }

    /**
     * Activate a school subscription.
     * All expires values stored as Unix timestamps.
     */
    public static function activate_school($school_id, $tier, $period, $expires_ts) {
        update_option("nais_school_{$school_id}_plan", $tier);
        update_option("nais_school_{$school_id}_period", $period);
        update_option("nais_school_{$school_id}_payment_status", 'active');
        update_option("nais_school_{$school_id}_expires", (int)$expires_ts);

        /* Clear any grace state */
        delete_option("nais_school_{$school_id}_grace_start");

        NAIS_Database::audit_log('school_subscription_activated', 'school', $school_id, $school_id, [
            'tier' => $tier, 'period' => $period, 'expires' => $expires_ts,
        ]);
    }

    /**
     * Grant free trial to a new school.
     */
    public static function grant_free_trial($school_id) {
        $settings = self::get_payment_settings();
        $trial_days = max(7, (int)$settings['free_trial_days']);

        $expires = strtotime('+' . $trial_days . ' days');

        update_option("nais_school_{$school_id}_plan", 'basic');
        update_option("nais_school_{$school_id}_period", 'yearly');
        update_option("nais_school_{$school_id}_payment_status", 'trial');
        update_option("nais_school_{$school_id}_expires", $expires);

        NAIS_Database::audit_log('school_free_trial', 'school', $school_id, $school_id, [
            'trial_days' => $trial_days,
        ]);
    }

    /**
     * Check expiry for all schools — handle grace period + locking.
     *
     * States: trial → active → grace (15 days) → locked
     * Data is NEVER deleted. Dashboard locks until payment.
     */
    public static function check_school_expiry() {
        if (!is_admin() && !wp_doing_cron()) return;
        if (wp_rand(1, 20) !== 1) return; /* Run ~5% of requests */

        global $wpdb;
        $schools = $wpdb->get_col("SELECT id FROM " . NAIS_Database::table('schools') . " WHERE status = 'active'");

        $now         = time();
        $grace_days  = 15;

        foreach ($schools as $sid) {
            $expires = (int)get_option("nais_school_{$sid}_expires", 0);
            $status  = get_option("nais_school_{$sid}_payment_status", 'trial');

            if ($expires <= 0 || $status === 'locked') continue;

            if ($now > $expires && in_array($status, ['trial', 'active'], true)) {
                /* Just expired → move to grace period */
                update_option("nais_school_{$sid}_payment_status", 'grace');
                update_option("nais_school_{$sid}_grace_start", $expires);
                NAIS_Database::audit_log('school_grace_period', 'school', $sid, $sid, '15-day grace period started');
            }

            if ($status === 'grace') {
                $grace_start = (int)get_option("nais_school_{$sid}_grace_start", $now);
                $grace_end   = $grace_start + ($grace_days * DAY_IN_SECONDS);

                if ($now > $grace_end) {
                    /* Grace period over → lock dashboard */
                    update_option("nais_school_{$sid}_payment_status", 'locked');
                    NAIS_Database::audit_log('school_locked', 'school', $sid, $sid, 'Grace period ended. Dashboard locked.');
                }
            }
        }
    }


    /**
     * Daily cron: Send email reminders before expiry.
     * Sends at 30, 15, 7, and 1 day(s) before expiry.
     */
    public static function send_expiry_reminders() {
        global $wpdb;
        $schools = $wpdb->get_results("SELECT id, name, email FROM " . NAIS_Database::table('schools') . " WHERE status = 'active'");

        $reminder_days = [30, 15, 7, 1];
        $now = time();

        foreach ($schools as $school) {
            $expires = (int)get_option("nais_school_{$school->id}_expires", 0);
            $status  = get_option("nais_school_{$school->id}_payment_status", 'trial');

            if ($expires <= 0 || $status === 'locked') continue;

            $days_left = (int)floor(($expires - $now) / DAY_IN_SECONDS);

            foreach ($reminder_days as $rd) {
                if ($days_left === $rd) {
                    $sent_key = "nais_school_{$school->id}_reminder_{$rd}_{$expires}";

                    /* Only send once per expiry cycle */
                    if (get_option($sent_key)) continue;

                    /* Get admin email */
                    $admin_email = self::get_school_admin_email($school);

                    if (!$admin_email) continue;

                    /* Build email */
                    $plan_label = ($status === 'trial') ? 'free trial' : 'subscription';
                    $renew_url  = home_url('/subscribe/');
                    $days_text  = $rd === 1 ? 'tomorrow' : "in {$rd} days";

                    $subject = "Nagaland AI Schools — Your {$plan_label} expires {$days_text}";

                    $body = "Hello,\n\n";
                    $body .= "Your Nagaland AI Schools {$plan_label} for \"{$school->name}\" expires {$days_text}.\n\n";

                    if ($rd <= 7) {
                        $body .= "⚠ After expiry, you have a 15-day grace period. After that, your dashboard will be locked (your data stays safe).\n\n";
                    }

                    $body .= "Renew now to keep your school's digital system running:\n";
                    $body .= "{$renew_url}\n\n";
                    $body .= "Plans start at just ₹2,999/year (Basic — up to 100 students).\n\n";
                    $body .= "Questions? Reply to this email or WhatsApp us at +91 63833 59495.\n\n";
                    $body .= "— Nagaland AI Schools\nhttps://schools.nagalandai.com";

                    $headers = ['From: Nagaland AI Schools <info@nagaland.me>'];

                    wp_mail($admin_email, $subject, $body, $headers);
                    update_option($sent_key, true);

                    NAIS_Database::audit_log('reminder_sent', 'school', $school->id, $school->id,
                        "Expiry reminder ({$rd} days) sent to {$admin_email}"
                    );
                }
            }

            /* Also send reminder during grace period (day 5 and day 12 of grace) */
            if ($status === 'grace') {
                $grace_start = (int)get_option("nais_school_{$school->id}_grace_start", $now);
                $grace_day   = (int)floor(($now - $grace_start) / DAY_IN_SECONDS);
                $days_remaining = 15 - $grace_day;

                if (in_array($grace_day, [5, 12], true)) {
                    $sent_key = "nais_school_{$school->id}_grace_reminder_{$grace_day}";
                    if (get_option($sent_key)) continue;

                    $admin_email = self::get_school_admin_email($school);
                    if (!$admin_email) continue;

                    $subject = "⚠ Nagaland AI Schools — {$days_remaining} days until your dashboard locks";
                    $body = "Hello,\n\n";
                    $body .= "Your school \"{$school->name}\" is in the grace period. Your dashboard will be LOCKED in {$days_remaining} days.\n\n";
                    $body .= "Don't lose access to your school system. Renew now:\n";
                    $body .= home_url('/subscribe/') . "\n\n";
                    $body .= "Your data is safe — renewing unlocks everything instantly.\n\n";
                    $body .= "— Nagaland AI Schools";

                    wp_mail($admin_email, $subject, $body, ['From: Nagaland AI Schools <info@nagaland.me>']);
                    update_option($sent_key, true);
                }
            }
        }
    }

    /**
     * Helper: Get admin email for a school.
     */
    private static function get_school_admin_email($school) {
        global $wpdb;

        $admin_user_id = $wpdb->get_var($wpdb->prepare(
            "SELECT admin_user_id FROM " . NAIS_Database::table('schools') . " WHERE id = %d",
            $school->id
        ));

        $admin_email = '';
        if ($admin_user_id) {
            $user = get_user_by('id', $admin_user_id);
            $admin_email = $user ? $user->user_email : '';
        }
        if (!$admin_email && !empty($school->email)) {
            $admin_email = $school->email;
        }

        return $admin_email;
    }


    /**
     * Get renewal banner HTML for a school.
     * Call this from any shortcode to show the banner.
     *
     * Returns empty string if school is active and not near expiry.
     */
    public static function get_renewal_banner($school_id) {
        if (!$school_id) return '';

        $status  = get_option("nais_school_{$school_id}_payment_status", 'trial');
        $expires = (int)get_option("nais_school_{$school_id}_expires", 0);
        $now     = time();

        $renew_url = home_url('/subscribe/');

        /* Locked — show full-page lock */
        if ($status === 'locked') {
            return '<div class="nais-lock-banner">
                <div class="nais-lock-icon">🔒</div>
                <h2>Dashboard Locked</h2>
                <p>Your subscription has expired and the grace period has ended. Your data is safe — renew to unlock your dashboard instantly.</p>
                <a href="' . esc_url($renew_url) . '" class="nais-btn nais-btn-primary nais-btn-lg">Renew Now</a>
                <p class="nais-hint" style="margin-top:12px;">Questions? WhatsApp us at +91 63833 59495</p>
            </div>';
        }

        /* Grace period — urgent banner */
        if ($status === 'grace') {
            $grace_start = (int)get_option("nais_school_{$school_id}_grace_start", $now);
            $grace_end   = $grace_start + (15 * DAY_IN_SECONDS);
            $days_left   = max(0, (int)ceil(($grace_end - $now) / DAY_IN_SECONDS));

            return '<div class="nais-renewal-banner nais-banner-urgent">
                <div class="nais-banner-content">
                    <strong>⚠ Your subscription has expired!</strong>
                    Dashboard will lock in <strong>' . $days_left . ' day' . ($days_left !== 1 ? 's' : '') . '</strong>.
                    <a href="' . esc_url($renew_url) . '" class="nais-btn nais-btn-sm" style="margin-left:12px;">Renew Now</a>
                </div>
            </div>';
        }

        /* Trial or active — show warning if near expiry */
        if ($expires > 0 && in_array($status, ['trial', 'active'], true)) {
            $days_left = (int)floor(($expires - $now) / DAY_IN_SECONDS);

            if ($days_left <= 30 && $days_left > 7) {
                $label = ($status === 'trial') ? 'free trial' : 'subscription';
                return '<div class="nais-renewal-banner nais-banner-info">
                    <div class="nais-banner-content">
                        Your ' . $label . ' expires in <strong>' . $days_left . ' days</strong>.
                        <a href="' . esc_url($renew_url) . '" class="nais-btn nais-btn-sm" style="margin-left:12px;">Renew Early</a>
                    </div>
                </div>';
            }

            if ($days_left <= 7 && $days_left > 0) {
                $label = ($status === 'trial') ? 'free trial' : 'subscription';
                return '<div class="nais-renewal-banner nais-banner-warning">
                    <div class="nais-banner-content">
                        <strong>⏳ Your ' . $label . ' expires in ' . $days_left . ' day' . ($days_left !== 1 ? 's' : '') . '!</strong>
                        <a href="' . esc_url($renew_url) . '" class="nais-btn nais-btn-sm" style="margin-left:12px;">Renew Now</a>
                    </div>
                </div>';
            }
        }

        return '';
    }


    /**
     * Check if a school's dashboard should be locked.
     */
    public static function is_school_locked($school_id) {
        return get_option("nais_school_{$school_id}_payment_status", 'trial') === 'locked';
    }


    /**
     * Calculate expiry timestamp for a new subscription.
     * If school is still active, extend from current expiry (reward early renewal).
     */
    private static function calculate_expiry($school_id, $period) {
        $current_expires = (int)get_option("nais_school_{$school_id}_expires", 0);
        $current_status  = get_option("nais_school_{$school_id}_payment_status", 'trial');
        $now = time();

        /* Start from current expiry if still active (early renewal reward) */
        $base = ($current_expires > $now && $current_status === 'active') ? $current_expires : $now;

        if ($period === 'yearly') {
            return strtotime('+1 year', $base);
        }
        return strtotime('+3 months', $base);
    }


    /* ═══════════════════════════════════════════
       ADMIN MENUS
    ═══════════════════════════════════════════ */

    public static function admin_menus() {
        add_submenu_page(
            'nagaland-schools',
            'Pricing',
            'Pricing',
            'nais_platform_admin',
            'nais-pricing',
            [__CLASS__, 'page_pricing']
        );

        add_submenu_page(
            'nagaland-schools',
            'Payment Settings',
            'Payment Settings',
            'nais_platform_admin',
            'nais-payment-settings',
            [__CLASS__, 'page_payment_settings']
        );

        add_submenu_page(
            'nagaland-schools',
            'School Payments',
            'School Payments',
            'nais_platform_admin',
            'nais-school-payments',
            [__CLASS__, 'page_payments']
        );

        add_submenu_page(
            'nagaland-schools',
            'School Coupons',
            'School Coupons',
            'nais_platform_admin',
            'nais-school-coupons',
            [__CLASS__, 'page_coupons']
        );

        add_submenu_page(
            'nagaland-schools',
            'Gift School',
            'Gift School',
            'nais_platform_admin',
            'nais-gift-school',
            [__CLASS__, 'page_gift']
        );
    }


    /**
     * Pricing page — adjust all prices from dashboard.
     */
    public static function page_pricing() {
        $pricing = self::get_pricing();

        if (isset($_POST['nais_save_pricing']) && wp_verify_nonce($_POST['_nais_nonce'], 'nais_save_pricing')) {
            $new = [];
            foreach ($pricing as $tier => $data) {
                $new[$tier] = [
                    'name'            => sanitize_text_field($_POST[$tier . '_name'] ?? $data['name']),
                    'quarterly_price' => max(0, (float)($_POST[$tier . '_quarterly'] ?? $data['quarterly_price'])),
                    'yearly_price'    => max(0, (float)($_POST[$tier . '_yearly'] ?? $data['yearly_price'])),
                    'max_students'    => max(0, (int)($_POST[$tier . '_max_students'] ?? $data['max_students'])),
                    'description'     => sanitize_text_field($_POST[$tier . '_description'] ?? $data['description']),
                ];
            }
            update_option('nais_school_pricing', $new);
            NAIS_Database::audit_log('pricing_updated', 'system', 0, 0, 'Pricing tiers updated from admin');
            echo '<div class="notice notice-success"><p>Pricing updated.</p></div>';
            $pricing = self::get_pricing(); /* Refresh */
        }

        ?>
        <div class="wrap">
            <h1>School Pricing — Adjust Anytime</h1>
            <p>Change any price below. Schools on existing plans will continue at their locked-in rate until renewal.</p>

            <form method="post">
                <?php wp_nonce_field('nais_save_pricing', '_nais_nonce'); ?>
                <table class="form-table">
                    <?php foreach ($pricing as $tier => $data): ?>
                        <tr><td colspan="2"><h2 style="margin:20px 0 5px;"><?php echo esc_html($data['name']); ?> Plan</h2></td></tr>
                        <tr>
                            <th>Quarterly Price (₹)</th>
                            <td><input type="number" name="<?php echo $tier; ?>_quarterly" value="<?php echo (int)$data['quarterly_price']; ?>" min="0" step="1" class="small-text"></td>
                        </tr>
                        <tr>
                            <th>Yearly Price (₹)</th>
                            <td><input type="number" name="<?php echo $tier; ?>_yearly" value="<?php echo (int)$data['yearly_price']; ?>" min="0" step="1" class="small-text"></td>
                        </tr>
                        <tr>
                            <th>Max Students</th>
                            <td><input type="number" name="<?php echo $tier; ?>_max_students" value="<?php echo (int)$data['max_students']; ?>" min="0" class="small-text"> <span class="description">0 = unlimited (not recommended)</span></td>
                        </tr>
                        <tr>
                            <th>Description</th>
                            <td><input type="text" name="<?php echo $tier; ?>_description" value="<?php echo esc_attr($data['description']); ?>" class="regular-text"></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
                <p class="submit"><input type="submit" name="nais_save_pricing" class="button-primary" value="Save Pricing"></p>
            </form>
        </div>
        <?php
    }


    /**
     * Payment settings — Razorpay keys, bank details, UPI, WhatsApp.
     */
    public static function page_payment_settings() {
        $settings = self::get_payment_settings();

        if (isset($_POST['nais_save_payment_settings']) && wp_verify_nonce($_POST['_nais_nonce'], 'nais_save_payment_settings')) {
            $new = [
                'razorpay_key_id'      => sanitize_text_field($_POST['razorpay_key_id'] ?? ''),
                'razorpay_key_secret'  => sanitize_text_field($_POST['razorpay_key_secret'] ?? ''),
                'bank_name'            => sanitize_text_field($_POST['bank_name'] ?? ''),
                'bank_account_name'    => sanitize_text_field($_POST['bank_account_name'] ?? ''),
                'bank_account_number'  => sanitize_text_field($_POST['bank_account_number'] ?? ''),
                'bank_ifsc'            => sanitize_text_field($_POST['bank_ifsc'] ?? ''),
                'upi_id'               => sanitize_text_field($_POST['upi_id'] ?? ''),
                'whatsapp_number'      => sanitize_text_field($_POST['whatsapp_number'] ?? ''),
                'payment_instructions' => sanitize_textarea_field($_POST['payment_instructions'] ?? ''),
                'free_trial_days'      => max(0, (int)($_POST['free_trial_days'] ?? 180)),
            ];
            update_option('nais_payment_settings', $new);
            NAIS_Database::audit_log('payment_settings_updated', 'system', 0, 0, 'Payment settings updated from admin');
            echo '<div class="notice notice-success"><p>Payment settings saved.</p></div>';
            $settings = self::get_payment_settings();
        }

        ?>
        <div class="wrap">
            <h1>Payment Settings</h1>
            <form method="post">
                <?php wp_nonce_field('nais_save_payment_settings', '_nais_nonce'); ?>
                <table class="form-table">
                    <tr><td colspan="2"><h2>Razorpay (Online Payments)</h2></td></tr>
                    <tr><th>Key ID</th><td><input type="text" name="razorpay_key_id" value="<?php echo esc_attr($settings['razorpay_key_id']); ?>" class="regular-text"></td></tr>
                    <tr><th>Key Secret</th><td><input type="password" name="razorpay_key_secret" value="<?php echo esc_attr($settings['razorpay_key_secret']); ?>" class="regular-text"></td></tr>

                    <tr><td colspan="2"><h2>Bank Transfer Details</h2><p class="description">Shown to schools choosing offline bank transfer.</p></td></tr>
                    <tr><th>Bank Name</th><td><input type="text" name="bank_name" value="<?php echo esc_attr($settings['bank_name']); ?>" class="regular-text" placeholder="State Bank of India"></td></tr>
                    <tr><th>Account Name</th><td><input type="text" name="bank_account_name" value="<?php echo esc_attr($settings['bank_account_name']); ?>" class="regular-text"></td></tr>
                    <tr><th>Account Number</th><td><input type="text" name="bank_account_number" value="<?php echo esc_attr($settings['bank_account_number']); ?>" class="regular-text"></td></tr>
                    <tr><th>IFSC Code</th><td><input type="text" name="bank_ifsc" value="<?php echo esc_attr($settings['bank_ifsc']); ?>" class="regular-text"></td></tr>

                    <tr><td colspan="2"><h2>UPI</h2></td></tr>
                    <tr><th>UPI ID</th><td><input type="text" name="upi_id" value="<?php echo esc_attr($settings['upi_id']); ?>" class="regular-text" placeholder="nagalandme@sbi"></td></tr>

                    <tr><td colspan="2"><h2>WhatsApp</h2></td></tr>
                    <tr><th>WhatsApp Number</th><td><input type="text" name="whatsapp_number" value="<?php echo esc_attr($settings['whatsapp_number']); ?>" class="regular-text" placeholder="+916383359495"></td></tr>

                    <tr><td colspan="2"><h2>General</h2></td></tr>
                    <tr><th>Payment Instructions</th><td><textarea name="payment_instructions" rows="3" class="large-text"><?php echo esc_textarea($settings['payment_instructions']); ?></textarea></td></tr>
                    <tr><th>Free Trial Days</th><td><input type="number" name="free_trial_days" value="<?php echo (int)$settings['free_trial_days']; ?>" min="0" max="365" class="small-text"> <span class="description">0 = no trial. New schools get this many days free.</span></td></tr>
                </table>
                <p class="submit"><input type="submit" name="nais_save_payment_settings" class="button-primary" value="Save Settings"></p>
            </form>
        </div>
        <?php
    }


    /**
     * Payments list — with "Mark as Paid" button for offline payments.
     */
    public static function page_payments() {
        global $wpdb;

        /* Handle mark as paid */
        if (isset($_POST['nais_mark_paid']) && wp_verify_nonce($_POST['_nais_nonce'], 'nais_mark_paid')) {
            if (!current_user_can('nais_platform_admin')) {
                echo '<div class="notice notice-error"><p>Permission denied.</p></div>';
                return;
            }
            $payment_id = absint($_POST['payment_id']);
            $notes = sanitize_textarea_field($_POST['admin_notes'] ?? '');
            self::process_mark_paid($payment_id, $notes);
            echo '<div class="notice notice-success"><p>Payment marked as paid and school activated.</p></div>';
        }

        $payments = $wpdb->get_results(
            "SELECT p.*, s.name AS school_name
             FROM " . NAIS_Database::table('school_payments') . " p
             LEFT JOIN " . NAIS_Database::table('schools') . " s ON p.school_id = s.id
             ORDER BY p.id DESC LIMIT 100"
        );

        ?>
        <div class="wrap">
            <h1>School Payments</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th><th>School</th><th>Plan</th><th>Period</th>
                        <th>Amount</th><th>Method</th><th>Status</th>
                        <th>Reference</th><th>Date</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($payments)): ?>
                        <tr><td colspan="10">No payments yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($payments as $p): ?>
                            <tr>
                                <td><?php echo (int)$p->id; ?></td>
                                <td><?php echo esc_html($p->school_name ?: 'School #' . $p->school_id); ?></td>
                                <td><?php echo esc_html(ucfirst($p->plan_tier)); ?></td>
                                <td><?php echo esc_html(ucfirst($p->period)); ?></td>
                                <td>₹<?php echo esc_html(number_format((float)$p->amount, 2)); ?></td>
                                <td><?php echo esc_html(self::$payment_methods[$p->payment_method] ?? ucfirst($p->payment_method)); ?></td>
                                <td>
                                    <span style="color:<?php echo $p->status === 'success' ? '#0a7558' : ($p->status === 'pending' ? '#f59e0b' : '#ef4444'); ?>; font-weight:700;">
                                        <?php echo esc_html(strtoupper($p->status)); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html($p->offline_reference ?: $p->razorpay_payment_id ?: '—'); ?></td>
                                <td><?php echo esc_html($p->created_at); ?></td>
                                <td>
                                    <?php if ($p->status === 'pending'): ?>
                                        <form method="post" style="display:inline;">
                                            <?php wp_nonce_field('nais_mark_paid', '_nais_nonce'); ?>
                                            <input type="hidden" name="payment_id" value="<?php echo (int)$p->id; ?>">
                                            <input type="text" name="admin_notes" placeholder="Notes" style="width:100px;">
                                            <button type="submit" name="nais_mark_paid" class="button button-primary button-small">Mark Paid</button>
                                        </form>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }


    /**
     * Process marking an offline payment as paid.
     */
    private static function process_mark_paid($payment_id, $admin_notes = '') {
        global $wpdb;
        $table = NAIS_Database::table('school_payments');

        $payment = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $payment_id));
        if (!$payment || $payment->status === 'success') return;

        $wpdb->update($table, [
            'status'      => 'success',
            'admin_notes' => $admin_notes,
            'verified_by' => get_current_user_id(),
        ], ['id' => $payment_id]);

        /* Calculate expiry (reward early renewal) */
        $period  = $payment->period === 'yearly' ? 'yearly' : 'quarterly';
        $expires = self::calculate_expiry($payment->school_id, $period);

        /* Activate school */
        self::activate_school($payment->school_id, $payment->plan_tier, $period, $expires);

        /* Atomic coupon increment — prevents race condition */
        if ($payment->coupon_code) {
            $coupon_table = NAIS_Database::table('school_coupons');
            $wpdb->query($wpdb->prepare(
                "UPDATE {$coupon_table} SET used_count = used_count + 1 WHERE code = %s AND (max_uses = 0 OR used_count < max_uses)",
                $payment->coupon_code
            ));
        }

        NAIS_Database::audit_log('payment_verified', 'payment', $payment_id, $payment->school_id,
            'Marked paid by admin. Notes: ' . ($admin_notes ?: '—')
        );
    }


    /**
     * Coupons page.
     */
    public static function page_coupons() {
        global $wpdb;
        $table = NAIS_Database::table('school_coupons');

        if (isset($_POST['nais_save_school_coupon']) && wp_verify_nonce($_POST['_nais_nonce'], 'nais_save_school_coupon')) {
            $code  = strtoupper(sanitize_text_field($_POST['code'] ?? ''));
            $code  = preg_replace('/[^A-Z0-9_-]/', '', $code);
            $dtype = sanitize_key($_POST['discount_type'] ?? 'percent');
            $dval  = max(0, (float)($_POST['discount_value'] ?? 0));
            $max   = max(0, (int)($_POST['max_uses'] ?? 0));
            $active = isset($_POST['active']) ? 1 : 0;

            if (!in_array($dtype, ['percent', 'fixed'], true)) $dtype = 'percent';
            if ($dtype === 'percent') $dval = min(99, $dval); /* Cap percent at 99% */

            if ($code && $dval > 0) {
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE code = %s", $code));
                if ($exists) {
                    $wpdb->update($table, [
                        'discount_type'  => $dtype,
                        'discount_value' => $dval,
                        'max_uses'       => $max,
                        'active'         => $active,
                    ], ['id' => $exists]);
                } else {
                    $wpdb->insert($table, [
                        'code'           => $code,
                        'discount_type'  => $dtype,
                        'discount_value' => $dval,
                        'max_uses'       => $max,
                        'active'         => $active,
                    ]);
                }
                NAIS_Database::audit_log('coupon_saved', 'system', 0, 0, $code . ' (' . $dtype . ': ' . $dval . ')');
                echo '<div class="notice notice-success"><p>Coupon saved.</p></div>';
            }
        }

        /* Toggle */
        if (isset($_GET['toggle_coupon']) && wp_verify_nonce($_GET['_wpnonce'] ?? '', 'nais_toggle_coupon')) {
            $cid = absint($_GET['toggle_coupon']);
            $current = $wpdb->get_var($wpdb->prepare("SELECT active FROM {$table} WHERE id = %d", $cid));
            if ($current !== null) {
                $wpdb->update($table, ['active' => (int)$current === 1 ? 0 : 1], ['id' => $cid]);
            }
        }

        $coupons = $wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT 100");

        ?>
        <div class="wrap">
            <h1>School Coupons</h1>

            <h2>Create / Update Coupon</h2>
            <form method="post">
                <?php wp_nonce_field('nais_save_school_coupon', '_nais_nonce'); ?>
                <table class="form-table">
                    <tr><th>Code</th><td><input type="text" name="code" required placeholder="SCHOOL50" style="width:200px;"></td></tr>
                    <tr><th>Discount Type</th><td><select name="discount_type"><option value="percent">Percent (%)</option><option value="fixed">Fixed Amount (₹)</option></select></td></tr>
                    <tr><th>Value</th><td><input type="number" name="discount_value" step="0.01" min="1" required style="width:100px;"> <span class="description">Percent: 1–99. Fixed: rupees off.</span></td></tr>
                    <tr><th>Max Uses</th><td><input type="number" name="max_uses" min="0" value="0" style="width:100px;"> <span class="description">0 = unlimited</span></td></tr>
                    <tr><th>Active</th><td><label><input type="checkbox" name="active" value="1" checked> Enabled</label></td></tr>
                </table>
                <p class="submit"><input type="submit" name="nais_save_school_coupon" class="button-primary" value="Save Coupon"></p>
            </form>

            <h2>Existing Coupons</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Max Uses</th><th>Used</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                    <?php if (empty($coupons)): ?>
                        <tr><td colspan="7">No coupons yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($coupons as $c):
                            $toggle_url = wp_nonce_url(add_query_arg(['page' => 'nais-school-coupons', 'toggle_coupon' => $c->id], admin_url('admin.php')), 'nais_toggle_coupon');
                        ?>
                            <tr>
                                <td><code><?php echo esc_html($c->code); ?></code></td>
                                <td><?php echo esc_html(ucfirst($c->discount_type)); ?></td>
                                <td><?php echo $c->discount_type === 'fixed' ? '₹' . number_format((float)$c->discount_value) : number_format((float)$c->discount_value) . '%'; ?></td>
                                <td><?php echo (int)$c->max_uses ?: 'Unlimited'; ?></td>
                                <td><?php echo (int)$c->used_count; ?></td>
                                <td><?php echo (int)$c->active ? '<span style="color:#10b981;">Active</span>' : '<span style="color:#ef4444;">Disabled</span>'; ?></td>
                                <td><a href="<?php echo esc_url($toggle_url); ?>"><?php echo (int)$c->active ? 'Disable' : 'Enable'; ?></a></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }


    /**
     * Gift school page — give free access.
     */
    public static function page_gift() {
        global $wpdb;

        if (isset($_POST['nais_gift_school']) && wp_verify_nonce($_POST['_nais_nonce'], 'nais_gift_school')) {
            $school_id = absint($_POST['school_id']);
            $tier      = sanitize_key($_POST['tier'] ?? 'basic');
            $period    = sanitize_key($_POST['period'] ?? 'yearly');
            $months    = max(1, (int)($_POST['months'] ?? 12));

            if ($school_id) {
                $expires = strtotime('+' . $months . ' months');
                self::activate_school($school_id, $tier, $period, $expires);

                /* Record gift transaction */
                $wpdb->insert(NAIS_Database::table('school_payments'), [
                    'school_id'       => $school_id,
                    'txnid'           => 'GIFT' . time() . wp_rand(1000, 9999) . wp_rand(100, 999),
                    'plan_tier'       => $tier,
                    'period'          => $period,
                    'amount'          => 0,
                    'original_amount' => 0,
                    'payment_method'  => 'gift',
                    'status'          => 'success',
                    'admin_notes'     => 'Gift by admin — ' . $months . ' months',
                    'verified_by'     => get_current_user_id(),
                ]);

                NAIS_Database::audit_log('school_gifted', 'school', $school_id, $school_id,
                    $tier . ' plan for ' . $months . ' months (gift)'
                );

                echo '<div class="notice notice-success"><p>School activated for ' . $months . ' months!</p></div>';
            }
        }

        $schools = $wpdb->get_results("SELECT id, name, district FROM " . NAIS_Database::table('schools') . " ORDER BY name ASC");
        $pricing = self::get_pricing();

        ?>
        <div class="wrap">
            <h1>Gift School Access</h1>
            <p>Give free access to pilot schools, government schools, or partner institutions.</p>

            <form method="post">
                <?php wp_nonce_field('nais_gift_school', '_nais_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th>School</th>
                        <td>
                            <select name="school_id" required>
                                <option value="">Select School</option>
                                <?php foreach ($schools as $s): ?>
                                    <option value="<?php echo $s->id; ?>"><?php echo esc_html($s->name . ' (' . $s->district . ')'); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Plan Tier</th>
                        <td>
                            <select name="tier">
                                <?php foreach ($pricing as $t => $d): ?>
                                    <option value="<?php echo $t; ?>"><?php echo esc_html($d['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Duration (months)</th>
                        <td><input type="number" name="months" value="12" min="1" max="60" class="small-text"></td>
                    </tr>
                    <tr>
                        <th>Period</th>
                        <td><select name="period"><option value="yearly">Yearly</option><option value="quarterly">Quarterly</option></select></td>
                    </tr>
                </table>
                <p class="submit"><input type="submit" name="nais_gift_school" class="button-primary" value="Gift Access"></p>
            </form>
        </div>
        <?php
    }


    /* ═══════════════════════════════════════════
       FRONTEND: SCHOOL PAYMENT SHORTCODE
    ═══════════════════════════════════════════ */

    /**
     * Payment page shortcode [nais_school_payment]
     * Shown to school admins to pay for their school.
     */
    public static function payment_shortcode() {
        if (!is_user_logged_in()) {
            return '<div class="nais-login-prompt"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">School Subscription</h2><p>Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to manage your school subscription.</p></div>';
        }

        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) {
            return '<p>Only school administrators can manage subscriptions.</p>';
        }

        $school_id = NAIS_Roles::get_user_school_id();
        if (!$school_id) {
            return '<div class="nais-msg"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">No School Found</h2><p>No school is assigned to your account. Please contact the platform administrator.</p></div>';
        }

        $sub       = self::get_school_subscription($school_id);
        $pricing   = self::get_pricing();
        $settings  = self::get_payment_settings();
        $school    = $sub['school'];

        $is_active  = $sub['payment_status'] === 'active';
        $is_trial   = $sub['payment_status'] === 'trial';
        $is_expired = in_array($sub['payment_status'], ['expired', 'grace', 'locked'], true);
        $is_grace   = $sub['payment_status'] === 'grace';
        $is_locked  = $sub['payment_status'] === 'locked';
        $expires_txt = $sub['expires_at'] ? date_i18n('d M Y', $sub['expires_at']) : '—';

        /* Status color: green=active, yellow=trial, orange=grace, red=expired/locked */
        $status_color = '#ef4444';
        if ($is_active) $status_color = '#10b981';
        elseif ($is_trial) $status_color = '#f59e0b';
        elseif ($is_grace) $status_color = '#f97316';

        /* Enqueue Razorpay SDK if configured */
        $has_razorpay = !empty($settings['razorpay_key_id']);
        if ($has_razorpay) {
            wp_enqueue_script('razorpay-checkout', 'https://checkout.razorpay.com/v1/checkout.js', [], null, true);
        }

        ob_start();
        ?>
        <div class="nais-payment-page">

            <!-- Current Status -->
            <div class="nais-child-card">
                <h3><?php echo esc_html($school->name); ?> — Subscription</h3>
                <div class="nais-stats-grid" style="grid-template-columns: repeat(3, 1fr);">
                    <div class="nais-stat-item">
                        <div class="nais-stat-number" style="font-size:18px;"><?php echo esc_html(ucfirst($sub['plan_tier'])); ?></div>
                        <div class="nais-stat-label">Plan</div>
                    </div>
                    <div class="nais-stat-item">
                        <div class="nais-stat-number" style="font-size:18px; color:<?php echo $status_color; ?>;">
                            <?php echo esc_html(strtoupper($sub['payment_status'])); ?>
                        </div>
                        <div class="nais-stat-label">Status</div>
                    </div>
                    <div class="nais-stat-item">
                        <div class="nais-stat-number" style="font-size:18px;"><?php echo esc_html($expires_txt); ?></div>
                        <div class="nais-stat-label">Valid Until</div>
                    </div>
                </div>
                <?php if ($is_grace): ?>
                    <p style="margin-top:12px;padding:10px;background:#fff7ed;border-radius:8px;color:#9a3412;font-size:13px;">
                        <strong>⚠ Grace Period:</strong> Your subscription has expired. You have 15 days to renew before your dashboard locks. Your data is safe.
                    </p>
                <?php elseif ($is_locked): ?>
                    <p style="margin-top:12px;padding:10px;background:#fef2f2;border-radius:8px;color:#991b1b;font-size:13px;">
                        <strong>🔒 Locked:</strong> Grace period ended. Pay below to unlock your dashboard instantly. All your data is safe.
                    </p>
                <?php endif; ?>
            </div>

            <?php if ($is_trial || $is_expired || !$is_active): ?>

            <!-- Plan Selection -->
            <div class="nais-child-card" style="margin-top:20px;">
                <h3><?php echo $is_expired ? 'Renew Your Subscription' : 'Choose a Plan'; ?></h3>

                <form id="nais-school-payment-form">
                    <div class="nais-form-row">
                        <label><strong>Billing Period</strong></label>
                        <select name="period" id="nais-period-select">
                            <option value="quarterly">Quarterly (Every 3 months)</option>
                            <option value="yearly" selected>Yearly (Save more)</option>
                        </select>
                    </div>

                    <?php foreach ($pricing as $tier => $data): ?>
                        <label style="display:block;margin:10px 0;padding:16px;border:2px solid #e8e8e8;border-radius:12px;cursor:pointer;transition:border-color 0.2s;">
                            <input type="radio" name="tier" value="<?php echo esc_attr($tier); ?>" <?php echo $tier === 'basic' ? 'checked' : ''; ?>>
                            <strong><?php echo esc_html($data['name']); ?></strong>
                            — ₹<span class="nais-price-display" data-quarterly="<?php echo (int)$data['quarterly_price']; ?>" data-yearly="<?php echo (int)$data['yearly_price']; ?>"><?php echo number_format((int)$data['yearly_price']); ?></span>
                            <span class="nais-price-period">/year</span>
                            <br><small style="color:#666;"><?php echo esc_html($data['description']); ?></small>
                        </label>
                    <?php endforeach; ?>

                    <!-- Custom tier — contact for large/government -->
                    <div style="display:block;margin:10px 0;padding:16px;border:2px dashed #d4a843;border-radius:12px;background:#fffbeb;">
                        <strong style="color:#92400e;">Custom</strong> — Need more than 1500 students?
                        <br><small style="color:#666;">For district administration, government schools, or multi-branch institutions — we'll create a custom plan for you.</small>
                        <br><a href="mailto:info@nagaland.me?subject=Custom%20School%20Plan%20Request&body=School%20Name:%0ADistrict:%0ANumber%20of%20Students:%0AContact%20Number:" style="display:inline-block;margin-top:8px;padding:8px 16px;background:#d4a843;color:#fff;border-radius:8px;text-decoration:none;font-weight:600;font-size:13px;">Contact Us — info@nagaland.me</a>
                    </div>

                    <div class="nais-form-row" style="margin-top:16px;">
                        <label>Coupon Code (optional)</label>
                        <div style="display:flex;gap:8px;">
                            <input type="text" name="coupon" id="nais-coupon-input" placeholder="Enter coupon code" style="flex:1;">
                            <button type="button" id="nais-apply-coupon" class="nais-btn nais-btn-sm">Apply</button>
                        </div>
                        <div id="nais-coupon-result" style="margin-top:6px;font-size:13px;"></div>
                    </div>

                    <div class="nais-form-row" style="margin-top:16px;">
                        <label><strong>Payment Method</strong></label>
                        <?php foreach (self::$payment_methods as $method => $label): ?>
                            <?php if ($method === 'razorpay' && !$has_razorpay) continue; ?>
                            <label style="display:block;margin:6px 0;">
                                <input type="radio" name="payment_method" value="<?php echo esc_attr($method); ?>" <?php echo ($method === 'razorpay' && $has_razorpay) ? 'checked' : (($method === 'upi_manual' && !$has_razorpay) ? 'checked' : ''); ?>>
                                <?php echo esc_html($label); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <!-- Offline details (shown based on selection) -->
                    <div id="nais-offline-details" style="display:none;margin-top:16px;padding:16px;background:#f9fafb;border-radius:10px;border:1px solid #e8e8e8;">
                        <div id="nais-bank-details" style="display:none;">
                            <h4>Bank Transfer Details</h4>
                            <p><strong>Bank:</strong> <?php echo esc_html($settings['bank_name']); ?></p>
                            <p><strong>Account Name:</strong> <?php echo esc_html($settings['bank_account_name']); ?></p>
                            <p><strong>Account No:</strong> <?php echo esc_html($settings['bank_account_number']); ?></p>
                            <p><strong>IFSC:</strong> <?php echo esc_html($settings['bank_ifsc']); ?></p>
                        </div>
                        <div id="nais-upi-details" style="display:none;">
                            <h4>UPI Transfer</h4>
                            <p>Send payment to UPI ID: <strong><?php echo esc_html($settings['upi_id']); ?></strong></p>
                        </div>
                        <div id="nais-whatsapp-details" style="display:none;">
                            <h4>WhatsApp Payment</h4>
                            <p>Send payment confirmation to: <strong><?php echo esc_html($settings['whatsapp_number']); ?></strong></p>
                            <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $settings['whatsapp_number']); ?>?text=School%20Payment%20for%20<?php echo urlencode($school->name); ?>" target="_blank" class="nais-btn nais-btn-sm" style="background:#25d366;">Message on WhatsApp</a>
                        </div>
                        <div id="nais-cash-details" style="display:none;">
                            <h4>Cash Payment</h4>
                            <p>Pay cash at the Nagaland AI office or to the designated school coordinator.</p>
                        </div>
                        <div class="nais-form-row" style="margin-top:12px;">
                            <label>Reference / Transaction ID</label>
                            <input type="text" name="offline_reference" placeholder="UTR number, transaction ID, or receipt number">
                        </div>
                        <p style="font-size:13px;color:#666;margin-top:8px;"><?php echo esc_html($settings['payment_instructions']); ?></p>
                    </div>

                    <button type="submit" class="nais-btn nais-btn-primary nais-btn-lg" style="margin-top:20px;" id="nais-pay-btn">
                        Pay & Subscribe
                    </button>
                </form>
            </div>

            <?php endif; ?>

            <!-- Payment History -->
            <?php
            global $wpdb;
            $history = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM " . NAIS_Database::table('school_payments') . " WHERE school_id = %d ORDER BY id DESC LIMIT 10",
                $school_id
            ));
            if (!empty($history)):
            ?>
            <div class="nais-child-card" style="margin-top:20px;">
                <h3>Payment History</h3>
                <div style="overflow-x:auto;">
                    <table style="width:100%;border-collapse:collapse;font-size:13px;">
                        <thead>
                            <tr style="background:#f3f4f6;text-align:left;">
                                <th style="padding:8px;">Date</th>
                                <th style="padding:8px;">Plan</th>
                                <th style="padding:8px;">Amount</th>
                                <th style="padding:8px;">Method</th>
                                <th style="padding:8px;">Status</th>
                                <th style="padding:8px;">Ref</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($history as $h): ?>
                                <tr style="border-bottom:1px solid #e8e8e8;">
                                    <td style="padding:8px;"><?php echo esc_html(date_i18n('d M Y', strtotime($h->created_at))); ?></td>
                                    <td style="padding:8px;"><?php echo esc_html(ucfirst($h->plan_tier) . ' / ' . ucfirst($h->period)); ?></td>
                                    <td style="padding:8px;">₹<?php echo esc_html(number_format((float)$h->amount, 2)); ?></td>
                                    <td style="padding:8px;"><?php echo esc_html(self::$payment_methods[$h->payment_method] ?? ucfirst($h->payment_method)); ?></td>
                                    <td style="padding:8px;">
                                        <span style="color:<?php echo $h->status === 'success' ? '#10b981' : ($h->status === 'pending' ? '#f59e0b' : '#ef4444'); ?>;font-weight:600;">
                                            <?php echo esc_html(ucfirst($h->status)); ?>
                                        </span>
                                    </td>
                                    <td style="padding:8px;"><?php echo esc_html($h->txnid); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

        </div>

        <script>
        (function($){
            /* Period toggle — update prices */
            $('#nais-period-select').on('change', function(){
                var period = $(this).val();
                $('.nais-price-display').each(function(){
                    var price = period === 'yearly' ? $(this).data('yearly') : $(this).data('quarterly');
                    $(this).text(price.toLocaleString('en-IN'));
                });
                $('.nais-price-period').text(period === 'yearly' ? '/year' : '/quarter');
            });

            /* Highlight selected plan */
            $('input[name="tier"]').on('change', function(){
                $('input[name="tier"]').closest('label').css('border-color', '#e8e8e8');
                $(this).closest('label').css('border-color', '#10b981');
            });
            $('input[name="tier"]:checked').closest('label').css('border-color', '#10b981');

            /* Payment method toggle */
            $('input[name="payment_method"]').on('change', function(){
                var method = $(this).val();
                var isOffline = (method !== 'razorpay');
                $('#nais-offline-details').toggle(isOffline);
                $('#nais-bank-details').toggle(method === 'bank_transfer');
                $('#nais-upi-details').toggle(method === 'upi_manual');
                $('#nais-whatsapp-details').toggle(method === 'whatsapp');
                $('#nais-cash-details').toggle(method === 'cash');
                $('#nais-pay-btn').text(isOffline ? 'Submit Payment Request' : 'Pay & Subscribe');
            });

            /* Apply coupon */
            $('#nais-apply-coupon').on('click', function(){
                var code = $('#nais-coupon-input').val().trim();
                if (!code) return;
                var tier = $('input[name="tier"]:checked').val();
                var period = $('#nais-period-select').val();
                var $btn = $(this);
                $btn.prop('disabled', true).text('Checking...');

                $.post(naisData.ajaxUrl, {
                    action: 'nais_apply_school_coupon',
                    nonce: naisData.nonce,
                    code: code,
                    tier: tier,
                    period: period
                }, function(res){
                    $btn.prop('disabled', false).text('Apply');
                    if (res.success) {
                        $('#nais-coupon-result').html('<span style="color:#10b981;">✅ ' + res.data.message + '</span>');
                    } else {
                        $('#nais-coupon-result').html('<span style="color:#ef4444;">❌ ' + (res.data || 'Invalid coupon') + '</span>');
                    }
                }).fail(function(){
                    $btn.prop('disabled', false).text('Apply');
                    $('#nais-coupon-result').html('<span style="color:#ef4444;">❌ Network error. Try again.</span>');
                });
            });

            /* Submit payment */
            $('#nais-school-payment-form').on('submit', function(e){
                e.preventDefault();

                var paymentMethod = $('input[name="payment_method"]:checked').val();
                if (!paymentMethod) {
                    alert('Please select a payment method.');
                    return;
                }

                var formData = {
                    action: 'nais_initiate_school_payment',
                    nonce: naisData.nonce,
                    tier: $('input[name="tier"]:checked').val(),
                    period: $('#nais-period-select').val(),
                    payment_method: paymentMethod,
                    coupon: $('#nais-coupon-input').val().trim(),
                    offline_reference: $('input[name="offline_reference"]').val() || ''
                };

                $('#nais-pay-btn').prop('disabled', true).text('Processing...');

                $.post(naisData.ajaxUrl, formData, function(res){
                    if (res.success) {
                        if (res.data.razorpay && typeof Razorpay !== 'undefined') {
                            /* ─── Open Razorpay Checkout ─── */
                            var options = {
                                key: res.data.key_id,
                                amount: res.data.amount,
                                currency: 'INR',
                                name: res.data.name,
                                description: res.data.description,
                                order_id: res.data.order_id,
                                handler: function(response) {
                                    /* Verify on server */
                                    $('#nais-pay-btn').text('Verifying...');
                                    $.post(naisData.ajaxUrl, {
                                        action: 'nais_verify_school_payment',
                                        nonce: naisData.nonce,
                                        txnid: res.data.txnid,
                                        razorpay_payment_id: response.razorpay_payment_id,
                                        razorpay_order_id: response.razorpay_order_id,
                                        razorpay_signature: response.razorpay_signature
                                    }, function(verifyRes){
                                        if (verifyRes.success) {
                                            alert(verifyRes.data.message || 'Payment successful!');
                                            location.reload();
                                        } else {
                                            alert(verifyRes.data || 'Verification failed. Contact support with TXN: ' + res.data.txnid);
                                            $('#nais-pay-btn').prop('disabled', false).text('Pay & Subscribe');
                                        }
                                    }).fail(function(){
                                        alert('Verification request failed. Contact support with TXN: ' + res.data.txnid);
                                        $('#nais-pay-btn').prop('disabled', false).text('Pay & Subscribe');
                                    });
                                },
                                modal: {
                                    ondismiss: function() {
                                        $('#nais-pay-btn').prop('disabled', false).text('Pay & Subscribe');
                                    }
                                },
                                theme: { color: '#0F2419' }
                            };
                            var rzp = new Razorpay(options);
                            rzp.on('payment.failed', function(response){
                                alert('Payment failed: ' + (response.error.description || 'Unknown error'));
                                $('#nais-pay-btn').prop('disabled', false).text('Pay & Subscribe');
                            });
                            rzp.open();
                        } else if (res.data.message) {
                            /* Offline success */
                            alert(res.data.message);
                            location.reload();
                        }
                    } else {
                        alert(res.data || 'Error processing payment.');
                        $('#nais-pay-btn').prop('disabled', false).text('Pay & Subscribe');
                    }
                }).fail(function(){
                    alert('Network error. Please try again.');
                    $('#nais-pay-btn').prop('disabled', false).text('Pay & Subscribe');
                });
            });
        })(jQuery);
        </script>
        <?php
        return ob_get_clean();
    }


    /* ═══════════════════════════════════════════
       AJAX HANDLERS (Frontend)
    ═══════════════════════════════════════════ */

    /**
     * Initiate school payment — handles both Razorpay and offline.
     */
    public static function ajax_initiate_school_payment() {
        check_ajax_referer('nais_nonce', 'nonce');

        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        global $wpdb;
        $school_id      = NAIS_Roles::get_user_school_id();
        $tier           = sanitize_key($_POST['tier'] ?? 'basic');
        $period         = sanitize_key($_POST['period'] ?? 'yearly');
        $payment_method = sanitize_key($_POST['payment_method'] ?? 'razorpay');
        $coupon_code    = strtoupper(sanitize_text_field($_POST['coupon'] ?? ''));
        $offline_ref    = sanitize_text_field($_POST['offline_reference'] ?? '');

        if (!$school_id) wp_send_json_error('No school found.');

        $pricing = self::get_pricing();
        if (!isset($pricing[$tier])) wp_send_json_error('Invalid plan.');
        if (!in_array($period, ['yearly', 'quarterly'], true)) $period = 'yearly';
        if (!array_key_exists($payment_method, self::$payment_methods)) wp_send_json_error('Invalid payment method.');

        $original_amount = ($period === 'yearly') ? (float)$pricing[$tier]['yearly_price'] : (float)$pricing[$tier]['quarterly_price'];
        $discount = 0;
        $final_amount = $original_amount;

        /* Apply coupon if provided */
        if ($coupon_code) {
            $coupon_table = NAIS_Database::table('school_coupons');
            $coupon = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$coupon_table} WHERE code = %s AND active = 1",
                $coupon_code
            ));

            if ($coupon) {
                if ((int)$coupon->max_uses > 0 && (int)$coupon->used_count >= (int)$coupon->max_uses) {
                    $coupon_code = ''; /* Exhausted — skip */
                } else {
                    if ($coupon->discount_type === 'fixed') {
                        $discount = min((float)$coupon->discount_value, $original_amount - 1);
                    } else {
                        $pct = min(99, (float)$coupon->discount_value); /* Cap at 99% */
                        $discount = round($original_amount * ($pct / 100), 2);
                    }
                    $final_amount = max(1, $original_amount - $discount);
                }
            } else {
                $coupon_code = '';
            }
        }

        $txnid = 'NAIS' . time() . wp_rand(1000, 9999) . wp_rand(100, 999);

        $wpdb->insert(NAIS_Database::table('school_payments'), [
            'school_id'       => $school_id,
            'txnid'           => $txnid,
            'plan_tier'       => $tier,
            'period'          => $period,
            'amount'          => $final_amount,
            'original_amount' => $original_amount,
            'discount_amount' => $discount,
            'coupon_code'     => $coupon_code ?: null,
            'payment_method'  => $payment_method,
            'status'          => 'pending',
            'offline_reference' => $offline_ref ?: null,
            'paid_by_user_id' => get_current_user_id(),
        ]);

        NAIS_Database::audit_log('school_payment_initiated', 'payment', $wpdb->insert_id, $school_id, [
            'tier' => $tier, 'amount' => $final_amount, 'method' => $payment_method,
        ]);

        /* For offline payments — just record and notify admin */
        if ($payment_method !== 'razorpay') {
            /* Notify admin */
            $admin_email = get_option('admin_email');
            $school = $wpdb->get_row($wpdb->prepare("SELECT name FROM " . NAIS_Database::table('schools') . " WHERE id = %d", $school_id));
            $school_name = $school ? $school->name : 'School #' . $school_id;

            wp_mail(
                $admin_email,
                '[NAIS] Offline Payment Submitted — ' . $school_name,
                sprintf(
                    "School: %s\nPlan: %s (%s)\nAmount: ₹%s\nMethod: %s\nReference: %s\nTXN: %s\n\nPlease verify and mark as paid in wp-admin → AI Schools → School Payments.",
                    $school_name, $tier, $period, number_format($final_amount, 2),
                    self::$payment_methods[$payment_method] ?? $payment_method,
                    $offline_ref ?: '—', $txnid
                )
            );

            wp_send_json_success([
                'message' => 'Payment request submitted! Your school will be activated once payment is verified. Reference: ' . $txnid,
            ]);
            return;
        }

        /* For Razorpay — create order and return checkout data */
        $settings = self::get_payment_settings();
        if (!$settings['razorpay_key_id'] || !$settings['razorpay_key_secret']) {
            wp_send_json_error('Razorpay is not configured. Please use offline payment or contact admin.');
        }

        /* Create Razorpay order */
        $amount_paise = (int)round($final_amount * 100);
        $order_payload = [
            'amount'   => $amount_paise,
            'currency' => 'INR',
            'receipt'  => $txnid,
            'notes'    => [
                'school_id' => (string)$school_id,
                'txnid'     => $txnid,
                'tier'      => $tier,
                'period'    => $period,
            ],
        ];

        $ch = curl_init('https://api.razorpay.com/v1/orders');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Basic ' . base64_encode($settings['razorpay_key_id'] . ':' . $settings['razorpay_key_secret']),
            ],
            CURLOPT_POSTFIELDS     => json_encode($order_payload),
            CURLOPT_TIMEOUT        => 20,
        ]);
        $result   = curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr) {
            wp_send_json_error('Payment gateway unreachable. Please try offline payment.');
        }

        $order = json_decode($result, true);

        if ($httpCode < 200 || $httpCode >= 300 || empty($order['id'])) {
            wp_send_json_error('Could not create payment order. Please try offline payment.');
        }

        /* Store Razorpay order_id on the payment record */
        $wpdb->update(NAIS_Database::table('school_payments'), [
            'razorpay_order_id' => $order['id'],
        ], ['txnid' => $txnid]);

        wp_send_json_success([
            'razorpay'    => true,
            'order_id'    => $order['id'],
            'key_id'      => $settings['razorpay_key_id'],
            'amount'      => $amount_paise,
            'txnid'       => $txnid,
            'school_id'   => $school_id,
            'name'        => 'Nagaland AI Schools',
            'description' => ucfirst($tier) . ' Plan — ' . ucfirst($period),
        ]);
    }

    /**
     * Verify Razorpay payment after checkout.
     */
    public static function ajax_verify_school_payment() {
        check_ajax_referer('nais_nonce', 'nonce');

        global $wpdb;
        $txnid      = sanitize_text_field($_POST['txnid'] ?? '');
        $payment_id = sanitize_text_field($_POST['razorpay_payment_id'] ?? '');
        $signature  = sanitize_text_field($_POST['razorpay_signature'] ?? '');
        $order_id   = sanitize_text_field($_POST['razorpay_order_id'] ?? '');

        if (!$txnid || !$payment_id || !$signature || !$order_id) {
            wp_send_json_error('Missing payment data.');
        }

        $table   = NAIS_Database::table('school_payments');
        $payment = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE txnid = %s", $txnid));
        if (!$payment) wp_send_json_error('Payment not found.');

        if ($payment->status === 'success') {
            wp_send_json_success(['message' => 'Payment already verified.']);
            return;
        }

        /* Verify order_id matches what was stored during initiation (prevents cross-payment replay) */
        if (empty($payment->razorpay_order_id) || $payment->razorpay_order_id !== $order_id) {
            NAIS_Database::audit_log('payment_order_mismatch', 'payment', $payment->id, $payment->school_id,
                'POST order_id: ' . $order_id . ' vs DB: ' . ($payment->razorpay_order_id ?: 'empty'));
            wp_send_json_error('Payment verification failed — order mismatch.');
        }

        /* Verify signature */
        $settings = self::get_payment_settings();
        $expected = hash_hmac('sha256', $order_id . '|' . $payment_id, $settings['razorpay_key_secret']);

        if (!hash_equals($expected, $signature)) {
            $wpdb->update($table, ['status' => 'failed', 'admin_notes' => 'Signature verification failed'], ['txnid' => $txnid]);
            NAIS_Database::audit_log('payment_signature_failed', 'payment', $payment->id, $payment->school_id, $txnid);
            wp_send_json_error('Payment verification failed.');
        }

        /* Mark as success */
        $wpdb->update($table, [
            'status'              => 'success',
            'razorpay_payment_id' => $payment_id,
            'razorpay_signature'  => $signature,
            'verified_by'         => get_current_user_id(),
        ], ['txnid' => $txnid]);

        /* Activate school (early renewal rewarded) */
        $period  = $payment->period === 'yearly' ? 'yearly' : 'quarterly';
        $expires = self::calculate_expiry($payment->school_id, $period);
        self::activate_school($payment->school_id, $payment->plan_tier, $period, $expires);

        /* Atomic coupon increment — prevents race condition where two concurrent payments both pass the check */
        if ($payment->coupon_code) {
            $wpdb->query($wpdb->prepare(
                "UPDATE " . NAIS_Database::table('school_coupons') .
                " SET used_count = used_count + 1 WHERE code = %s AND (max_uses = 0 OR used_count < max_uses)",
                $payment->coupon_code
            ));
        }

        /* Notify admin */
        $school = $wpdb->get_row($wpdb->prepare("SELECT name FROM " . NAIS_Database::table('schools') . " WHERE id = %d", $payment->school_id));
        wp_mail(get_option('admin_email'),
            '[NAIS] Online Payment Received — ' . ($school ? $school->name : 'School'),
            "Payment verified.\nTXN: {$txnid}\nAmount: ₹" . number_format((float)$payment->amount, 2) . "\nPayment ID: {$payment_id}"
        );

        wp_send_json_success(['message' => 'Payment successful! Your school is now active.']);
    }

    /**
     * Apply coupon — returns discounted price.
     */
    public static function ajax_apply_coupon() {
        check_ajax_referer('nais_nonce', 'nonce');

        global $wpdb;
        $code   = strtoupper(sanitize_text_field($_POST['code'] ?? ''));
        $tier   = sanitize_key($_POST['tier'] ?? 'basic');
        $period = sanitize_key($_POST['period'] ?? 'yearly');

        if (!$code) wp_send_json_error('Enter a coupon code.');

        $pricing = self::get_pricing();
        if (!isset($pricing[$tier])) wp_send_json_error('Invalid plan.');

        $original = ($period === 'yearly') ? (float)$pricing[$tier]['yearly_price'] : (float)$pricing[$tier]['quarterly_price'];

        $coupon = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('school_coupons') . " WHERE code = %s AND active = 1",
            $code
        ));

        if (!$coupon) wp_send_json_error('Coupon not found or inactive.');

        if ((int)$coupon->max_uses > 0 && (int)$coupon->used_count >= (int)$coupon->max_uses) {
            wp_send_json_error('Coupon limit reached.');
        }

        $discount = 0;
        if ($coupon->discount_type === 'fixed') {
            $discount = min((float)$coupon->discount_value, $original - 1);
        } else {
            $pct = min(99, (float)$coupon->discount_value); /* Cap at 99% */
            $discount = round($original * ($pct / 100), 2);
        }

        $final = max(1, $original - $discount);

        wp_send_json_success([
            'message'  => 'Coupon applied! You save ₹' . number_format($discount) . '. New price: ₹' . number_format($final),
            'discount' => $discount,
            'final'    => $final,
        ]);
    }


    /* ═══════════════════════════════════════════
       AJAX HANDLERS (Admin — for AJAX-based admin UI)
    ═══════════════════════════════════════════ */

    /**
     * Admin AJAX: Mark an offline payment as paid.
     */
    public static function ajax_admin_mark_paid() {
        check_ajax_referer('nais_admin_nonce', 'nonce');
        if (!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        $payment_id = absint($_POST['payment_id'] ?? 0);
        if (!$payment_id) wp_send_json_error('Missing payment ID.');

        global $wpdb;
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('school_payments') . " WHERE id = %d",
            $payment_id
        ));
        if (!$payment) wp_send_json_error('Payment not found.');
        if ($payment->status === 'success') wp_send_json_error('Payment already verified.');

        $notes = sanitize_textarea_field($_POST['notes'] ?? '');
        self::process_mark_paid($payment_id, $notes);

        wp_send_json_success(['message' => 'Payment marked as paid. School plan activated.']);
    }

    /**
     * Admin AJAX: Save pricing tiers.
     */
    public static function ajax_save_pricing() {
        check_ajax_referer('nais_admin_nonce', 'nonce');
        if (!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        $tiers = $_POST['pricing'] ?? [];
        if (!is_array($tiers) || empty($tiers)) wp_send_json_error('No pricing data.');

        $pricing = [];
        foreach ($tiers as $key => $tier) {
            $key = sanitize_key($key);
            if (!in_array($key, self::get_valid_tiers(), true)) continue;

            $pricing[$key] = [
                'name'            => sanitize_text_field($tier['name'] ?? $key),
                'max_students'    => absint($tier['max_students'] ?? 100),
                'yearly_price'    => max(0, (float)($tier['yearly_price'] ?? 0)),
                'quarterly_price' => max(0, (float)($tier['quarterly_price'] ?? 0)),
                'description'     => sanitize_text_field($tier['description'] ?? ''),
            ];
        }

        update_option('nais_school_pricing', $pricing);
        NAIS_Database::audit_log('pricing_updated', 'system', 0, 0, 'Pricing tiers updated via AJAX');
        wp_send_json_success(['message' => 'Pricing saved.']);
    }

    /**
     * Admin AJAX: Save payment settings (Razorpay keys, bank details, UPI ID, etc.).
     */
    public static function ajax_save_payment_settings() {
        check_ajax_referer('nais_admin_nonce', 'nonce');
        if (!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        $settings = [
            'razorpay_key_id'      => sanitize_text_field($_POST['razorpay_key_id'] ?? ''),
            'razorpay_key_secret'  => sanitize_text_field($_POST['razorpay_key_secret'] ?? ''),
            'bank_name'            => sanitize_text_field($_POST['bank_name'] ?? ''),
            'bank_account_name'    => sanitize_text_field($_POST['bank_account_name'] ?? ''),
            'bank_account_number'  => sanitize_text_field($_POST['bank_account_number'] ?? ''),
            'bank_ifsc'            => sanitize_text_field($_POST['bank_ifsc'] ?? ''),
            'upi_id'               => sanitize_text_field($_POST['upi_id'] ?? ''),
            'whatsapp_number'      => sanitize_text_field($_POST['whatsapp_number'] ?? ''),
            'payment_instructions' => sanitize_textarea_field($_POST['payment_instructions'] ?? ''),
            'free_trial_days'      => max(0, (int)($_POST['free_trial_days'] ?? 180)),
        ];

        update_option('nais_payment_settings', $settings);
        NAIS_Database::audit_log('payment_settings_updated', 'system', 0, 0, 'Payment settings updated via AJAX');
        wp_send_json_success(['message' => 'Payment settings saved.']);
    }

    /**
     * Admin AJAX: Gift a school a free plan.
     */
    public static function ajax_gift_school() {
        check_ajax_referer('nais_admin_nonce', 'nonce');
        if (!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        $school_id = absint($_POST['school_id'] ?? 0);
        $tier      = sanitize_key($_POST['plan'] ?? sanitize_key($_POST['tier'] ?? 'basic'));
        $months    = max(1, absint($_POST['months'] ?? 12));
        $period    = sanitize_key($_POST['period'] ?? 'yearly');

        if (!$school_id) wp_send_json_error('Missing school ID.');

        /* Validate tier against known tiers */
        $valid_tiers = self::get_valid_tiers();
        if (!in_array($tier, $valid_tiers, true)) {
            wp_send_json_error('Invalid plan tier. Valid: ' . implode(', ', $valid_tiers));
        }

        /* Validate period */
        if (!in_array($period, ['yearly', 'quarterly'], true)) {
            wp_send_json_error('Invalid period. Must be yearly or quarterly.');
        }

        global $wpdb;
        $school = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('schools') . " WHERE id = %d",
            $school_id
        ));
        if (!$school) wp_send_json_error('School not found.');

        $expires = strtotime('+' . $months . ' months');
        self::activate_school($school_id, $tier, $period, $expires);

        /* Record gift transaction */
        $wpdb->insert(NAIS_Database::table('school_payments'), [
            'school_id'       => $school_id,
            'txnid'           => 'GIFT' . time() . wp_rand(1000, 9999) . wp_rand(100, 999),
            'plan_tier'       => $tier,
            'period'          => $period,
            'amount'          => 0,
            'original_amount' => 0,
            'payment_method'  => 'gift',
            'status'          => 'success',
            'admin_notes'     => 'Gift by admin — ' . $months . ' months',
            'verified_by'     => get_current_user_id(),
        ]);

        NAIS_Database::audit_log('school_gifted', 'school', $school_id, $school_id,
            $tier . ' plan for ' . $months . ' months (gift via AJAX)'
        );
        wp_send_json_success(['message' => 'School gifted ' . ucfirst($tier) . ' plan for ' . $months . ' months.']);
    }

    /**
     * Admin AJAX: Create or update a coupon.
     */
    public static function ajax_save_coupon() {
        check_ajax_referer('nais_admin_nonce', 'nonce');
        if (!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $code           = strtoupper(sanitize_text_field($_POST['code'] ?? ''));
        $code           = preg_replace('/[^A-Z0-9_-]/', '', $code);
        $discount_type  = sanitize_key($_POST['discount_type'] ?? 'percent');
        $discount_value = max(0, (float)($_POST['discount_value'] ?? 0));
        $max_uses       = absint($_POST['max_uses'] ?? 0);

        if (!$code || !$discount_value) wp_send_json_error('Coupon code and discount value are required.');
        if (!in_array($discount_type, ['percent', 'fixed'], true)) $discount_type = 'percent';
        if ($discount_type === 'percent') $discount_value = min(99, $discount_value); /* Cap at 99% */

        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('school_coupons') . " WHERE code = %s",
            $code
        ));

        if ($existing) {
            $wpdb->update(NAIS_Database::table('school_coupons'), [
                'discount_type'  => $discount_type,
                'discount_value' => $discount_value,
                'max_uses'       => $max_uses,
            ], ['id' => $existing]);
        } else {
            $wpdb->insert(NAIS_Database::table('school_coupons'), [
                'code'           => $code,
                'discount_type'  => $discount_type,
                'discount_value' => $discount_value,
                'max_uses'       => $max_uses,
                'active'         => 1,
            ]);
        }

        NAIS_Database::audit_log('coupon_saved', 'system', 0, 0, $code . ' (' . $discount_type . ': ' . $discount_value . ')');
        wp_send_json_success(['message' => 'Coupon "' . $code . '" saved.']);
    }

    /**
     * Admin AJAX: Enable or disable a coupon.
     */
    public static function ajax_toggle_coupon() {
        check_ajax_referer('nais_admin_nonce', 'nonce');
        if (!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $coupon_id = absint($_POST['coupon_id'] ?? 0);
        if (!$coupon_id) wp_send_json_error('Missing coupon ID.');

        $current = $wpdb->get_var($wpdb->prepare(
            "SELECT active FROM " . NAIS_Database::table('school_coupons') . " WHERE id = %d",
            $coupon_id
        ));
        if ($current === null) wp_send_json_error('Coupon not found.');

        $new_status = ((int)$current === 1) ? 0 : 1;
        $wpdb->update(NAIS_Database::table('school_coupons'), ['active' => $new_status], ['id' => $coupon_id]);

        $label = $new_status ? 'activated' : 'deactivated';
        wp_send_json_success(['message' => 'Coupon ' . $label . '.', 'active' => $new_status]);
    }
}

/* Init */
add_action('init', [NAIS_Payment::class, 'init']);