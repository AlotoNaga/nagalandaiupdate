<?php
/**
 * NAIS SCHOOL ADMIN — Manage One School
 * Tabs: Classes, Students, Teachers, Codes, Holidays, Alerts, Reports, Buses, Homework, Results, Timetable
 */
if (!defined('ABSPATH')) exit;

class NAIS_School_Admin {

    public static function init() {
        add_action('wp_ajax_nais_add_class', [__CLASS__, 'ajax_add_class']);
        add_action('wp_ajax_nais_add_student', [__CLASS__, 'ajax_add_student']);
        add_action('wp_ajax_nais_add_teacher', [__CLASS__, 'ajax_add_teacher']);
        add_action('wp_ajax_nais_assign_teacher_class', [__CLASS__, 'ajax_assign_teacher_class']);
        add_action('wp_ajax_nais_bulk_add_students', [__CLASS__, 'ajax_bulk_add_students']);
        add_action('wp_ajax_nais_get_parent_slips', [__CLASS__, 'ajax_get_parent_slips']);
        add_action('wp_ajax_nais_lookup_student_code', [__CLASS__, 'ajax_lookup_student_code']);
        add_action('wp_ajax_nais_send_alert', [__CLASS__, 'ajax_send_alert']);
        add_action('wp_ajax_nais_get_alerts', [__CLASS__, 'ajax_get_alerts']);
        add_action('wp_ajax_nais_get_class_report', [__CLASS__, 'ajax_get_class_report']);
        add_action('wp_ajax_nais_download_report_pdf', [__CLASS__, 'ajax_download_report_pdf']);

        /* Holiday AJAX handlers */
        add_action('wp_ajax_nais_mark_holiday', [__CLASS__, 'ajax_mark_holiday']);
        add_action('wp_ajax_nais_get_holidays', [__CLASS__, 'ajax_get_holidays']);
        add_action('wp_ajax_nais_remove_holiday', [__CLASS__, 'ajax_remove_holiday']);

        /* Delete/Edit AJAX handlers */
        add_action('wp_ajax_nais_delete_student', [__CLASS__, 'ajax_delete_student']);
        add_action('wp_ajax_nais_edit_student', [__CLASS__, 'ajax_edit_student']);
        add_action('wp_ajax_nais_delete_teacher', [__CLASS__, 'ajax_delete_teacher']);
        add_action('wp_ajax_nais_edit_teacher', [__CLASS__, 'ajax_edit_teacher']);
        add_action('wp_ajax_nais_delete_class', [__CLASS__, 'ajax_delete_class']);
        add_action('wp_ajax_nais_get_students_list', [__CLASS__, 'ajax_get_students_list']);

        /* Subject management AJAX handlers */
        add_action('wp_ajax_nais_add_subject', [__CLASS__, 'ajax_add_subject']);
        add_action('wp_ajax_nais_delete_subject', [__CLASS__, 'ajax_delete_subject']);
    }

    /** Default subject list (kept as baseline; cannot be removed by school admins). */
    private static $subjects = [
        /* Languages — general */
        'Alternative English', 'Assamese', 'Bengali', 'English', 'French',
        'German', 'Hindi', 'Manipuri', 'Nagamese', 'Sanskrit', 'Spanish', 'Urdu',

        /* Naga tribal languages */
        'Angami', 'Ao', 'Chakhesang', 'Chang', 'Khiamniungan', 'Konyak',
        'Lotha', 'Phom', 'Pochury', 'Rengma', 'Sangtam', 'Sumi',
        'Tenyidie', 'Yimchunger', 'Zeliang',

        /* Mathematics & Sciences */
        'Biology', 'Botany', 'Chemistry', 'Computer Science', 'Engineering Graphics',
        'Foundation of Information Technology', 'Informatics Practices', 'Mathematics',
        'Multimedia and Web Technology', 'Physics', 'Science', 'Statistics',
        'Web Application', 'Zoology',

        /* Social Sciences & Humanities */
        'Anthropology', 'Economics', 'Education', 'Geography', 'History',
        'Knowledge Traditions and Practices of India', 'Logic', 'Philosophy',
        'Political Science', 'Psychology', 'Social Science', 'Sociology',

        /* Commerce & Business */
        'Accountancy', 'Banking & Insurance', 'Book Keeping & Accountancy',
        'Business Studies', 'Entrepreneurship', 'Financial Literacy',
        'Financial Market Management', 'Fundamentals of Business Mathematics',
        'Legal Studies', 'Marketing',

        /* Vocational & Skill */
        'Agriculture', 'Automotive', 'Beauty & Wellness', 'Electronics & Hardware',
        'Fashion Studies', 'Health Care', 'IT / ITeS', 'Mass Media Studies',
        'Multi-Skill Foundation Course', 'Retail', 'Tourism & Hospitality',

        /* Arts, Activities & Values */
        'Adolescence Education', 'Art & Craft', 'Bible Studies',
        'Christian Moral Education', 'Dance', 'Environmental Education',
        'Environmental Studies', 'Fine Arts', 'General Knowledge',
        'Health & Physical Education', 'Home Science', 'Moral Science', 'Music',
        'Nagaland Heritage Studies', 'Painting', 'Physical Education',
        'Work Education', 'Yoga',
    ];

    /** WP option key holding a school's custom subjects. */
    private static function custom_subjects_option_key($school_id) {
        return 'nais_custom_subjects_' . (int)$school_id;
    }

    /** Returns the array of custom subjects saved for this school (may be empty). */
    private static function get_custom_subjects($school_id) {
        $stored = get_option(self::custom_subjects_option_key($school_id), []);
        if (!is_array($stored)) $stored = [];
        $clean = [];
        foreach ($stored as $s) {
            $s = is_string($s) ? trim($s) : '';
            if ($s !== '') $clean[] = $s;
        }
        return $clean;
    }

    /** Returns defaults + custom (deduped, case-insensitive) for dropdown rendering. */
    private static function get_subjects_for_school($school_id) {
        $merged = array_merge(self::$subjects, self::get_custom_subjects($school_id));
        $seen = [];
        $out  = [];
        foreach ($merged as $s) {
            $key = mb_strtolower($s);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $out[] = $s;
        }
        return $out;
    }

    public static function manage_school_shortcode() {
        if (!is_user_logged_in()) return '<p>Please log in.</p>';
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) return '<p>Access denied.</p>';
        $school_id = NAIS_Roles::get_user_school_id();
        if (!$school_id) return '<p>No school assigned to your account.</p>';
        global $wpdb;
        $school = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . NAIS_Database::table('schools') . " WHERE id = %d", $school_id));
        if (!$school) return '<p>School not found.</p>';
        $classes = $wpdb->get_results($wpdb->prepare("SELECT c.*, (SELECT COUNT(*) FROM " . NAIS_Database::table('students') . " s WHERE s.class_id = c.id AND s.status = 'active') AS student_count FROM " . NAIS_Database::table('classes') . " c WHERE c.school_id = %d AND c.status = 'active' ORDER BY c.class_name ASC, c.section ASC", $school_id));
        $teachers = $wpdb->get_results($wpdb->prepare("SELECT t.*, u.user_email FROM " . NAIS_Database::table('teachers') . " t LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID WHERE t.school_id = %d AND t.status = 'active' ORDER BY t.name ASC", $school_id));
        $total_students = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . NAIS_Database::table('students') . " WHERE school_id = %d AND status = 'active'", $school_id));
        $total_buses = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . NAIS_Bus_Tracking::table('buses') . " WHERE school_id = %d AND status = 'active'", $school_id));
        $total_exams = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . NAIS_Database::table('student_results') . " WHERE school_id = %d AND status = 'active'", $school_id));

        /* Get teacher-class assignments for display */
        $teacher_assignments = [];
        foreach ($teachers as $t) {
            $assigns = $wpdb->get_results($wpdb->prepare(
                "SELECT c.id AS class_id, tc.subject, tc.is_class_teacher, c.class_name, c.section
                 FROM " . NAIS_Database::table('teacher_classes') . " tc
                 JOIN " . NAIS_Database::table('classes') . " c ON tc.class_id = c.id
                 WHERE tc.teacher_id = %d AND c.status = 'active'",
                $t->id
            ));
            $teacher_assignments[$t->id] = $assigns;
        }

        ob_start();
        ?>
        <div class="nais-school-admin" data-school-id="<?php echo (int)$school_id; ?>">
            <?php if (NAIS_Payment::is_school_locked($school_id)) { echo NAIS_Payment::get_renewal_banner($school_id); echo '</div>'; return ob_get_clean(); } echo NAIS_Payment::get_renewal_banner($school_id); ?>
            <div class="nais-school-header"><h2><?php echo esc_html($school->name); ?></h2>
                <div class="nais-school-stats"><span class="nais-stat-badge"><?php echo count($classes); ?> Classes</span><span class="nais-stat-badge"><?php echo (int)$total_students; ?> Students</span><span class="nais-stat-badge"><?php echo count($teachers); ?> Teachers</span><span class="nais-stat-badge"><?php echo (int)$total_buses; ?> Buses</span><span class="nais-stat-badge"><?php echo (int)$total_exams; ?> Results</span></div></div>
            <div class="nais-tabs">
                <button class="nais-tab active" data-tab="classes">Classes</button><button class="nais-tab" data-tab="students">Students</button><button class="nais-tab" data-tab="teachers">Teachers</button><button class="nais-tab" data-tab="codes">Parent Codes</button><button class="nais-tab" data-tab="holidays">Holidays</button><button class="nais-tab" data-tab="alerts">Alerts</button><button class="nais-tab" data-tab="reports">Reports</button><button class="nais-tab" data-tab="buses">Buses</button><button class="nais-tab" data-tab="homework">Homework</button><button class="nais-tab" data-tab="results">Results</button><button class="nais-tab" data-tab="timetable">Timetable</button>
            </div>

            <!-- CLASSES --><div class="nais-tab-content active" id="nais-tab-classes"><h3>Manage Classes</h3>
                <form class="nais-inline-form" id="nais-add-class-form"><select name="class_name" required><option value="">Select Class</option><?php foreach (['Nursery','LKG','UKG','Class 1','Class 2','Class 3','Class 4','Class 5','Class 6','Class 7','Class 8','Class 9','Class 10','Class 11','Class 12'] as $co): ?><option value="<?php echo esc_attr($co); ?>"><?php echo esc_html($co); ?></option><?php endforeach; ?></select>
                    <select name="section"><option value="A">Section A</option><option value="B">Section B</option><option value="C">Section C</option><option value="D">Section D</option></select><button type="submit" class="nais-btn">Add Class</button></form>
                <table class="nais-table"><thead><tr><th>Class</th><th>Section</th><th>Students</th><th>Academic Year</th><th>Action</th></tr></thead><tbody id="nais-classes-list"><?php foreach ($classes as $c): ?><tr><td><?php echo esc_html($c->class_name); ?></td><td><?php echo esc_html($c->section); ?></td><td><?php echo (int)$c->student_count; ?></td><td><?php echo esc_html($c->academic_year); ?></td><td><button type="button" class="nais-btn nais-btn-xs nais-btn-danger nais-delete-class-btn" data-class-id="<?php echo (int)$c->id; ?>" data-class-name="<?php echo esc_attr($c->class_name . ' ' . $c->section); ?>" data-student-count="<?php echo (int)$c->student_count; ?>">Delete</button></td></tr><?php endforeach; ?></tbody></table></div>

            <!-- STUDENTS --><div class="nais-tab-content" id="nais-tab-students"><h3>Add Student</h3>
                <form class="nais-form" id="nais-add-student-form"><div class="nais-form-row"><label>Class *</label><select name="class_id" required><option value="">Select Class</option><?php foreach ($classes as $c): ?><option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option><?php endforeach; ?></select></div>
                    <div class="nais-form-row"><label>Student Name *</label><input type="text" name="name" required></div><div class="nais-form-row"><label>Roll No</label><input type="text" name="roll_no"></div><div class="nais-form-row"><label>Admission No</label><input type="text" name="admission_no"></div>
                    <div class="nais-form-row"><label>Gender</label><select name="gender"><option value="">Select</option><option value="male">Male</option><option value="female">Female</option><option value="other">Other</option></select></div><div class="nais-form-row"><label>Date of Birth</label><input type="date" name="dob"></div>
                    <div class="nais-form-row"><label>Parent/Guardian Name</label><input type="text" name="parent_name"></div><div class="nais-form-row"><label>Parent Phone</label><input type="tel" name="parent_phone"></div><button type="submit" class="nais-btn">Add Student</button></form><div id="nais-student-result" class="nais-result"></div>
                <h3 style="margin-top:32px;">Student List</h3>
                <div class="nais-inline-form" style="margin-bottom:16px;">
                    <select id="nais-students-filter-class"><option value="">All Classes</option><?php foreach ($classes as $c): ?><option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option><?php endforeach; ?></select>
                    <button type="button" class="nais-btn nais-btn-sm" id="nais-load-students-list">Load Students</button>
                </div>
                <div id="nais-students-list-container"><p class="nais-hint">Select a class and click "Load Students" to view and manage students.</p></div>
                <div class="nais-bulk-section"><h3>Bulk Upload Students (CSV)</h3><p class="nais-hint">Upload CSV to add many students at once.</p><div class="nais-bulk-steps"><div id="nais-bulk-step1"><div class="nais-form-row"><label>Class *</label><select id="nais-bulk-class" required><option value="">Select Class</option><?php foreach ($classes as $c): ?><option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option><?php endforeach; ?></select></div>
                    <div class="nais-form-row"><label>CSV File *</label><input type="file" id="nais-bulk-file" accept=".csv,.txt"><small class="nais-hint">Format: Name, Roll No, Gender, Parent Name, Parent Phone</small></div><div class="nais-bulk-template"><button type="button" class="nais-btn nais-btn-sm" id="nais-download-template">Download CSV Template</button><span style="margin-left:10px;color:#666;">or paste:</span></div>
                    <div class="nais-form-row"><label>Or Paste Student List</label><textarea id="nais-bulk-paste" rows="6" placeholder="Anya Longkumer, 1, female, Mrs. Longkumer, 9876543210"></textarea></div><button type="button" class="nais-btn" id="nais-bulk-preview">Preview Before Upload</button></div>
                    <div id="nais-bulk-step2" style="display:none;"><h4>Preview — <span id="nais-bulk-count">0</span> students found</h4><div class="nais-table-wrap"><table class="nais-table" id="nais-bulk-preview-table"><thead><tr><th>#</th><th>Name</th><th>Roll</th><th>Gender</th><th>Parent</th><th>Phone</th></tr></thead><tbody></tbody></table></div><div style="margin-top:16px;"><button type="button" class="nais-btn nais-btn-primary" id="nais-bulk-confirm">Upload All Students</button><button type="button" class="nais-btn nais-btn-sm" id="nais-bulk-back" style="margin-left:8px;">Go Back</button></div></div>
                    <div id="nais-bulk-step3" style="display:none;"><div id="nais-bulk-result"></div></div></div></div></div>

            <!-- TEACHERS (V2: Subject + Class Teacher per class) --><div class="nais-tab-content" id="nais-tab-teachers"><h3>Manage Teachers</h3>

                <!-- SUBJECTS (custom list manager) -->
                <?php $nais_default_subjects = self::$subjects; $nais_custom_subjects = self::get_custom_subjects($school_id); ?>
                <div class="nais-subjects-manager" style="margin-bottom:24px;padding:16px;border:1px solid #e5e7eb;border-radius:10px;background:#f9fafb;">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
                        <div>
                            <h4 style="margin:0;">Subjects</h4>
                            <p class="nais-hint" style="margin:4px 0 0;">Add subjects taught at your school. Defaults are always available; you can extend the list with new local or future subjects.</p>
                        </div>
                        <button type="button" class="nais-btn nais-btn-sm" id="nais-toggle-subject-manager" aria-expanded="false">Manage Subjects</button>
                    </div>
                    <div id="nais-subject-manager-body" style="display:none;margin-top:14px;">
                        <div style="margin-bottom:12px;">
                            <strong style="display:block;margin-bottom:6px;">Default subjects (built-in)</strong>
                            <div id="nais-default-subjects-list" style="display:flex;flex-wrap:wrap;gap:6px;">
                                <?php foreach ($nais_default_subjects as $subj): ?>
                                    <span class="nais-chip" style="display:inline-block;padding:4px 10px;border-radius:999px;background:#e5e7eb;color:#374151;font-size:12px;"><?php echo esc_html($subj); ?></span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div style="margin-bottom:12px;">
                            <strong style="display:block;margin-bottom:6px;">Your custom subjects</strong>
                            <div id="nais-custom-subjects-list" style="display:flex;flex-wrap:wrap;gap:6px;min-height:32px;">
                                <?php if (empty($nais_custom_subjects)): ?>
                                    <span class="nais-hint" id="nais-custom-subjects-empty">No custom subjects yet.</span>
                                <?php else: foreach ($nais_custom_subjects as $subj): ?>
                                    <span class="nais-chip nais-chip-custom" data-subject="<?php echo esc_attr($subj); ?>" style="display:inline-flex;align-items:center;gap:6px;padding:4px 6px 4px 10px;border-radius:999px;background:#dcfce7;color:#065f46;font-size:12px;">
                                        <span class="nais-chip-label"><?php echo esc_html($subj); ?></span>
                                        <button type="button" class="nais-delete-subject-btn" aria-label="Delete subject" data-subject="<?php echo esc_attr($subj); ?>" style="border:none;background:#10b981;color:#fff;width:18px;height:18px;border-radius:999px;cursor:pointer;line-height:1;font-size:12px;padding:0;">&times;</button>
                                    </span>
                                <?php endforeach; endif; ?>
                            </div>
                        </div>
                        <form class="nais-inline-form" id="nais-add-subject-form" onsubmit="return false;">
                            <input type="text" id="nais-new-subject-name" maxlength="100" placeholder="New subject name" autocomplete="off" style="min-width:220px;">
                            <button type="submit" class="nais-btn nais-btn-sm" id="nais-add-subject-btn">Add Subject</button>
                            <span id="nais-subject-result" class="nais-hint" style="margin-left:8px;"></span>
                        </form>
                        <p class="nais-hint" style="margin-top:10px;font-size:11px;">Tip: After adding a new subject, it will appear in the teacher subject dropdowns below. Existing teacher assignments are not affected.</p>
                    </div>
                </div>

                <form class="nais-form" id="nais-add-teacher-form" style="max-width:600px;">
                    <div class="nais-form-row"><label>Teacher Name *</label><input type="text" name="name" required></div>
                    <div class="nais-form-row"><label>Email * (for login)</label><input type="email" name="email" required></div>
                    <div class="nais-form-row"><label>Phone</label><input type="tel" name="phone"></div>
                    <div class="nais-form-row"><label>Employee ID</label><input type="text" name="employee_id"></div>
                    <div class="nais-form-row"><label>Designation</label><input type="text" name="designation" value="Teacher"></div>
                    <div class="nais-form-row">
                        <label>Assign to Classes</label>
                        <p class="nais-hint" style="margin-top:0;margin-bottom:10px;">Select classes, choose the subject taught, and tick if they are the class teacher.</p>
                        <div class="nais-teacher-class-list">
                            <?php foreach ($classes as $c): ?>
                                <div class="nais-teacher-class-row">
                                    <label class="nais-checkbox" style="min-width:140px;">
                                        <input type="checkbox" name="class_ids[]" value="<?php echo $c->id; ?>">
                                        <?php echo esc_html($c->class_name . ' ' . $c->section); ?>
                                    </label>
                                    <select name="subjects[<?php echo $c->id; ?>]" class="nais-teacher-subject-select">
                                        <option value="">Subject</option>
                                        <?php foreach (self::get_subjects_for_school($school_id) as $subj): ?>
                                            <option value="<?php echo esc_attr($subj); ?>"><?php echo esc_html($subj); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label class="nais-checkbox nais-ct-label">
                                        <input type="checkbox" name="class_teacher[<?php echo $c->id; ?>]" value="1"> Class Teacher
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="submit" class="nais-btn">Add Teacher</button>
                </form>
                <h4>Current Teachers</h4>
                <table class="nais-table"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Designation</th><th>Classes & Subjects</th><th>Action</th></tr></thead><tbody>
                    <?php foreach ($teachers as $t):
                        $assigns = $teacher_assignments[$t->id] ?? [];
                        $assign_text = [];
                        foreach ($assigns as $a) {
                            $label = $a->class_name . ' ' . $a->section;
                            if ($a->subject) $label .= ' (' . $a->subject . ')';
                            if ($a->is_class_teacher) $label .= ' ★';
                            $assign_text[] = $label;
                        }
                    ?>
                        <tr>
                            <td><?php echo esc_html($t->name); ?></td>
                            <td><?php echo esc_html($t->user_email); ?></td>
                            <td><?php echo esc_html($t->phone); ?></td>
                            <td><?php echo esc_html($t->designation); ?></td>
                            <td style="font-size:12px;"><?php echo esc_html(implode(', ', $assign_text) ?: '—'); ?></td>
                            <td><?php
                                $assign_json = [];
                                foreach ($assigns as $a) {
                                    $assign_json[] = ['class_id' => (int)$a->class_id, 'subject' => $a->subject, 'is_class_teacher' => (int)$a->is_class_teacher];
                                }
                            ?><button type="button" class="nais-btn nais-btn-xs nais-reassign-teacher-btn" data-teacher-id="<?php echo (int)$t->id; ?>" data-teacher-name="<?php echo esc_attr($t->name); ?>" data-assigns="<?php echo esc_attr(wp_json_encode($assign_json)); ?>">Reassign</button>
                            <button type="button" class="nais-btn nais-btn-xs nais-edit-teacher-btn" data-teacher-id="<?php echo (int)$t->id; ?>" data-name="<?php echo esc_attr($t->name); ?>" data-phone="<?php echo esc_attr($t->phone); ?>" data-employee-id="<?php echo esc_attr($t->employee_id); ?>" data-designation="<?php echo esc_attr($t->designation); ?>">Edit</button>
                            <button type="button" class="nais-btn nais-btn-xs nais-btn-danger nais-delete-teacher-btn" data-teacher-id="<?php echo (int)$t->id; ?>" data-teacher-name="<?php echo esc_attr($t->name); ?>">Delete</button></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody></table>

                <!-- Reassign Classes Panel (hidden by default) -->
                <div id="nais-reassign-panel" style="display:none;margin-top:20px;padding:20px;border:2px solid #10B981;border-radius:12px;background:#f0fdf4;">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
                        <h4 style="margin:0;color:#0F2419;">Reassign Classes for <span id="nais-reassign-teacher-name"></span></h4>
                        <button type="button" class="nais-btn nais-btn-xs" id="nais-reassign-cancel" style="background:#6B7280;">Cancel</button>
                    </div>
                    <input type="hidden" id="nais-reassign-teacher-id" value="">
                    <p class="nais-hint" style="margin-top:0;margin-bottom:10px;">Select classes, choose the subject taught, and tick if they are the class teacher.</p>
                    <div class="nais-teacher-class-list">
                        <?php foreach ($classes as $c): ?>
                            <div class="nais-teacher-class-row">
                                <label class="nais-checkbox" style="min-width:140px;">
                                    <input type="checkbox" name="reassign_class_ids[]" value="<?php echo $c->id; ?>">
                                    <?php echo esc_html($c->class_name . ' ' . $c->section); ?>
                                </label>
                                <select name="reassign_subjects[<?php echo $c->id; ?>]" class="nais-teacher-subject-select">
                                    <option value="">Subject</option>
                                    <?php foreach (self::get_subjects_for_school($school_id) as $subj): ?>
                                        <option value="<?php echo esc_attr($subj); ?>"><?php echo esc_html($subj); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <label class="nais-checkbox nais-ct-label">
                                    <input type="checkbox" name="reassign_class_teacher[<?php echo $c->id; ?>]" value="1"> Class Teacher
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="nais-btn nais-btn-primary" id="nais-reassign-save" style="margin-top:14px;">Save Assignments</button>
                </div>
            </div>

            <!-- PARENT CODES --><div class="nais-tab-content" id="nais-tab-codes">
                <h3>Student Code Lookup</h3>
                <p>Search for a student by name to find their parent code. Useful when parents lose their code slips.</p>
                <div class="nais-code-lookup">
                    <div class="nais-inline-form" id="nais-code-lookup-form">
                        <input type="text" id="nais-code-lookup-name" placeholder="Type student name..." autocomplete="off">
                        <select id="nais-code-lookup-class"><option value="">All Classes</option><?php foreach ($classes as $c): ?><option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option><?php endforeach; ?></select>
                        <button type="button" class="nais-btn" id="nais-code-lookup-btn">Search</button>
                    </div>
                    <div id="nais-code-lookup-results"></div>
                </div>
                <hr style="margin:32px 0;border:none;border-top:1px solid #e5e7eb;">
                <h3>Parent Code Slips</h3><p>Select a class to generate printable parent code slips.</p>
                <form id="nais-print-codes-form"><select name="class_id" required><option value="">Select Class</option><?php foreach ($classes as $c): ?><option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option><?php endforeach; ?></select><button type="submit" class="nais-btn">Generate Slips</button></form><div id="nais-slips-container"></div></div>

            <!-- HOLIDAYS --><div class="nais-tab-content" id="nais-tab-holidays"><h3>Holiday Calendar</h3><p>Set holidays and half-days in advance.</p>
                <div class="nais-holiday-add"><div class="nais-inline-form"><input type="date" id="nais-admin-holiday-date" min="<?php echo current_time('Y-m-d'); ?>"><select id="nais-admin-holiday-type"><option value="holiday">Holiday</option><option value="half_day">Half Day</option></select><input type="text" id="nais-admin-holiday-title" placeholder="Reason"><button class="nais-btn" id="nais-admin-add-holiday">Add</button></div></div>
                <div class="nais-holiday-month-nav" style="margin:16px 0;"><select id="nais-holiday-month"><?php for ($m = 1; $m <= 12; $m++): ?><option value="<?php echo $m; ?>" <?php selected($m, (int)current_time('m')); ?>><?php echo gmdate('F', mktime(0, 0, 0, $m)); ?></option><?php endfor; ?></select><input type="number" id="nais-holiday-year" value="<?php echo current_time('Y'); ?>" min="2024" max="2030"><button class="nais-btn nais-btn-sm" id="nais-load-holidays">Load</button></div><div id="nais-holidays-list"><p class="nais-hint">Click "Load" to see holidays.</p></div></div>

            <!-- ALERTS --><div class="nais-tab-content" id="nais-tab-alerts"><h3>Emergency Alerts</h3><p>Send alerts to all parents.</p><div class="nais-alert-form"><div class="nais-form-row"><label><strong>Alert Type *</strong></label><select id="nais-alert-type"><option value="emergency">🚨 Emergency</option><option value="announcement">📢 Announcement</option><option value="reminder">📋 Reminder</option><option value="holiday">🎉 Holiday/Closure</option></select></div>
                <div class="nais-form-row"><label><strong>Message *</strong></label><textarea id="nais-alert-message" rows="4" placeholder="e.g. School closing early due to heavy rain." required></textarea></div><div id="nais-alert-preview" style="display:none;"><h4>Preview:</h4><div id="nais-alert-preview-box"></div></div>
                <div style="margin-top:12px;"><button class="nais-btn nais-btn-sm" id="nais-preview-alert" type="button">Preview</button><button class="nais-btn nais-btn-primary" id="nais-send-alert" type="button" style="margin-left:8px;">Send Alert</button></div></div><h4 style="margin-top:32px;">Recent Alerts</h4><div id="nais-alerts-history"><p class="nais-hint">No alerts sent yet.</p></div></div>

            <!-- REPORTS --><div class="nais-tab-content" id="nais-tab-reports"><h3>Attendance Reports</h3>
                <form id="nais-report-form" class="nais-inline-form">
                    <select name="class_id" id="nais-report-class" required><option value="">Select Class</option><?php foreach ($classes as $c): ?><option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option><?php endforeach; ?></select>
                    <select name="month" id="nais-report-month"><?php for ($m = 1; $m <= 12; $m++): ?><option value="<?php echo $m; ?>" <?php selected($m, (int)current_time('m')); ?>><?php echo gmdate('F', mktime(0, 0, 0, $m)); ?></option><?php endfor; ?></select>
                    <input type="number" name="year" id="nais-report-year" value="<?php echo current_time('Y'); ?>" min="2024" max="2030">
                    <button type="submit" class="nais-btn">View Report</button>
                    <button type="button" class="nais-btn nais-btn-sm" id="nais-download-pdf" style="display:none;margin-left:8px;">Download PDF</button>
                </form><div id="nais-report-container"></div></div>

            <!-- BUSES --><div class="nais-tab-content" id="nais-tab-buses"><?php echo NAIS_Bus_Tracking::render_buses_tab($school_id, $classes); ?></div>

            <!-- HOMEWORK --><div class="nais-tab-content" id="nais-tab-homework"><?php echo NAIS_Homework::render_homework_tab($school_id, $classes); ?></div>

            <!-- RESULTS --><div class="nais-tab-content" id="nais-tab-results"><?php echo NAIS_Exam_Results::render_results_tab($school_id, $classes); ?></div>

            <!-- TIMETABLE --><div class="nais-tab-content" id="nais-tab-timetable"><?php echo NAIS_Timetable::render_timetable_tab($school_id, $classes); ?></div>
        </div>
        <script>
        (function(){
            if (window.naisSubjectManagerInit) return;
            window.naisSubjectManagerInit = true;
            document.addEventListener('DOMContentLoaded', function(){
                var root = document.querySelector('.nais-subjects-manager');
                if (!root) return;
                var toggleBtn = document.getElementById('nais-toggle-subject-manager');
                var body      = document.getElementById('nais-subject-manager-body');
                var list      = document.getElementById('nais-custom-subjects-list');
                var empty     = document.getElementById('nais-custom-subjects-empty');
                var input     = document.getElementById('nais-new-subject-name');
                var addBtn    = document.getElementById('nais-add-subject-btn');
                var resultEl  = document.getElementById('nais-subject-result');
                if (!toggleBtn || !body || !list || !input || !addBtn) return;

                var ajaxUrl = (window.naisData && naisData.ajaxUrl) || (typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php');
                var nonce   = (window.naisData && naisData.nonce) || '';

                function setResult(msg, isError){
                    if (!resultEl) return;
                    resultEl.textContent = msg || '';
                    resultEl.style.color = isError ? '#b91c1c' : '#065f46';
                }

                toggleBtn.addEventListener('click', function(){
                    var open = body.style.display !== 'none';
                    body.style.display = open ? 'none' : 'block';
                    toggleBtn.setAttribute('aria-expanded', open ? 'false' : 'true');
                });

                function postForm(action, data){
                    var body = new URLSearchParams();
                    body.append('action', action);
                    body.append('nonce', nonce);
                    Object.keys(data || {}).forEach(function(k){ body.append(k, data[k]); });
                    return fetch(ajaxUrl, {
                        method: 'POST',
                        credentials: 'same-origin',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                        body: body.toString()
                    }).then(function(r){ return r.json(); });
                }

                function escapeHtml(s){
                    return String(s).replace(/[&<>"']/g, function(c){
                        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
                    });
                }
                function escapeAttr(s){ return escapeHtml(s); }

                function appendCustomChip(name){
                    if (empty && empty.parentNode) empty.parentNode.removeChild(empty);
                    var span = document.createElement('span');
                    span.className = 'nais-chip nais-chip-custom';
                    span.setAttribute('data-subject', name);
                    span.style.cssText = 'display:inline-flex;align-items:center;gap:6px;padding:4px 6px 4px 10px;border-radius:999px;background:#dcfce7;color:#065f46;font-size:12px;';
                    span.innerHTML = '<span class="nais-chip-label">' + escapeHtml(name) + '</span>'
                        + '<button type="button" class="nais-delete-subject-btn" aria-label="Delete subject" data-subject="' + escapeAttr(name) + '" style="border:none;background:#10b981;color:#fff;width:18px;height:18px;border-radius:999px;cursor:pointer;line-height:1;font-size:12px;padding:0;">&times;</button>';
                    list.appendChild(span);
                }

                function addToTeacherDropdowns(name){
                    var selects = document.querySelectorAll('.nais-teacher-subject-select');
                    selects.forEach(function(sel){
                        var exists = false;
                        for (var i = 0; i < sel.options.length; i++) {
                            if (sel.options[i].value.toLowerCase() === name.toLowerCase()) { exists = true; break; }
                        }
                        if (!exists) {
                            var opt = document.createElement('option');
                            opt.value = name;
                            opt.textContent = name;
                            sel.appendChild(opt);
                        }
                    });
                }

                function removeFromTeacherDropdowns(name){
                    var selects = document.querySelectorAll('.nais-teacher-subject-select');
                    selects.forEach(function(sel){
                        for (var i = sel.options.length - 1; i >= 0; i--) {
                            if (sel.options[i].value.toLowerCase() === name.toLowerCase()) {
                                if (sel.options[i].selected) sel.selectedIndex = 0;
                                sel.remove(i);
                            }
                        }
                    });
                }

                addBtn.addEventListener('click', function(){
                    var name = (input.value || '').trim();
                    if (!name) { setResult('Please enter a subject name.', true); return; }
                    if (name.length > 100) { setResult('Subject name is too long (max 100).', true); return; }
                    addBtn.disabled = true;
                    setResult('Saving...', false);
                    postForm('nais_add_subject', {subject: name}).then(function(res){
                        addBtn.disabled = false;
                        if (res && res.success) {
                            appendCustomChip(res.data.subject);
                            addToTeacherDropdowns(res.data.subject);
                            input.value = '';
                            setResult('Added "' + res.data.subject + '".', false);
                        } else {
                            setResult((res && res.data) ? res.data : 'Failed to add subject.', true);
                        }
                    }).catch(function(){
                        addBtn.disabled = false;
                        setResult('Network error. Please try again.', true);
                    });
                });

                input.addEventListener('keydown', function(e){
                    if (e.key === 'Enter') { e.preventDefault(); addBtn.click(); }
                });

                list.addEventListener('click', function(e){
                    var btn = e.target.closest && e.target.closest('.nais-delete-subject-btn');
                    if (!btn) return;
                    var name = btn.getAttribute('data-subject') || '';
                    if (!name) return;
                    if (!window.confirm('Remove "' + name + '" from your custom subjects?\n\nExisting teacher assignments will not change.')) return;
                    btn.disabled = true;
                    postForm('nais_delete_subject', {subject: name}).then(function(res){
                        btn.disabled = false;
                        if (res && res.success) {
                            var chip = list.querySelector('.nais-chip-custom[data-subject="' + name.replace(/"/g, '\\"') + '"]');
                            if (chip) chip.remove();
                            removeFromTeacherDropdowns(name);
                            if (!list.querySelector('.nais-chip-custom')) {
                                var span = document.createElement('span');
                                span.className = 'nais-hint';
                                span.id = 'nais-custom-subjects-empty';
                                span.textContent = 'No custom subjects yet.';
                                list.appendChild(span);
                            }
                            setResult('Removed "' + name + '".', false);
                        } else {
                            setResult((res && res.data) ? res.data : 'Failed to remove subject.', true);
                        }
                    }).catch(function(){
                        btn.disabled = false;
                        setResult('Network error. Please try again.', true);
                    });
                });
            });
        })();
        </script>
        <?php return ob_get_clean();
    }

    /* ═══ ALL EXISTING AJAX HANDLERS — UNCHANGED (except ajax_add_teacher) ═══ */

    public static function ajax_add_class() {
        check_ajax_referer('nais_nonce', 'nonce'); if (!current_user_can('nais_manage_classes') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $school_id = NAIS_Roles::get_user_school_id(); $class_name = sanitize_text_field($_POST['class_name'] ?? ''); $section = sanitize_text_field($_POST['section'] ?? 'A');
        if (!$school_id || !$class_name) wp_send_json_error('Missing data.');
        if ($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . NAIS_Database::table('classes') . " WHERE school_id = %d AND class_name = %s AND section = %s AND academic_year = %s AND status = 'active'", $school_id, $class_name, $section, NAIS_ACADEMIC_YEAR))) wp_send_json_error('This class/section already exists.');
        /* Re-activate if previously deleted, otherwise insert new */
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . NAIS_Database::table('classes') . " WHERE school_id = %d AND class_name = %s AND section = %s AND academic_year = %s AND status = 'inactive'", $school_id, $class_name, $section, NAIS_ACADEMIC_YEAR));
        if ($existing) {
            $wpdb->update(NAIS_Database::table('classes'), ['status' => 'active'], ['id' => $existing]);
            $new_class_id = (int)$existing;
        } else {
            $wpdb->insert(NAIS_Database::table('classes'), ['school_id' => $school_id, 'class_name' => $class_name, 'section' => $section, 'academic_year' => NAIS_ACADEMIC_YEAR]);
            $new_class_id = $wpdb->insert_id;
        }
        NAIS_Database::audit_log('class_created', 'class', $new_class_id, $school_id, $class_name . ' ' . $section);
        wp_send_json_success(['message' => $class_name . ' ' . $section . ' created.', 'class_id' => $new_class_id, 'class_name' => $class_name, 'section' => $section, 'academic_year' => NAIS_ACADEMIC_YEAR]);
    }

    public static function ajax_add_student() {
        check_ajax_referer('nais_nonce', 'nonce'); if (!current_user_can('nais_manage_students') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $school_id = NAIS_Roles::get_user_school_id(); $name = sanitize_text_field($_POST['name'] ?? ''); $class_id = absint($_POST['class_id'] ?? 0);
        if (!$school_id || !$name || !$class_id) wp_send_json_error('Student name and class are required.');
        /* Verify class belongs to this school */
        $class_check = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d AND status = 'active'", $class_id, $school_id));
        if (!$class_check) wp_send_json_error('Class not found in your school.');
        /* Validate phone format if provided */
        $parent_phone = sanitize_text_field($_POST['parent_phone'] ?? '');
        if ($parent_phone && !preg_match('/^[\d\s\+\-()]{6,20}$/', $parent_phone)) {
            wp_send_json_error('Invalid phone number format.');
        }

        $parent_code = NAIS_Database::generate_parent_code();
        $result = $wpdb->insert(NAIS_Database::table('students'), ['school_id'=>$school_id,'class_id'=>$class_id,'roll_no'=>sanitize_text_field($_POST['roll_no']??''),'admission_no'=>sanitize_text_field($_POST['admission_no']??''),'name'=>$name,'gender'=>sanitize_text_field($_POST['gender']??''),'dob'=>sanitize_text_field($_POST['dob']??'')?:null,'parent_name'=>sanitize_text_field($_POST['parent_name']??''),'parent_phone'=>$parent_phone,'parent_code'=>$parent_code]);
        if (!$result) wp_send_json_error('Failed to add student. Please try again.');
        NAIS_Database::audit_log('student_added', 'student', $wpdb->insert_id, $school_id, $name);
        wp_send_json_success(['message'=>'Student added! Parent code: '.$parent_code,'parent_code'=>$parent_code,'student_id'=>$wpdb->insert_id]);
    }

    /** V2: Teacher form now sends subject + is_class_teacher per class */
    public static function ajax_add_teacher() {
        check_ajax_referer('nais_nonce', 'nonce'); if (!current_user_can('nais_manage_teachers') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $school_id = NAIS_Roles::get_user_school_id(); $name = sanitize_text_field($_POST['name']??''); $email = sanitize_email($_POST['email']??'');
        $phone = sanitize_text_field($_POST['phone']??''); $employee_id = sanitize_text_field($_POST['employee_id']??''); $designation = sanitize_text_field($_POST['designation']??'Teacher'); $class_ids = array_map('absint', $_POST['class_ids']??[]);
        if (!$school_id||!$name||!$email) wp_send_json_error('Name and email are required.');
        if (!is_email($email)) wp_send_json_error('Invalid email address.');
        if ($phone && !preg_match('/^[\d\s\+\-()]{6,20}$/', $phone)) wp_send_json_error('Invalid phone number format.');
        $user = get_user_by('email',$email);
        if (!$user) { $pw = wp_generate_password(12); $uid = wp_create_user($email,$pw,$email); if (is_wp_error($uid)) wp_send_json_error('Failed: '.$uid->get_error_message()); wp_update_user(['ID'=>$uid,'display_name'=>$name,'first_name'=>$name]); $user = get_user_by('id',$uid); wp_new_user_notification($uid,null,'user'); }
        $user->add_role(NAIS_Roles::TEACHER);
        $result = $wpdb->insert(NAIS_Database::table('teachers'), ['school_id'=>$school_id,'user_id'=>$user->ID,'name'=>$name,'phone'=>$phone,'employee_id'=>$employee_id,'designation'=>$designation]);
        if (!$result) wp_send_json_error('Failed to add teacher record. Please try again.');
        $tid = $wpdb->insert_id;

        /* V2: Use subject + is_class_teacher from form instead of hardcoding */
        $subjects_map     = $_POST['subjects'] ?? [];
        $class_teacher_map = $_POST['class_teacher'] ?? [];
        foreach ($class_ids as $cid) {
            /* Verify class belongs to this school */
            $cls_ok = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d AND status = 'active'", $cid, $school_id));
            if (!$cls_ok) continue;
            $subj  = sanitize_text_field($subjects_map[$cid] ?? '');
            $is_ct = !empty($class_teacher_map[$cid]) ? 1 : 0;
            $wpdb->insert(NAIS_Database::table('teacher_classes'), [
                'teacher_id'       => $tid,
                'class_id'         => $cid,
                'subject'          => $subj ?: 'General',
                'is_class_teacher' => $is_ct,
            ]);
        }

        NAIS_Database::audit_log('teacher_added', 'teacher', $tid, $school_id, $name);
        wp_send_json_success(['message'=>'Teacher '.$name.' added and login credentials sent to '.$email]);
    }

    /** Reassign classes/subjects for an existing teacher */
    public static function ajax_assign_teacher_class() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_teachers') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb;
        $school_id  = NAIS_Roles::get_user_school_id();
        $teacher_id = absint($_POST['teacher_id'] ?? 0);
        $class_ids  = array_map('absint', $_POST['class_ids'] ?? []);
        if (!$school_id || !$teacher_id) wp_send_json_error('Missing teacher or school.');

        /* Verify teacher belongs to this school */
        $teacher = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('teachers') . " WHERE id = %d AND school_id = %d AND status = 'active'",
            $teacher_id, $school_id
        ));
        if (!$teacher) wp_send_json_error('Teacher not found in your school.');

        /* Transaction: remove old assignments and insert new ones atomically */
        $subjects_map      = $_POST['subjects'] ?? [];
        $class_teacher_map = $_POST['class_teacher'] ?? [];

        $wpdb->query('START TRANSACTION');
        $wpdb->delete(NAIS_Database::table('teacher_classes'), ['teacher_id' => $teacher_id]);

        $assigned = 0;
        foreach ($class_ids as $cid) {
            /* Verify class belongs to same school */
            $cls = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d AND status = 'active'",
                $cid, $school_id
            ));
            if (!$cls) continue;
            $subj  = sanitize_text_field($subjects_map[$cid] ?? '');
            $is_ct = !empty($class_teacher_map[$cid]) ? 1 : 0;
            $result = $wpdb->insert(NAIS_Database::table('teacher_classes'), [
                'teacher_id'       => $teacher_id,
                'class_id'         => $cid,
                'subject'          => $subj ?: 'General',
                'is_class_teacher' => $is_ct,
            ]);
            if ($result) $assigned++;
        }

        if ($assigned > 0 || empty($class_ids)) {
            $wpdb->query('COMMIT');
        } else {
            $wpdb->query('ROLLBACK');
            wp_send_json_error('Failed to assign classes. Please try again.');
        }

        NAIS_Database::audit_log('teacher_classes_reassigned', 'teacher', $teacher_id, $school_id, $assigned . ' classes assigned');
        wp_send_json_success(['message' => 'Teacher reassigned to ' . $assigned . ' class(es).', 'assigned' => $assigned]);
    }

    public static function ajax_bulk_add_students() {
        check_ajax_referer('nais_nonce','nonce'); if (!current_user_can('nais_manage_students')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $school_id = NAIS_Roles::get_user_school_id(); $class_id = absint($_POST['class_id']??0);
        $raw_json = stripslashes($_POST['students'] ?? '');
        $rows = json_decode($raw_json, true);
        if (json_last_error() !== JSON_ERROR_NONE) wp_send_json_error('Invalid student data format.');
        if (!$school_id||!$class_id) wp_send_json_error('School and class required.'); if (empty($rows)||!is_array($rows)) wp_send_json_error('No student data.');
        $class = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".NAIS_Database::table('classes')." WHERE id=%d AND school_id=%d",$class_id,$school_id)); if (!$class) wp_send_json_error('Class not found.');
        $added=0;$skipped=0;$codes=[];
        foreach ($rows as $row) { $n=sanitize_text_field(trim($row['name']??'')); if(!$n){$skipped++;continue;} $pc=NAIS_Database::generate_parent_code();
            $r=$wpdb->insert(NAIS_Database::table('students'),['school_id'=>$school_id,'class_id'=>$class_id,'name'=>$n,'roll_no'=>sanitize_text_field(trim($row['roll_no']??'')),'gender'=>sanitize_text_field(trim($row['gender']??'')),'parent_name'=>sanitize_text_field(trim($row['parent_name']??'')),'parent_phone'=>sanitize_text_field(trim($row['parent_phone']??'')),'parent_code'=>$pc]);
            if($r){$added++;$codes[]=['name'=>$n,'parent_code'=>$pc];}else{$skipped++;}}
        NAIS_Database::audit_log('bulk_students_added','class',$class_id,$school_id,$added.' students added to '.$class->class_name.' '.$class->section);
        wp_send_json_success(['message'=>$added.' students added'.($skipped>0?', '.$skipped.' skipped':'').'.','added'=>$added,'skipped'=>$skipped,'codes'=>$codes,'class'=>$class->class_name.' '.$class->section]);
    }

    public static function ajax_get_parent_slips() {
        check_ajax_referer('nais_nonce','nonce'); if (!current_user_can('nais_generate_codes')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $cid=absint($_POST['class_id']??0); if(!$cid) wp_send_json_error('Select a class.');
        $school_id = NAIS_Roles::get_user_school_id();
        $cl=$wpdb->get_row($wpdb->prepare("SELECT c.*,s.name AS school_name FROM ".NAIS_Database::table('classes')." c JOIN ".NAIS_Database::table('schools')." s ON c.school_id=s.id WHERE c.id=%d",$cid));
        if (!$cl) wp_send_json_error('Class not found.');
        if ($school_id && (int)$cl->school_id !== $school_id) wp_send_json_error('Access denied.');
        $sts=$wpdb->get_results($wpdb->prepare("SELECT name,roll_no,parent_code,parent_name FROM ".NAIS_Database::table('students')." WHERE class_id=%d AND status='active' ORDER BY roll_no ASC,name ASC",$cid));
        if(empty($sts)) wp_send_json_error('No students.');
        $h='<div class="nais-slips-print"><div style="text-align:center;margin-bottom:20px"><h3>'.esc_html($cl->school_name).'</h3><p>'.esc_html($cl->class_name.' '.$cl->section).' — Parent Codes</p><button onclick="window.print()" class="nais-btn">Print Slips</button></div><div class="nais-slips-grid">';
        foreach($sts as $s){$h.='<div class="nais-slip"><div class="nais-slip-school">'.esc_html($cl->school_name).'</div><div class="nais-slip-student">'.esc_html($s->name).'</div><div class="nais-slip-class">'.esc_html($cl->class_name.' '.$cl->section).'</div><div class="nais-slip-code">'.esc_html($s->parent_code).'</div><div class="nais-slip-instructions">Go to <strong>schools.nagalandai.com/register</strong><br>Enter this code to check attendance.</div></div>';}
        $h.='</div></div>'; wp_send_json_success(['html'=>$h]);
    }

    public static function ajax_send_alert() {
        check_ajax_referer('nais_nonce','nonce'); if(!current_user_can('nais_manage_school')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        $sid=NAIS_Roles::get_user_school_id(); if(!$sid) wp_send_json_error('No school.'); $type=sanitize_text_field($_POST['type']??'announcement'); $msg=sanitize_textarea_field($_POST['message']??'');
        if(!$msg) wp_send_json_error('Message required.'); if(!in_array($type,['emergency','announcement','reminder','holiday'],true)) $type='announcement';
        $alerts=get_option("nais_school_{$sid}_alerts",[]); if(!is_array($alerts)) $alerts=[];
        $alert=['id'=>uniqid('alert_'),'type'=>$type,'message'=>$msg,'sent_by'=>get_current_user_id(),'sent_at'=>current_time('mysql'),'timestamp'=>time()];
        array_unshift($alerts,$alert); $alerts=array_slice($alerts,0,50); update_option("nais_school_{$sid}_alerts",$alerts);
        $tl=['emergency'=>'EMERGENCY','announcement'=>'Announcement','reminder'=>'Reminder','holiday'=>'Holiday/Closure'];
        NAIS_Database::audit_log('alert_sent','school',$sid,$sid,'['.($tl[$type]??$type).'] '.mb_substr($msg,0,200));
        global $wpdb; $pc=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT pl.parent_user_id) FROM ".NAIS_Database::table('parent_links')." pl JOIN ".NAIS_Database::table('students')." s ON pl.student_id=s.id WHERE s.school_id=%d AND pl.verified=1",$sid));
        wp_send_json_success(['message'=>($tl[$type]??$type).' alert sent! '.$pc.' parent(s) will be notified.','alert'=>$alert,'parent_count'=>$pc]);
    }

    public static function ajax_get_alerts() {
        check_ajax_referer('nais_nonce','nonce'); if(!current_user_can('nais_manage_school')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        $sid=NAIS_Roles::get_user_school_id(); if(!$sid) wp_send_json_error('No school.');
        $a=get_option("nais_school_{$sid}_alerts",[]); if(!is_array($a)) $a=[]; wp_send_json_success(['alerts'=>$a]);
    }

    public static function ajax_get_class_report() {
        check_ajax_referer('nais_nonce','nonce');
        if(!current_user_can('nais_view_reports')&&!current_user_can('nais_view_attendance')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $school_id=NAIS_Roles::get_user_school_id(); $class_id=absint($_POST['class_id']??0); $month=absint($_POST['month']??current_time('m')); $year=absint($_POST['year']??current_time('Y'));
        if(!$class_id) wp_send_json_error('Select a class.');
        $class=$wpdb->get_row($wpdb->prepare("SELECT c.*,s.name AS school_name FROM ".NAIS_Database::table('classes')." c JOIN ".NAIS_Database::table('schools')." s ON c.school_id=s.id WHERE c.id=%d",$class_id));
        if(!$class) wp_send_json_error('Class not found.');
        if (!$school_id && !current_user_can('nais_platform_admin')) wp_send_json_error('Access denied.');
        if ($school_id && (int)$class->school_id !== $school_id) wp_send_json_error('Access denied.');
        $students=$wpdb->get_results($wpdb->prepare("SELECT id,name,roll_no,gender FROM ".NAIS_Database::table('students')." WHERE class_id=%d AND status='active' ORDER BY roll_no ASC,name ASC",$class_id));
        if(empty($students)) wp_send_json_error('No students.');
        $start=sprintf('%04d-%02d-01',$year,$month); $end=gmdate('Y-m-t',strtotime($start)); $dim=(int)gmdate('t',strtotime($start)); $mn=gmdate('F',strtotime($start));
        $holidays=[]; foreach(NAIS_Database::get_holidays((int)$class->school_id,$month,$year) as $h){$holidays[(int)gmdate('j',strtotime($h->holiday_date))]=$h->type;}
        $sids=wp_list_pluck($students,'id'); $ph=implode(',',array_fill(0,count($sids),'%d'));
        $arows=$wpdb->get_results($wpdb->prepare("SELECT student_id,att_date,status FROM ".NAIS_Database::table('attendance_daily')." WHERE student_id IN($ph) AND att_date BETWEEN %s AND %s",array_merge($sids,[$start,$end])));
        $am=[]; foreach($arows as $a){$am[$a->student_id][(int)gmdate('j',strtotime($a->att_date))]=$a->status;}
        $report=[];$cp=0;$ca=0;
        foreach($students as $s){$days=[];$p=0;$ab=0;$lt=0;$ex=0;
            for($d=1;$d<=$dim;$d++){$ds=sprintf('%04d-%02d-%02d',$year,$month,$d);$dw=(int)gmdate('w',strtotime($ds));
                if($dw===0){$days[$d]='sunday';}elseif(isset($holidays[$d])){$days[$d]=$holidays[$d];}
                elseif(isset($am[$s->id][$d])){$st=$am[$s->id][$d];$days[$d]=$st;if($st==='present')$p++;elseif($st==='absent')$ab++;elseif($st==='late'){$lt++;$p++;}elseif($st==='excused')$ex++;}
                else{$days[$d]='';}}
            $wd=$p+$ab+$ex;$pct=$wd>0?round(($p/$wd)*100,1):0;$cp+=$p;$ca+=$ab;
            $report[]=['id'=>$s->id,'name'=>$s->name,'roll_no'=>$s->roll_no,'gender'=>$s->gender,'days'=>$days,'present'=>$p,'absent'=>$ab,'late'=>$lt,'excused'=>$ex,'percentage'=>$pct];}
        wp_send_json_success(['school'=>$class->school_name,'class'=>$class->class_name.' '.$class->section,'month'=>$mn,'year'=>$year,'days_in_month'=>$dim,'holidays'=>$holidays,'students'=>$report,'total'=>count($report),'class_present'=>$cp,'class_absent'=>$ca]);
    }

    public static function ajax_download_report_pdf() {
        if(!wp_verify_nonce($_POST['nonce']??'','nais_nonce')) wp_die('Security check failed.');
        if(!current_user_can('nais_view_reports')&&!current_user_can('nais_view_attendance')&&!current_user_can('nais_platform_admin')) wp_die('Permission denied.');
        global $wpdb; $class_id=absint($_POST['class_id']??0); $month=absint($_POST['month']??current_time('m')); $year=absint($_POST['year']??current_time('Y'));
        if(!$class_id) wp_die('Select a class.');
        $class=$wpdb->get_row($wpdb->prepare("SELECT c.*,s.name AS school_name FROM ".NAIS_Database::table('classes')." c JOIN ".NAIS_Database::table('schools')." s ON c.school_id=s.id WHERE c.id=%d",$class_id));
        if(!$class) wp_die('Class not found.');
        /* Verify school ownership */
        $school_id=NAIS_Roles::get_user_school_id();
        if (!$school_id && !current_user_can('nais_platform_admin')) wp_die('Access denied.');
        if ($school_id && (int)$class->school_id !== $school_id) wp_die('Access denied.');
        $students=$wpdb->get_results($wpdb->prepare("SELECT id,name,roll_no FROM ".NAIS_Database::table('students')." WHERE class_id=%d AND status='active' ORDER BY roll_no ASC,name ASC",$class_id));
        $start=sprintf('%04d-%02d-01',$year,$month);$end=gmdate('Y-m-t',strtotime($start));$dim=(int)gmdate('t',strtotime($start));$mn=gmdate('F',strtotime($start));
        $holidays=[];foreach(NAIS_Database::get_holidays((int)$class->school_id,$month,$year) as $h){$holidays[(int)gmdate('j',strtotime($h->holiday_date))]=$h->type;}
        $am=[];if(!empty($students)){$sids=wp_list_pluck($students,'id');$ph=implode(',',array_fill(0,count($sids),'%d'));
            $rows=$wpdb->get_results($wpdb->prepare("SELECT student_id,att_date,status FROM ".NAIS_Database::table('attendance_daily')." WHERE student_id IN($ph) AND att_date BETWEEN %s AND %s",array_merge($sids,[$start,$end])));
            foreach($rows as $a){$am[$a->student_id][(int)gmdate('j',strtotime($a->att_date))]=$a->status;}}
        header('Content-Type: text/html; charset=utf-8');
        echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Attendance — '.esc_html($class->class_name.' '.$class->section.' — '.$mn.' '.$year).'</title>';
        echo '<style>@import url("https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap");*{margin:0;padding:0;box-sizing:border-box}body{font-family:Outfit,Arial,sans-serif;font-size:11px;color:#333;padding:20px}.hd{text-align:center;margin-bottom:20px;border-bottom:2px solid #0A7558;padding-bottom:12px}.hd h1{font-size:18px;color:#0F2419}.hd h2{font-size:14px;color:#0A7558;font-weight:500}.hd p{font-size:11px;color:#666;margin-top:4px}.lg{display:flex;gap:16px;justify-content:center;margin:12px 0;font-size:10px;flex-wrap:wrap}.lg span{display:inline-flex;align-items:center;gap:4px}.lg .b{width:14px;height:14px;border-radius:3px;display:inline-block}.bP{background:#10B981}.bA{background:#EF4444}.bL{background:#F59E0B}.bE{background:#8B5CF6}.bH{background:#D1D5DB}.bS{background:#E5E7EB}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{border:1px solid #D1D5DB;padding:3px 4px;text-align:center;font-size:10px}th{background:#0F2419;color:#fff;font-weight:600;font-size:9px}.nc{text-align:left;min-width:100px;font-weight:500}.dc{width:22px}.sc{width:30px;font-weight:600}.P{background:#D1FAE5;color:#065F46;font-weight:700}.A{background:#FEE2E2;color:#991B1B;font-weight:700}.L{background:#FEF3C7;color:#92400E;font-weight:700}.E{background:#EDE9FE;color:#5B21B6;font-weight:700}.H{background:#F3F4F6;color:#9CA3AF}.Su{background:#F9FAFB;color:#D1D5DB}.sm{margin-top:16px;display:flex;gap:20px;flex-wrap:wrap}.sc2{background:#F9FAFB;border:1px solid #E5E7EB;border-radius:8px;padding:10px 16px;text-align:center}.sc2 .n{font-size:20px;font-weight:700;color:#0F2419}.sc2 .l{font-size:10px;color:#666}.ft{margin-top:20px;text-align:center;font-size:9px;color:#999;border-top:1px solid #E5E7EB;padding-top:8px}.np{margin:16px 0;text-align:center}.np button{background:#10B981;color:#fff;border:none;padding:10px 24px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;margin:0 4px;font-family:Outfit,sans-serif}.np button:hover{background:#0A7558}.np .bs{background:#6B7280}@media print{.np{display:none!important}body{padding:10px}@page{size:landscape;margin:10mm}}</style></head><body>';
        echo '<div class="np"><button onclick="window.print()">Print / Save as PDF</button><button class="bs" onclick="window.close()">Close</button></div>';
        echo '<div class="hd"><h1>'.esc_html($class->school_name).'</h1><h2>Attendance Report — '.esc_html($class->class_name.' '.$class->section).'</h2><p>'.esc_html($mn.' '.$year).' | Academic Year: '.esc_html(NAIS_ACADEMIC_YEAR).' | Generated: '.current_time('d M Y, h:i A').'</p></div>';
        echo '<div class="lg"><span><span class="b bP"></span> P=Present</span><span><span class="b bA"></span> A=Absent</span><span><span class="b bL"></span> L=Late</span><span><span class="b bE"></span> E=Excused</span><span><span class="b bH"></span> H=Holiday</span><span><span class="b bS"></span> S=Sunday</span></div>';
        echo '<table><thead><tr><th style="width:30px">#</th><th class="nc">Student Name</th>';
        for($d=1;$d<=$dim;$d++){$dn=gmdate('D',strtotime(sprintf('%04d-%02d-%02d',$year,$month,$d)));echo '<th class="dc">'.$d.'<br><small>'.substr($dn,0,2).'</small></th>';}
        echo '<th class="sc">P</th><th class="sc">A</th><th class="sc">L</th><th class="sc">%</th></tr></thead><tbody>';
        $tp=0;$ta=0;$rn=0;
        foreach($students as $s){$rn++;$pr=0;$ab=0;$lt=0;$ex=0;echo '<tr><td>'.esc_html($s->roll_no?:$rn).'</td><td class="nc">'.esc_html($s->name).'</td>';
            for($d=1;$d<=$dim;$d++){$ds=sprintf('%04d-%02d-%02d',$year,$month,$d);$dw=(int)gmdate('w',strtotime($ds));$c='';$cs='';
                if($dw===0){$c='S';$cs='Su';}elseif(isset($holidays[$d])){$c='H';$cs='H';}
                elseif(isset($am[$s->id][$d])){$st=$am[$s->id][$d];if($st==='present'){$c='P';$cs='P';$pr++;}elseif($st==='absent'){$c='A';$cs='A';$ab++;}elseif($st==='late'){$c='L';$cs='L';$lt++;$pr++;}elseif($st==='excused'){$c='E';$cs='E';$ex++;}}
                else{$c='-';}echo '<td class="dc '.$cs.'">'.$c.'</td>';}
            $wd=$pr+$ab+$ex;$pct=$wd>0?round(($pr/$wd)*100,0):0;$tp+=$pr;$ta+=$ab;
            echo '<td class="sc" style="color:#059669">'.$pr.'</td><td class="sc" style="color:#DC2626">'.$ab.'</td><td class="sc" style="color:#D97706">'.$lt.'</td><td class="sc">'.$pct.'%</td></tr>';}
        echo '</tbody></table>';
        echo '<div class="sm"><div class="sc2"><div class="n">'.count($students).'</div><div class="l">Total Students</div></div><div class="sc2"><div class="n" style="color:#059669">'.$tp.'</div><div class="l">Total Present</div></div><div class="sc2"><div class="n" style="color:#DC2626">'.$ta.'</div><div class="l">Total Absent</div></div></div>';
        echo '<div class="ft">Nagaland AI Schools — '.esc_html($class->school_name).' — schools.nagalandai.com<br>Powered by Nagaland Me (GST: 13DIHPA5679B1ZK)</div></body></html>';
        wp_die();
    }

    /* ═══════════════════════════════════════════
       DELETE / EDIT AJAX HANDLERS
    ═══════════════════════════════════════════ */

    /** AJAX: Get students list for a class (for the students table) */
    public static function ajax_get_students_list() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_students') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $class_id  = absint($_POST['class_id'] ?? 0);
        if (!$school_id) wp_send_json_error('No school found.');

        $where = $wpdb->prepare("WHERE school_id = %d AND status = 'active'", $school_id);
        if ($class_id) {
            $where .= $wpdb->prepare(" AND class_id = %d", $class_id);
        }

        $students = $wpdb->get_results(
            "SELECT s.id, s.name, s.roll_no, s.admission_no, s.gender, s.dob, s.parent_name, s.parent_phone, s.class_id, s.school_id, s.status, c.class_name, c.section
             FROM " . NAIS_Database::table('students') . " s
             LEFT JOIN " . NAIS_Database::table('classes') . " c ON s.class_id = c.id
             {$where}
             ORDER BY c.class_name ASC, c.section ASC, s.roll_no ASC, s.name ASC"
        );

        wp_send_json_success(['students' => $students]);
    }

    /** AJAX: Delete a student (soft delete — set status to inactive) */
    public static function ajax_delete_student() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_students') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id  = NAIS_Roles::get_user_school_id();
        $student_id = absint($_POST['student_id'] ?? 0);
        if (!$school_id || !$student_id) wp_send_json_error('Missing data.');

        $student = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('students') . " WHERE id = %d AND school_id = %d",
            $student_id, $school_id
        ));
        if (!$student) wp_send_json_error('Student not found in your school.');

        $wpdb->update(NAIS_Database::table('students'), ['status' => 'inactive'], ['id' => $student_id]);
        NAIS_Database::audit_log('student_deleted', 'student', $student_id, $school_id, 'Soft deleted: ' . $student->name);
        wp_send_json_success(['message' => 'Student "' . esc_html($student->name) . '" has been removed.']);
    }

    /** AJAX: Edit a student's details */
    public static function ajax_edit_student() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_students') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id  = NAIS_Roles::get_user_school_id();
        $student_id = absint($_POST['student_id'] ?? 0);
        $name       = sanitize_text_field($_POST['name'] ?? '');
        if (!$school_id || !$student_id || !$name) wp_send_json_error('Student name is required.');

        $student = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('students') . " WHERE id = %d AND school_id = %d",
            $student_id, $school_id
        ));
        if (!$student) wp_send_json_error('Student not found in your school.');

        $data = [
            'name'         => $name,
            'roll_no'      => sanitize_text_field($_POST['roll_no'] ?? ''),
            'admission_no' => sanitize_text_field($_POST['admission_no'] ?? ''),
            'gender'       => sanitize_text_field($_POST['gender'] ?? ''),
            'dob'          => sanitize_text_field($_POST['dob'] ?? '') ?: null,
            'parent_name'  => sanitize_text_field($_POST['parent_name'] ?? ''),
            'parent_phone' => sanitize_text_field($_POST['parent_phone'] ?? ''),
            'class_id'     => absint($_POST['class_id'] ?? $student->class_id),
        ];

        /* Verify class belongs to this school (always validate, not just on change) */
        $cls_ok = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d AND status = 'active'", $data['class_id'], $school_id));
        if (!$cls_ok) wp_send_json_error('Target class not found in your school.');

        $wpdb->update(NAIS_Database::table('students'), $data, ['id' => $student_id]);
        NAIS_Database::audit_log('student_edited', 'student', $student_id, $school_id, 'Updated: ' . $name);
        wp_send_json_success(['message' => 'Student "' . esc_html($name) . '" updated successfully.']);
    }

    /** AJAX: Delete a teacher (soft delete + remove role) */
    public static function ajax_delete_teacher() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_teachers') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id  = NAIS_Roles::get_user_school_id();
        $teacher_id = absint($_POST['teacher_id'] ?? 0);
        if (!$school_id || !$teacher_id) wp_send_json_error('Missing data.');

        $teacher = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('teachers') . " WHERE id = %d AND school_id = %d",
            $teacher_id, $school_id
        ));
        if (!$teacher) wp_send_json_error('Teacher not found in your school.');

        /* Soft delete teacher */
        $wpdb->update(NAIS_Database::table('teachers'), ['status' => 'inactive'], ['id' => $teacher_id]);

        /* Remove class assignments */
        $wpdb->delete(NAIS_Database::table('teacher_classes'), ['teacher_id' => $teacher_id]);

        /* Remove teacher role from WP user if they have no other active teacher records */
        $other_active = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . NAIS_Database::table('teachers') . " WHERE user_id = %d AND status = 'active' AND id != %d",
            $teacher->user_id, $teacher_id
        ));
        if (!$other_active) {
            $user = get_user_by('id', $teacher->user_id);
            if ($user) $user->remove_role(NAIS_Roles::TEACHER);
        }

        NAIS_Database::audit_log('teacher_deleted', 'teacher', $teacher_id, $school_id, 'Removed: ' . $teacher->name);
        wp_send_json_success(['message' => 'Teacher "' . esc_html($teacher->name) . '" has been removed.']);
    }

    /** AJAX: Edit a teacher's details */
    public static function ajax_edit_teacher() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_teachers') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id  = NAIS_Roles::get_user_school_id();
        $teacher_id = absint($_POST['teacher_id'] ?? 0);
        $name       = sanitize_text_field($_POST['name'] ?? '');
        if (!$school_id || !$teacher_id || !$name) wp_send_json_error('Teacher name is required.');

        $teacher = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('teachers') . " WHERE id = %d AND school_id = %d AND status = 'active'",
            $teacher_id, $school_id
        ));
        if (!$teacher) wp_send_json_error('Teacher not found in your school.');

        $data = [
            'name'        => $name,
            'phone'       => sanitize_text_field($_POST['phone'] ?? ''),
            'employee_id' => sanitize_text_field($_POST['employee_id'] ?? ''),
            'designation' => sanitize_text_field($_POST['designation'] ?? 'Teacher'),
        ];

        $wpdb->update(NAIS_Database::table('teachers'), $data, ['id' => $teacher_id]);

        /* Also update WP user display name */
        wp_update_user(['ID' => $teacher->user_id, 'display_name' => $name, 'first_name' => $name]);

        NAIS_Database::audit_log('teacher_edited', 'teacher', $teacher_id, $school_id, 'Updated: ' . $name);
        wp_send_json_success(['message' => 'Teacher "' . esc_html($name) . '" updated successfully.']);
    }

    /** AJAX: Delete a class (only if no active students) */
    public static function ajax_delete_class() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_classes') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $class_id  = absint($_POST['class_id'] ?? 0);
        if (!$school_id || !$class_id) wp_send_json_error('Missing data.');

        $class = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d",
            $class_id, $school_id
        ));
        if (!$class) wp_send_json_error('Class not found in your school.');

        /* Check for active students */
        $student_count = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . NAIS_Database::table('students') . " WHERE class_id = %d AND status = 'active'",
            $class_id
        ));
        if ($student_count > 0) {
            wp_send_json_error('Cannot delete — this class has ' . $student_count . ' active student(s). Remove or move the students first.');
        }

        /* Soft delete */
        $wpdb->update(NAIS_Database::table('classes'), ['status' => 'inactive'], ['id' => $class_id]);

        /* Remove teacher-class assignments for this class */
        $wpdb->delete(NAIS_Database::table('teacher_classes'), ['class_id' => $class_id]);

        NAIS_Database::audit_log('class_deleted', 'class', $class_id, $school_id, 'Removed: ' . $class->class_name . ' ' . $class->section);
        wp_send_json_success(['message' => $class->class_name . ' ' . $class->section . ' has been removed.']);
    }

    /* ═══════════════════════════════════════════
       HOLIDAY AJAX HANDLERS
    ═══════════════════════════════════════════ */

    /** Mark a holiday (or half-day) — school admin only */
    public static function ajax_mark_holiday() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        $date  = sanitize_text_field($_POST['date'] ?? '');
        $type  = sanitize_key($_POST['type'] ?? 'full');
        $title = sanitize_text_field($_POST['title'] ?? '');

        if (!$date) wp_send_json_error('Date is required.');
        if (!in_array($type, ['holiday', 'half_day'], true)) $type = 'holiday';

        $school_id = NAIS_Roles::get_user_school_id();
        if (!$school_id) wp_send_json_error('No school found for your account.');

        $id = NAIS_Database::add_holiday($school_id, $date, $type, $title);
        NAIS_Database::audit_log('holiday_marked', 'school', $school_id, $school_id, 'Holiday on ' . $date . ' (' . $type . ')');
        wp_send_json_success(['message' => 'Holiday marked.', 'id' => $id]);
    }

    /** Get holidays for a month */
    public static function ajax_get_holidays() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_mark_attendance') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        $month = absint($_POST['month'] ?? current_time('m'));
        $year  = absint($_POST['year'] ?? current_time('Y'));

        $school_id = NAIS_Roles::get_user_school_id();
        if (!$school_id) wp_send_json_error('No school found for your account.');

        $holidays = NAIS_Database::get_holidays($school_id, $month, $year);
        wp_send_json_success(['holidays' => $holidays]);
    }

    /** Remove a holiday */
    public static function ajax_remove_holiday() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        $date = sanitize_text_field($_POST['date'] ?? '');
        if (!$date) wp_send_json_error('Date is required.');

        $school_id = NAIS_Roles::get_user_school_id();
        if (!$school_id) wp_send_json_error('No school found for your account.');

        NAIS_Database::remove_holiday($school_id, $date);
        NAIS_Database::audit_log('holiday_removed', 'school', $school_id, $school_id, 'Holiday removed: ' . $date);
        wp_send_json_success(['message' => 'Holiday removed.']);
    }

    /** Lookup student parent codes by name search */
    public static function ajax_lookup_student_code() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_generate_codes') && !current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        if (!$school_id) wp_send_json_error('No school found for your account.');

        $search   = sanitize_text_field($_POST['search'] ?? '');
        $class_id = absint($_POST['class_id'] ?? 0);

        if (strlen($search) < 2) wp_send_json_error('Please enter at least 2 characters to search.');

        $sql = $wpdb->prepare(
            "SELECT s.name, s.roll_no, s.parent_code, s.parent_name, s.parent_phone, c.class_name, c.section
             FROM " . NAIS_Database::table('students') . " s
             JOIN " . NAIS_Database::table('classes') . " c ON s.class_id = c.id
             WHERE s.school_id = %d AND s.status = 'active' AND s.name LIKE %s",
            $school_id,
            '%' . $wpdb->esc_like($search) . '%'
        );

        if ($class_id) {
            $class_check = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d AND status = 'active'",
                $class_id, $school_id
            ));
            if (!$class_check) wp_send_json_error('Class not found in your school.');
            $sql .= $wpdb->prepare(" AND s.class_id = %d", $class_id);
        }

        $sql .= " ORDER BY c.class_name ASC, c.section ASC, s.name ASC LIMIT 50";

        $results = $wpdb->get_results($sql);

        if (empty($results)) wp_send_json_error('No students found matching "' . esc_html($search) . '".');

        $html = '<table class="nais-table nais-code-lookup-table"><thead><tr><th>Student Name</th><th>Class</th><th>Roll No</th><th>Parent/Guardian</th><th>Phone</th><th>Parent Code</th></tr></thead><tbody>';
        foreach ($results as $s) {
            $html .= '<tr>'
                . '<td>' . esc_html($s->name) . '</td>'
                . '<td>' . esc_html($s->class_name . ' ' . $s->section) . '</td>'
                . '<td>' . esc_html($s->roll_no ?: '-') . '</td>'
                . '<td>' . esc_html($s->parent_name ?: '-') . '</td>'
                . '<td>' . esc_html($s->parent_phone ?: '-') . '</td>'
                . '<td><span class="nais-code-highlight">' . esc_html($s->parent_code) . '</span></td>'
                . '</tr>';
        }
        $html .= '</tbody></table>';
        $html .= '<p class="nais-hint" style="margin-top:10px;">' . count($results) . ' student(s) found.</p>';

        wp_send_json_success(['html' => $html]);
    }

    /** Add a custom subject for the current school. */
    public static function ajax_add_subject() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }
        $school_id = NAIS_Roles::get_user_school_id();
        if (!$school_id) wp_send_json_error('No school assigned to your account.');

        $raw = isset($_POST['subject']) ? wp_unslash($_POST['subject']) : '';
        $subject = trim(sanitize_text_field($raw));
        if ($subject === '') wp_send_json_error('Subject name is required.');
        if (mb_strlen($subject) > 100) wp_send_json_error('Subject name is too long (max 100 characters).');

        $lower = mb_strtolower($subject);
        foreach (self::$subjects as $def) {
            if (mb_strtolower($def) === $lower) wp_send_json_error('That subject is already in the default list.');
        }

        $key = self::custom_subjects_option_key($school_id);
        $custom = self::get_custom_subjects($school_id);
        foreach ($custom as $c) {
            if (mb_strtolower($c) === $lower) wp_send_json_error('You have already added this subject.');
        }
        $custom[] = $subject;
        update_option($key, $custom, false);

        if (class_exists('NAIS_Database') && method_exists('NAIS_Database', 'audit_log')) {
            NAIS_Database::audit_log('subject_added', 'school', $school_id, $school_id, $subject);
        }
        wp_send_json_success(['subject' => $subject]);
    }

    /** Remove a custom subject for the current school (defaults are protected). */
    public static function ajax_delete_subject() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }
        $school_id = NAIS_Roles::get_user_school_id();
        if (!$school_id) wp_send_json_error('No school assigned to your account.');

        $raw = isset($_POST['subject']) ? wp_unslash($_POST['subject']) : '';
        $subject = trim(sanitize_text_field($raw));
        if ($subject === '') wp_send_json_error('Subject name is required.');

        $lower = mb_strtolower($subject);
        foreach (self::$subjects as $def) {
            if (mb_strtolower($def) === $lower) wp_send_json_error('Default subjects cannot be removed.');
        }

        $key = self::custom_subjects_option_key($school_id);
        $custom = self::get_custom_subjects($school_id);
        $new = [];
        $removed = false;
        foreach ($custom as $c) {
            if (mb_strtolower($c) === $lower) { $removed = true; continue; }
            $new[] = $c;
        }
        if (!$removed) wp_send_json_error('Subject not found in your custom list.');
        update_option($key, $new, false);

        if (class_exists('NAIS_Database') && method_exists('NAIS_Database', 'audit_log')) {
            NAIS_Database::audit_log('subject_removed', 'school', $school_id, $school_id, $subject);
        }
        wp_send_json_success(['subject' => $subject]);
    }
}

add_action('init', [NAIS_School_Admin::class, 'init']);