<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS API — REST Endpoints for NagalandAI Integration
 * ═══════════════════════════════════════════════════════════════
 *
 * Endpoints:
 *   GET /nais/v1/attendance?code=XXXXXX&date=YYYY-MM-DD&api_key=...
 *       → Returns attendance for the student on a specific date (defaults to today)
 *       → Includes holiday info if the date is a holiday
 *
 *   GET /nais/v1/attendance/report?code=XXXXXX&month=3&year=2026&api_key=...
 *       → Returns monthly attendance stats + day-by-day breakdown
 *
 *   GET /nais/v1/attendance/history?code=XXXXXX&from=YYYY-MM-DD&to=YYYY-MM-DD&api_key=...
 *       → Returns day-by-day attendance records for a date range (max 365 days)
 *
 *   GET /nais/v1/student?code=XXXXXX&api_key=...
 *       → Returns student info (name, class, school)
 *
 *   GET /nais/v1/school/holidays?code=XXXXXX&month=4&year=2026&api_key=...
 *       → Returns holiday list for the student's school
 *
 * Security:
 *   - API key required (shared between nagalandai.com and this site)
 *   - Rate limited
 *   - No sensitive data exposed (no DOB, no parent phone)
 */

if (!defined('ABSPATH')) exit;

class NAIS_API {

    /**
     * Register REST API routes.
     */
    public static function register_routes() {

        /* Today's attendance by parent code */
        register_rest_route('nais/v1', '/attendance', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_attendance'],
            'permission_callback' => [__CLASS__, 'verify_api_key'],
        ]);

        /* Monthly report by parent code */
        register_rest_route('nais/v1', '/attendance/report', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_report'],
            'permission_callback' => [__CLASS__, 'verify_api_key'],
        ]);

        /* Day-by-day attendance history for a date range */
        register_rest_route('nais/v1', '/attendance/history', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_history'],
            'permission_callback' => [__CLASS__, 'verify_api_key'],
        ]);

        /* Student info by parent code */
        register_rest_route('nais/v1', '/student', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_student'],
            'permission_callback' => [__CLASS__, 'verify_api_key'],
        ]);

        /* School holidays by parent code */
        register_rest_route('nais/v1', '/school/holidays', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_holidays'],
            'permission_callback' => [__CLASS__, 'verify_api_key'],
        ]);

        /* Health check */
        register_rest_route('nais/v1', '/health', [
            'methods'             => 'GET',
            'callback'            => function() {
                return new WP_REST_Response([
                    'status'  => 'ok',
                    'version' => NAIS_VERSION,
                    'time'    => current_time('mysql'),
                ], 200);
            },
            'permission_callback' => '__return_true',
        ]);
    }

    /**
     * Verify API key from request.
     */
    public static function verify_api_key($request) {
        $api_key = $request->get_param('api_key');

        if (!$api_key) {
            $api_key = $request->get_header('X-NAIS-API-Key');
        }

        if (!defined('NAIS_API_KEY') || !hash_equals(NAIS_API_KEY, (string)$api_key)) {
            return new WP_Error('unauthorized', 'Invalid API key.', ['status' => 401]);
        }

        /* Rate limit API calls */
        if (!NAIS_Database::check_rate_limit('api_call', 100, 5)) {
            return new WP_Error('rate_limited', 'Too many requests. Try again shortly.', ['status' => 429]);
        }

        return true;
    }

    /**
     * GET /nais/v1/attendance?code=XXXXXX&date=YYYY-MM-DD
     * Returns attendance for the student on a specific date (defaults to today).
     * Includes holiday info when applicable.
     */
    public static function get_attendance($request) {
        $code = sanitize_text_field($request->get_param('code'));

        if (!$code || strlen($code) < 6) {
            return new WP_REST_Response([
                'error' => 'Invalid parent code.',
            ], 400);
        }

        $student = self::get_student_by_code($code);
        if (!$student) {
            return new WP_REST_Response([
                'error' => 'No student found for this code.',
            ], 404);
        }

        /* Support optional date parameter — defaults to today */
        $date = sanitize_text_field($request->get_param('date'));
        if ($date && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            $query_date = $date;
        } else {
            $query_date = current_time('Y-m-d');
        }

        /* Check if this date is a holiday for the student's school */
        $holiday = NAIS_Database::check_holiday($student->school_id, $query_date);

        /* Get attendance for the requested date */
        global $wpdb;
        $daily = $wpdb->get_row($wpdb->prepare(
            "SELECT status, remarks, marked_at FROM " . NAIS_Database::table('attendance_daily') .
            " WHERE student_id = %d AND att_date = %s",
            $student->id, $query_date
        ));

        $periods = $wpdb->get_results($wpdb->prepare(
            "SELECT period_number, subject, status, marked_at FROM " . NAIS_Database::table('attendance_period') .
            " WHERE student_id = %d AND att_date = %s ORDER BY period_number ASC",
            $student->id, $query_date
        ));

        /* Format response for NagalandAI */
        $response = [
            'student_name'  => $student->name,
            'class'         => $student->class_name . ' ' . $student->section,
            'school'        => $student->school_name,
            'date'          => $query_date,
            'is_today'      => ($query_date === current_time('Y-m-d')),
            'holiday'       => null,
            'attendance'    => null,
            'periods'       => [],
        ];

        if ($holiday) {
            $response['holiday'] = [
                'type'  => $holiday->type,
                'title' => $holiday->title,
            ];
        }

        if ($daily) {
            $response['attendance'] = [
                'status'    => $daily->status,
                'remarks'   => $daily->remarks,
                'marked_at' => $daily->marked_at,
            ];
        }

        if (!empty($periods)) {
            foreach ($periods as $p) {
                $response['periods'][] = [
                    'period'  => (int)$p->period_number,
                    'subject' => $p->subject,
                    'status'  => $p->status,
                ];
            }
        }

        /* Log this API access */
        NAIS_Database::audit_log('api_attendance_query', 'student', $student->id, $student->school_id, [
            'code' => $code,
            'date' => $query_date,
        ]);

        return new WP_REST_Response($response, 200);
    }

    /**
     * GET /nais/v1/attendance/report?code=XXXXXX&month=3&year=2026
     * Returns monthly summary + day-by-day breakdown + holidays.
     */
    public static function get_report($request) {
        $code  = sanitize_text_field($request->get_param('code'));
        $month = absint($request->get_param('month')) ?: (int)current_time('m');
        $year  = absint($request->get_param('year')) ?: (int)current_time('Y');

        if (!$code || strlen($code) < 6) {
            return new WP_REST_Response(['error' => 'Invalid parent code.'], 400);
        }

        $student = self::get_student_by_code($code);
        if (!$student) {
            return new WP_REST_Response(['error' => 'No student found.'], 404);
        }

        $stats = NAIS_Attendance::get_student_stats($student->id, $month, $year);

        /* Day-by-day breakdown */
        global $wpdb;
        $start = sprintf('%04d-%02d-01', $year, $month);
        $end   = gmdate('Y-m-t', strtotime($start));

        $daily_records = $wpdb->get_results($wpdb->prepare(
            "SELECT att_date, status, remarks FROM " . NAIS_Database::table('attendance_daily') .
            " WHERE student_id = %d AND att_date BETWEEN %s AND %s ORDER BY att_date ASC",
            $student->id, $start, $end
        ));

        $days = [];
        foreach ($daily_records as $r) {
            $days[] = [
                'date'    => $r->att_date,
                'status'  => $r->status,
                'remarks' => $r->remarks,
            ];
        }

        /* Holidays for this month */
        $holidays_raw = NAIS_Database::get_holidays($student->school_id, $month, $year);
        $holidays = [];
        foreach ($holidays_raw as $h) {
            $holidays[] = [
                'date'  => $h->holiday_date,
                'type'  => $h->type,
                'title' => $h->title,
            ];
        }

        return new WP_REST_Response([
            'student_name' => $student->name,
            'class'        => $student->class_name . ' ' . $student->section,
            'school'       => $student->school_name,
            'month'        => $month,
            'year'         => $year,
            'summary'      => [
                'total_days' => (int)($stats->total_days ?? 0),
                'present'    => (int)($stats->present ?? 0),
                'absent'     => (int)($stats->absent ?? 0),
                'late'       => (int)($stats->late ?? 0),
                'excused'    => (int)($stats->excused ?? 0),
                'percentage' => (float)($stats->percentage ?? 0),
            ],
            'days'     => $days,
            'holidays' => $holidays,
        ], 200);
    }

    /**
     * GET /nais/v1/attendance/history?code=XXXXXX&from=YYYY-MM-DD&to=YYYY-MM-DD
     * Returns day-by-day attendance for a date range (max 365 days).
     * Perfect for yearly summaries and long-term audit.
     */
    public static function get_history($request) {
        $code = sanitize_text_field($request->get_param('code'));
        $from = sanitize_text_field($request->get_param('from'));
        $to   = sanitize_text_field($request->get_param('to'));

        if (!$code || strlen($code) < 6) {
            return new WP_REST_Response(['error' => 'Invalid parent code.'], 400);
        }

        $student = self::get_student_by_code($code);
        if (!$student) {
            return new WP_REST_Response(['error' => 'No student found.'], 404);
        }

        /* Default range: current academic month if not specified */
        if (!$from || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
            $from = gmdate('Y-m-01', strtotime(current_time('Y-m-d')));
        }
        if (!$to || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
            $to = current_time('Y-m-d');
        }

        /* Cap at 365 days to prevent abuse */
        $diff = (strtotime($to) - strtotime($from)) / DAY_IN_SECONDS;
        if ($diff < 0) {
            return new WP_REST_Response(['error' => '"from" date must be before "to" date.'], 400);
        }
        if ($diff > 365) {
            return new WP_REST_Response(['error' => 'Date range cannot exceed 365 days.'], 400);
        }

        global $wpdb;

        /* Get all attendance records in range */
        $records = $wpdb->get_results($wpdb->prepare(
            "SELECT att_date, status, remarks FROM " . NAIS_Database::table('attendance_daily') .
            " WHERE student_id = %d AND att_date BETWEEN %s AND %s ORDER BY att_date ASC",
            $student->id, $from, $to
        ));

        $days = [];
        $summary = ['present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0];
        foreach ($records as $r) {
            $days[] = [
                'date'    => $r->att_date,
                'status'  => $r->status,
                'remarks' => $r->remarks,
            ];
            if (isset($summary[$r->status])) {
                $summary[$r->status]++;
            }
        }
        $summary['total_days'] = count($records);
        $summary['percentage'] = $summary['total_days'] > 0
            ? round((($summary['present'] + $summary['late']) / $summary['total_days']) * 100, 1)
            : 0;

        /* Get holidays in the range */
        $holidays_raw = $wpdb->get_results($wpdb->prepare(
            "SELECT holiday_date, type, title FROM " . NAIS_Database::table('holidays') .
            " WHERE school_id = %d AND holiday_date BETWEEN %s AND %s ORDER BY holiday_date ASC",
            $student->school_id, $from, $to
        ));
        $holidays = [];
        foreach ($holidays_raw as $h) {
            $holidays[] = [
                'date'  => $h->holiday_date,
                'type'  => $h->type,
                'title' => $h->title,
            ];
        }

        NAIS_Database::audit_log('api_history_query', 'student', $student->id, $student->school_id, [
            'code' => $code,
            'from' => $from,
            'to'   => $to,
        ]);

        return new WP_REST_Response([
            'student_name' => $student->name,
            'class'        => $student->class_name . ' ' . $student->section,
            'school'       => $student->school_name,
            'from'         => $from,
            'to'           => $to,
            'summary'      => $summary,
            'days'         => $days,
            'holidays'     => $holidays,
        ], 200);
    }

    /**
     * GET /nais/v1/student?code=XXXXXX
     */
    public static function get_student($request) {
        $code = sanitize_text_field($request->get_param('code'));

        if (!$code || strlen($code) < 6) {
            return new WP_REST_Response(['error' => 'Invalid parent code.'], 400);
        }

        $student = self::get_student_by_code($code);
        if (!$student) {
            return new WP_REST_Response(['error' => 'No student found.'], 404);
        }

        return new WP_REST_Response([
            'name'    => $student->name,
            'class'   => $student->class_name . ' ' . $student->section,
            'school'  => $student->school_name,
            'roll_no' => $student->roll_no,
        ], 200);
    }

    /**
     * GET /nais/v1/school/holidays?code=XXXXXX&month=4&year=2026
     * Returns holidays for the student's school in a given month.
     */
    public static function get_holidays($request) {
        $code  = sanitize_text_field($request->get_param('code'));
        $month = absint($request->get_param('month')) ?: (int)current_time('m');
        $year  = absint($request->get_param('year')) ?: (int)current_time('Y');

        if (!$code || strlen($code) < 6) {
            return new WP_REST_Response(['error' => 'Invalid parent code.'], 400);
        }

        $student = self::get_student_by_code($code);
        if (!$student) {
            return new WP_REST_Response(['error' => 'No student found.'], 404);
        }

        $holidays_raw = NAIS_Database::get_holidays($student->school_id, $month, $year);
        $holidays = [];
        foreach ($holidays_raw as $h) {
            $holidays[] = [
                'date'  => $h->holiday_date,
                'type'  => $h->type,
                'title' => $h->title,
            ];
        }

        return new WP_REST_Response([
            'school'   => $student->school_name,
            'month'    => $month,
            'year'     => $year,
            'holidays' => $holidays,
        ], 200);
    }

    /**
     * Lookup student by parent code.
     */
    private static function get_student_by_code($code) {
        global $wpdb;

        return $wpdb->get_row($wpdb->prepare(
            "SELECT s.*, sc.name AS school_name, c.class_name, c.section
             FROM " . NAIS_Database::table('students') . " s
             JOIN " . NAIS_Database::table('schools') . " sc ON s.school_id = sc.id
             JOIN " . NAIS_Database::table('classes') . " c ON s.class_id = c.id
             WHERE s.parent_code = %s AND s.status = 'active'",
            $code
        ));
    }
}