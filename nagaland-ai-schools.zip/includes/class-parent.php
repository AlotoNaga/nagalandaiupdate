<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS PARENT — Registration & Child Attendance View
 * ═══════════════════════════════════════════════════════════════
 *
 * Parent registration flow:
 * 1. School gives parent a slip with 6-digit code
 * 2. Parent visits schools.nagalandai.com/register
 * 3. Enters code + creates account (or links to existing)
 * 4. Can now view child's attendance, homework, results,
 *    timetable + ask NagalandAI
 *
 * V2: Homework = read-only teacher checklist view (no submission).
 *     Results = document view (dues-gated).
 *     Timetable = weekly grid + exam schedule.
 *
 * Brute-force protected: 5 attempts, 30-minute lockout.
 */

if (!defined('ABSPATH')) exit;

class NAIS_Parent {

    /**
     * Parent registration shortcode.
     */
    public static function register_shortcode() {
        /* Already logged in parent → redirect to child view */
        if (is_user_logged_in() && current_user_can('nais_view_own_child')) {
            return self::my_child_shortcode();
        }

        ob_start();
        $error   = '';
        $success = '';

        if (isset($_POST['nais_parent_register']) && wp_verify_nonce($_POST['_nais_nonce'], 'nais_parent_register')) {

            $parent_code = sanitize_text_field($_POST['parent_code'] ?? '');
            $email       = sanitize_email($_POST['email'] ?? '');
            $password    = $_POST['password'] ?? '';
            $phone       = sanitize_text_field($_POST['phone'] ?? '');

            /* Rate limit check */
            if (!NAIS_Database::check_rate_limit('parent_register', 5, 30)) {
                $error = 'Too many attempts. Please wait 30 minutes and try again.';
            } elseif (!$parent_code || strlen($parent_code) !== 6) {
                $error = 'Please enter your 6-digit parent code from the school slip.';
            } elseif (!$email || !$password) {
                $error = 'Email and password are required.';
            } else {
                global $wpdb;

                /* Find student with this code */
                $student = $wpdb->get_row($wpdb->prepare(
                    "SELECT s.*, sc.name AS school_name, c.class_name, c.section
                     FROM " . NAIS_Database::table('students') . " s
                     JOIN " . NAIS_Database::table('schools') . " sc ON s.school_id = sc.id
                     JOIN " . NAIS_Database::table('classes') . " c ON s.class_id = c.id
                     WHERE s.parent_code = %s AND s.status = 'active'",
                    $parent_code
                ));

                if (!$student) {
                    $error = 'Invalid parent code. Please check the code on your slip and try again.';
                } else {
                    /* Create or get WP user */
                    $user = get_user_by('email', $email);

                    if (!$user) {
                        $user_id = wp_create_user($email, $password, $email);
                        if (is_wp_error($user_id)) {
                            $error = $user_id->get_error_message();
                        } else {
                            $user = get_user_by('id', $user_id);
                            $user->set_role(NAIS_Roles::PARENT);

                            wp_update_user([
                                'ID'           => $user_id,
                                'display_name' => sanitize_text_field($_POST['parent_name'] ?? $student->parent_name),
                                'first_name'   => sanitize_text_field($_POST['parent_name'] ?? $student->parent_name),
                            ]);

                            if ($phone) {
                                update_user_meta($user_id, 'nais_phone', $phone);
                            }
                        }
                    } else {
                        /* Existing user — verify password before linking */
                        if (!wp_check_password($password, $user->data->user_pass, $user->ID)) {
                            $error = 'Incorrect password for this email. If you already have an account, please use your existing password.';
                        } else {
                            if (!in_array(NAIS_Roles::PARENT, $user->roles, true)) {
                                $user->add_role(NAIS_Roles::PARENT);
                            }
                        }
                    }

                    if ($user && !$error) {
                        /* Check if already linked */
                        $already = $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM " . NAIS_Database::table('parent_links') .
                            " WHERE parent_user_id = %d AND student_id = %d",
                            $user->ID, $student->id
                        ));

                        if (!$already) {
                            $wpdb->insert(NAIS_Database::table('parent_links'), [
                                'student_id'     => $student->id,
                                'parent_user_id' => $user->ID,
                                'parent_code'    => $parent_code,
                                'verified'       => 1,
                            ]);
                        }

                        NAIS_Database::audit_log('parent_registered', 'parent_link', $student->id, $student->school_id, [
                            'parent_user_id' => $user->ID,
                            'student_name'   => $student->name,
                        ]);

                        /* Reset rate limit on success */
                        NAIS_Database::reset_rate_limit('parent_register');

                        /* Auto-login */
                        wp_set_current_user($user->ID);
                        wp_set_auth_cookie($user->ID);

                        $success = sprintf(
                            'Registration successful! You are now linked to <strong>%s</strong> (%s %s) at <strong>%s</strong>.',
                            esc_html($student->name),
                            esc_html($student->class_name),
                            esc_html($student->section),
                            esc_html($student->school_name)
                        );
                    }
                }
            }
        }

        ?>
        <div class="nais-parent-register">
            <div class="nais-register-card">
                <h2>Parent Registration</h2>
                <p>Enter the 6-digit code from the slip your child's school gave you.</p>

                <?php if ($error): ?>
                    <div class="nais-alert nais-alert-error"><?php echo esc_html($error); ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="nais-alert nais-alert-success"><?php echo $success; ?></div>
                    <p><a href="<?php echo home_url('/dashboard/'); ?>" class="nais-btn">View Your Child's Attendance</a></p>
                <?php else: ?>

                    <form method="post" class="nais-form">
                        <?php wp_nonce_field('nais_parent_register', '_nais_nonce'); ?>

                        <div class="nais-form-row">
                            <label>6-Digit Parent Code *</label>
                            <input type="text" name="parent_code" maxlength="6" pattern="[0-9A-Za-z]{6}" required
                                   class="nais-code-input" placeholder="e.g. 482716"
                                   value="<?php echo esc_attr($_POST['parent_code'] ?? ''); ?>">
                        </div>

                        <div class="nais-form-row">
                            <label>Your Name</label>
                            <input type="text" name="parent_name"
                                   value="<?php echo esc_attr($_POST['parent_name'] ?? ''); ?>">
                        </div>

                        <div class="nais-form-row">
                            <label>Email Address *</label>
                            <input type="email" name="email" required
                                   value="<?php echo esc_attr($_POST['email'] ?? ''); ?>">
                        </div>

                        <div class="nais-form-row">
                            <label>Password *</label>
                            <input type="password" name="password" required minlength="6">
                        </div>

                        <div class="nais-form-row">
                            <label>Phone Number</label>
                            <input type="tel" name="phone"
                                   value="<?php echo esc_attr($_POST['phone'] ?? ''); ?>">
                        </div>

                        <button type="submit" name="nais_parent_register" class="nais-btn nais-btn-primary nais-btn-lg">Register</button>
                    </form>

                    <p class="nais-hint">Already registered? <a href="<?php echo wp_login_url(home_url('/dashboard/')); ?>">Log in here</a></p>

                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }


    /**
     * My Child shortcode — parent views attendance, homework, results, timetable.
     */
    public static function my_child_shortcode() {
        if (!is_user_logged_in()) {
            return '<div class="nais-login-prompt"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">My Child\'s Attendance</h2><p>Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to view your child\'s attendance.</p></div>';
        }

        global $wpdb;
        $user_id = get_current_user_id();

        /* Get linked students */
        $students = $wpdb->get_results($wpdb->prepare(
            "SELECT s.*, sc.name AS school_name, c.class_name, c.section, pl.parent_code AS my_parent_code
             FROM " . NAIS_Database::table('parent_links') . " pl
             JOIN " . NAIS_Database::table('students') . " s ON pl.student_id = s.id
             JOIN " . NAIS_Database::table('schools') . " sc ON s.school_id = sc.id
             JOIN " . NAIS_Database::table('classes') . " c ON s.class_id = c.id
             WHERE pl.parent_user_id = %d AND pl.verified = 1 AND s.status = 'active'",
            $user_id
        ));

        if (empty($students)) {
            return '<div class="nais-msg"><p>No child linked to your account. <a href="' . home_url('/register/') . '">Register with your parent code</a>.</p></div>';
        }

        $month = (int)current_time('m');
        $year  = (int)current_time('Y');

        ob_start();
        ?>
        <div class="nais-parent-view">

            <?php foreach ($students as $student): ?>
                <?php
                $stats = NAIS_Attendance::get_student_stats($student->id, $month, $year);
                $today = NAIS_Attendance::get_student_today($student->id);
                ?>
                <div class="nais-child-card">
                    <div class="nais-child-header">
                        <h3><?php echo esc_html($student->name); ?></h3>
                        <p><?php echo esc_html($student->class_name . ' ' . $student->section); ?> — <?php echo esc_html($student->school_name); ?></p>
                        <p class="nais-parent-code-display">Your Parent Code: <span class="nais-code-highlight"><?php echo esc_html($student->my_parent_code); ?></span></p>
                    </div>

                    <!-- Today's Status -->
                    <div class="nais-today-status">
                        <h4>Today (<?php echo current_time('j M Y'); ?>)</h4>
                        <?php if ($today['daily']): ?>
                            <div class="nais-status-badge nais-status-<?php echo esc_attr($today['daily']->status); ?>">
                                <?php echo ucfirst(esc_html($today['daily']->status)); ?>
                            </div>
                            <small>Marked at <?php echo esc_html(wp_date('g:i A', strtotime($today['daily']->marked_at))); ?></small>

                            <?php if (!empty($today['periods'])): ?>
                                <div class="nais-periods">
                                    <h5>Period-wise:</h5>
                                    <?php foreach ($today['periods'] as $p): ?>
                                        <span class="nais-period-badge nais-status-<?php echo esc_attr($p->status); ?>">
                                            P<?php echo (int)$p->period_number; ?>: <?php echo ucfirst($p->status); ?>
                                            <?php echo $p->subject ? '(' . esc_html($p->subject) . ')' : ''; ?>
                                        </span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="nais-status-badge nais-status-pending">Not marked yet</div>
                        <?php endif; ?>
                    </div>

                    <!-- Bus Tracking -->
                    <div class="nais-bus-section" style="margin-top:20px;padding:20px;background:#f9fafb;border-radius:14px;">
                        <h4 style="font-size:13px;color:#9ca3af;text-transform:uppercase;margin-bottom:10px;">Bus Tracking</h4>
                        <p style="font-size:14px;color:#666;margin-bottom:12px;">Track your child's school bus in real-time when a trip is active.</p>
                        <button id="nais-track-bus-btn" class="nais-btn nais-btn-sm">Track My Child's Bus</button>
                        <div id="nais-bus-map-container"></div>
                    </div>

                    <!-- Homework (V2: read-only teacher checklist view) -->
                    <?php echo NAIS_Homework::render_parent_homework($student); ?>

                    <!-- Exam Results (V2: document view, dues-gated) -->
                    <?php echo NAIS_Exam_Results::render_parent_results($student); ?>

                    <!-- Timetable (V2: weekly grid + exam schedule) -->
                    <?php echo NAIS_Timetable::render_parent_timetable($student); ?>

                    <!-- Monthly Stats -->
                    <div class="nais-monthly-stats">
                        <h4><?php echo wp_date('F Y', mktime(0, 0, 0, $month, 1, $year)); ?> Summary</h4>
                        <div class="nais-stats-grid">
                            <div class="nais-stat-item">
                                <div class="nais-stat-number"><?php echo $stats->percentage; ?>%</div>
                                <div class="nais-stat-label">Attendance</div>
                            </div>
                            <div class="nais-stat-item nais-stat-present">
                                <div class="nais-stat-number"><?php echo $stats->present; ?></div>
                                <div class="nais-stat-label">Present</div>
                            </div>
                            <div class="nais-stat-item nais-stat-absent">
                                <div class="nais-stat-number"><?php echo $stats->absent; ?></div>
                                <div class="nais-stat-label">Absent</div>
                            </div>
                            <div class="nais-stat-item nais-stat-late">
                                <div class="nais-stat-number"><?php echo $stats->late; ?></div>
                                <div class="nais-stat-label">Late</div>
                            </div>
                        </div>
                    </div>

                    <!-- AI Tip -->
                    <div class="nais-ai-tip">
                        <p>You can also ask <strong>Nagaland AI</strong>: <em>"Did <?php echo esc_html($student->name); ?> go to school today?"</em></p>
                        <a href="https://nagalandai.com" target="_blank" class="nais-btn nais-btn-sm">Ask Nagaland AI</a>
                    </div>

                    <!-- DPDP Compliance -->
                    <div class="nais-privacy-section">
                        <small>Your data is protected under the DPDP Act 2023.
                        <a href="#" class="nais-delete-request" data-student="<?php echo (int)$student->id; ?>">Request data deletion</a></small>
                    </div>
                </div>
            <?php endforeach; ?>

        </div>
        <?php
        return ob_get_clean();
    }
}