<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS DATABASE — 11 Tables, Government-Ready Schema
 * ═══════════════════════════════════════════════════════════════
 *
 * Designed for 1,00,000+ students across multiple schools.
 * Every query column is indexed. Compound indexes on attendance
 * tables ensure sub-second lookups even at massive scale.
 *
 * UDISE codes, district/block fields, and academic_year isolation
 * make this ready for Nagaland state government adoption.
 */

if (!defined('ABSPATH')) exit;

class NAIS_Database {

    /**
     * Get table name with WP prefix.
     */
    public static function table($name) {
        global $wpdb;
        return $wpdb->prefix . 'nais_' . $name;
    }

    /**
     * Create all 11 tables (schools, classes, students, teachers, teacher_classes, attendance_daily, attendance_period, parent_links, audit_log, rate_limits, holidays).
     * Uses dbDelta for safe upgrades.
     */
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        /* ═══════════════════════════════════════════
           TABLE 1: SCHOOLS
           Central registry of all schools.
           UDISE code is the govt standard identifier.
        ═══════════════════════════════════════════ */
        $schools = self::table('schools');
        dbDelta("CREATE TABLE {$schools} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name            VARCHAR(255)    NOT NULL,
            district        VARCHAR(100)    NOT NULL DEFAULT '',
            block           VARCHAR(100)    NOT NULL DEFAULT '',
            village_town    VARCHAR(100)    NOT NULL DEFAULT '',
            pin_code        VARCHAR(10)     NOT NULL DEFAULT '',
            udise_code      VARCHAR(20)     NOT NULL DEFAULT '',
            board           VARCHAR(20)     NOT NULL DEFAULT 'NBSE',
            phone           VARCHAR(20)     NOT NULL DEFAULT '',
            email           VARCHAR(100)    NOT NULL DEFAULT '',
            address         TEXT            NOT NULL,
            admin_user_id   BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status          VARCHAR(20)     NOT NULL DEFAULT 'active',
            created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY udise_code (udise_code),
            KEY district (district),
            KEY block (block),
            KEY status (status),
            KEY admin_user_id (admin_user_id)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 2: CLASSES
           Class + Section per school per academic year.
        ═══════════════════════════════════════════ */
        $classes = self::table('classes');
        dbDelta("CREATE TABLE {$classes} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            school_id       BIGINT UNSIGNED NOT NULL,
            class_name      VARCHAR(50)     NOT NULL,
            section         VARCHAR(10)     NOT NULL DEFAULT 'A',
            academic_year   VARCHAR(15)     NOT NULL DEFAULT '2026-2027',
            status          VARCHAR(20)     NOT NULL DEFAULT 'active',
            created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY school_id (school_id),
            KEY school_class (school_id, class_name, section, academic_year),
            KEY academic_year (academic_year)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 3: STUDENTS
           One row per student. parent_code is the
           unique 6-digit code printed on slips.
        ═══════════════════════════════════════════ */
        $students = self::table('students');
        dbDelta("CREATE TABLE {$students} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            school_id       BIGINT UNSIGNED NOT NULL,
            class_id        BIGINT UNSIGNED NOT NULL,
            roll_no         VARCHAR(20)     NOT NULL DEFAULT '',
            admission_no    VARCHAR(50)     NOT NULL DEFAULT '',
            name            VARCHAR(255)    NOT NULL,
            gender          VARCHAR(10)     NOT NULL DEFAULT '',
            dob             DATE            DEFAULT NULL,
            parent_name     VARCHAR(255)    NOT NULL DEFAULT '',
            parent_phone    VARCHAR(20)     NOT NULL DEFAULT '',
            parent_code     VARCHAR(10)     NOT NULL,
            status          VARCHAR(20)     NOT NULL DEFAULT 'active',
            created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY parent_code (parent_code),
            KEY school_id (school_id),
            KEY class_id (class_id),
            KEY school_class (school_id, class_id),
            KEY school_status (school_id, status),
            KEY admission_no (school_id, admission_no)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 4: TEACHERS
           Links WP users to schools.
        ═══════════════════════════════════════════ */
        $teachers = self::table('teachers');
        dbDelta("CREATE TABLE {$teachers} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            school_id       BIGINT UNSIGNED NOT NULL,
            user_id         BIGINT UNSIGNED NOT NULL,
            name            VARCHAR(255)    NOT NULL,
            phone           VARCHAR(20)     NOT NULL DEFAULT '',
            employee_id     VARCHAR(50)     NOT NULL DEFAULT '',
            designation     VARCHAR(100)    NOT NULL DEFAULT 'Teacher',
            status          VARCHAR(20)     NOT NULL DEFAULT 'active',
            created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY school_id (school_id),
            KEY user_id (user_id),
            UNIQUE KEY school_user (school_id, user_id)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 5: TEACHER ↔ CLASS ASSIGNMENTS
           Which teacher handles which class/subject.
        ═══════════════════════════════════════════ */
        $teacher_classes = self::table('teacher_classes');
        dbDelta("CREATE TABLE {$teacher_classes} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            teacher_id      BIGINT UNSIGNED NOT NULL,
            class_id        BIGINT UNSIGNED NOT NULL,
            subject         VARCHAR(100)    NOT NULL DEFAULT 'Class Teacher',
            is_class_teacher TINYINT(1)     NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY teacher_id (teacher_id),
            KEY class_id (class_id),
            UNIQUE KEY teacher_class_subject (teacher_id, class_id, subject)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 6: DAILY ATTENDANCE
           One row per student per day.
           This is the high-volume table — compound
           indexes ensure fast queries at 1L+ scale.
        ═══════════════════════════════════════════ */
        $attendance_daily = self::table('attendance_daily');
        dbDelta("CREATE TABLE {$attendance_daily} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id      BIGINT UNSIGNED NOT NULL,
            school_id       BIGINT UNSIGNED NOT NULL,
            class_id        BIGINT UNSIGNED NOT NULL,
            att_date        DATE            NOT NULL,
            status          VARCHAR(20)     NOT NULL DEFAULT 'present',
            remarks         VARCHAR(255)    NOT NULL DEFAULT '',
            marked_by       BIGINT UNSIGNED NOT NULL,
            marked_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_by      BIGINT UNSIGNED NOT NULL DEFAULT 0,
            updated_at      DATETIME        DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY student_date (student_id, att_date),
            KEY school_date (school_id, att_date),
            KEY class_date (class_id, att_date),
            KEY school_class_date (school_id, class_id, att_date),
            KEY status_date (school_id, att_date, status),
            KEY marked_by (marked_by)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 7: PERIOD-WISE ATTENDANCE
           Optional: track per-period (1st, 2nd, etc.)
        ═══════════════════════════════════════════ */
        $attendance_period = self::table('attendance_period');
        dbDelta("CREATE TABLE {$attendance_period} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id      BIGINT UNSIGNED NOT NULL,
            school_id       BIGINT UNSIGNED NOT NULL,
            class_id        BIGINT UNSIGNED NOT NULL,
            att_date        DATE            NOT NULL,
            period_number   TINYINT UNSIGNED NOT NULL,
            subject         VARCHAR(100)    NOT NULL DEFAULT '',
            status          VARCHAR(20)     NOT NULL DEFAULT 'present',
            marked_by       BIGINT UNSIGNED NOT NULL,
            marked_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY student_date_period (student_id, att_date, period_number),
            KEY school_date (school_id, att_date),
            KEY class_date_period (class_id, att_date, period_number),
            KEY marked_by (marked_by)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 8: PARENT ↔ STUDENT LINKS
           Parent registers with 6-digit code.
           Verified = parent owns this student record.
        ═══════════════════════════════════════════ */
        $parent_links = self::table('parent_links');
        dbDelta("CREATE TABLE {$parent_links} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id      BIGINT UNSIGNED NOT NULL,
            parent_user_id  BIGINT UNSIGNED NOT NULL,
            parent_code     VARCHAR(10)     NOT NULL,
            verified        TINYINT(1)      NOT NULL DEFAULT 1,
            linked_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY student_id (student_id),
            KEY parent_user_id (parent_user_id),
            UNIQUE KEY parent_student (parent_user_id, student_id),
            KEY parent_code (parent_code)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 9: AUDIT LOG
           Every attendance action is logged.
           Essential for government accountability.
        ═══════════════════════════════════════════ */
        $audit_log = self::table('audit_log');
        dbDelta("CREATE TABLE {$audit_log} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id         BIGINT UNSIGNED NOT NULL,
            action          VARCHAR(100)    NOT NULL,
            entity_type     VARCHAR(50)     NOT NULL DEFAULT '',
            entity_id       BIGINT UNSIGNED NOT NULL DEFAULT 0,
            school_id       BIGINT UNSIGNED NOT NULL DEFAULT 0,
            details         TEXT            NOT NULL,
            ip_address      VARCHAR(45)     NOT NULL DEFAULT '',
            created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY action (action),
            KEY school_id (school_id),
            KEY created_at (created_at)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 10: BRUTE FORCE PROTECTION
           Rate limits parent code attempts.
        ═══════════════════════════════════════════ */
        $rate_limits = self::table('rate_limits');
        dbDelta("CREATE TABLE {$rate_limits} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            ip_address      VARCHAR(45)     NOT NULL,
            action          VARCHAR(50)     NOT NULL,
            attempts        INT UNSIGNED    NOT NULL DEFAULT 1,
            locked_until    DATETIME        DEFAULT NULL,
            last_attempt    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY ip_action (ip_address, action),
            KEY locked_until (locked_until)
        ) {$charset};");


        /* ═══════════════════════════════════════════
           TABLE 11: HOLIDAYS & HALF DAYS
           School admin sets in advance, or teacher
           marks on the fly. Prevents attendance
           marking on holidays.
        ═══════════════════════════════════════════ */
        $holidays = self::table('holidays');
        dbDelta("CREATE TABLE {$holidays} (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            school_id       BIGINT UNSIGNED NOT NULL,
            holiday_date    DATE            NOT NULL,
            type            VARCHAR(20)     NOT NULL DEFAULT 'holiday',
            title           VARCHAR(255)    NOT NULL DEFAULT '',
            created_by      BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY school_date (school_id, holiday_date),
            KEY school_id (school_id),
            KEY type (type)
        ) {$charset};");
    }


    /**
     * Generate unique 6-digit parent code.
     * Checks for collisions against existing codes.
     */
    public static function generate_parent_code() {
        global $wpdb;
        $table = self::table('students');
        $max_attempts = 50;

        for ($i = 0; $i < $max_attempts; $i++) {
            $code = str_pad(random_int(100000, 999999), 6, '0', STR_PAD_LEFT);

            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE parent_code = %s",
                $code
            ));

            if ((int)$exists === 0) {
                return $code;
            }
        }

        /* Fallback: alphanumeric if numeric space is crowded */
        for ($i = 0; $i < $max_attempts; $i++) {
            $code = strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));

            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE parent_code = %s",
                $code
            ));

            if ((int)$exists === 0) {
                return $code;
            }
        }

        /* Last resort: timestamp-based code (extremely unlikely to reach here) */
        return strtoupper(substr(md5(uniqid((string)mt_rand(), true)), 0, 6));
    }


    /**
     * Log an audit event.
     */
    public static function audit_log($action, $entity_type = '', $entity_id = 0, $school_id = 0, $details = '') {
        global $wpdb;

        $wpdb->insert(self::table('audit_log'), [
            'user_id'     => get_current_user_id(),
            'action'      => $action,
            'entity_type' => $entity_type,
            'entity_id'   => $entity_id,
            'school_id'   => $school_id,
            'details'     => is_array($details) ? json_encode($details) : $details,
            'ip_address'  => self::get_ip(),
            'created_at'  => current_time('mysql'),
        ]);
    }


    /**
     * Check brute-force rate limit.
     * Returns true if allowed, false if locked.
     */
    public static function check_rate_limit($action, $max_attempts = 5, $lockout_minutes = 30) {
        global $wpdb;
        $table = self::table('rate_limits');
        $ip    = self::get_ip();
        $now   = current_time('mysql');

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE ip_address = %s AND action = %s",
            $ip, $action
        ));

        if (!$row) {
            /* First attempt — allow */
            $wpdb->insert($table, [
                'ip_address'   => $ip,
                'action'       => $action,
                'attempts'     => 1,
                'last_attempt' => $now,
            ]);
            return true;
        }

        /* Check if locked — compare using WordPress local time consistently */
        $now_ts = current_time('timestamp');
        if ($row->locked_until && strtotime($row->locked_until) > $now_ts) {
            return false; /* Still locked */
        }

        /* Reset if lock expired */
        if ($row->locked_until && strtotime($row->locked_until) <= $now_ts) {
            $wpdb->update($table,
                ['attempts' => 1, 'locked_until' => null, 'last_attempt' => $now],
                ['id' => $row->id]
            );
            return true;
        }

        /* Increment */
        $new_attempts = (int)$row->attempts + 1;

        if ($new_attempts >= $max_attempts) {
            /* Lock this IP */
            $lock_time = wp_date('Y-m-d H:i:s', strtotime('+' . $lockout_minutes . ' minutes', current_time('timestamp')));
            $wpdb->update($table,
                ['attempts' => $new_attempts, 'locked_until' => $lock_time, 'last_attempt' => $now],
                ['id' => $row->id]
            );
            return false;
        }

        $wpdb->update($table,
            ['attempts' => $new_attempts, 'last_attempt' => $now],
            ['id' => $row->id]
        );
        return true;
    }


    /**
     * Reset rate limit on successful action.
     */
    public static function reset_rate_limit($action) {
        global $wpdb;
        $wpdb->delete(self::table('rate_limits'), [
            'ip_address' => self::get_ip(),
            'action'     => $action,
        ]);
    }


    /**
     * Check if a date is a holiday or half-day for a school.
     * Returns: false or object with ->type ('holiday'|'half_day') and ->title
     */
    public static function check_holiday($school_id, $date) {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT type, title FROM " . self::table('holidays') .
            " WHERE school_id = %d AND holiday_date = %s",
            $school_id, $date
        ));
        return $row ?: false;
    }

    /**
     * Add a holiday or half-day.
     */
    public static function add_holiday($school_id, $date, $type = 'holiday', $title = '') {
        global $wpdb;

        /* Check if already exists */
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::table('holidays') .
            " WHERE school_id = %d AND holiday_date = %s",
            $school_id, $date
        ));

        if ($existing) {
            $wpdb->update(self::table('holidays'), [
                'type'  => $type,
                'title' => $title,
            ], ['id' => $existing]);
            return $existing;
        }

        $wpdb->insert(self::table('holidays'), [
            'school_id'    => $school_id,
            'holiday_date' => $date,
            'type'         => $type,
            'title'        => $title,
            'created_by'   => get_current_user_id(),
        ]);
        return $wpdb->insert_id;
    }

    /**
     * Remove a holiday.
     */
    public static function remove_holiday($school_id, $date) {
        global $wpdb;
        $wpdb->delete(self::table('holidays'), [
            'school_id'    => $school_id,
            'holiday_date' => $date,
        ]);
    }

    /**
     * Get holidays for a school in a month.
     */
    public static function get_holidays($school_id, $month, $year) {
        global $wpdb;
        $start = sprintf('%04d-%02d-01', $year, $month);
        $end   = gmdate('Y-m-t', strtotime($start));

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::table('holidays') .
            " WHERE school_id = %d AND holiday_date BETWEEN %s AND %s ORDER BY holiday_date ASC",
            $school_id, $start, $end
        ));
    }


    /**
     * Get client IP address (CloudFlare-aware).
     */
    public static function get_ip() {
        /* Only trust CF header if the request actually came through CloudFlare.
           X-Forwarded-For is trivially spoofable — never trust it. */
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP']) && !empty($_SERVER['HTTP_CF_RAY'])) {
            return sanitize_text_field($_SERVER['HTTP_CF_CONNECTING_IP']);
        }
        return sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    }


    /**
     * Permanently delete a school and ALL related data.
     * This is a cascading hard delete — irreversible.
     * Only platform admin should call this.
     *
     * Returns array with counts of deleted records per table.
     */
    public static function delete_school_cascade($school_id) {
        global $wpdb;

        $school_id = absint($school_id);
        if (!$school_id) return false;

        $school = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::table('schools') . " WHERE id = %d", $school_id
        ));
        if (!$school) return false;

        $counts = [];

        /* Log before we delete anything */
        self::audit_log('school_hard_delete_started', 'school', $school_id, $school_id, [
            'school_name' => $school->name,
            'district'    => $school->district,
            'admin_user'  => $school->admin_user_id,
        ]);

        /* ─── Get all student IDs and class IDs for this school ─── */
        $student_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . self::table('students') . " WHERE school_id = %d", $school_id
        ));
        $class_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . self::table('classes') . " WHERE school_id = %d", $school_id
        ));
        $teacher_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . self::table('teachers') . " WHERE school_id = %d", $school_id
        ));

        /* ─── 1. Delete parent links for this school's students ─── */
        if (!empty($student_ids)) {
            $placeholders = implode(',', array_fill(0, count($student_ids), '%d'));
            $counts['parent_links'] = (int)$wpdb->query($wpdb->prepare(
                "DELETE FROM " . self::table('parent_links') . " WHERE student_id IN ($placeholders)",
                ...$student_ids
            ));
        }

        /* ─── 2. Delete attendance records ─── */
        $counts['attendance_daily'] = (int)$wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::table('attendance_daily') . " WHERE school_id = %d", $school_id
        ));
        $counts['attendance_period'] = (int)$wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::table('attendance_period') . " WHERE school_id = %d", $school_id
        ));

        /* ─── 3. Delete teacher-class assignments ─── */
        if (!empty($teacher_ids)) {
            $placeholders = implode(',', array_fill(0, count($teacher_ids), '%d'));
            $counts['teacher_classes'] = (int)$wpdb->query($wpdb->prepare(
                "DELETE FROM " . self::table('teacher_classes') . " WHERE teacher_id IN ($placeholders)",
                ...$teacher_ids
            ));
        }

        /* ─── 4. Remove teacher WP roles ─── */
        $teacher_user_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT user_id FROM " . self::table('teachers') . " WHERE school_id = %d", $school_id
        ));
        foreach ($teacher_user_ids as $uid) {
            $user = get_user_by('id', $uid);
            if ($user) {
                $user->remove_role(NAIS_Roles::TEACHER);
            }
        }

        /* ─── 5. Delete teachers ─── */
        $counts['teachers'] = (int)$wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::table('teachers') . " WHERE school_id = %d", $school_id
        ));

        /* ─── 6. Delete homework status ─── */
        $homework_table = $wpdb->prefix . 'nais_homework_status';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$homework_table}'") === $homework_table) {
            $counts['homework'] = (int)$wpdb->query($wpdb->prepare(
                "DELETE FROM {$homework_table} WHERE school_id = %d", $school_id
            ));
        }

        /* ─── 7. Delete exam results & dues ─── */
        $results_table = self::table('student_results');
        if ($wpdb->get_var("SHOW TABLES LIKE '{$results_table}'") === $results_table) {
            $counts['student_results'] = (int)$wpdb->query($wpdb->prepare(
                "DELETE FROM {$results_table} WHERE school_id = %d", $school_id
            ));
        }
        $dues_table = self::table('student_dues');
        if ($wpdb->get_var("SHOW TABLES LIKE '{$dues_table}'") === $dues_table) {
            $counts['student_dues'] = (int)$wpdb->query($wpdb->prepare(
                "DELETE FROM {$dues_table} WHERE school_id = %d", $school_id
            ));
        }

        /* ─── 8. Delete timetable & exam schedule ─── */
        $timetable_table = self::table('timetable');
        if ($wpdb->get_var("SHOW TABLES LIKE '{$timetable_table}'") === $timetable_table) {
            $counts['timetable'] = (int)$wpdb->query($wpdb->prepare(
                "DELETE FROM {$timetable_table} WHERE school_id = %d", $school_id
            ));
        }
        $exam_schedule_table = self::table('exam_schedule');
        if ($wpdb->get_var("SHOW TABLES LIKE '{$exam_schedule_table}'") === $exam_schedule_table) {
            $counts['exam_schedule'] = (int)$wpdb->query($wpdb->prepare(
                "DELETE FROM {$exam_schedule_table} WHERE school_id = %d", $school_id
            ));
        }

        /* ─── 9. Delete bus tracking data ─── */
        $buses_table = $wpdb->prefix . 'nais_buses';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$buses_table}'") === $buses_table) {
            $bus_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM {$buses_table} WHERE school_id = %d", $school_id
            ));
            if (!empty($bus_ids)) {
                $bp = implode(',', array_fill(0, count($bus_ids), '%d'));
                $wpdb->query($wpdb->prepare("DELETE FROM " . $wpdb->prefix . "nais_bus_locations WHERE bus_id IN ($bp)", ...$bus_ids));
                $wpdb->query($wpdb->prepare("DELETE FROM " . $wpdb->prefix . "nais_bus_students WHERE bus_id IN ($bp)", ...$bus_ids));
                $wpdb->query($wpdb->prepare("DELETE FROM " . $wpdb->prefix . "nais_bus_view_log WHERE bus_id IN ($bp)", ...$bus_ids));
                $wpdb->query($wpdb->prepare("DELETE FROM " . $wpdb->prefix . "nais_bus_trips WHERE bus_id IN ($bp)", ...$bus_ids));
            }
            $counts['buses'] = (int)$wpdb->query($wpdb->prepare(
                "DELETE FROM {$buses_table} WHERE school_id = %d", $school_id
            ));
        }

        /* ─── 10. Delete holidays ─── */
        $counts['holidays'] = (int)$wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::table('holidays') . " WHERE school_id = %d", $school_id
        ));

        /* ─── 11. Delete students ─── */
        $counts['students'] = (int)$wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::table('students') . " WHERE school_id = %d", $school_id
        ));

        /* ─── 12. Delete classes ─── */
        $counts['classes'] = (int)$wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::table('classes') . " WHERE school_id = %d", $school_id
        ));

        /* ─── 13. Delete payments ─── */
        $payments_table = $wpdb->prefix . 'nais_school_payments';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$payments_table}'") === $payments_table) {
            $counts['payments'] = (int)$wpdb->query($wpdb->prepare(
                "DELETE FROM {$payments_table} WHERE school_id = %d", $school_id
            ));
        }

        /* ─── 14. Delete school subscription options ─── */
        delete_option("nais_school_{$school_id}_plan");
        delete_option("nais_school_{$school_id}_period");
        delete_option("nais_school_{$school_id}_payment_status");
        delete_option("nais_school_{$school_id}_expires");
        delete_option("nais_school_{$school_id}_app_admin_name");
        delete_option("nais_school_{$school_id}_app_admin_email");
        delete_option("nais_school_{$school_id}_app_admin_phone");
        delete_option("nais_school_{$school_id}_app_student_count");
        delete_option("nais_school_{$school_id}_app_message");

        /* ─── 15. Remove school admin role from user ─── */
        if ($school->admin_user_id) {
            $admin_user = get_user_by('id', $school->admin_user_id);
            if ($admin_user) {
                $admin_user->remove_role(NAIS_Roles::SCHOOL_ADMIN);
            }
        }

        /* ─── 16. Delete audit log entries for this school ─── */
        $counts['audit_logs'] = (int)$wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::table('audit_log') . " WHERE school_id = %d", $school_id
        ));

        /* ─── 17. Finally, delete the school itself ─── */
        $wpdb->delete(self::table('schools'), ['id' => $school_id]);
        $counts['school'] = 1;

        /* Final audit log (school_id=0 since school is gone) */
        self::audit_log('school_hard_deleted', 'school', $school_id, 0, [
            'school_name'   => $school->name,
            'district'      => $school->district,
            'deleted_counts' => $counts,
        ]);

        return $counts;
    }


    /**
     * Auto-cleanup old audit logs and rate limit entries.
     * Called by daily cron. Keeps last 12 months of audit logs.
     */
    public static function cleanup_old_data() {
        global $wpdb;

        /* Delete audit logs older than 12 months */
        $cutoff = wp_date('Y-m-d H:i:s', strtotime('-12 months'));
        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::table('audit_log') . " WHERE created_at < %s",
            $cutoff
        ));

        /* Delete expired rate limit entries (older than 1 day) */
        $wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::table('rate_limits') . " WHERE last_attempt < %s",
            wp_date('Y-m-d H:i:s', strtotime('-1 day'))
        ));

        if ($deleted > 0) {
            self::audit_log('auto_cleanup', 'system', 0, 0, $deleted . ' old audit log entries removed (older than 12 months).');
        }
    }
}