<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS HOMEWORK — Teacher Marks Homework Status Per Subject
 * ═══════════════════════════════════════════════════════════════
 *
 * Flow (matches real Nagaland school process):
 *   Teacher assigns homework verbally in class →
 *   Student does homework in physical notebook at home →
 *   Next day: Subject teacher checks notebooks in class →
 *   Teacher opens this system, marks each student:
 *     ✅ Done  |  ❌ Not Done  |  📝 Half Done  |  📋 No Homework Today
 *   Parent sees homework status on My Child page.
 *
 * Key design: Teacher marks status — parent does NOT submit anything.
 * "No Homework Today" applies per-subject (English had HW, Math didn't).
 *
 * DB Table (1):
 *   nais_homework_status — one row per student per subject per date
 *
 * Self-contained: auto-creates tables on first load.
 */

if (!defined('ABSPATH')) exit;

class NAIS_Homework {

    public static function init() {
        /* Teacher marks homework */
        add_action('wp_ajax_nais_get_homework_checklist', [__CLASS__, 'ajax_get_homework_checklist']);
        add_action('wp_ajax_nais_save_homework',          [__CLASS__, 'ajax_save_homework']);
        add_action('wp_ajax_nais_no_homework_today',      [__CLASS__, 'ajax_no_homework_today']);

        /* Admin summary */
        add_action('wp_ajax_nais_get_homework_summary',   [__CLASS__, 'ajax_get_homework_summary']);
    }

    /* ═══ TABLE CREATION ═══ */
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta("CREATE TABLE " . self::table('homework_status') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            school_id BIGINT UNSIGNED NOT NULL,
            class_id BIGINT UNSIGNED NOT NULL,
            student_id BIGINT UNSIGNED NOT NULL,
            teacher_id BIGINT UNSIGNED NOT NULL,
            subject VARCHAR(100) NOT NULL,
            hw_date DATE NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'not_done',
            marked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY student_subject_date (student_id, subject, hw_date),
            KEY school_date (school_id, hw_date),
            KEY class_date (class_id, hw_date),
            KEY class_subject_date (class_id, subject, hw_date),
            KEY teacher_id (teacher_id)
        ) {$charset};");
    }

    public static function table($name) {
        global $wpdb;
        return $wpdb->prefix . 'nais_' . $name;
    }


    /* ═══════════════════════════════════════════
       SCHOOL ADMIN: HOMEWORK TAB (Summary View)
    ═══════════════════════════════════════════ */

    public static function render_homework_tab($school_id, $classes) {
        ob_start();
        ?>
        <h3>Homework Overview</h3>
        <p>View homework completion status across classes. Teachers mark homework from their own dashboard.</p>

        <div class="nais-inline-form">
            <select id="nais-hw-summary-class">
                <option value="">Select Class</option>
                <?php foreach ($classes as $c): ?>
                    <option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="date" id="nais-hw-summary-date" value="<?php echo current_time('Y-m-d'); ?>">
            <button type="button" class="nais-btn nais-btn-sm" id="nais-hw-load-summary">View Summary</button>
        </div>
        <div id="nais-hw-summary-container"><p class="nais-hint">Select a class and date to see homework status.</p></div>
        <?php
        return ob_get_clean();
    }


    /* ═══════════════════════════════════════════
       TEACHER: HOMEWORK MARKING INTERFACE
       (Rendered inside class-teacher.php tabs)
    ═══════════════════════════════════════════ */

    public static function render_teacher_homework($teacher, $classes) {
        $today = current_time('Y-m-d');
        ob_start();
        ?>
        <div class="nais-controls">
            <div class="nais-control-group">
                <label>Class:</label>
                <select id="nais-hw-class-select">
                    <option value="">Select Class</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c->id; ?>" data-subject="<?php echo esc_attr($c->subject); ?>">
                            <?php echo esc_html($c->class_name . ' ' . $c->section); ?>
                            <?php echo $c->is_class_teacher ? ' (Class Teacher)' : ' — ' . esc_html($c->subject); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="nais-control-group">
                <label>Date:</label>
                <input type="date" id="nais-hw-date" value="<?php echo esc_attr($today); ?>" max="<?php echo esc_attr($today); ?>">
            </div>

            <button id="nais-hw-load-students" class="nais-btn">Load Students</button>
        </div>

        <!-- Subject label (auto-detected from teacher assignment) -->
        <div id="nais-hw-subject-info" style="display:none;"></div>

        <!-- Quick actions -->
        <div id="nais-hw-quick-actions" style="display:none;">
            <div class="nais-quick-actions">
                <button class="nais-btn nais-btn-sm nais-hw-mark-all" data-status="done">✅ All Done</button>
                <button class="nais-btn nais-btn-sm nais-btn-danger nais-hw-mark-all" data-status="not_done">❌ All Not Done</button>
                <button class="nais-btn nais-btn-sm nais-hw-no-homework-btn" style="background:#6366f1;">📋 No Homework Today</button>
                <span class="nais-attendance-summary" id="nais-hw-summary-text"></span>
            </div>
        </div>

        <!-- Student checklist -->
        <div id="nais-hw-checklist-container">
            <p class="nais-hint">Select a class and click "Load Students" to mark homework.</p>
        </div>

        <!-- Save button -->
        <div id="nais-hw-save-bar" style="display:none;">
            <div class="nais-save-bar">
                <button id="nais-hw-save" class="nais-btn nais-btn-primary nais-btn-lg">Save Homework Status</button>
                <span id="nais-hw-save-status"></span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }


    /* ═══════════════════════════════════════════
       PARENT: HOMEWORK STATUS VIEW
    ═══════════════════════════════════════════ */

    public static function render_parent_homework($student) {
        global $wpdb;

        $today = current_time('Y-m-d');

        /* Get today's homework status */
        $today_hw = $wpdb->get_results($wpdb->prepare(
            "SELECT subject, status, marked_at FROM " . self::table('homework_status') .
            " WHERE student_id = %d AND hw_date = %s ORDER BY subject ASC",
            $student->id, $today
        ));

        /* Get last 7 days of homework (excluding today) */
        $recent_hw = $wpdb->get_results($wpdb->prepare(
            "SELECT subject, status, hw_date FROM " . self::table('homework_status') .
            " WHERE student_id = %d AND hw_date < %s AND hw_date >= DATE_SUB(%s, INTERVAL 7 DAY)
             ORDER BY hw_date DESC, subject ASC",
            $student->id, $today, $today
        ));

        $status_icons = [
            'done'        => '✅ Done',
            'not_done'    => '❌ Not Done',
            'half_done'   => '📝 Half Done',
            'no_homework' => '📋 No Homework',
        ];

        $status_colors = [
            'done'        => '#d1fae5;color:#065f46',
            'not_done'    => '#fee2e2;color:#991b1b',
            'half_done'   => '#fef3c7;color:#92400e',
            'no_homework' => '#f3f4f6;color:#6b7280',
        ];

        ob_start();
        ?>
        <div class="nais-hw-parent-section" style="margin-top:20px;padding:20px;background:#f9fafb;border-radius:14px;">
            <h4 style="font-size:13px;color:#9ca3af;text-transform:uppercase;margin-bottom:10px;">📝 Homework Status</h4>

            <?php if (!empty($today_hw)): ?>
                <div style="margin-bottom:12px;">
                    <strong style="font-size:14px;color:#374151;">Today (<?php echo current_time('j M Y'); ?>)</strong>
                </div>
                <?php foreach ($today_hw as $hw): ?>
                    <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 12px;margin-bottom:4px;background:<?php echo $status_colors[$hw->status] ?? '#f3f4f6;color:#666'; ?>;border-radius:8px;font-size:14px;">
                        <strong><?php echo esc_html($hw->subject); ?></strong>
                        <span><?php echo $status_icons[$hw->status] ?? esc_html($hw->status); ?></span>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="font-size:14px;color:#666;">No homework status marked for today yet.</p>
            <?php endif; ?>

            <?php if (!empty($recent_hw)): ?>
                <div style="margin-top:16px;">
                    <strong style="font-size:13px;color:#9ca3af;">Recent Days</strong>
                    <table class="nais-table" style="margin-top:8px;">
                        <thead><tr><th>Date</th><th>Subject</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php
                        $current_date = '';
                        foreach ($recent_hw as $hw):
                            $date_fmt = date_i18n('j M (D)', strtotime($hw->hw_date));
                            $show_date = ($hw->hw_date !== $current_date);
                            $current_date = $hw->hw_date;
                        ?>
                            <tr>
                                <td style="white-space:nowrap;"><?php echo $show_date ? esc_html($date_fmt) : ''; ?></td>
                                <td><?php echo esc_html($hw->subject); ?></td>
                                <td><?php echo $status_icons[$hw->status] ?? esc_html($hw->status); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }


    /* ═══════════════════════════════════════════
       AJAX: TEACHER — LOAD HOMEWORK CHECKLIST
    ═══════════════════════════════════════════ */

    public static function ajax_get_homework_checklist() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_mark_attendance') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        global $wpdb;
        $class_id = absint($_POST['class_id'] ?? 0);
        $date     = sanitize_text_field($_POST['hw_date'] ?? $_POST['date'] ?? current_time('Y-m-d'));
        $subject  = sanitize_text_field($_POST['subject'] ?? '');

        if (!$class_id || !$subject) wp_send_json_error('Class and subject required.');

        /* Verify class belongs to teacher's school */
        $school_id = NAIS_Roles::get_user_school_id();
        if ($school_id) {
            $cls_ok = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d", $class_id, $school_id));
            if (!$cls_ok) wp_send_json_error('Class not found in your school.');
        }

        /* Get students */
        $students = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name, roll_no FROM " . NAIS_Database::table('students') .
            " WHERE class_id = %d AND status = 'active' ORDER BY roll_no ASC, name ASC",
            $class_id
        ));

        if (empty($students)) wp_send_json_error('No students found in this class.');

        /* Get existing homework status for this date+subject */
        $existing = $wpdb->get_results($wpdb->prepare(
            "SELECT student_id, status FROM " . self::table('homework_status') .
            " WHERE class_id = %d AND subject = %s AND hw_date = %s",
            $class_id, $subject, $date
        ));

        $status_map = [];
        foreach ($existing as $e) {
            $status_map[$e->student_id] = $e->status;
        }

        $list = [];
        foreach ($students as $s) {
            $list[] = [
                'id'      => (int)$s->id,
                'name'    => $s->name,
                'roll_no' => $s->roll_no ?: '—',
                'status'  => $status_map[$s->id] ?? '',
            ];
        }

        wp_send_json_success(['students' => $list, 'subject' => $subject, 'date' => $date]);
    }


    /* ═══ AJAX: TEACHER — SAVE HOMEWORK STATUS ═══ */

    public static function ajax_save_homework() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_mark_attendance') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        global $wpdb;
        $class_id = absint($_POST['class_id'] ?? 0);
        $subject  = sanitize_text_field($_POST['subject'] ?? '');
        $date     = sanitize_text_field($_POST['hw_date'] ?? $_POST['date'] ?? current_time('Y-m-d'));
        $homework = json_decode(stripslashes($_POST['homework'] ?? ''), true);

        if (!$class_id || !$subject || empty($homework)) {
            wp_send_json_error('Missing data.');
        }

        $user_id   = get_current_user_id();
        $school_id = NAIS_Roles::get_user_school_id();

        /* Verify class belongs to teacher's school */
        if ($school_id) {
            $cls_ok = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d", $class_id, $school_id));
            if (!$cls_ok) wp_send_json_error('Class not found in your school.');
        }

        /* Get teacher ID */
        $teacher_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('teachers') . " WHERE user_id = %d AND status = 'active'",
            $user_id
        )) ?: 0;

        $saved   = 0;
        $allowed = ['done', 'not_done', 'half_done', 'no_homework'];

        foreach ($homework as $student_id => $status) {
            $student_id = absint($student_id);
            $status     = sanitize_text_field($status);

            if (!$student_id || !in_array($status, $allowed, true)) continue;

            /* Upsert */
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM " . self::table('homework_status') .
                " WHERE student_id = %d AND subject = %s AND hw_date = %s",
                $student_id, $subject, $date
            ));

            if ($existing) {
                $result = $wpdb->update(self::table('homework_status'), [
                    'status'    => $status,
                    'teacher_id' => $teacher_id,
                    'marked_at' => current_time('mysql'),
                ], ['id' => $existing]);
            } else {
                $result = $wpdb->insert(self::table('homework_status'), [
                    'school_id'  => $school_id,
                    'class_id'   => $class_id,
                    'student_id' => $student_id,
                    'teacher_id' => $teacher_id,
                    'subject'    => $subject,
                    'hw_date'    => $date,
                    'status'     => $status,
                ]);
            }
            if ($result !== false) $saved++;
        }

        if ($saved === 0 && !empty($entries)) {
            wp_send_json_error('Failed to save homework records. Please try again.');
        }

        NAIS_Database::audit_log('homework_marked', 'homework', $class_id, $school_id,
            $subject . ' — ' . $saved . ' students marked for ' . $date);

        wp_send_json_success(['message' => $subject . ' homework saved for ' . $saved . ' students.']);
    }


    /* ═══ AJAX: TEACHER — NO HOMEWORK TODAY ═══ */

    public static function ajax_no_homework_today() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_mark_attendance') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        global $wpdb;
        $class_id = absint($_POST['class_id'] ?? 0);
        $subject  = sanitize_text_field($_POST['subject'] ?? '');
        $date     = sanitize_text_field($_POST['date'] ?? current_time('Y-m-d'));

        if (!$class_id || !$subject) wp_send_json_error('Missing data.');

        $user_id   = get_current_user_id();
        $school_id = NAIS_Roles::get_user_school_id();

        /* Verify class belongs to teacher's school */
        if ($school_id) {
            $cls_ok = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d", $class_id, $school_id));
            if (!$cls_ok) wp_send_json_error('Class not found in your school.');
        }

        $teacher_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('teachers') . " WHERE user_id = %d AND status = 'active'", $user_id
        )) ?: 0;

        /* Get all students in this class */
        $students = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('students') .
            " WHERE class_id = %d AND status = 'active'",
            $class_id
        ));

        $saved = 0;
        foreach ($students as $student_id) {
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM " . self::table('homework_status') .
                " WHERE student_id = %d AND subject = %s AND hw_date = %s",
                $student_id, $subject, $date
            ));

            if ($existing) {
                $wpdb->update(self::table('homework_status'), [
                    'status' => 'no_homework', 'teacher_id' => $teacher_id, 'marked_at' => current_time('mysql'),
                ], ['id' => $existing]);
            } else {
                $wpdb->insert(self::table('homework_status'), [
                    'school_id' => $school_id, 'class_id' => $class_id, 'student_id' => $student_id,
                    'teacher_id' => $teacher_id, 'subject' => $subject, 'hw_date' => $date, 'status' => 'no_homework',
                ]);
            }
            $saved++;
        }

        NAIS_Database::audit_log('no_homework_marked', 'homework', $class_id, $school_id,
            $subject . ' — No homework today for ' . $saved . ' students on ' . $date);

        wp_send_json_success(['message' => 'No homework today marked for ' . $subject . ' (' . $saved . ' students).']);
    }


    /* ═══ AJAX: ADMIN — HOMEWORK SUMMARY ═══ */

    public static function ajax_get_homework_summary() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_mark_attendance') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        global $wpdb;
        $class_id = absint($_POST['class_id'] ?? 0);
        $date     = sanitize_text_field($_POST['date'] ?? current_time('Y-m-d'));

        if (!$class_id) wp_send_json_error('Select a class.');

        /* Verify class belongs to user's school */
        $school_id = NAIS_Roles::get_user_school_id();
        if ($school_id) {
            $cls_ok = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d", $class_id, $school_id));
            if (!$cls_ok) wp_send_json_error('Class not found in your school.');
        }

        /* Get all homework records for this class+date, grouped by subject */
        $records = $wpdb->get_results($wpdb->prepare(
            "SELECT subject,
                    SUM(status = 'done') AS done_count,
                    SUM(status = 'not_done') AS not_done_count,
                    SUM(status = 'half_done') AS half_done_count,
                    SUM(status = 'no_homework') AS no_hw_count,
                    COUNT(*) AS total
             FROM " . self::table('homework_status') .
            " WHERE class_id = %d AND hw_date = %s
             GROUP BY subject ORDER BY subject ASC",
            $class_id, $date
        ));

        $total_students = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . NAIS_Database::table('students') .
            " WHERE class_id = %d AND status = 'active'",
            $class_id
        ));

        wp_send_json_success([
            'subjects'       => $records,
            'total_students' => $total_students,
            'date'           => $date,
        ]);
    }
}

/* Auto-init + create tables on first load */
add_action('init', [NAIS_Homework::class, 'init']);
add_action('plugins_loaded', function() {
    if (get_option('nais_homework_tables_version', '0') !== '2.0') {
        NAIS_Homework::create_tables();
        update_option('nais_homework_tables_version', '2.0');
    }
});