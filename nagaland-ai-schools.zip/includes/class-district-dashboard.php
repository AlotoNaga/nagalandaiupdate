<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS DISTRICT DASHBOARD — Government Read-Only View
 * ═══════════════════════════════════════════════════════════════
 *
 * Accessible to: Government Auditors + Platform Admin
 * Shows: Aggregate attendance data across all schools
 * Cannot: Modify any data
 *
 * Shortcode: [nais_district_dashboard]
 * Create a page called "District Dashboard" with this shortcode.
 */

if (!defined('ABSPATH')) exit;

class NAIS_District_Dashboard {

    public static function init() {
        add_shortcode('nais_district_dashboard', [__CLASS__, 'dashboard_shortcode']);
        add_action('wp_ajax_nais_district_data', [__CLASS__, 'ajax_get_district_data']);
        add_action('wp_ajax_nais_district_school_detail', [__CLASS__, 'ajax_get_school_detail']);
    }

    /**
     * District Dashboard shortcode — frontend read-only view.
     */
    public static function dashboard_shortcode() {
        if (!is_user_logged_in()) {
            return '<div class="nais-login-prompt"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;">District Dashboard</h2><p>Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to access the dashboard.</p></div>';
        }

        if (!current_user_can('nais_audit_access') && !current_user_can('nais_platform_admin')) {
            return '<p>Access denied. This dashboard is for authorized government officials only.</p>';
        }

        /* Nagaland districts */
        $districts = ['All Districts', 'Chumoukedima', 'Dimapur', 'Kiphire', 'Kohima', 'Longleng', 'Mokokchung', 'Mon', 'Niuland', 'Noklak', 'Peren', 'Phek', 'Shamator', 'Tseminyü', 'Tuensang', 'Wokha', 'Zunheboto'];

        ob_start();
        ?>
        <div class="nais-district-dashboard">

            <div class="nais-dd-header">
                <h2>Nagaland AI Schools — District Dashboard</h2>
                <p>Real-time attendance monitoring across all registered schools. Read-only access.</p>
            </div>

            <!-- Filters -->
            <div class="nais-dd-filters">
                <select id="nais-dd-district">
                    <?php foreach ($districts as $d): ?>
                        <option value="<?php echo esc_attr($d === 'All Districts' ? '' : $d); ?>"><?php echo esc_html($d); ?></option>
                    <?php endforeach; ?>
                </select>
                <select id="nais-dd-period">
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                    <option value="month" selected>This Month</option>
                    <option value="year">This Year</option>
                </select>
                <button class="nais-btn" id="nais-dd-load">Load Dashboard</button>
            </div>

            <!-- Overview Cards -->
            <div class="nais-dd-cards" id="nais-dd-cards">
                <div class="nais-dd-card"><div class="nais-dd-num" id="dd-total-schools">—</div><div class="nais-dd-label">Schools</div></div>
                <div class="nais-dd-card"><div class="nais-dd-num" id="dd-total-students">—</div><div class="nais-dd-label">Students</div></div>
                <div class="nais-dd-card"><div class="nais-dd-num" id="dd-total-teachers">—</div><div class="nais-dd-label">Teachers</div></div>
                <div class="nais-dd-card nais-dd-card-green"><div class="nais-dd-num" id="dd-att-rate">—</div><div class="nais-dd-label">Attendance Rate</div></div>
                <div class="nais-dd-card"><div class="nais-dd-num" id="dd-present-today">—</div><div class="nais-dd-label">Present Today</div></div>
                <div class="nais-dd-card nais-dd-card-red"><div class="nais-dd-num" id="dd-absent-today">—</div><div class="nais-dd-label">Absent Today</div></div>
            </div>

            <!-- District Breakdown -->
            <div id="nais-dd-district-table"></div>

            <!-- School-by-School -->
            <div id="nais-dd-school-table"></div>

            <div class="nais-dd-footer">
                <p>Nagaland AI Schools — District Dashboard | Data refreshes on each load | Powered by Nagaland Me</p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }


    /**
     * AJAX: Get district dashboard data.
     */
    public static function ajax_get_district_data() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_audit_access') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        global $wpdb;
        $district = sanitize_text_field($_POST['district'] ?? '');
        $period   = sanitize_text_field($_POST['period'] ?? 'month');

        $schools_table    = NAIS_Database::table('schools');
        $students_table   = NAIS_Database::table('students');
        $teachers_table   = NAIS_Database::table('teachers');
        $attendance_table = NAIS_Database::table('attendance_daily');

        /* Date range based on period */
        $today = current_time('Y-m-d');
        switch ($period) {
            case 'today': $start = $today; $end = $today; break;
            case 'week':  $start = date_i18n('Y-m-d', strtotime('monday this week')); $end = $today; break;
            case 'year':  $start = current_time('Y') . '-01-01'; $end = $today; break;
            default:      $start = current_time('Y-m') . '-01'; $end = $today; break;
        }

        /* District filter */
        $district_where = $district ? $wpdb->prepare(" AND s.district = %s", $district) : '';

        /* Total schools */
        $total_schools = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$schools_table} s WHERE s.status = 'active'" . $district_where);

        /* Total students */
        $total_students = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$students_table} st JOIN {$schools_table} s ON st.school_id = s.id WHERE st.status = 'active' AND s.status = 'active'" . $district_where);

        /* Total teachers */
        $total_teachers = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$teachers_table} t JOIN {$schools_table} s ON t.school_id = s.id WHERE t.status = 'active' AND s.status = 'active'" . $district_where);

        /* Attendance stats for period */
        $att_stats = $wpdb->get_row($wpdb->prepare(
            "SELECT
                COUNT(*) AS total_records,
                SUM(CASE WHEN a.status IN ('present','late') THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) AS absent_count
             FROM {$attendance_table} a
             JOIN {$students_table} st ON a.student_id = st.id
             JOIN {$schools_table} s ON a.school_id = s.id
             WHERE a.att_date BETWEEN %s AND %s
             AND s.status = 'active'" . $district_where,
            $start, $end
        ));

        $total_records = (int)($att_stats->total_records ?? 0);
        $present_count = (int)($att_stats->present_count ?? 0);
        $absent_count  = (int)($att_stats->absent_count ?? 0);
        $att_rate      = $total_records > 0 ? round(($present_count / $total_records) * 100, 1) : 0;

        /* Today's counts specifically */
        $today_stats = $wpdb->get_row($wpdb->prepare(
            "SELECT
                SUM(CASE WHEN a.status IN ('present','late') THEN 1 ELSE 0 END) AS present_today,
                SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) AS absent_today
             FROM {$attendance_table} a
             JOIN {$schools_table} s ON a.school_id = s.id
             WHERE a.att_date = %s AND s.status = 'active'" . $district_where,
            $today
        ));

        $present_today = (int)($today_stats->present_today ?? 0);
        $absent_today  = (int)($today_stats->absent_today ?? 0);

        /* District breakdown */
        $district_breakdown = $wpdb->get_results($wpdb->prepare(
            "SELECT
                s.district,
                COUNT(DISTINCT s.id) AS school_count,
                COUNT(DISTINCT st.id) AS student_count,
                (SELECT COUNT(*) FROM {$attendance_table} a2
                 JOIN {$schools_table} s2 ON a2.school_id = s2.id
                 WHERE s2.district = s.district AND a2.att_date BETWEEN %s AND %s
                 AND a2.status IN ('present','late')) AS period_present,
                (SELECT COUNT(*) FROM {$attendance_table} a3
                 JOIN {$schools_table} s3 ON a3.school_id = s3.id
                 WHERE s3.district = s.district AND a3.att_date BETWEEN %s AND %s) AS period_total
             FROM {$schools_table} s
             LEFT JOIN {$students_table} st ON st.school_id = s.id AND st.status = 'active'
             WHERE s.status = 'active'
             GROUP BY s.district
             ORDER BY s.district ASC",
            $start, $end, $start, $end
        ));

        $districts_data = [];
        foreach ($district_breakdown as $d) {
            $d_rate = (int)$d->period_total > 0 ? round(((int)$d->period_present / (int)$d->period_total) * 100, 1) : 0;
            $districts_data[] = [
                'district'      => $d->district ?: 'Unknown',
                'schools'       => (int)$d->school_count,
                'students'      => (int)$d->student_count,
                'attendance'    => $d_rate,
            ];
        }

        /* School-by-school */
        $schools_data = $wpdb->get_results($wpdb->prepare(
            "SELECT
                s.id, s.name, s.district, s.board, s.udise_code,
                (SELECT COUNT(*) FROM {$students_table} st WHERE st.school_id = s.id AND st.status = 'active') AS students,
                (SELECT COUNT(*) FROM {$teachers_table} t WHERE t.school_id = s.id AND t.status = 'active') AS teachers,
                (SELECT COUNT(*) FROM {$attendance_table} a WHERE a.school_id = s.id AND a.att_date BETWEEN %s AND %s AND a.status IN ('present','late')) AS period_present,
                (SELECT COUNT(*) FROM {$attendance_table} a2 WHERE a2.school_id = s.id AND a2.att_date BETWEEN %s AND %s) AS period_total
             FROM {$schools_table} s
             WHERE s.status = 'active'" . $district_where . "
             ORDER BY s.district ASC, s.name ASC",
            $start, $end, $start, $end
        ));

        $schools_list = [];
        foreach ($schools_data as $sc) {
            $sc_rate = (int)$sc->period_total > 0 ? round(((int)$sc->period_present / (int)$sc->period_total) * 100, 1) : 0;
            $schools_list[] = [
                'id'         => (int)$sc->id,
                'name'       => $sc->name,
                'district'   => $sc->district ?: '—',
                'board'      => $sc->board ?: '—',
                'udise'      => $sc->udise_code ?: '—',
                'students'   => (int)$sc->students,
                'teachers'   => (int)$sc->teachers,
                'attendance' => $sc_rate,
                'present'    => (int)$sc->period_present,
                'total'      => (int)$sc->period_total,
            ];
        }

        wp_send_json_success([
            'overview' => [
                'schools'       => $total_schools,
                'students'      => $total_students,
                'teachers'      => $total_teachers,
                'att_rate'      => $att_rate . '%',
                'present_today' => $present_today,
                'absent_today'  => $absent_today,
            ],
            'districts' => $districts_data,
            'schools'   => $schools_list,
            'period'    => $period,
            'date_range'=> $start . ' to ' . $end,
        ]);
    }


    /**
     * AJAX: Get detailed data for a single school.
     */
    public static function ajax_get_school_detail() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_audit_access') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        global $wpdb;
        $school_id = absint($_POST['school_id'] ?? 0);
        if (!$school_id) wp_send_json_error('Missing school ID.');

        $schools_table = NAIS_Database::table('schools');
        $school = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$schools_table} WHERE id = %d", $school_id));
        if (!$school) wp_send_json_error('School not found.');

        /* Classes with student counts */
        $classes = $wpdb->get_results($wpdb->prepare(
            "SELECT c.class_name, c.section,
                    (SELECT COUNT(*) FROM " . NAIS_Database::table('students') . " s WHERE s.class_id = c.id AND s.status = 'active') AS students
             FROM " . NAIS_Database::table('classes') . " c
             WHERE c.school_id = %d AND c.status = 'active'
             ORDER BY c.class_name ASC", $school_id
        ));

        /* Monthly attendance for last 6 months */
        $monthly = [];
        for ($i = 5; $i >= 0; $i--) {
            $m_start = date_i18n('Y-m-01', strtotime("-{$i} months"));
            $m_end   = date_i18n('Y-m-t', strtotime($m_start));
            $m_label = date_i18n('M Y', strtotime($m_start));

            $stats = $wpdb->get_row($wpdb->prepare(
                "SELECT COUNT(*) AS total,
                        SUM(CASE WHEN status IN ('present','late') THEN 1 ELSE 0 END) AS present_count
                 FROM " . NAIS_Database::table('attendance_daily') . "
                 WHERE school_id = %d AND att_date BETWEEN %s AND %s",
                $school_id, $m_start, $m_end
            ));

            $total = (int)($stats->total ?? 0);
            $present = (int)($stats->present_count ?? 0);
            $monthly[] = [
                'month'      => $m_label,
                'attendance' => $total > 0 ? round(($present / $total) * 100, 1) : 0,
                'records'    => $total,
            ];
        }

        /* Subscription status */
        $plan   = get_option("nais_school_{$school_id}_plan", 'free_trial');
        $status = get_option("nais_school_{$school_id}_payment_status", 'trial');
        $expires = (int)get_option("nais_school_{$school_id}_expires", 0);

        wp_send_json_success([
            'school'  => [
                'name'     => $school->name,
                'district' => $school->district,
                'board'    => $school->board,
                'udise'    => $school->udise_code ?: '—',
                'phone'    => $school->phone,
                'email'    => $school->email,
                'address'  => $school->address,
            ],
            'classes'      => $classes,
            'monthly'      => $monthly,
            'subscription' => [
                'plan'    => ucfirst($plan),
                'status'  => ucfirst($status),
                'expires' => $expires > 0 ? date_i18n('d M Y', $expires) : '—',
            ],
        ]);
    }
}

/* Note: init() is called from main plugin's init_modules() — no standalone add_action needed */