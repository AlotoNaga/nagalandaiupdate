<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS TEACHER — Attendance Marking Interface
 * ═══════════════════════════════════════════════════════════════
 *
 * Teacher sees their assigned classes, selects one, and marks
 * attendance for all students with a checklist interface.
 * Supports daily (morning roll call) and period-wise marking.
 *
 * V2: Added "Homework Check" type — teacher marks
 * Done/Not Done/Half Done/No HW per student per subject.
 */

if (!defined('ABSPATH')) exit;

class NAIS_Teacher {

    /**
     * Attendance marking shortcode.
     */
    public static function mark_attendance_shortcode() {
        if (!is_user_logged_in()) {
            return '<div class="nais-login-prompt"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">Mark Attendance</h2><p>Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to mark attendance for your class.</p></div>';
        }

        if (!current_user_can('nais_mark_attendance') && !current_user_can('nais_platform_admin')) {
            return '<div class="nais-msg"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">Access Denied</h2><p>Only teachers can mark attendance. If you are a teacher, please contact your school administrator.</p></div>';
        }

        global $wpdb;
        $user_id = get_current_user_id();

        /* Get teacher record */
        $teacher = $wpdb->get_row($wpdb->prepare(
            "SELECT t.*, s.name AS school_name FROM " . NAIS_Database::table('teachers') . " t
             JOIN " . NAIS_Database::table('schools') . " s ON t.school_id = s.id
             WHERE t.user_id = %d AND t.status = 'active'",
            $user_id
        ));

        /* Platform admin bypass */
        if (!$teacher && current_user_can('nais_platform_admin')) {
            return '<div class="nais-msg"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">Platform Admin</h2><p>Use the <a href="' . admin_url('admin.php?page=nagaland-schools') . '">admin dashboard</a> to manage schools and view attendance reports.</p></div>';
        }

        if (!$teacher) {
            return '<div class="nais-msg"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">Setup Required</h2><p>Your teacher profile is not set up yet. Contact your school administrator to get started.</p></div>';
        }

        /* Get assigned classes */
        $classes = $wpdb->get_results($wpdb->prepare(
            "SELECT c.id, c.class_name, c.section, tc.subject, tc.is_class_teacher
             FROM " . NAIS_Database::table('teacher_classes') . " tc
             JOIN " . NAIS_Database::table('classes') . " c ON tc.class_id = c.id
             WHERE tc.teacher_id = %d AND c.status = 'active'
             ORDER BY c.class_name ASC",
            $teacher->id
        ));

        if (empty($classes)) {
            return '<div class="nais-msg"><h2 style="font-family:DM Serif Display,Georgia,serif;font-size:28px;margin-bottom:12px;">No Classes Assigned</h2><p>No classes have been assigned to you yet. Contact your school administrator to get your classes set up.</p></div>';
        }

        $today = current_time('Y-m-d');
        $periods_per_day = (int)get_option('nais_periods_per_day', 6);

        /* Check if today is a holiday */
        $school_id = (int)$teacher->school_id;
        $holiday = NAIS_Database::check_holiday($school_id, $today);

        /* Check if school is locked */
        if (NAIS_Payment::is_school_locked($school_id)) {
            return '<div class="nais-teacher">' . NAIS_Payment::get_renewal_banner($school_id) . '</div>';
        }

        ob_start();
        ?>
        <div class="nais-teacher" data-teacher-id="<?php echo (int)$teacher->id; ?>" data-school-id="<?php echo $school_id; ?>">

            <?php echo NAIS_Payment::get_renewal_banner($school_id); ?>

            <div class="nais-teacher-header">
                <h2>Mark Attendance</h2>
                <p class="nais-school-name"><?php echo esc_html($teacher->school_name); ?> — <?php echo esc_html($teacher->name); ?></p>
            </div>

            <?php if ($holiday): ?>
                <div class="nais-holiday-banner nais-holiday-<?php echo esc_attr($holiday->type); ?>">
                    <?php if ($holiday->type === 'holiday'): ?>
                        <strong>🎉 Today is a Holiday<?php echo $holiday->title ? ': ' . esc_html($holiday->title) : ''; ?></strong>
                        <p>No attendance marking needed. You can still mark for other dates using the date picker below.</p>
                    <?php else: ?>
                        <strong>📋 Today is a Half Day<?php echo $holiday->title ? ': ' . esc_html($holiday->title) : ''; ?></strong>
                        <p>Only morning attendance is required.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Class selector + date -->
            <div class="nais-controls">
                <div class="nais-control-group">
                    <label>Class:</label>
                    <select id="nais-class-select">
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c->id; ?>" data-subject="<?php echo esc_attr($c->subject); ?>">
                                <?php echo esc_html($c->class_name . ' ' . $c->section); ?>
                                <?php echo $c->is_class_teacher ? ' (Class Teacher)' : ' — ' . esc_html($c->subject); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="nais-control-group">
                    <label>Date:</label>
                    <input type="date" id="nais-att-date" value="<?php echo esc_attr($today); ?>" max="<?php echo esc_attr($today); ?>">
                </div>

                <div class="nais-control-group">
                    <label>Type:</label>
                    <select id="nais-att-type">
                        <option value="daily">Daily (Morning Roll Call)</option>
                        <option value="homework">📋 Homework Check</option>
                        <?php for ($p = 1; $p <= $periods_per_day; $p++): ?>
                            <option value="period-<?php echo $p; ?>">Period <?php echo $p; ?> (Subject)</option>
                        <?php endfor; ?>
                    </select>
                </div>

                <button id="nais-load-students" class="nais-btn">Load Students</button>
            </div>

            <!-- Holiday info banner (shown after checking date) -->
            <div id="nais-date-holiday-info" style="display:none;"></div>

            <!-- Quick actions (attendance mode only) -->
            <div class="nais-quick-actions" style="display:none;">
                <button class="nais-btn nais-btn-sm nais-mark-all" data-status="present">✓ All Present</button>
                <button class="nais-btn nais-btn-sm nais-btn-danger nais-mark-all" data-status="absent">✗ All Absent</button>
                <span class="nais-attendance-summary" id="nais-summary"></span>
            </div>

            <!-- Homework quick actions (homework mode only) -->
            <div class="nais-hw-quick-actions" style="display:none;">
                <button class="nais-btn nais-btn-sm nais-hw-mark-all" data-status="done" style="background:#10b981;">✓ All Done</button>
                <button class="nais-btn nais-btn-sm nais-hw-mark-all" data-status="not_done" style="background:#ef4444;">✗ All Not Done</button>
                <button class="nais-btn nais-btn-sm nais-hw-mark-all" data-status="no_homework" style="background:#6b7280;">— No Homework Today</button>
                <span class="nais-attendance-summary" id="nais-hw-summary"></span>
            </div>

            <!-- Student checklist (attendance or homework) -->
            <div id="nais-checklist-container">
                <p class="nais-hint">Select a class and click "Load Students" to begin.</p>
            </div>

            <!-- Save button -->
            <div class="nais-save-bar" style="display:none;">
                <button id="nais-save-attendance" class="nais-btn nais-btn-primary nais-btn-lg">Save Attendance</button>
                <button id="nais-save-homework" class="nais-btn nais-btn-primary nais-btn-lg" style="display:none;">Save Homework Check</button>
                <span id="nais-save-status"></span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}