<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS ATTENDANCE — Core Attendance Logic
 * ═══════════════════════════════════════════════════════════════
 *
 * Handles:
 * - Daily attendance marking (present/absent/late/excused)
 * - Period-wise attendance marking
 * - Attendance reports (daily, weekly, monthly)
 * - Student attendance percentage calculation
 * - AJAX handlers for teacher marking interface
 * - Mobile app (Nagaland Me) attendance endpoints
 *
 * Return-type note (2026-04-26):
 *   mark_daily() and mark_period() now return the affected row_id (int > 0)
 *   on success, or false on failure. Previously they returned bool true on
 *   success. Existing callers using `if (mark_daily(...))` still work because
 *   a positive int is truthy. Strict `=== true` comparisons (uncommon) would
 *   need updating to `!== false`.
 */

if (!defined('ABSPATH')) exit;

class NAIS_Attendance {

    const STATUS_PRESENT = 'present';
    const STATUS_ABSENT  = 'absent';
    const STATUS_LATE    = 'late';
    const STATUS_EXCUSED = 'excused';

    /**
     * Init hooks.
     */
    public static function init() {
        /* AJAX: save daily attendance */
        add_action('wp_ajax_nais_save_daily_attendance', [__CLASS__, 'ajax_save_daily']);

        /* AJAX: save period attendance */
        add_action('wp_ajax_nais_save_period_attendance', [__CLASS__, 'ajax_save_period']);

        /* AJAX: get attendance for a class/date */
        add_action('wp_ajax_nais_get_attendance', [__CLASS__, 'ajax_get_attendance']);

        /* AJAX: get student attendance report */
        add_action('wp_ajax_nais_get_student_report', [__CLASS__, 'ajax_get_student_report']);

        /* ───── Mobile App (Nagaland Me) ───── */
        add_action('wp_ajax_nais_get_nonce',                 [__CLASS__, 'ajax_get_nonce']);
        add_action('wp_ajax_nais_teacher_get_my_classes',    [__CLASS__, 'ajax_teacher_get_my_classes']);
        add_action('wp_ajax_nais_teacher_attendance_today',  [__CLASS__, 'ajax_teacher_attendance_today']);
        add_action('wp_ajax_nais_teacher_submit_attendance', [__CLASS__, 'ajax_teacher_submit_attendance']);
    }

    /**
     * Mark daily attendance for a single student.
     *
     * @return int|false  Row ID on success, false on failure.
     */
    public static function mark_daily($student_id, $date, $status, $remarks = '') {
        global $wpdb;
        $table = NAIS_Database::table('attendance_daily');
        $user_id = get_current_user_id();

        /* Get student's school_id and class_id */
        $student = $wpdb->get_row($wpdb->prepare(
            "SELECT school_id, class_id FROM " . NAIS_Database::table('students') . " WHERE id = %d",
            $student_id
        ));

        if (!$student) return false;

        /* Check if already marked today */
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE student_id = %d AND att_date = %s",
            $student_id, $date
        ));

        if ($existing) {
            /* Update existing record */
            $result = $wpdb->update($table, [
                'status'     => $status,
                'remarks'    => $remarks,
                'updated_by' => $user_id,
                'updated_at' => current_time('mysql'),
            ], ['id' => $existing]);

            if ($result === false) return false;

            NAIS_Database::audit_log('attendance_updated', 'daily', $existing, $student->school_id, [
                'student_id' => $student_id,
                'date'       => $date,
                'status'     => $status,
            ]);

            return (int)$existing;
        }

        /* Insert new record */
        $result = $wpdb->insert($table, [
            'student_id' => $student_id,
            'school_id'  => $student->school_id,
            'class_id'   => $student->class_id,
            'att_date'   => $date,
            'status'     => $status,
            'remarks'    => $remarks,
            'marked_by'  => $user_id,
            'marked_at'  => current_time('mysql'),
        ]);

        if ($result === false) return false;

        $new_id = (int)$wpdb->insert_id;

        NAIS_Database::audit_log('attendance_marked', 'daily', $new_id, $student->school_id, [
            'student_id' => $student_id,
            'date'       => $date,
            'status'     => $status,
        ]);

        return $new_id;
    }

    /**
     * Mark period attendance for a single student.
     *
     * @return int|false  Row ID on success, false on failure.
     */
    public static function mark_period($student_id, $date, $period_number, $subject, $status) {
        global $wpdb;
        $table = NAIS_Database::table('attendance_period');
        $user_id = get_current_user_id();

        $student = $wpdb->get_row($wpdb->prepare(
            "SELECT school_id, class_id FROM " . NAIS_Database::table('students') . " WHERE id = %d",
            $student_id
        ));

        if (!$student) return false;

        /* Check existing */
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE student_id = %d AND att_date = %s AND period_number = %d",
            $student_id, $date, $period_number
        ));

        if ($existing) {
            $result = $wpdb->update($table, [
                'subject'   => $subject,
                'status'    => $status,
                'marked_by' => $user_id,
                'marked_at' => current_time('mysql'),
            ], ['id' => $existing]);
            if ($result === false) return false;
            return (int)$existing;
        }

        $result = $wpdb->insert($table, [
            'student_id'    => $student_id,
            'school_id'     => $student->school_id,
            'class_id'      => $student->class_id,
            'att_date'      => $date,
            'period_number' => $period_number,
            'subject'       => $subject,
            'status'        => $status,
            'marked_by'     => $user_id,
            'marked_at'     => current_time('mysql'),
        ]);
        if ($result === false) return false;

        return (int)$wpdb->insert_id;
    }

    /**
     * Get daily attendance for a class on a date.
     */
    public static function get_class_attendance($class_id, $date) {
        global $wpdb;

        $students_table    = NAIS_Database::table('students');
        $attendance_table  = NAIS_Database::table('attendance_daily');

        return $wpdb->get_results($wpdb->prepare(
            "SELECT s.id AS student_id, s.name, s.roll_no, s.gender,
                    a.status, a.remarks, a.marked_at, a.marked_by
             FROM {$students_table} s
             LEFT JOIN {$attendance_table} a ON a.student_id = s.id AND a.att_date = %s
             WHERE s.class_id = %d AND s.status = 'active'
             ORDER BY s.roll_no ASC, s.name ASC",
            $date, $class_id
        ));
    }

    /**
     * Get period attendance for a class on a date.
     */
    public static function get_class_period_attendance($class_id, $date) {
        global $wpdb;

        $students_table   = NAIS_Database::table('students');
        $period_table     = NAIS_Database::table('attendance_period');

        return $wpdb->get_results($wpdb->prepare(
            "SELECT s.id AS student_id, s.name, s.roll_no,
                    p.period_number, p.subject, p.status, p.marked_at
             FROM {$students_table} s
             LEFT JOIN {$period_table} p ON p.student_id = s.id AND p.att_date = %s
             WHERE s.class_id = %d AND s.status = 'active'
             ORDER BY s.roll_no ASC, p.period_number ASC",
            $date, $class_id
        ));
    }

    /**
     * Get attendance stats for a student (monthly).
     */
    public static function get_student_stats($student_id, $month = null, $year = null) {
        global $wpdb;
        $table = NAIS_Database::table('attendance_daily');

        if (!$month) $month = (int)current_time('m');
        if (!$year)  $year  = (int)current_time('Y');

        $start = sprintf('%04d-%02d-01', $year, $month);
        $end   = gmdate('Y-m-t', strtotime($start));

        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT
                COUNT(*) AS total_days,
                SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent,
                SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) AS late,
                SUM(CASE WHEN status = 'excused' THEN 1 ELSE 0 END) AS excused
             FROM {$table}
             WHERE student_id = %d AND att_date BETWEEN %s AND %s",
            $student_id, $start, $end
        ));

        if ($stats && $stats->total_days > 0) {
            $stats->percentage = round(
                (($stats->present + $stats->late) / $stats->total_days) * 100,
                1
            );
        } else {
            $stats = (object)[
                'total_days' => 0, 'present' => 0, 'absent' => 0,
                'late' => 0, 'excused' => 0, 'percentage' => 0,
            ];
        }

        return $stats;
    }

    /**
     * Get today's attendance for a student (for parent AI query).
     */
    public static function get_student_today($student_id) {
        global $wpdb;
        $today = current_time('Y-m-d');

        /* Daily attendance */
        $daily = $wpdb->get_row($wpdb->prepare(
            "SELECT status, remarks, marked_at FROM " . NAIS_Database::table('attendance_daily') .
            " WHERE student_id = %d AND att_date = %s",
            $student_id, $today
        ));

        /* Period attendance */
        $periods = $wpdb->get_results($wpdb->prepare(
            "SELECT period_number, subject, status, marked_at FROM " . NAIS_Database::table('attendance_period') .
            " WHERE student_id = %d AND att_date = %s ORDER BY period_number ASC",
            $student_id, $today
        ));

        return [
            'date'    => $today,
            'daily'   => $daily,
            'periods' => $periods,
        ];
    }


    /* ═══════════════════════════════════════════
       AJAX HANDLERS
    ═══════════════════════════════════════════ */

    /**
     * AJAX: Save daily attendance for entire class.
     * Expects POST: class_id, date, attendance[student_id] = status
     */
    public static function ajax_save_daily() {
        check_ajax_referer('nais_nonce', 'nonce');

        if (!current_user_can('nais_mark_attendance')) {
            wp_send_json_error('Permission denied.');
        }

        $class_id   = absint($_POST['class_id'] ?? 0);
        $date       = sanitize_text_field($_POST['date'] ?? current_time('Y-m-d'));
        $attendance = $_POST['attendance'] ?? [];

        if (!$class_id || !is_array($attendance) || empty($attendance)) {
            wp_send_json_error('Missing data.');
        }

        /* Verify teacher has access to this class */
        if (!current_user_can('nais_platform_admin') && !self::teacher_can_mark_class($class_id)) {
            wp_send_json_error('You are not assigned to this class.');
        }

        /* Validate date — not in future, not more than 7 days ago */
        $date_ts = strtotime($date);
        $today_ts = strtotime(current_time('Y-m-d'));
        if ($date_ts > $today_ts || $date_ts < ($today_ts - 7 * DAY_IN_SECONDS)) {
            wp_send_json_error('Invalid date. Attendance can only be marked for today or up to 7 days in the past.');
        }

        global $wpdb;

        /* Server-side holiday check — block full holidays */
        $class_school_id = $wpdb->get_var($wpdb->prepare(
            "SELECT school_id FROM " . NAIS_Database::table('classes') . " WHERE id = %d",
            $class_id
        ));
        if ($class_school_id) {
            $holiday = NAIS_Database::check_holiday($class_school_id, $date);
            if ($holiday && $holiday->type === 'holiday') {
                wp_send_json_error('Cannot mark attendance on a full holiday (' . esc_html($holiday->title) . '). Change the date or remove the holiday first.');
            }
        }

        /* Get valid student IDs for this class (array_flip for O(1) lookup) */
        $valid_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('students') . " WHERE class_id = %d AND status = 'active'",
            $class_id
        ));
        $valid_students = array_flip($valid_ids);

        $saved = 0;
        $valid_statuses = ['present' => 1, 'absent' => 1, 'late' => 1, 'excused' => 1];
        foreach ($attendance as $student_id => $data) {
            $student_id = absint($student_id);
            if (!isset($valid_students[$student_id])) continue;
            $status     = sanitize_text_field($data['status'] ?? 'present');
            $remarks    = sanitize_text_field($data['remarks'] ?? '');

            if (!isset($valid_statuses[$status])) {
                $status = 'present';
            }

            if (self::mark_daily($student_id, $date, $status, $remarks)) {
                $saved++;
            }
        }

        if ($saved === 0 && !empty($attendance)) {
            wp_send_json_error('Failed to save attendance. Please try again.');
        }

        wp_send_json_success([
            'message' => sprintf('Attendance saved for %d students.', $saved),
            'count'   => $saved,
        ]);
    }

    /**
     * AJAX: Save period attendance.
     * Expects POST: class_id, date, period_number, subject, attendance[student_id] = status
     */
    public static function ajax_save_period() {
        check_ajax_referer('nais_nonce', 'nonce');

        if (!current_user_can('nais_mark_attendance')) {
            wp_send_json_error('Permission denied.');
        }

        $class_id      = absint($_POST['class_id'] ?? 0);
        $date          = sanitize_text_field($_POST['date'] ?? current_time('Y-m-d'));
        $period_number = absint($_POST['period_number'] ?? 0);
        $subject       = sanitize_text_field($_POST['subject'] ?? '');
        $attendance    = $_POST['attendance'] ?? [];

        if (!$class_id || !$period_number || !is_array($attendance)) {
            wp_send_json_error('Missing data.');
        }

        /* Subject is required for period attendance */
        if (empty($subject)) {
            wp_send_json_error('Subject is required for period attendance.');
        }

        if (!current_user_can('nais_platform_admin') && !self::teacher_can_mark_class($class_id)) {
            wp_send_json_error('You are not assigned to this class.');
        }

        /* Validate date — not in future, not more than 7 days ago */
        $date_ts = strtotime($date);
        $today_ts = strtotime(current_time('Y-m-d'));
        if ($date_ts > $today_ts || $date_ts < ($today_ts - 7 * DAY_IN_SECONDS)) {
            wp_send_json_error('Invalid date. Attendance can only be marked for today or up to 7 days in the past.');
        }

        global $wpdb;

        /* Server-side holiday check — block full holidays */
        $class_school_id = $wpdb->get_var($wpdb->prepare(
            "SELECT school_id FROM " . NAIS_Database::table('classes') . " WHERE id = %d",
            $class_id
        ));
        if ($class_school_id) {
            $holiday = NAIS_Database::check_holiday($class_school_id, $date);
            if ($holiday && $holiday->type === 'holiday') {
                wp_send_json_error('Cannot mark attendance on a full holiday (' . esc_html($holiday->title) . '). Change the date or remove the holiday first.');
            }
        }

        /* Get valid student IDs for this class (array_flip for O(1) lookup) */
        $valid_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('students') . " WHERE class_id = %d AND status = 'active'",
            $class_id
        ));
        $valid_students = array_flip($valid_ids);

        $saved = 0;
        $valid_statuses = ['present' => 1, 'absent' => 1, 'late' => 1, 'excused' => 1];
        foreach ($attendance as $student_id => $status) {
            $student_id = absint($student_id);
            if (!isset($valid_students[$student_id])) continue;
            $status     = sanitize_text_field($status);

            if (!isset($valid_statuses[$status])) {
                $status = 'present';
            }

            if (self::mark_period($student_id, $date, $period_number, $subject, $status)) {
                $saved++;
            }
        }

        if ($saved === 0 && !empty($attendance)) {
            wp_send_json_error('Failed to save period attendance. Please try again.');
        }

        wp_send_json_success([
            'message' => sprintf('Period %d attendance saved for %d students.', $period_number, $saved),
        ]);
    }

    /**
     * AJAX: Get attendance data for a class on a date.
     */
    public static function ajax_get_attendance() {
        check_ajax_referer('nais_nonce', 'nonce');

        if (!current_user_can('nais_mark_attendance') && !current_user_can('nais_view_attendance')) {
            wp_send_json_error('Permission denied.');
        }

        $class_id = absint($_POST['class_id'] ?? 0);
        $date     = sanitize_text_field($_POST['date'] ?? current_time('Y-m-d'));

        if (!$class_id) {
            wp_send_json_error('Missing class ID.');
        }

        /* Verify teacher has access to this class */
        if (!current_user_can('nais_platform_admin') && !current_user_can('nais_view_attendance') && !self::teacher_can_mark_class($class_id)) {
            wp_send_json_error('You are not assigned to this class.');
        }

        $daily   = self::get_class_attendance($class_id, $date);
        $periods = self::get_class_period_attendance($class_id, $date);

        wp_send_json_success([
            'daily'   => $daily,
            'periods' => $periods,
        ]);
    }

    /**
     * AJAX: Get student report for parent view.
     */
    public static function ajax_get_student_report() {
        check_ajax_referer('nais_nonce', 'nonce');

        if (!current_user_can('nais_view_own_child') && !current_user_can('nais_view_attendance') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error('Permission denied.');
        }

        $student_id = absint($_POST['student_id'] ?? 0);
        $month      = absint($_POST['month'] ?? current_time('m'));
        $year       = absint($_POST['year'] ?? current_time('Y'));

        if (!$student_id) {
            wp_send_json_error('Missing student ID.');
        }

        /* Parent can only see their own child */
        if (current_user_can('nais_view_own_child') && !current_user_can('nais_view_attendance')) {
            global $wpdb;
            $linked = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM " . NAIS_Database::table('parent_links') .
                " WHERE parent_user_id = %d AND student_id = %d AND verified = 1",
                get_current_user_id(), $student_id
            ));
            if (!$linked) {
                wp_send_json_error('Access denied.');
            }
        }

        $stats = self::get_student_stats($student_id, $month, $year);

        /* Get daily breakdown */
        global $wpdb;
        $start = sprintf('%04d-%02d-01', $year, $month);
        $end   = gmdate('Y-m-t', strtotime($start));

        $daily_records = $wpdb->get_results($wpdb->prepare(
            "SELECT att_date, status, remarks FROM " . NAIS_Database::table('attendance_daily') .
            " WHERE student_id = %d AND att_date BETWEEN %s AND %s ORDER BY att_date ASC",
            $student_id, $start, $end
        ));

        wp_send_json_success([
            'stats'   => $stats,
            'records' => $daily_records,
        ]);
    }

    /**
     * Check if current teacher is assigned to a class.
     */
    private static function teacher_can_mark_class($class_id) {
        global $wpdb;
        $user_id = get_current_user_id();

        $teacher_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('teachers') . " WHERE user_id = %d AND status = 'active'",
            $user_id
        ));

        if (!$teacher_id) return false;

        return (bool)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . NAIS_Database::table('teacher_classes') .
            " WHERE teacher_id = %d AND class_id = %d",
            $teacher_id, $class_id
        ));
    }


    /* ═══════════════════════════════════════════
       MOBILE APP (Nagaland Me) — ATTENDANCE ENDPOINTS
       ═══════════════════════════════════════════ */

    /**
     * AJAX: nais_get_nonce
     * Returns a fresh nais_nonce. Used by the mobile app right after login.
     */
    public static function ajax_get_nonce() {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Not logged in.']);
        }
        wp_send_json_success(['nonce' => wp_create_nonce('nais_nonce')]);
    }

    /**
     * AJAX: nais_teacher_get_my_classes
     * Returns teacher info + every assigned class with its students and
     * subject list inline. The mobile app caches this in SQLite for offline use.
     */
    public static function ajax_teacher_get_my_classes() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_mark_attendance') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        global $wpdb;
        $user_id = get_current_user_id();

        $teacher = $wpdb->get_row($wpdb->prepare(
            "SELECT t.id, t.name, t.school_id, s.name AS school_name
             FROM " . NAIS_Database::table('teachers') . " t
             JOIN " . NAIS_Database::table('schools') . " s ON t.school_id = s.id
             WHERE t.user_id = %d AND t.status = 'active'",
            $user_id
        ));
        if (!$teacher) {
            wp_send_json_error(['message' => 'Your account is not assigned as a teacher.']);
        }

        if (class_exists('NAIS_Payment') && NAIS_Payment::is_school_locked((int)$teacher->school_id)) {
            wp_send_json_error(['message' => 'School subscription has expired. Contact your school administrator.']);
        }

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT c.id AS class_id, c.class_name, c.section, s.name AS school_name,
                    tc.subject, tc.is_class_teacher
             FROM " . NAIS_Database::table('teacher_classes') . " tc
             JOIN " . NAIS_Database::table('classes') . " c ON tc.class_id = c.id
             JOIN " . NAIS_Database::table('schools') . " s ON c.school_id = s.id
             WHERE tc.teacher_id = %d AND c.status = 'active'",
            $teacher->id
        ));

        $classes = [];
        foreach ($rows as $r) {
            $cid = (int)$r->class_id;
            if (!isset($classes[$cid])) {
                $classes[$cid] = [
                    'id'               => $cid,
                    'name'             => $r->class_name,
                    'section'          => $r->section,
                    'school_name'      => $r->school_name,
                    'is_class_teacher' => false,
                    'subjects'         => [],
                    '_seen'            => [],
                    'students'         => [],
                ];
            }
            if ($r->is_class_teacher) $classes[$cid]['is_class_teacher'] = true;
            $sub = trim((string)$r->subject);
            if ($sub !== '' && !isset($classes[$cid]['_seen'][$sub])) {
                $classes[$cid]['subjects'][] = ['id' => $sub, 'name' => $sub];
                $classes[$cid]['_seen'][$sub] = true;
            }
        }

        foreach ($classes as $cid => &$c) {
            unset($c['_seen']);
            $c['has_subjects'] = !empty($c['subjects']);
            $students = $wpdb->get_results($wpdb->prepare(
                "SELECT id, name, roll_no
                 FROM " . NAIS_Database::table('students') . "
                 WHERE class_id = %d AND status = 'active'
                 ORDER BY CASE WHEN roll_no IS NULL OR roll_no = '' THEN 1 ELSE 0 END,
                          CAST(roll_no AS UNSIGNED), name ASC",
                $cid
            ));
            $c['students'] = array_map(function ($s) {
                return [
                    'id'      => (int)$s->id,
                    'name'    => $s->name,
                    'roll_no' => $s->roll_no,
                ];
            }, $students);
        }
        unset($c);

        wp_send_json_success([
            'teacher' => [
                'id'          => (int)$teacher->id,
                'name'        => $teacher->name,
                'school_name' => $teacher->school_name,
            ],
            'classes' => array_values($classes),
        ]);
    }

    /**
     * AJAX: nais_teacher_attendance_today
     * Returns existing entries for (class, subject?, period?, date) so the
     * mobile app can pre-fill the roster when the teacher reopens it.
     *
     * period_number is optional. When omitted, defaults to 1 so older app
     * builds keep working unchanged.
     */
    public static function ajax_teacher_attendance_today() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_mark_attendance') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        $class_id   = absint($_POST['class_id'] ?? 0);
        $date       = sanitize_text_field($_POST['date'] ?? current_time('Y-m-d'));
        $subject_id = sanitize_text_field($_POST['subject_id'] ?? '');

        /* Period number from app. Defaults to 1 when not sent (back-compat with current iOS build). */
        $period_number = absint($_POST['period_number'] ?? 1);
        if ($period_number < 1) $period_number = 1;

        if (!$class_id) {
            wp_send_json_error(['message' => 'Missing class ID.']);
        }
        if (!current_user_can('nais_platform_admin') && !self::teacher_can_mark_class($class_id)) {
            wp_send_json_error(['message' => 'You are not assigned to this class.']);
        }

        global $wpdb;
        if ($subject_id === '') {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT student_id, status, remarks
                 FROM " . NAIS_Database::table('attendance_daily') . "
                 WHERE class_id = %d AND att_date = %s",
                $class_id, $date
            ));
        } else {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT student_id, status, '' AS remarks
                 FROM " . NAIS_Database::table('attendance_period') . "
                 WHERE class_id = %d AND att_date = %s AND period_number = %d AND subject = %s",
                $class_id, $date, $period_number, $subject_id
            ));
        }

        $records = array_map(function ($r) {
            return [
                'student_id' => (int)$r->student_id,
                'status'     => (string)$r->status,
                'remarks'    => (string)($r->remarks ?? ''),
            ];
        }, $rows);

        wp_send_json_success(['records' => $records]);
    }

    /**
     * AJAX: nais_teacher_submit_attendance
     * Accepts a batch of records for one (class, subject?, period?, date)
     * submitted from the mobile app.
     *
     * Hardening:
     *  - 2-second per-user rate limit blocks duplicate hits from network
     *    retries or accidental double-taps without blocking sequential
     *    submissions across multiple classes.
     *  - period_number is read from POST (defaults to 1 for back-compat),
     *    so the app can submit Period 2, 3, etc.
     *  - Per-record idempotency cache keyed on client_id (60s window).
     *    A retry of the same client_id within the window returns the
     *    cached server_id without re-touching the DB. Outside the window,
     *    normal upsert resumes — so legitimate corrections still work.
     *  - The save loop is wrapped in a DB transaction. If zero records
     *    save, the whole batch is rolled back so audit logs and partial
     *    rows don't leak through.
     */
    public static function ajax_teacher_submit_attendance() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_mark_attendance') && !current_user_can('nais_platform_admin')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        /* Rate limit: prevent duplicate submissions from network retries / double-taps. */
        $rate_key = 'nais_att_submit_' . get_current_user_id();
        if (get_transient($rate_key)) {
            wp_send_json_error(['message' => 'Too many requests. Please wait a moment and try again.']);
        }
        set_transient($rate_key, 1, 2);

        $class_id   = absint($_POST['class_id'] ?? 0);
        $date       = sanitize_text_field($_POST['date'] ?? current_time('Y-m-d'));
        $subject_id = sanitize_text_field($_POST['subject_id'] ?? '');
        $records_in = $_POST['records'] ?? '';

        /* Period number from app. Defaults to 1 when not sent (back-compat with current iOS build). */
        $period_number = absint($_POST['period_number'] ?? 1);
        if ($period_number < 1) $period_number = 1;

        if (!$class_id) {
            wp_send_json_error(['message' => 'Missing class ID.']);
        }

        /* Records arrive as a JSON-encoded string */
        if (is_string($records_in)) $records_in = json_decode(wp_unslash($records_in), true);
        if (!is_array($records_in) || empty($records_in)) {
            wp_send_json_error(['message' => 'No records to save.']);
        }

        if (!current_user_can('nais_platform_admin') && !self::teacher_can_mark_class($class_id)) {
            wp_send_json_error(['message' => 'You are not assigned to this class.']);
        }

        $date_ts  = strtotime($date);
        $today_ts = strtotime(current_time('Y-m-d'));
        if (!$date_ts || $date_ts > $today_ts || $date_ts < ($today_ts - 7 * DAY_IN_SECONDS)) {
            wp_send_json_error(['message' => 'Invalid date. Attendance can only be marked for today or up to 7 days ago.']);
        }

        global $wpdb;

        $school_id = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT school_id FROM " . NAIS_Database::table('classes') . " WHERE id = %d",
            $class_id
        ));
        if ($school_id) {
            if (class_exists('NAIS_Payment') && NAIS_Payment::is_school_locked($school_id)) {
                wp_send_json_error(['message' => 'School subscription has expired.']);
            }
            $holiday = NAIS_Database::check_holiday($school_id, $date);
            if ($holiday && $holiday->type === 'holiday') {
                wp_send_json_error(['message' => 'Cannot mark attendance on a full holiday (' . esc_html($holiday->title) . ').']);
            }
        }

        $valid_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('students') . "
             WHERE class_id = %d AND status = 'active'",
            $class_id
        ));
        $valid = array_flip(array_map('intval', $valid_ids));

        $valid_statuses = ['present' => 1, 'absent' => 1, 'late' => 1, 'excused' => 1];
        $is_period      = ($subject_id !== '');
        $current_user   = get_current_user_id();

        /* Wrap the save loop in a transaction so a fully-failed batch leaves
           no audit log noise or half-saved roster behind. InnoDB only. */
        $wpdb->query('START TRANSACTION');

        $results = [];
        $saved   = 0;

        foreach ($records_in as $rec) {
            $student_id = absint($rec['student_id'] ?? 0);
            $status     = sanitize_text_field($rec['status'] ?? '');
            $remarks    = sanitize_text_field($rec['remarks'] ?? '');
            $client_id  = sanitize_text_field($rec['client_id'] ?? '');

            if (!$student_id || !isset($valid[$student_id])) continue;
            if (!isset($valid_statuses[$status])) continue;

            /* Idempotency: if this exact client_id was processed in the last
               60 seconds, return the cached server_id without re-processing.
               This catches network retries cleanly. After 60s the cache
               expires and normal upsert resumes, so corrections still work. */
            $idem_key = '';
            if ($client_id !== '') {
                $idem_key  = 'nais_att_idem_' . $current_user . '_' . md5($client_id);
                $cached_id = get_transient($idem_key);
                if ($cached_id !== false) {
                    $results[] = [
                        'client_id'  => $client_id,
                        'student_id' => $student_id,
                        'server_id'  => (int)$cached_id,
                    ];
                    $saved++;
                    continue;
                }
            }

            if ($is_period) {
                $row_id = self::mark_period($student_id, $date, $period_number, $subject_id, $status);
            } else {
                $row_id = self::mark_daily($student_id, $date, $status, $remarks);
            }

            if (!$row_id) continue;

            /* Cache (client_id → row_id) for 60s so retries are no-ops. */
            if ($idem_key !== '') {
                set_transient($idem_key, (int)$row_id, 60);
            }

            $results[] = [
                'client_id'  => $client_id,
                'student_id' => $student_id,
                'server_id'  => (int)$row_id,
            ];
            $saved++;
        }

        if ($saved === 0) {
            $wpdb->query('ROLLBACK');
            wp_send_json_error(['message' => 'No records were saved. The roster may have changed.']);
        }

        $wpdb->query('COMMIT');

        wp_send_json_success([
            'saved'   => $saved,
            'results' => $results,
        ]);
    }
}