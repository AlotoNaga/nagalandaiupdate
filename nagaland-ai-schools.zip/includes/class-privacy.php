<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS PRIVACY — DPDP Act 2023 Compliance + Login/Logout
 * ═══════════════════════════════════════════════════════════════
 */

if (!defined('ABSPATH')) exit;

class NAIS_Privacy {

    public static function setup_privacy() {
        update_option('blog_public', '0');
    }

    public static function init() {
        add_action('wp_head', [__CLASS__, 'force_noindex'], 1);
        add_action('admin_init', [__CLASS__, 'block_admin_access']);
        add_filter('show_admin_bar', [__CLASS__, 'hide_admin_bar']);
        add_action('wp_ajax_nais_request_data_deletion', [__CLASS__, 'handle_deletion_request']);
        add_filter('robots_txt', [__CLASS__, 'strict_robots'], 10, 2);

        /* Login/Logout */
        add_action('login_enqueue_scripts', [__CLASS__, 'login_styles']);
        add_filter('login_headerurl', function() { return home_url('/'); });
        add_filter('login_headertext', function() { return 'Nagaland AI Schools'; });
        add_filter('login_redirect', [__CLASS__, 'login_redirect'], 10, 3);
        add_action('wp_logout', [__CLASS__, 'logout_redirect']);
        add_filter('wp_nav_menu_items', [__CLASS__, 'add_logout_to_menu'], 10, 2);
        add_action('template_redirect', [__CLASS__, 'require_login']);
        add_filter('login_errors', [__CLASS__, 'login_error_message']);
        add_filter('login_message', [__CLASS__, 'login_register_links']);
        add_action('login_footer', [__CLASS__, 'login_footer_links']);
    }

    public static function force_noindex() {
        echo '<meta name="robots" content="noindex, nofollow, noarchive, nosnippet">' . "\n";
    }

    public static function strict_robots($output, $public) {
        return "User-agent: *\nDisallow: /\n";
    }

    public static function block_admin_access() {
        if (wp_doing_ajax()) return;
        $user = wp_get_current_user();
        if (!$user || !$user->ID) return;
        $allowed_roles = ['administrator', 'nais_school_admin', 'nais_auditor'];
        foreach ($allowed_roles as $role) {
            if (in_array($role, (array)$user->roles, true)) return;
        }
        /* Also allow users with the platform admin capability (granted to administrators) */
        if (current_user_can('nais_platform_admin')) return;
        wp_redirect(home_url('/dashboard/'));
        exit;
    }

    public static function hide_admin_bar($show) {
        if (current_user_can('manage_options') || current_user_can('nais_platform_admin')) return $show;
        return false;
    }


    /* ═══════════════════════════════════════════
       BRANDED LOGIN PAGE
    ═══════════════════════════════════════════ */

    public static function login_styles() {
        ?>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Outfit:wght@300;400;500;600;700&display=swap');

            body.login {
                background: #0F2419 !important;
                font-family: 'Outfit', -apple-system, sans-serif;
            }

            #login h1 a {
                background-image: none !important;
                width: auto !important;
                height: auto !important;
                text-indent: 0 !important;
                font-family: 'DM Serif Display', Georgia, serif !important;
                font-size: 28px !important;
                color: #10B981 !important;
                text-decoration: none !important;
                padding-bottom: 10px !important;
            }

            .login form {
                background: #1A2E23 !important;
                border: 1px solid #2A4A3A !important;
                border-radius: 12px !important;
                box-shadow: 0 8px 32px rgba(0,0,0,0.3) !important;
                padding: 26px 24px !important;
            }

            .login form .input,
            .login form input[type="text"],
            .login form input[type="password"],
            .login form input[type="email"] {
                background: #0F2419 !important;
                border: 1px solid #2A4A3A !important;
                border-radius: 8px !important;
                color: #E5E7EB !important;
                padding: 10px 14px !important;
                font-size: 15px !important;
                font-family: 'Outfit', sans-serif !important;
            }

            .login form .input:focus,
            .login form input:focus {
                border-color: #10B981 !important;
                box-shadow: 0 0 0 2px rgba(16,185,129,0.2) !important;
                outline: none !important;
            }

            .login form label {
                color: #D1D5DB !important;
                font-family: 'Outfit', sans-serif !important;
                font-size: 14px !important;
            }

            .wp-core-ui .button-primary {
                background: #10B981 !important;
                border: none !important;
                border-radius: 8px !important;
                color: #fff !important;
                font-family: 'Outfit', sans-serif !important;
                font-weight: 600 !important;
                font-size: 15px !important;
                padding: 10px 24px !important;
                text-shadow: none !important;
                box-shadow: none !important;
                transition: background 0.2s !important;
                width: 100% !important;
                height: auto !important;
            }

            .wp-core-ui .button-primary:hover,
            .wp-core-ui .button-primary:focus {
                background: #0A7558 !important;
            }

            .login .forgetmenot label { color: #9CA3AF !important; }

            .login #nav a,
            .login #backtoblog a,
            .login .privacy-policy-page-link a {
                color: #10B981 !important;
                font-family: 'Outfit', sans-serif !important;
            }

            .login #nav a:hover,
            .login #backtoblog a:hover { color: #D4A843 !important; }

            .login .message, .login .success {
                border-left: 4px solid #10B981 !important;
                background: #1A2E23 !important;
                color: #D1D5DB !important;
                border-radius: 8px !important;
                font-family: 'Outfit', sans-serif !important;
                text-align: center;
            }

            #login_error {
                border-left: 4px solid #EF4444 !important;
                background: #1A2E23 !important;
                color: #FCA5A5 !important;
                border-radius: 8px !important;
                font-family: 'Outfit', sans-serif !important;
            }

            .login #backtoblog { display: none !important; }
            .login #nav { text-align: center; }

            #login::after {
                content: 'Nagaland AI \2014 India\2019s First AI Built for Nagaland';
                display: block;
                text-align: center;
                color: #6B7280;
                font-family: 'Outfit', sans-serif;
                font-size: 12px;
                margin-top: 20px;
            }
        </style>
        <?php
    }


    /* ═══════════════════════════════════════════
       LOGIN / LOGOUT REDIRECTS
    ═══════════════════════════════════════════ */

    public static function login_redirect($redirect_to, $requested_redirect_to, $user) {
        if (!is_wp_error($user) && $user instanceof WP_User) {
            $roles = (array)$user->roles;
            /* Pure administrator (not also school admin) → wp-admin */
            if (in_array('administrator', $roles, true) && !in_array('nais_school_admin', $roles, true)) {
                return admin_url();
            }
            /* Everyone else → frontend dashboard */
            return home_url('/dashboard/');
        }
        return $redirect_to;
    }

    public static function logout_redirect() {
        wp_safe_redirect(wp_login_url() . '?logged_out=true');
        exit;
    }

    /**
     * Add Login/Logout link to the navigation menu.
     */
    public static function add_logout_to_menu($items, $args) {
        if (is_user_logged_in()) {
            $logout_url = wp_logout_url(wp_login_url());
            $items .= '<li class="menu-item"><a href="' . esc_url($logout_url) . '" style="color:#EF4444 !important;">Logout</a></li>';
        } else {
            $login_url = wp_login_url(home_url('/dashboard/'));
            $items .= '<li class="menu-item"><a href="' . esc_url($login_url) . '">Login</a></li>';
        }
        return $items;
    }

    /**
     * Force login on all pages. Entire site is private.
     * Exceptions: wp-login, wp-cron, wp-json (REST API), register page.
     */
    public static function require_login() {
        if (is_user_logged_in()) return;
        if (wp_doing_ajax()) return;
        if (defined('REST_REQUEST') && REST_REQUEST) return;

        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $path = parse_url($uri, PHP_URL_PATH) ?: '';
        if (strpos($path, 'wp-login') !== false) return;
        if (strpos($path, 'wp-cron') !== false) return;
        if (strpos($path, 'wp-json') !== false) return;
        if (preg_match('#/register/?$#', $path) || preg_match('#/register-school/?$#', $path)) return;

        wp_redirect(wp_login_url(home_url($uri)));
        exit;
    }

    /**
     * Don't reveal if username exists — security hardening.
     */
    public static function login_error_message($error) {
        return '<strong>Login failed.</strong> Please check your username and password.';
    }


    /**
     * Show registration links above the login form.
     */
    public static function login_register_links($message) {
        /* Don't show on password reset page */
        $action = $_GET['action'] ?? 'login';
        if ($action !== 'login') return $message;

        $register_url = home_url('/register/');
        $school_url   = home_url('/register-school/');

        $html = '<div style="background:#1A2E23;border:1px solid #2A4A3A;border-radius:12px;padding:20px 24px;margin-bottom:16px;text-align:center;font-family:Outfit,sans-serif;">';
        $html .= '<p style="color:#D1D5DB;font-size:14px;margin:0 0 12px;">New here? Choose how to get started:</p>';
        $html .= '<a href="' . esc_url($register_url) . '" style="display:block;background:#10B981;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px;margin-bottom:8px;">I\'m a Parent (Register with Code)</a>';
        $html .= '<a href="' . esc_url($school_url) . '" style="display:block;background:#D4A843;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px;">Register My School</a>';
        $html .= '<p style="color:#6B7280;font-size:12px;margin:10px 0 0;">Teachers: Your school admin will create your account.</p>';
        $html .= '</div>';

        return $html . $message;
    }

    /**
     * Add helpful links below the login form.
     */
    public static function login_footer_links() {
        ?>
        <div style="text-align:center;margin-top:16px;font-family:Outfit,sans-serif;">
            <p style="color:#6B7280;font-size:13px;margin:8px 0;">
                Need help? WhatsApp us at
                <a href="https://wa.me/916383359495" style="color:#10B981;text-decoration:none;">+91 63833 59495</a>
            </p>
            <p style="margin:8px 0;">
                <a href="https://nagalandai.com" style="color:#10B981;text-decoration:none;font-size:13px;">Visit Nagaland AI &rarr;</a>
            </p>
        </div>
        <?php
    }


    /* ═══════════════════════════════════════════
       DATA DELETION (DPDP Act 2023)
    ═══════════════════════════════════════════ */

    public static function handle_deletion_request() {
        check_ajax_referer('nais_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id) wp_send_json_error('Not logged in.');
        if (!current_user_can('nais_view_own_child')) wp_send_json_error('Only parents can request data deletion.');

        global $wpdb;
        $student_id = absint($_POST['student_id'] ?? 0);
        if ($student_id) {
            $wpdb->delete(NAIS_Database::table('parent_links'), ['parent_user_id' => $user_id, 'student_id' => $student_id]);
        } else {
            $wpdb->delete(NAIS_Database::table('parent_links'), ['parent_user_id' => $user_id]);
        }

        NAIS_Database::audit_log('data_deletion_request', 'parent', $user_id, 0,
            'Parent requested data deletion under DPDP Act 2023.');

        $admin_email = get_option('admin_email');
        $user_info = get_userdata($user_id);
        wp_mail($admin_email, '[NAIS] Data Deletion Request',
            sprintf("Parent data deletion request:\n\nUser: %s (ID: %d)\nEmail: %s\nDate: %s\n\nParent links removed.",
                $user_info->display_name, $user_id, $user_info->user_email, current_time('mysql')));

        wp_send_json_success('Your data deletion request has been processed.');
    }
}