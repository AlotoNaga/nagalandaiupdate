<?php
/**
 * NAIS BUS TRACKING — Secure Live Bus Location System
 * Maximum security: audit every view, delete GPS after trip, rate limit, kill switch
 */
if (!defined('ABSPATH')) exit;

class NAIS_Bus_Tracking {
    const MAX_VIEWS_PER_HOUR = 30;
    const SUSPICIOUS_THRESHOLD = 50;

    public static function init() {
        add_action('wp_ajax_nais_add_bus', [__CLASS__, 'ajax_add_bus']);
        add_action('wp_ajax_nais_get_buses', [__CLASS__, 'ajax_get_buses']);
        add_action('wp_ajax_nais_delete_bus', [__CLASS__, 'ajax_delete_bus']);
        add_action('wp_ajax_nais_assign_bus_students', [__CLASS__, 'ajax_assign_bus_students']);
        add_action('wp_ajax_nais_get_bus_students', [__CLASS__, 'ajax_get_bus_students']);
        add_action('wp_ajax_nais_bus_kill_switch', [__CLASS__, 'ajax_kill_switch']);
        add_action('wp_ajax_nais_get_bus_view_log', [__CLASS__, 'ajax_get_view_log']);
        add_action('wp_ajax_nais_driver_start_trip', [__CLASS__, 'ajax_start_trip']);
        add_action('wp_ajax_nais_driver_end_trip', [__CLASS__, 'ajax_end_trip']);
        add_action('wp_ajax_nais_driver_ping_location', [__CLASS__, 'ajax_ping_location']);
        add_action('wp_ajax_nais_driver_get_my_bus', [__CLASS__, 'ajax_get_my_bus']);
        add_action('wp_ajax_nais_parent_get_bus_location', [__CLASS__, 'ajax_parent_get_bus_location']);
        add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
        add_action('nais_cleanup_stale_locations', [__CLASS__, 'cleanup_stale_locations']);
        if (!wp_next_scheduled('nais_cleanup_stale_locations')) {
            wp_schedule_event(time(), 'hourly', 'nais_cleanup_stale_locations');
        }
    }

    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta("CREATE TABLE " . self::table('buses') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, school_id BIGINT UNSIGNED NOT NULL,
            bus_number VARCHAR(50) NOT NULL, plate_number VARCHAR(50) DEFAULT '',
            driver_user_id BIGINT UNSIGNED DEFAULT NULL, driver_name VARCHAR(255) DEFAULT '',
            driver_phone VARCHAR(20) DEFAULT '', capacity INT DEFAULT 40,
            route_name VARCHAR(255) DEFAULT '', route_details TEXT,
            status VARCHAR(20) DEFAULT 'active', tracking_enabled TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), KEY school_id (school_id), KEY driver_user_id (driver_user_id)
        ) {$charset};");

        dbDelta("CREATE TABLE " . self::table('bus_students') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, bus_id BIGINT UNSIGNED NOT NULL,
            student_id BIGINT UNSIGNED NOT NULL, pickup_point VARCHAR(255) DEFAULT '',
            assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY bus_student (bus_id, student_id), KEY student_id (student_id)
        ) {$charset};");

        dbDelta("CREATE TABLE " . self::table('bus_trips') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, bus_id BIGINT UNSIGNED NOT NULL,
            driver_user_id BIGINT UNSIGNED NOT NULL, school_id BIGINT UNSIGNED NOT NULL,
            trip_type VARCHAR(20) DEFAULT 'morning', started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            ended_at DATETIME DEFAULT NULL, status VARCHAR(20) DEFAULT 'active',
            PRIMARY KEY (id), KEY bus_id (bus_id), KEY status (status), KEY school_id (school_id)
        ) {$charset};");

        dbDelta("CREATE TABLE " . self::table('bus_locations') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, trip_id BIGINT UNSIGNED NOT NULL,
            bus_id BIGINT UNSIGNED NOT NULL, latitude DECIMAL(10,7) NOT NULL,
            longitude DECIMAL(10,7) NOT NULL, speed_kmh DECIMAL(5,1) DEFAULT NULL,
            accuracy_meters DECIMAL(5,1) DEFAULT NULL, recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), KEY trip_id (trip_id), KEY bus_id (bus_id), KEY recorded_at (recorded_at)
        ) {$charset};");

        dbDelta("CREATE TABLE " . self::table('bus_view_log') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, bus_id BIGINT UNSIGNED NOT NULL,
            trip_id BIGINT UNSIGNED DEFAULT NULL, parent_user_id BIGINT UNSIGNED NOT NULL,
            student_id BIGINT UNSIGNED NOT NULL, ip_address VARCHAR(45) NOT NULL,
            user_agent VARCHAR(500) DEFAULT '', viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            flagged TINYINT(1) DEFAULT 0, flag_reason VARCHAR(255) DEFAULT '',
            PRIMARY KEY (id), KEY bus_id (bus_id), KEY parent_user_id (parent_user_id),
            KEY viewed_at (viewed_at), KEY flagged (flagged)
        ) {$charset};");
    }

    public static function table($name) { global $wpdb; return $wpdb->prefix . 'nais_' . $name; }

    /* ═══ SCHOOL ADMIN: BUSES TAB ═══ */
    public static function render_buses_tab($school_id, $classes) {
        global $wpdb;
        $buses = $wpdb->get_results($wpdb->prepare(
            "SELECT b.*, (SELECT COUNT(*) FROM " . self::table('bus_students') . " bs WHERE bs.bus_id = b.id) AS student_count,
             (SELECT COUNT(*) FROM " . self::table('bus_trips') . " t WHERE t.bus_id = b.id AND t.status = 'active') AS active_trip
             FROM " . self::table('buses') . " b WHERE b.school_id = %d AND b.status = 'active' ORDER BY b.bus_number ASC", $school_id));
        $students = $wpdb->get_results($wpdb->prepare(
            "SELECT s.id, s.name, s.roll_no, c.class_name, c.section FROM " . NAIS_Database::table('students') . " s
             JOIN " . NAIS_Database::table('classes') . " c ON s.class_id = c.id
             WHERE s.school_id = %d AND s.status = 'active' ORDER BY c.class_name ASC, s.name ASC", $school_id));
        $global_disabled = get_option("nais_school_{$school_id}_bus_tracking_disabled", false);
        ob_start(); ?>
        <h3>Bus & Transport Management</h3>
        <p>Manage school buses, assign students, and monitor live tracking.</p>
        <div style="margin-bottom:20px;">
            <button class="nais-btn <?php echo $global_disabled ? 'nais-btn-primary' : 'nais-btn-danger'; ?>" id="nais-bus-kill-switch" data-enabled="<?php echo $global_disabled ? '0' : '1'; ?>">
                <?php echo $global_disabled ? 'Enable All Bus Tracking' : 'DISABLE All Bus Tracking (Kill Switch)'; ?>
            </button>
            <?php if ($global_disabled): ?><span style="color:#DC2626;font-weight:600;margin-left:10px;">Tracking DISABLED</span><?php endif; ?>
        </div>
        <h4>Add New Bus</h4>
        <form id="nais-add-bus-form" class="nais-form">
            <div class="nais-form-row"><label>Bus Number *</label><input type="text" name="bus_number" placeholder="Bus 1" required></div>
            <div class="nais-form-row"><label>Plate Number</label><input type="text" name="plate_number" placeholder="NL-01-1234"></div>
            <div class="nais-form-row"><label>Driver Name</label><input type="text" name="driver_name"></div>
            <div class="nais-form-row"><label>Driver Phone</label><input type="tel" name="driver_phone"></div>
            <div class="nais-form-row"><label>Capacity</label><input type="number" name="capacity" value="40" min="1" max="100"></div>
            <div class="nais-form-row"><label>Route Name</label><input type="text" name="route_name" placeholder="Dimapur - School"></div>
            <div class="nais-form-row"><label>Route Details</label><textarea name="route_details" rows="2" placeholder="Stop A → Stop B → School"></textarea></div>
            <button type="submit" class="nais-btn">Add Bus</button>
        </form>
        <h4 style="margin-top:24px;">Your Buses (<?php echo count($buses); ?>)</h4>
        <?php if (empty($buses)): ?><p class="nais-hint">No buses yet.</p>
        <?php else: foreach ($buses as $bus): ?>
            <div class="nais-bus-card" data-bus-id="<?php echo $bus->id; ?>" style="border:1px solid #e5e7eb;border-radius:12px;padding:16px;margin-bottom:12px;">
                <strong><?php echo esc_html($bus->bus_number); ?></strong>
                <?php if ($bus->plate_number): ?><span style="color:#666;"> | <?php echo esc_html($bus->plate_number); ?></span><?php endif; ?>
                <?php if ($bus->active_trip): ?><span class="nais-status-badge nais-status-present" style="font-size:11px;padding:4px 10px;margin-left:8px;">LIVE</span><?php endif; ?>
                <div style="font-size:13px;color:#666;margin-top:4px;">Driver: <?php echo esc_html($bus->driver_name ?: '—'); ?> | Students: <?php echo (int)$bus->student_count; ?>/<?php echo (int)$bus->capacity; ?> | Route: <?php echo esc_html($bus->route_name ?: '—'); ?></div>
                <div style="margin-top:8px;">
                    <button class="nais-btn nais-btn-xs nais-assign-students-btn" data-bus-id="<?php echo $bus->id; ?>" data-bus-name="<?php echo esc_attr($bus->bus_number); ?>">Assign Students</button>
                    <button class="nais-btn nais-btn-xs nais-view-bus-log" data-bus-id="<?php echo $bus->id; ?>" style="margin-left:4px;">View Log</button>
                    <button class="nais-btn nais-btn-xs nais-btn-danger nais-delete-bus" data-bus-id="<?php echo $bus->id; ?>" style="margin-left:4px;">Delete</button>
                </div>
            </div>
        <?php endforeach; endif; ?>
        <div id="nais-bus-assign-modal" style="display:none;margin-top:20px;padding:20px;border:2px solid #0A7558;border-radius:12px;">
            <h4>Assign Students to: <span id="nais-assign-bus-name"></span></h4>
            <input type="hidden" id="nais-assign-bus-id">
            <p class="nais-hint">Only these parents will see this bus's live location.</p>
            <div id="nais-bus-student-list" style="max-height:400px;overflow-y:auto;">
                <?php foreach ($students as $s): ?>
                    <label class="nais-checkbox"><input type="checkbox" name="bus_student_ids[]" value="<?php echo $s->id; ?>"><?php echo esc_html($s->name); ?> <small style="color:#999;">(<?php echo esc_html($s->class_name . ' ' . $s->section); ?>)</small></label>
                <?php endforeach; ?>
            </div>
            <div style="margin-top:12px;">
                <button class="nais-btn" id="nais-save-bus-students">Save Assignments</button>
                <button class="nais-btn nais-btn-sm" id="nais-close-assign-modal" style="margin-left:8px;">Close</button>
            </div>
        </div>
        <div id="nais-bus-log-container" style="display:none;margin-top:20px;padding:20px;border:1px solid #e5e7eb;border-radius:12px;">
            <h4>Bus Location View Log</h4>
            <p class="nais-hint">Who viewed live location, when, and from which IP. Flagged = suspicious.</p>
            <div id="nais-bus-log-data"></div>
            <button class="nais-btn nais-btn-sm" id="nais-close-log" style="margin-top:12px;">Close</button>
        </div>
        <?php return ob_get_clean();
    }

    /* ═══ AJAX HANDLERS ═══ */
    public static function ajax_add_bus() {
        check_ajax_referer('nais_nonce','nonce'); if(!current_user_can('nais_manage_school')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $sid=NAIS_Roles::get_user_school_id(); if(!$sid) wp_send_json_error('No school.');
        $bn=sanitize_text_field($_POST['bus_number']??''); if(!$bn) wp_send_json_error('Bus number required.');
        $wpdb->insert(self::table('buses'),['school_id'=>$sid,'bus_number'=>$bn,'plate_number'=>sanitize_text_field($_POST['plate_number']??''),
            'driver_name'=>sanitize_text_field($_POST['driver_name']??''),'driver_phone'=>sanitize_text_field($_POST['driver_phone']??''),
            'capacity'=>absint($_POST['capacity']??40),'route_name'=>sanitize_text_field($_POST['route_name']??''),
            'route_details'=>sanitize_textarea_field($_POST['route_details']??'')]);
        NAIS_Database::audit_log('bus_created','bus',$wpdb->insert_id,$sid,'Bus: '.$bn);
        wp_send_json_success(['message'=>'Bus "'.$bn.'" added.']);
    }

    public static function ajax_get_buses() {
        check_ajax_referer('nais_nonce','nonce'); if(!current_user_can('nais_manage_school')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $sid=NAIS_Roles::get_user_school_id();
        wp_send_json_success(['buses'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM ".self::table('buses')." WHERE school_id=%d AND status='active' ORDER BY bus_number",$sid))]);
    }

    public static function ajax_delete_bus() {
        check_ajax_referer('nais_nonce','nonce'); if(!current_user_can('nais_manage_school')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $bid=absint($_POST['bus_id']??0); $sid=NAIS_Roles::get_user_school_id();
        $bus=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table('buses')." WHERE id=%d AND school_id=%d",$bid,$sid));
        if(!$bus) wp_send_json_error('Bus not found.');
        $wpdb->update(self::table('bus_trips'),['status'=>'ended','ended_at'=>current_time('mysql')],['bus_id'=>$bid,'status'=>'active']);
        $wpdb->query($wpdb->prepare("DELETE FROM ".self::table('bus_locations')." WHERE bus_id=%d",$bid));
        $wpdb->update(self::table('buses'),['status'=>'deleted'],['id'=>$bid]);
        NAIS_Database::audit_log('bus_deleted','bus',$bid,$sid,'Bus: '.$bus->bus_number);
        wp_send_json_success(['message'=>'Bus deleted. GPS data removed.']);
    }

    public static function ajax_get_bus_students() {
        check_ajax_referer('nais_nonce','nonce'); if(!current_user_can('nais_manage_school')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $bid=absint($_POST['bus_id']??0); $sid=NAIS_Roles::get_user_school_id();
        /* Verify bus belongs to this school */
        if ($sid) { $bus_ok=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::table('buses')." WHERE id=%d AND school_id=%d",$bid,$sid)); if(!$bus_ok) wp_send_json_error('Bus not found.'); }
        wp_send_json_success(['student_ids'=>$wpdb->get_col($wpdb->prepare("SELECT student_id FROM ".self::table('bus_students')." WHERE bus_id=%d",$bid))]);
    }

    public static function ajax_assign_bus_students() {
        check_ajax_referer('nais_nonce','nonce'); if(!current_user_can('nais_manage_school')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $bid=absint($_POST['bus_id']??0); $sids=array_map('absint',$_POST['student_ids']??[]); $sid=NAIS_Roles::get_user_school_id();
        $bus=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table('buses')." WHERE id=%d AND school_id=%d",$bid,$sid));
        if(!$bus) wp_send_json_error('Bus not found.');
        /* Enforce capacity */
        if(count($sids)>(int)$bus->capacity) wp_send_json_error('Cannot assign more than '.$bus->capacity.' students (bus capacity).');
        /* Transaction: delete old assignments then insert new ones atomically */
        $wpdb->query('START TRANSACTION');
        $wpdb->delete(self::table('bus_students'),['bus_id'=>$bid]);
        $inserted=0;
        foreach($sids as $s){if($wpdb->insert(self::table('bus_students'),['bus_id'=>$bid,'student_id'=>$s])) $inserted++;}
        if($inserted===count($sids)||empty($sids)){$wpdb->query('COMMIT');}
        else{$wpdb->query('ROLLBACK');wp_send_json_error('Failed to assign some students. Please try again.');}
        NAIS_Database::audit_log('bus_students_assigned','bus',$bid,$sid,$inserted.' students assigned to '.$bus->bus_number);
        wp_send_json_success(['message'=>$inserted.' students assigned.']);
    }

    public static function ajax_kill_switch() {
        check_ajax_referer('nais_nonce','nonce'); if(!current_user_can('nais_manage_school')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $sid=NAIS_Roles::get_user_school_id(); $en=absint($_POST['enabled']??0);
        if($en){delete_option("nais_school_{$sid}_bus_tracking_disabled");$msg='Bus tracking ENABLED.';}
        else{update_option("nais_school_{$sid}_bus_tracking_disabled",true);
            $wpdb->query($wpdb->prepare("UPDATE ".self::table('bus_trips')." SET status='killed',ended_at=%s WHERE school_id=%d AND status='active'",current_time('mysql'),$sid));
            $wpdb->query($wpdb->prepare("DELETE loc FROM ".self::table('bus_locations')." loc JOIN ".self::table('buses')." b ON loc.bus_id=b.id WHERE b.school_id=%d",$sid));
            $msg='Bus tracking DISABLED. All GPS data deleted.';}
        NAIS_Database::audit_log('bus_kill_switch','school',$sid,$sid,$msg);
        wp_send_json_success(['message'=>$msg]);
    }

    public static function ajax_get_view_log() {
        check_ajax_referer('nais_nonce','nonce'); if(!current_user_can('nais_manage_school')&&!current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');
        global $wpdb; $bid=absint($_POST['bus_id']??0);
        $logs=$wpdb->get_results($wpdb->prepare("SELECT vl.*,u.display_name AS parent_name,s.name AS student_name FROM ".self::table('bus_view_log')." vl LEFT JOIN {$wpdb->users} u ON vl.parent_user_id=u.ID LEFT JOIN ".NAIS_Database::table('students')." s ON vl.student_id=s.id WHERE vl.bus_id=%d ORDER BY vl.viewed_at DESC LIMIT 100",$bid));
        $flagged=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".self::table('bus_view_log')." WHERE bus_id=%d AND flagged=1",$bid));
        wp_send_json_success(['logs'=>$logs,'flagged'=>$flagged]);
    }

    /* ═══ DRIVER TRIP MANAGEMENT ═══ */
    public static function ajax_start_trip() {
        check_ajax_referer('nais_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error('Not logged in.');
        global $wpdb; $uid=get_current_user_id(); $tt=sanitize_text_field($_POST['trip_type']??'morning');
        /* Validate trip_type against allowed values */
        if(!in_array($tt,['morning','afternoon','evening','special'],true)) $tt='morning';
        $bus=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table('buses')." WHERE driver_user_id=%d AND status='active'",$uid));
        if(!$bus) wp_send_json_error('No bus assigned to you.');
        if(get_option("nais_school_{$bus->school_id}_bus_tracking_disabled",false)) wp_send_json_error('Tracking disabled by school.');
        if($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".self::table('bus_trips')." WHERE bus_id=%d AND status='active'",$bus->id))) wp_send_json_error('Trip already active.');
        $result=$wpdb->insert(self::table('bus_trips'),['bus_id'=>$bus->id,'driver_user_id'=>$uid,'school_id'=>$bus->school_id,'trip_type'=>$tt]);
        if(!$result) wp_send_json_error('Failed to start trip. Please try again.');
        NAIS_Database::audit_log('trip_started','bus',$bus->id,$bus->school_id,'Driver started '.$tt.' trip');
        wp_send_json_success(['message'=>'Trip started.','trip_id'=>$wpdb->insert_id,'bus'=>$bus->bus_number]);
    }

    public static function ajax_end_trip() {
        check_ajax_referer('nais_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error('Not logged in.');
        global $wpdb; $uid=get_current_user_id(); $tid=absint($_POST['trip_id']??0);
        $trip=$wpdb->get_row($wpdb->prepare("SELECT t.*,b.bus_number,b.school_id FROM ".self::table('bus_trips')." t JOIN ".self::table('buses')." b ON t.bus_id=b.id WHERE t.id=%d AND t.driver_user_id=%d AND t.status='active'",$tid,$uid));
        if(!$trip) wp_send_json_error('No active trip found.');
        /* Transaction: update trip status + delete GPS data atomically */
        $wpdb->query('START TRANSACTION');
        $updated=$wpdb->update(self::table('bus_trips'),['status'=>'ended','ended_at'=>current_time('mysql')],['id'=>$tid]);
        $del=$wpdb->query($wpdb->prepare("DELETE FROM ".self::table('bus_locations')." WHERE trip_id=%d",$tid));
        if($updated===false){$wpdb->query('ROLLBACK');wp_send_json_error('Failed to end trip.');}
        $wpdb->query('COMMIT');
        NAIS_Database::audit_log('trip_ended','bus',$trip->bus_id,$trip->school_id,'Trip ended. '.$del.' GPS records deleted.');
        wp_send_json_success(['message'=>'Trip ended. All GPS data deleted.','deleted'=>$del]);
    }

    public static function ajax_ping_location() {
        check_ajax_referer('nais_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error('Not logged in.');
        global $wpdb; $uid=get_current_user_id(); $lat=floatval($_POST['latitude']??0); $lng=floatval($_POST['longitude']??0);
        /* Validate GPS coordinate ranges */
        if($lat<-90||$lat>90||$lng<-180||$lng>180||($lat==0&&$lng==0)) wp_send_json_error('Invalid coordinates.');
        $trip=$wpdb->get_row($wpdb->prepare("SELECT t.*,b.school_id FROM ".self::table('bus_trips')." t JOIN ".self::table('buses')." b ON t.bus_id=b.id WHERE t.driver_user_id=%d AND t.status='active'",$uid));
        if(!$trip) wp_send_json_error('No active trip.');
        if(get_option("nais_school_{$trip->school_id}_bus_tracking_disabled",false)) wp_send_json_error('Tracking disabled.');
        $result=$wpdb->insert(self::table('bus_locations'),['trip_id'=>$trip->id,'bus_id'=>$trip->bus_id,'latitude'=>$lat,'longitude'=>$lng,
            'speed_kmh'=>max(0,floatval($_POST['speed']??0)),'accuracy_meters'=>max(0,floatval($_POST['accuracy']??0))]);
        if(!$result) wp_send_json_error('Failed to store location.');
        wp_send_json_success(['stored'=>true]);
    }

    public static function ajax_get_my_bus() {
        check_ajax_referer('nais_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error('Not logged in.');
        global $wpdb; $uid=get_current_user_id();
        $bus=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table('buses')." WHERE driver_user_id=%d AND status='active'",$uid));
        $trip=$bus?$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table('bus_trips')." WHERE bus_id=%d AND status='active'",$bus->id)):null;
        wp_send_json_success(['bus'=>$bus,'active_trip'=>$trip]);
    }

    /* ═══ PARENT: VIEW BUS (MAX SECURITY) ═══ */
    public static function ajax_parent_get_bus_location() {
        check_ajax_referer('nais_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error('Not logged in.');
        global $wpdb; $uid=get_current_user_id(); $ip=self::get_ip();

        /* Rate limit — per user AND per IP combined */
        $views=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".self::table('bus_view_log')." WHERE parent_user_id=%d AND viewed_at>DATE_SUB(NOW(),INTERVAL 1 HOUR)",$uid));
        $ip_views=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".self::table('bus_view_log')." WHERE ip_address=%s AND viewed_at>DATE_SUB(NOW(),INTERVAL 1 HOUR)",$ip));
        if($views>=self::MAX_VIEWS_PER_HOUR||$ip_views>=self::MAX_VIEWS_PER_HOUR*2){NAIS_Database::audit_log('bus_rate_limited','parent',$uid,0,'Rate limited: user='.$views.'/hr ip='.$ip_views.'/hr');wp_send_json_error('Too many requests. Limit: '.self::MAX_VIEWS_PER_HOUR.'/hour.');}

        /* Find child's bus */
        $cb=$wpdb->get_row($wpdb->prepare("SELECT bs.bus_id,bs.student_id,b.bus_number,b.school_id,b.tracking_enabled,s.name AS student_name FROM ".self::table('bus_students')." bs JOIN ".self::table('buses')." b ON bs.bus_id=b.id JOIN ".NAIS_Database::table('students')." s ON bs.student_id=s.id JOIN ".NAIS_Database::table('parent_links')." pl ON pl.student_id=s.id WHERE pl.parent_user_id=%d AND pl.verified=1 AND b.status='active' LIMIT 1",$uid));
        if(!$cb) wp_send_json_error('No bus assigned to your child.');
        if(get_option("nais_school_{$cb->school_id}_bus_tracking_disabled",false)) wp_send_json_error('Tracking disabled by school.');
        if(!$cb->tracking_enabled) wp_send_json_error('Tracking disabled for this bus.');

        /* Log view permanently */
        $at=$wpdb->get_row($wpdb->prepare("SELECT id FROM ".self::table('bus_trips')." WHERE bus_id=%d AND status='active'",$cb->bus_id));
        $flagged=0;$fr='';
        if($views>=self::MAX_VIEWS_PER_HOUR-5){$flagged=1;$fr='High frequency: '.$views.' views/hr';}
        $known=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT ip_address FROM ".self::table('bus_view_log')." WHERE parent_user_id=%d ORDER BY viewed_at DESC LIMIT 10",$uid));
        if(!empty($known)&&!in_array($ip,$known)){$flagged=1;$fr='New IP: '.$ip;}
        $wpdb->insert(self::table('bus_view_log'),['bus_id'=>$cb->bus_id,'trip_id'=>$at?$at->id:null,'parent_user_id'=>$uid,'student_id'=>$cb->student_id,'ip_address'=>$ip,'user_agent'=>sanitize_text_field(substr($_SERVER['HTTP_USER_AGENT']??'',0,500)),'flagged'=>$flagged,'flag_reason'=>$fr]);
        if($flagged){$ui=get_userdata($uid);$uname=$ui?$ui->display_name:'User#'.$uid;NAIS_Database::audit_log('bus_suspicious_view','bus',$cb->bus_id,$cb->school_id,'SUSPICIOUS: '.$uname.' IP:'.$ip.' — '.$fr);}

        /* Get location */
        if(!$at) wp_send_json_success(['status'=>'no_trip','bus'=>$cb->bus_number,'student'=>$cb->student_name,'message'=>'Bus is not currently running.']);
        $loc=$wpdb->get_row($wpdb->prepare("SELECT latitude,longitude,speed_kmh,recorded_at FROM ".self::table('bus_locations')." WHERE trip_id=%d ORDER BY recorded_at DESC LIMIT 1",$at->id));
        if(!$loc) wp_send_json_success(['status'=>'waiting','bus'=>$cb->bus_number,'student'=>$cb->student_name,'message'=>'Waiting for GPS signal.']);
        wp_send_json_success(['status'=>'live','bus'=>$cb->bus_number,'student'=>$cb->student_name,'latitude'=>(float)$loc->latitude,'longitude'=>(float)$loc->longitude,'speed'=>(float)$loc->speed_kmh,'updated'=>$loc->recorded_at,'message'=>'Live tracking active.']);
    }

    /* ═══ REST API for app GPS ═══ */
    public static function register_rest_routes() {
        register_rest_route('nais/v1','bus/ping',['methods'=>'POST','callback'=>[__CLASS__,'rest_ping'],'permission_callback'=>function(){
            if(!is_user_logged_in()) return false;
            /* Only allow drivers (users assigned to a bus) to ping GPS */
            global $wpdb;
            $bus=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".self::table('buses')." WHERE driver_user_id=%d AND status='active'",get_current_user_id()));
            return $bus > 0;
        }]);
    }
    public static function rest_ping($req) {
        global $wpdb; $uid=get_current_user_id(); $lat=floatval($req->get_param('latitude')); $lng=floatval($req->get_param('longitude'));
        if($lat<-90||$lat>90||$lng<-180||$lng>180||($lat==0&&$lng==0)) return new WP_REST_Response(['error'=>'Invalid coords'],400);
        $trip=$wpdb->get_row($wpdb->prepare("SELECT t.*,b.school_id FROM ".self::table('bus_trips')." t JOIN ".self::table('buses')." b ON t.bus_id=b.id WHERE t.driver_user_id=%d AND t.status='active'",$uid));
        if(!$trip) return new WP_REST_Response(['error'=>'No active trip'],404);
        if(get_option("nais_school_{$trip->school_id}_bus_tracking_disabled",false)) return new WP_REST_Response(['error'=>'Disabled'],403);
        $wpdb->insert(self::table('bus_locations'),['trip_id'=>$trip->id,'bus_id'=>$trip->bus_id,'latitude'=>$lat,'longitude'=>$lng,'speed_kmh'=>floatval($req->get_param('speed')??0),'accuracy_meters'=>floatval($req->get_param('accuracy')??0)]);
        return new WP_REST_Response(['stored'=>true],200);
    }

    /* ═══ CLEANUP ═══ */
    public static function cleanup_stale_locations() {
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE loc FROM ".self::table('bus_locations')." loc JOIN ".self::table('bus_trips')." t ON loc.trip_id=t.id WHERE t.status!='active' AND t.ended_at < %s",current_time('mysql',true)));
        $wpdb->query($wpdb->prepare("DELETE FROM ".self::table('bus_locations')." WHERE recorded_at < %s",gmdate('Y-m-d H:i:s',strtotime('-4 hours',current_time('timestamp',true)))));
    }

    private static function get_ip() {
        if(!empty($_SERVER['HTTP_CF_CONNECTING_IP']) && !empty($_SERVER['HTTP_CF_RAY'])) return sanitize_text_field($_SERVER['HTTP_CF_CONNECTING_IP']);
        return sanitize_text_field($_SERVER['REMOTE_ADDR']??'0.0.0.0');
    }
}

/* Auto-init + create tables on first load */
add_action('init', [NAIS_Bus_Tracking::class, 'init']);
add_action('plugins_loaded', function() {
    if (get_option('nais_bus_tables_version', '0') !== '1.0') {
        NAIS_Bus_Tracking::create_tables();
        update_option('nais_bus_tables_version', '1.0');
    }
});