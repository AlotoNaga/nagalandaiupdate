<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * NAIS TIMETABLE — Weekly Grid + Exam Schedule
 * ═══════════════════════════════════════════════════════════════
 *
 * Admin sets weekly timetable (Mon–Sat, 8 periods) per class.
 * Admin also manages exam schedules (date, subject, time, venue).
 * Parents view both timetable and upcoming exam dates.
 *
 * DB Tables:
 *   nais_timetable      — class_id, day_number, period_number, subject
 *   nais_exam_schedule  — class_id, exam_name, subject, exam_date, start_time, end_time, venue
 */

if (!defined('ABSPATH')) exit;

class NAIS_Timetable {

    public static function init() {
        add_action('wp_ajax_nais_get_timetable',          [__CLASS__, 'ajax_get_timetable']);
        add_action('wp_ajax_nais_save_timetable',          [__CLASS__, 'ajax_save_timetable']);
        add_action('wp_ajax_nais_save_exam_schedule',      [__CLASS__, 'ajax_save_exam_schedule']);
        add_action('wp_ajax_nais_get_exam_schedule',       [__CLASS__, 'ajax_get_exam_schedule']);
        add_action('wp_ajax_nais_delete_exam_schedule',    [__CLASS__, 'ajax_delete_exam_schedule']);
    }

    private static $days = [
        1 => 'Monday',
        2 => 'Tuesday',
        3 => 'Wednesday',
        4 => 'Thursday',
        5 => 'Friday',
        6 => 'Saturday',
    ];

    private static $periods = 8;

    /** Get period count from option (consistent with class-teacher.php) */
    private static function get_periods() {
        return (int) get_option('nais_periods_per_day', self::$periods);
    }


    /**
     * ═══ ADMIN TAB: Timetable Management ═══
     */
    public static function render_timetable_tab($school_id, $classes) {
        ob_start();
        ?>
        <h3>Timetable</h3>

        <!-- Weekly Timetable -->
        <div style="margin-bottom:32px;">
            <h4>Weekly Class Timetable</h4>
            <p class="nais-hint">Set the weekly subject timetable for each class (Monday–Saturday, 8 periods).</p>
            <div class="nais-inline-form">
                <select id="nais-tt-class">
                    <option value="">Select Class</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="nais-btn nais-btn-sm" id="nais-tt-load">Load Timetable</button>
            </div>
            <div id="nais-tt-grid-container"></div>
        </div>

        <!-- Exam Schedule -->
        <div style="padding-top:24px;border-top:2px solid #e5e7eb;">
            <h4>Exam Schedule</h4>
            <p class="nais-hint">Add exam dates so parents can see the upcoming schedule.</p>

            <form id="nais-add-exam-schedule-form" class="nais-form" style="max-width:600px;margin-bottom:20px;">
                <div class="nais-form-row">
                    <label>Class *</label>
                    <select id="nais-es-class" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="nais-form-row">
                    <label>Exam Name *</label>
                    <input type="text" id="nais-es-name" placeholder="e.g. Unit Test 1, Half Yearly" required>
                </div>
                <div class="nais-form-row">
                    <label>Subject *</label>
                    <input type="text" id="nais-es-subject" placeholder="e.g. Mathematics" required>
                </div>
                <div class="nais-form-row" style="display:flex;gap:10px;">
                    <div style="flex:1;">
                        <label>Date *</label>
                        <input type="date" id="nais-es-date" required>
                    </div>
                    <div style="flex:1;">
                        <label>Start Time</label>
                        <input type="time" id="nais-es-start">
                    </div>
                    <div style="flex:1;">
                        <label>End Time</label>
                        <input type="time" id="nais-es-end">
                    </div>
                </div>
                <div class="nais-form-row">
                    <label>Venue</label>
                    <input type="text" id="nais-es-venue" placeholder="e.g. Exam Hall A">
                </div>
                <button type="submit" class="nais-btn">Add to Schedule</button>
                <div id="nais-es-result" style="margin-top:8px;"></div>
            </form>

            <h4>View Exam Schedule</h4>
            <div class="nais-inline-form">
                <select id="nais-es-list-class">
                    <option value="">Select Class</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c->id; ?>"><?php echo esc_html($c->class_name . ' ' . $c->section); ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="nais-btn nais-btn-sm" id="nais-es-load">Load Schedule</button>
            </div>
            <div id="nais-es-container"></div>
        </div>
        <?php
        return ob_get_clean();
    }


    /**
     * ═══ PARENT VIEW: Timetable + Exam Schedule ═══
     */
    public static function render_parent_timetable($student) {
        global $wpdb;

        /* Get weekly timetable */
        $timetable = $wpdb->get_results($wpdb->prepare(
            "SELECT day_number, period_number, subject FROM " . NAIS_Database::table('timetable') .
            " WHERE class_id = %d AND school_id = %d ORDER BY day_number ASC, period_number ASC",
            $student->class_id, $student->school_id
        ));

        $grid = [];
        foreach ($timetable as $t) {
            $grid[$t->day_number . '_' . $t->period_number] = $t->subject;
        }

        /* Get upcoming exam schedule */
        $exams = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('exam_schedule') .
            " WHERE class_id = %d AND exam_date >= %s ORDER BY exam_date ASC, start_time ASC",
            $student->class_id, current_time('Y-m-d')
        ));

        $days = self::$days;
        $periods = self::get_periods();

        ob_start();
        ?>
        <div class="nais-timetable-section" style="margin-top:24px;">
            <h4 style="font-size:13px;color:#9ca3af;text-transform:uppercase;margin-bottom:12px;">Weekly Timetable</h4>

            <?php if (empty($grid)): ?>
                <p style="color:#6b7280;font-size:14px;">Timetable not set yet.</p>
            <?php else: ?>
                <div class="nais-table-wrap">
                    <table class="nais-table nais-tt-table">
                        <thead>
                            <tr>
                                <th>Period</th>
                                <?php foreach ($days as $num => $name): ?>
                                    <th><?php echo substr($name, 0, 3); ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for ($p = 1; $p <= $periods; $p++): ?>
                                <tr>
                                    <td style="font-weight:700;color:#0a7558;">P<?php echo $p; ?></td>
                                    <?php foreach ($days as $num => $name):
                                        $key = $num . '_' . $p;
                                        $subj = $grid[$key] ?? '';
                                    ?>
                                        <td><?php echo esc_html($subj ?: '—'); ?></td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <?php if (!empty($exams)): ?>
                <h4 style="font-size:13px;color:#9ca3af;text-transform:uppercase;margin:20px 0 12px;">Upcoming Exams</h4>
                <div class="nais-exam-schedule-list">
                    <?php foreach ($exams as $e):
                        $date = wp_date('D, d M Y', strtotime($e->exam_date));
                        $time = '';
                        if ($e->start_time) {
                            $time = wp_date('g:i A', strtotime($e->start_time));
                            if ($e->end_time) $time .= ' – ' . wp_date('g:i A', strtotime($e->end_time));
                        }
                    ?>
                        <div class="nais-es-parent-item">
                            <div class="nais-es-parent-date">
                                <div class="nais-es-parent-day"><?php echo wp_date('d', strtotime($e->exam_date)); ?></div>
                                <div class="nais-es-parent-month"><?php echo wp_date('M', strtotime($e->exam_date)); ?></div>
                            </div>
                            <div class="nais-es-parent-info">
                                <strong><?php echo esc_html($e->subject); ?></strong>
                                <div style="font-size:12px;color:#6b7280;">
                                    <?php echo esc_html($e->exam_name); ?>
                                    <?php if ($time): ?> — <?php echo esc_html($time); ?><?php endif; ?>
                                    <?php if ($e->venue): ?> — <?php echo esc_html($e->venue); ?><?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }


    /* ═══════════════════════════════════════════
       AJAX HANDLERS
    ═══════════════════════════════════════════ */

    /** Get weekly timetable grid */
    public static function ajax_get_timetable() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $class_id  = absint($_POST['class_id'] ?? 0);

        if (!$class_id) wp_send_json_error('Select a class.');

        /* Verify class exists and belongs to this user's school */
        $class = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('classes') . " WHERE id = %d",
            $class_id
        ));
        if (!$class) wp_send_json_error('Class not found.');
        if ($school_id && (int)$class->school_id !== $school_id) wp_send_json_error('Access denied.');

        $effective_school_id = $school_id ?: (int)$class->school_id;

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT day_number, period_number, subject FROM " . NAIS_Database::table('timetable') .
            " WHERE class_id = %d AND school_id = %d ORDER BY day_number ASC, period_number ASC",
            $class_id, $effective_school_id
        ));

        $grid = [];
        foreach ($rows as $r) {
            $grid[$r->day_number . '_' . $r->period_number] = $r->subject;
        }

        wp_send_json_success([
            'grid'    => $grid,
            'days'    => self::$days,
            'periods' => self::get_periods(),
        ]);
    }

    /** Save weekly timetable */
    public static function ajax_save_timetable() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id  = NAIS_Roles::get_user_school_id();
        $class_id   = absint($_POST['class_id'] ?? 0);
        $timetable  = json_decode(stripslashes($_POST['timetable'] ?? ''), true);

        if (!$class_id) wp_send_json_error('Select a class.');

        /* Verify class exists and belongs to this user's school */
        $class = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('classes') . " WHERE id = %d",
            $class_id
        ));
        if (!$class) wp_send_json_error('Class not found.');
        if ($school_id && (int)$class->school_id !== $school_id) wp_send_json_error('Access denied.');

        $effective_school_id = $school_id ?: (int)$class->school_id;

        /* Validate timetable data before deleting existing rows */
        if (!is_array($timetable) || empty($timetable)) {
            wp_send_json_error('No timetable data provided.');
        }

        /* Use transaction: delete + insert atomically to prevent data loss */
        $wpdb->query('START TRANSACTION');

        $wpdb->delete(NAIS_Database::table('timetable'), ['class_id' => $class_id, 'school_id' => $effective_school_id], ['%d', '%d']);

        $count = 0;
        $max_periods = self::get_periods();
        foreach ($timetable as $key => $subject) {
            $parts = explode('_', $key);
            if (count($parts) !== 2) continue;
            $day    = absint($parts[0]);
            $period = absint($parts[1]);
            $subj   = sanitize_text_field(trim($subject));
            if (!$day || $day > 6 || !$period || $period > $max_periods || !$subj) continue;

            $inserted = $wpdb->insert(NAIS_Database::table('timetable'), [
                'school_id'     => $effective_school_id,
                'class_id'      => $class_id,
                'day_of_week'   => $day,
                'day_number'    => $day,
                'period_number' => $period,
                'subject'       => $subj,
            ]);
            if ($inserted) $count++;
        }

        if ($count > 0) {
            $wpdb->query('COMMIT');
        } else {
            $wpdb->query('ROLLBACK');
            wp_send_json_error('No valid timetable entries to save.');
        }

        NAIS_Database::audit_log('timetable_saved', 'class', $class_id, $school_id, $count . ' slots');
        wp_send_json_success(['message' => 'Timetable saved (' . $count . ' slots).']);
    }

    /** Save exam schedule entry */
    public static function ajax_save_exam_schedule() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $class_id  = absint($_POST['class_id'] ?? 0);
        $exam_name = sanitize_text_field($_POST['exam_name'] ?? '');
        $subject   = sanitize_text_field($_POST['subject'] ?? '');
        $exam_date = sanitize_text_field($_POST['exam_date'] ?? '');

        if (!$class_id || !$exam_name || !$subject || !$exam_date) wp_send_json_error('Exam name, subject, and date are required.');

        /* Validate date format (YYYY-MM-DD) */
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $exam_date) || !strtotime($exam_date)) {
            wp_send_json_error('Invalid date format. Use YYYY-MM-DD.');
        }

        /* Validate time formats if provided */
        $start_time = sanitize_text_field($_POST['start_time'] ?? '');
        $end_time   = sanitize_text_field($_POST['end_time'] ?? '');
        if ($start_time && !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $start_time)) {
            wp_send_json_error('Invalid start time format.');
        }
        if ($end_time && !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $end_time)) {
            wp_send_json_error('Invalid end time format.');
        }

        /* Verify class belongs to this school */
        $cls_ok = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . NAIS_Database::table('classes') . " WHERE id = %d AND school_id = %d",
            $class_id, $school_id
        ));
        if (!$cls_ok) wp_send_json_error('Class not found in your school.');

        $inserted = $wpdb->insert(NAIS_Database::table('exam_schedule'), [
            'school_id'  => $school_id,
            'class_id'   => $class_id,
            'exam_name'  => $exam_name,
            'subject'    => $subject,
            'exam_date'  => $exam_date,
            'start_time' => $start_time,
            'end_time'   => $end_time,
            'venue'      => sanitize_text_field($_POST['venue'] ?? ''),
        ]);

        if (!$inserted) {
            wp_send_json_error('Failed to save exam schedule. Please try again.');
        }

        NAIS_Database::audit_log('exam_schedule_added', 'class', $class_id, $school_id, $subject . ' on ' . $exam_date);
        wp_send_json_success(['message' => $subject . ' exam added for ' . $exam_date . '.']);
    }

    /** Get exam schedule */
    public static function ajax_get_exam_schedule() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id = NAIS_Roles::get_user_school_id();
        $class_id  = absint($_POST['class_id'] ?? 0);

        if (!$class_id) wp_send_json_error('Select a class.');

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . NAIS_Database::table('exam_schedule') .
            " WHERE school_id = %d AND class_id = %d ORDER BY exam_date ASC, start_time ASC",
            $school_id, $class_id
        ));

        $list = [];
        foreach ($rows as $r) {
            $list[] = [
                'id'         => (int)$r->id,
                'exam_name'  => $r->exam_name,
                'subject'    => $r->subject,
                'exam_date'  => $r->exam_date,
                'start_time' => $r->start_time,
                'end_time'   => $r->end_time,
                'venue'      => $r->venue,
            ];
        }

        wp_send_json_success(['schedule' => $list]);
    }

    /** Delete exam schedule entry */
    public static function ajax_delete_exam_schedule() {
        check_ajax_referer('nais_nonce', 'nonce');
        if (!current_user_can('nais_manage_school') && !current_user_can('nais_platform_admin')) wp_send_json_error('Permission denied.');

        global $wpdb;
        $school_id   = NAIS_Roles::get_user_school_id();
        $schedule_id = absint($_POST['schedule_id'] ?? 0);

        if (!$schedule_id) wp_send_json_error('Missing data.');

        $wpdb->delete(
            NAIS_Database::table('exam_schedule'),
            ['id' => $schedule_id, 'school_id' => $school_id],
            ['%d', '%d']
        );

        wp_send_json_success(['message' => 'Exam date removed.']);
    }
    /**
     * Create timetable and exam schedule tables.
     */
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        /* Weekly timetable — one row per class per day per period */
        dbDelta("CREATE TABLE " . NAIS_Database::table('timetable') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            school_id BIGINT UNSIGNED NOT NULL,
            class_id BIGINT UNSIGNED NOT NULL,
            day_number TINYINT UNSIGNED NOT NULL,
            period_number TINYINT UNSIGNED NOT NULL,
            subject VARCHAR(100) NOT NULL DEFAULT '',
            PRIMARY KEY (id),
            UNIQUE KEY class_day_period (class_id, day_number, period_number),
            KEY school_id (school_id),
            KEY class_id (class_id)
        ) {$charset};");

        /* Exam schedule — date/time/venue per exam per class */
        dbDelta("CREATE TABLE " . NAIS_Database::table('exam_schedule') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            school_id BIGINT UNSIGNED NOT NULL,
            class_id BIGINT UNSIGNED NOT NULL,
            exam_name VARCHAR(255) NOT NULL,
            subject VARCHAR(100) NOT NULL,
            exam_date DATE NOT NULL,
            start_time VARCHAR(10) NOT NULL DEFAULT '',
            end_time VARCHAR(10) NOT NULL DEFAULT '',
            venue VARCHAR(255) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY school_id (school_id),
            KEY class_id (class_id),
            KEY exam_date (exam_date)
        ) {$charset};");
    }
}

add_action('init', [NAIS_Timetable::class, 'init']);
add_action('plugins_loaded', function() {
    if (get_option('nais_timetable_tables_version', '0') !== '1.0') {
        NAIS_Timetable::create_tables();
        update_option('nais_timetable_tables_version', '1.0');
    }
});